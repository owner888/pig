<?php

declare(strict_types=1);

namespace Pig\CodingAgent\Session;

use Closure;
use Pig\Agent\Agent;
use Pig\Agent\AgentError;
use Pig\Agent\AgentEndEvent;
use Pig\Agent\AgentEvent;
use Pig\Agent\AgentLoop;
use Pig\Agent\AgentLoopTurnUpdate;
use Pig\Agent\AgentStartEvent;
use Pig\Agent\AgentState;
use Pig\Agent\AgentToolResult;
use Pig\Agent\MessageEndEvent;
use Pig\Agent\MessageStartEvent;
use Pig\Agent\MessageUpdateEvent;
use Pig\Agent\PrepareNextTurnContext;
use Pig\Agent\PrepareRequestContext;
use Pig\Agent\QueueMode;
use Pig\Agent\ThinkingLevel;
use Pig\Agent\TurnEndEvent;
use Pig\Agent\TurnStartEvent;
use Pig\Agent\ToolExecutionStartEvent;
use Pig\Agent\ToolExecutionUpdateEvent;
use Pig\Agent\ToolExecutionEndEvent;
use Pig\Ai\AssistantMessage;
use Pig\Ai\Context;
use Pig\Ai\ImageContent;
use Pig\Ai\Model;
use Pig\Ai\Models;
use Pig\Ai\Providers\OpenAiCodexResponses;
use Pig\Ai\SimpleStreamOptions;
use Pig\Ai\StopReason;
use Pig\Ai\Stream;
use Pig\Ai\SystemMessage;
use Pig\Ai\TextContent;
use Pig\Ai\Timestamp;
use Pig\Ai\Tool;
use Pig\Ai\ToolCall;
use Pig\Ai\ToolResultMessage;
use Pig\Ai\TranscriptContext;
use Pig\Ai\Usage;
use Pig\Ai\UserMessage;
use Pig\Ai\Utils\Overflow;
use Pig\Ai\Utils\Retry;
use Pig\Ai\Utils\Text;
use Pig\Ai\Utils\Transcript;
use Pig\Ai\Utils\Uuid;
use Pig\Async\AbortController;
use Pig\Async\AbortSignal;
use Pig\Async\Async;
use Pig\Async\Deferred;
use Pig\Async\Future;
use Pig\Async\Loop;
use Pig\CodingAgent\Auth;
use Pig\CodingAgent\Extensions\Events\AgentEndEvent as ExtensionAgentEnd;
use Pig\CodingAgent\Extensions\Events\AgentSettledEvent as ExtensionAgentSettled;
use Pig\CodingAgent\Extensions\Events\AgentStartEvent as ExtensionAgentStart;
use Pig\CodingAgent\Extensions\Events\CacheWarmingDecisionEvent;
use Pig\CodingAgent\Extensions\Events\MessageEndEvent as ExtensionMessageEnd;
use Pig\CodingAgent\Extensions\Events\MessageStartEvent as ExtensionMessageStart;
use Pig\CodingAgent\Extensions\Events\MessageUpdateEvent as ExtensionMessageUpdate;
use Pig\CodingAgent\Extensions\Events\SessionBeforeCompactEvent;
use Pig\CodingAgent\Extensions\Events\SessionBeforeForkEvent;
use Pig\CodingAgent\Extensions\Events\SessionBeforeSwitchEvent;
use Pig\CodingAgent\Extensions\Events\SessionShutdownEvent;
use Pig\CodingAgent\Extensions\Events\SessionStartEvent;
use Pig\CodingAgent\Extensions\Events\SessionBeforeTreeEvent;
use Pig\CodingAgent\Extensions\Events\SessionCompactEvent;
use Pig\CodingAgent\Extensions\Events\SessionCompactFailedEvent;
use Pig\CodingAgent\Extensions\Events\InputEvent;
use Pig\CodingAgent\Extensions\Events\UserBashEvent;
use Pig\CodingAgent\Extensions\Events\ToolExecutionStartEvent as ExtensionToolExecutionStart;
use Pig\CodingAgent\Extensions\Events\ToolExecutionUpdateEvent as ExtensionToolExecutionUpdate;
use Pig\CodingAgent\Extensions\Events\ToolExecutionEndEvent as ExtensionToolExecutionEnd;
use Pig\CodingAgent\Extensions\Events\SessionInfoChangedEvent;
use Pig\CodingAgent\Extensions\Events\SessionTreeEvent;
use Pig\CodingAgent\Extensions\Events\TreePreparation;
use Pig\CodingAgent\Extensions\Events\TurnEndEvent as ExtensionTurnEnd;
use Pig\CodingAgent\Extensions\Events\AfterProviderResponseEvent;
use Pig\CodingAgent\Extensions\Events\ProviderStreamEvent;
use Pig\CodingAgent\Extensions\Events\ModelSelectEvent;
use Pig\CodingAgent\Extensions\Events\ThinkingLevelSelectEvent;
use Pig\CodingAgent\Extensions\Events\TurnStartEvent as ExtensionTurnStart;
use Pig\CodingAgent\Extensions\Boundary\BoundaryContextPreview;
use Pig\CodingAgent\Extensions\Boundary\CompactionDraft;
use Pig\CodingAgent\Extensions\Boundary\ContextEditDraft;
use Pig\CodingAgent\Extensions\Boundary\CustomEntryDraft;
use Pig\CodingAgent\Extensions\Boundary\CustomMessageDraft;
use Pig\CodingAgent\Extensions\Boundary\SessionBoundaryDraft;
use Pig\CodingAgent\Extensions\Events\AgentBeforeSettleEvent;
use Pig\CodingAgent\ModelRoute;
use Pig\CodingAgent\ModelRouteRequest;
use Pig\CodingAgent\RoutedModel;
use Pig\CodingAgent\VirtualModelRegistry;
use Pig\CodingAgent\CodingAgent;
use Pig\CodingAgent\Extensions\ExtensionError;
use Pig\CodingAgent\Extensions\ExtensionRunner;
use Pig\CodingAgent\ModelChoice;
use Pig\CodingAgent\ModelResolver;
use Pig\CodingAgent\Prompt\FileCommand;
use Pig\CodingAgent\Prompt\Skill;
use Pig\CodingAgent\Prompt\Skills;
use Pig\CodingAgent\Prompt\SlashCommands;
use Pig\CodingAgent\Prompt\SystemPrompt;
use Pig\CodingAgent\Prompt\SystemPromptOptions;
use Pig\CodingAgent\Theme\Themes;
use Pig\CodingAgent\ProviderAttribution;
use Pig\CodingAgent\Settings;
use Pig\CodingAgent\Tools\ToolLoadout;
use Pig\CodingAgent\Utils\ImageProcess;
use Pig\Agent\AgentTool;
use Pig\Agent\ToolArguments;
use Pig\CodingAgent\Tools\Run;
use Pig\CodingAgent\Tools\Truncate;
use Throwable;

/**
 * A conversation with a UI attached to it.
 *
 * `Agent` runs the conversation; this sits between it and the interactive mode, holding
 * what the UI needs and nothing the UI does not: the events, the messages waiting to be
 * sent, the thinking level, and what the session has cost. The UI never touches the
 * agent directly, so there is one place that knows how a keystroke becomes a prompt.
 *
 * Ported from upstream's `agent-session.ts`, which is 1901 lines. Most of that is
 * persistence, compaction, auto-retry, branching, hooks, custom tools, HTML export and
 * the model registry — every one of which needs a subsystem that is not ported yet, and
 * each of which can arrive on its own when it is. What is here is what makes a session
 * a session.
 *
 * **Upstream does not compile at the anchor commit.** `d0a4c37` split the agent's one
 * queue into `steer()` and `followUp()` and did not update this file, which still calls
 * `agent.queueMessage()`, `clearMessageQueue()` and `getQueueMode()` — none of which
 * exist any more. So there is no literal thing to port here, and this is written against
 * the split API that `Pig\Agent\Agent` actually has. See docs/dev/upstream.md.
 */
final class AgentSession
{
    /** @var array<int, Closure(AgentEvent): void> */
    private array $listeners = [];

    private int $nextListenerId = 0;

    /** @var list<string> steering messages, in the order they were typed */
    private array $steering = [];

    /** @var list<string> follow-ups, likewise */
    private array $followUps = [];

    private ?Closure $unsubscribeAgent = null;

    /** Upstream's `_cacheWarmer`; null until a mode with a next request turns it on. */
    private ?CacheWarmer $cacheWarmer = null;

    /** Whether a session names itself (`SessionTitle`): off until a mode with a person in it turns it on. */
    private bool $autoSessionName = false;

    /** @var array<string, true> sessions a name has been asked for, so a failure is not asked again each prompt */
    private array $titleAsked = [];

    /** @var array<string, true> `prompt()`'s request ids taken, or being taken, by this process */
    private array $requests = [];

    /** What the running tool has printed, beside the session file, for `continueRun()`. */
    private readonly ToolProgress $toolProgress;

    /** The provider call under the agent's stream function, which a cache refresh replays. */
    private ?Closure $innerStream = null;

    private ?AbortController $bash = null;

    /** @var list<BashExecution> run while the agent was working, waiting for it to stop */
    private array $pendingBash = [];

    /** How many turns this run has had, for the turn events. */
    private int $turnIndex = 0;

    /** Which retry we are on, or 0 when nothing is being retried. */
    private int $attempt = 0;

    /** Set while a retry is sleeping, so escape can call it off. */
    private ?AbortController $retrying = null;

    /**
     * The `fallbackModels` already moved on to during this prompt, as `provider/id`, so a list
     * that loops — or two entries that resolve to one model — cannot send the same turn to the
     * same wall twice. Cleared with the prompt.
     *
     * @var array<string, true>
     */
    private array $fallbacksTried = [];

    /**
     * A prompt is in progress, from the top of `startRun()` — `before_agent_start` included — to its
     * `agent_settled`: the runs, and the retry sleeps, summaries and queued messages between them.
     * Upstream's `_isAgentRunActive`, and what `isStreaming()` answers.
     */
    private bool $runActive = false;

    /**
     * Set while a run is being prepared (`prepareRun()`): busy, with no run in the agent yet.
     * A prompt sent then without `streamingBehavior` is refused, as upstream's is, rather than
     * waited out — the run it would wait for is the one waiting on its handler.
     */
    private bool $startingRun = false;

    /**
     * @var list<CustomMessage> custom messages sent while a run was in progress without
     *      `triggerTurn`, appended at the end of the turn — upstream's `_pendingCustomMessages`
     */
    private array $pendingHookMessages = [];

    /** @var list<CustomMessage> custom messages sent with `deliverAs: 'nextTurn'` — upstream's `_pendingNextTurnMessages` */
    private array $pendingNextTurnMessages = [];

    /** Escape reached the prompt in progress, so its post-run loop stops. Upstream's `_agentRunAbortRequested`. */
    private bool $runAbortRequested = false;

    /** @var 'completed'|'aborted'|'error' how the last turn ended, for `agent_before_settle` */
    private string $lastOutcome = 'completed';

    /** Set while the hooks hear `agent_settled`. Upstream's `_isEmittingAgentSettled`. */
    private bool $emittingSettled = false;

    /** @var list<Closure(): void> prompts asked for during `agent_settled`, run after it. Upstream's `_deferredSettledActions`. */
    private array $deferredSettledActions = [];

    /** Completed when the session is next idle, for whoever waits on that. Upstream's `_idleWaitPromise`. */
    private ?Deferred $idle = null;

    /**
     * Set while a summariser is running, so escape can call it off.
     *
     * Both compactions, the one somebody typed and the one an overflow started, because there is
     * one `compact()` here where upstream has two paths and two controllers. A caller may pass a
     * signal of its own as well; `compact()` forwards it into this one, so what goes downstream is
     * a single signal that either end can raise.
     */
    private ?AbortController $compacting = null;

    /**
     * What the `before_agent_start` handlers made of the prompt for the run in progress —
     * upstream's `_runSystemPromptOptions`: "Prompt options after before_agent_start mutations for
     * the active run." Their sections are diffed with the loadout's before every request of the run;
     * a forced prompt is projected onto the request and never recorded. Null between runs.
     */
    private ?SystemPromptOptions $runSystemPromptOptions = null;

    /**
     * Upstream's `_failedResponse`: the response a retry is sending again, for the virtual
     * model's router (`reason: retry`, with the failed request). Set when the retry is decided,
     * taken by the next request's routing, and cleared with the prompt.
     */
    private ?AssistantMessage $failedResponse = null;

    /**
     * Prompts kept as files, so `/review foo.php` is the prompt in `review.md` with `$1` filled in.
     *
     * Here rather than only in the terminal, which is where they used to live: a stored prompt
     * that only expands in front of a person is a stored prompt `pig -p "/review foo.php"` sends
     * to the model as the six characters `/review`. See `prompt()`.
     *
     * @var list<FileCommand>
     */
    private array $fileCommands;

    /**
     * What `--models` narrowed this session to, or empty for the whole registry.
     *
     * Upstream's `scopedModels`. Each entry carries a thinking level, because
     * `--models sonnet:high,haiku:low` says one per model — which is the reason cycling lives
     * here rather than in each mode: a caller that had to remember to apply the level is a
     * caller that will forget in one of the two places.
     *
     * @var list<ModelChoice>
     */
    private array $modelScope;

    /**
     * Upstream's `_overflowRecoveryAttempted`: one compact-and-retry per overflow. Set when the
     * retry is made, cleared by the next message somebody says and by an answer that did not fail.
     */
    private bool $overflowRecoveryAttempted = false;

    /** The overflow `promptTooLarge()` was last said for, so a prompt sent after it does not say it twice. */
    private ?AssistantMessage $promptTooLargeSaidFor = null;

    /** The id of this session while nothing writes it down — upstream's in-memory `SessionManager`'s. */
    private string $memoryId;

    /** When that in-memory session began, for its header. */
    private int $memoryCreatedAt;

    /** Whether this is a private session (`goIncognito()`). */
    private bool $incognito = false;

    /** The private session's own temporary directory, removed with it; null until it is private. */
    private ?string $scratch = null;

    /**
     * @param list<FileCommand> $fileCommands
     * @param list<ModelChoice> $modelScope
     */
    public function __construct(
        public readonly Agent $agent,
        private readonly string $cwd = '.',
        private ?SessionManager $store = null,
        private readonly ?Settings $settings = null,
        private ?ExtensionRunner $extensionRunner = null,
        array $fileCommands = [],
        array $modelScope = [],
        public readonly ?Auth $auth = null,
        private ?ToolLoadout $loadout = null,
        private bool $projectTrusted = true,
        // Upstream's `SessionManager.inMemory(cwd, { id })`: the id of a session that is not written
        // down (`--no-session --session-id`). Ignored while there is a store, whose id is the file's.
        ?string $sessionId = null,
        // Upstream's `usesDefaultTools`: "Whether the initial tools come from the `defaultTools`
        // setting. When true, a resumed session replaces them with the loadout its transcript
        // records, with `defaultToolModifiers` applied." False when `--tools` named the tools or
        // `--no-tools` / `--no-builtin-tools` cleared them. Upstream's option defaults to false and
        // `createAgentSession()` works it out; true here, since every session built without
        // `CodingAgent` — the tests' — starts from the defaults.
        private readonly bool $usesDefaultTools = true,
        // Upstream's `defaultToolModifiers`: the `--tools +name`/`-name` entries.
        /** @var list<string> */
        private readonly array $defaultToolModifiers = [],
        // pig's `--incognito`: start private (`goIncognito()`). Implies there is no store.
        bool $incognito = false,
    ) {
        $this->fileCommands = $fileCommands;
        $this->modelScope = $modelScope;
        $this->unsubscribeAgent = $this->agent->subscribe($this->onAgentEvent(...));
        $this->toolProgress = new ToolProgress(fn (): ?string => $this->store?->path);

        if ($sessionId !== null) {
            SessionManager::assertValidSessionId($sessionId);
        }

        $this->memoryId = $sessionId ?? SessionManager::createSessionId();
        $this->memoryCreatedAt = Timestamp::nowMs();
        // Upstream's agent carries the session manager's id as its `sessionId` — the in-memory
        // manager's too.
        $this->agent->sessionId = $this->sessionId();

        if ($incognito) {
            $this->goIncognito();
        }

        // Upstream's `createAgentSession()` builds the agent with the extension provider hooks as
        // its `onPayload` / `onResponse` / `onProviderStreamEvent`, `maxRetryDelayMs` from the
        // provider retry settings, and a `streamFn` that adds the request options
        // (`buildRequestOptions()`). pig's agent is built before the session, so the session puts
        // them on it here. Each reads `$this->extensionRunner` when it runs, so a `/reload` that swaps the
        // runner is picked up.
        $this->agent->onPayload = fn (mixed $payload, Model $model): mixed => $this->extensionRunner?->hasHandlers('before_provider_request') === true
            ? $this->extensionRunner->emitBeforeProviderRequest($payload)
            : $payload;
        $this->agent->onResponse = function (array $response, Model $model): void {
            if ($this->extensionRunner?->hasHandlers('after_provider_response') === true) {
                $this->extensionRunner->emit(new AfterProviderResponseEvent($response['status'], $response['headers']));
            }
        };
        $this->agent->onProviderStreamEvent = function (mixed $data, Model $model): void {
            if ($this->extensionRunner?->hasHandlers('provider_stream_event') === true) {
                $this->extensionRunner->emit(new ProviderStreamEvent($model->provider, $model->api->value, $model->id, $data));
            }
        };
        $this->agent->maxRetryDelayMs = $this->settings?->providerRetrySettings()['maxRetryDelayMs'] ?? 60_000;

        // Upstream's `convertToLlmWithBlockImages`, "defense-in-depth": with `images.blockImages` on,
        // every picture in a user message or a tool result becomes the line "Image reading is
        // disabled." on the way to the provider — a run of them one line — and the conversation
        // keeps them. The setting is read on every request, so turning it on mid-session counts.
        $convert = $this->agent->convertToLlm;
        $this->agent->convertToLlm = fn (array $messages): array => $this->settings?->blockImages() === true
            ? self::withoutImages($convert($messages))
            : $convert($messages);

        // Upstream's `_buildRuntime()` hands `read` its `autoResizeImages` and `bash` its
        // `commandPrefix`, and `_afterToolCall()` fits every tool's pictures after the `tool_result`
        // hooks have had them. Both are asked whenever the loadout is applied.
        $this->loadout?->useToolOptions(fn (): array => [
            'read' => [
                'autoResizeImages' => $this->settings?->imageAutoResize() ?? true,
                'resizeOptions' => fn (): ?array => $this->limitsModel()?->inputLimits['images']['resize'] ?? null,
            ],
            'bash' => [
                'commandPrefix' => $this->settings?->shellCommandPrefix(),
                'sessionEnvironment' => $this->sessionEnvironment(...),
            ],
            // Upstream's `createAllToolDefinitions()` gives `powershell` no `commandPrefix`.
            'powershell' => ['sessionEnvironment' => $this->sessionEnvironment(...)],
        ]);
        $this->loadout?->useResultImages(fn (array $content): array => ImageProcess::normalizeToolResult(
            $content,
            $this->settings?->imageAutoResize() ?? true,
            $this->limitsModel()?->inputLimits['images']['resize'] ?? null,
        ));
        $inner = $this->agent->streamFunction;
        $this->innerStream = $inner;
        $this->agent->streamFunction = function (Model $model, TranscriptContext $context, ?SimpleStreamOptions $options) use ($inner): mixed {
            $requestOptions = $this->buildRequestOptions($model, $options ?? new SimpleStreamOptions());

            // Compaction and summaries use their own routing ids; only session requests replace
            // the cache entry, so warming restarts from them — upstream's rule, on the options as
            // the agent sent them.
            if ($this->cacheWarmer !== null && $this->store !== null && $options?->sessionId === $this->store->id) {
                $this->cacheWarmer->start($model, $context, $requestOptions, $this->cacheContextIsCurrent($model));
            }

            return $inner !== null ? $inner($model, $context, $requestOptions) : Stream::simple($model, $context, $requestOptions);
        };

        // Upstream's `_installAgentNextTurnRefresh()`: before each turn after the first, the prompt
        // sections the loadout wants now are diffed against the ones the transcript has, and a
        // change goes in as a system message before the next request — the prompt follows a tool
        // that `tool_search` loaded mid-run, or a `setActiveTools()`, without waiting for the next
        // prompt. The tool declarations themselves are the loop's (`declareToolChanges()`). A
        // previous hook on the agent is asked first, as upstream chains it.
        $previousPrepareNextTurn = $this->agent->prepareNextTurnWithContext;
        $previousPrepareNextTurnWithoutContext = $this->agent->prepareNextTurn;
        $this->agent->prepareNextTurnWithContext = function (PrepareNextTurnContext $turn, ?AbortSignal $signal) use ($previousPrepareNextTurn, $previousPrepareNextTurnWithoutContext): ?AgentLoopTurnUpdate {
            $previous = $previousPrepareNextTurn !== null
                ? $previousPrepareNextTurn($turn, $signal)
                : ($previousPrepareNextTurnWithoutContext !== null ? $previousPrepareNextTurnWithoutContext($signal) : null);
            $context = $previous?->context ?? $turn->context;
            $update = $this->preparePromptUpdate($context->messages, $this->runSystemPromptOptions);

            if ($update === null) {
                return $previous;
            }

            return new AgentLoopTurnUpdate(
                $previous?->context,
                [...($previous?->messages ?? []), $update],
                $previous?->model,
                $previous?->thinkingLevel,
            );
        };

        // Upstream's `_installAgentForcedPromptProjection()`: "Send a forced prompt as the provider's
        // leading system prompt without recording it. A `before_agent_start` handler that returns
        // `systemPrompt` needs that exact text at the head of the request; a mid-conversation system
        // message would leave the original prompt in place. The forced text is a rendering of the
        // current prompt, so the transcript keeps its structured sections and the request is
        // projected instead: the system messages collapse into one head holding the forced text and
        // the current tools. Runs after the `context` extension handlers."
        $previousTransformContext = $this->agent->transformContext;
        $this->agent->transformContext = function (array $messages, ?AbortSignal $signal = null) use ($previousTransformContext): array {
            $transformed = $previousTransformContext !== null ? $previousTransformContext($messages, $signal) : $messages;
            $forced = $this->runSystemPromptOptions?->forceSystemPrompt;

            if ($forced === null) {
                return $transformed;
            }

            $current = Transcript::getCurrentSystemMessage($transformed);
            $head = new SystemMessage($forced, null, $current?->toolsAdded, null, $current?->timestamp ?? Timestamp::nowMs());

            return [$head, ...array_values(array_filter($transformed, static fn (mixed $message): bool => !$message instanceof SystemMessage))];
        };

        // Upstream's `_installAgentRequestProjection()`, the routing half: before every request,
        // a virtual selection is routed to the physical model and thinking level the request goes
        // out with. The selection stays in the agent's state; only the request uses the routed
        // model, so each request routes again. A previous hook on the agent is asked first.
        $previousPrepareRequest = $this->agent->prepareRequest;
        $this->agent->prepareRequest = function (PrepareRequestContext $request, ?AbortSignal $signal) use ($previousPrepareRequest): ?AgentLoopTurnUpdate {
            $failed = $this->failedResponse;
            $this->failedResponse = null;
            $previous = $previousPrepareRequest !== null
                ? $previousPrepareRequest(new PrepareRequestContext($request->context, $this->agent->state->model ?? $request->model, $this->agent->state->thinkingLevel), $signal)
                : null;
            $context = $previous?->context ?? $request->context;
            $model = $previous?->model ?? $this->agent->state->model ?? $request->model;
            $thinkingLevel = $previous?->thinkingLevel ?? $this->agent->state->thinkingLevel;

            if (!Models::isVirtual($model)) {
                return $previous;
            }

            $route = $this->route($model, $thinkingLevel, $context->messages, $failed, $signal);

            return new AgentLoopTurnUpdate($previous?->context, null, $route->model, $route->thinkingLevel);
        };

        // What was chosen last time, applied here rather than by whoever built the agent: this
        // is the class that holds both the agent and the settings, and `setSteeringMode()` /
        // `setFollowUpMode()` write the setting through the same pair — upstream's
        // `syncQueueModesFromSettings()`. A caller passing them into `AgentOptions` instead would
        // mean two routes for one fact, and the one route every mode and every test already goes
        // through is this constructor.
        if ($settings !== null) {
            $this->agent->setSteeringMode($settings->steeringMode());
            $this->agent->setFollowUpMode($settings->followUpMode());
        }

        // `ExtensionRunner::setSession()` existed and nothing called it, so `$ctx->session` was null
        // in every handler — a `ExtensionContext` field documented and wired at one end only. The
        // session is the thing that holds the runner, so it is the thing that tells the runner,
        // through `setExtensionRunner()`, which a later `/reload` goes through too.
        $this->setExtensionRunner($this->extensionRunner);
    }

    /** The hooks this session fires at, if any. */
    public function extensionRunner(): ?ExtensionRunner
    {
        return $this->extensionRunner;
    }

    public function setExtensionRunner(?ExtensionRunner $extensionRunner): void
    {
        $this->extensionRunner = $extensionRunner;
        $extensionRunner?->setSession($this);
    }

    /** @return list<FileCommand> the prompt templates `/name` expands — upstream's `promptTemplates` */
    public function fileCommands(): array
    {
        return $this->fileCommands;
    }

    /** @param list<FileCommand> $fileCommands */
    public function setFileCommands(array $fileCommands): void
    {
        $this->fileCommands = $fileCommands;
    }

    /**
     * Upstream's `extendResourcesFromExtensions()`: after `session_start`, the directories the
     * extensions add through `resources_discover` are loaded — skills onto the loadout, and so
     * into the system prompt; prompt templates beside the file commands; theme directories into
     * `Themes`. Null when nobody listened or nobody added anything, so a caller can leave its
     * own lists alone. A skill that could not be read is reported against the extension that
     * named its directory.
     *
     * @param 'startup'|'reload' $reason
     */
    public function discoverResources(string $reason): ?ExtensionResources
    {
        if ($this->extensionRunner === null || !$this->extensionRunner->listensTo('resources_discover')) {
            return null;
        }

        $found = $this->extensionRunner->emitResourcesDiscover($this->cwd, $reason);

        if ($found->isEmpty()) {
            return null;
        }

        $paths = static fn (array $entries): array => array_values(array_unique(array_column($entries, 'path')));

        [$skills, $warnings] = Skills::fromDirectories($paths($found->skillPaths));

        foreach ($warnings as $warning) {
            $extensionPath = '';

            foreach ($found->skillPaths as $entry) {
                if (str_starts_with($warning->path, rtrim($entry['path'], '/') . '/')) {
                    $extensionPath = $entry['extensionPath'];
                }
            }

            $this->extensionRunner->emitError(new ExtensionError($extensionPath, 'resources_discover', "skill {$warning->path}: {$warning->message}"));
        }

        $commands = SlashCommands::fromDirectories($paths($found->promptPaths));
        Themes::setExtensionThemeDirs($paths($found->themePaths));

        $this->fileCommands = [
            ...array_values(array_filter($this->fileCommands, static fn (FileCommand $c): bool => !str_starts_with($c->source, '(extension'))),
            ...$commands,
        ];
        $this->loadout?->addSkills($skills);

        return new ExtensionResources($skills, $commands);
    }

    /** Where this session is being written, if it is. */
    public function store(): ?SessionManager
    {
        return $this->store;
    }

    /** The command to resume this session, if it was persisted to disk. */
    public function resumeCommand(): ?string
    {
        return $this->store?->resumeCommand();
    }

    /**
     * Whether this is a private session — pig's own, Chrome's incognito window: nothing about it is
     * left on this machine once it ends. No session file, no tool output kept past the session
     * (`scratchDirectory()`), and the modes leave the logs and the crash records alone for it.
     * What is sent to the provider is sent all the same: private is about this machine.
     */
    public function isIncognito(): bool
    {
        return $this->incognito;
    }

    /**
     * Stop writing anything down from here on — `--incognito` at the start, `/incognito` part way.
     *
     * The conversation carries on as it was, in memory, under the **same id**: the provider's
     * prompt cache is keyed by it, and a turn after this should not pay for the whole context
     * again. The file that was being written is the caller's to remove (`/incognito` moves it to the
     * trash); this only lets go of it, so nothing writes it back. Once private, a session stays
     * private: `/new` starts another conversation in memory, and `/resume` reads a file without
     * writing to it, as both already do for a session with no store.
     *
     * @throws AgentError when the private temporary directory cannot be made — refused rather than
     *         carried on with tool output going where it would be kept
     */
    public function goIncognito(): void
    {
        if ($this->incognito) {
            return;
        }

        $directory = sys_get_temp_dir() . '/pig-incognito-' . bin2hex(random_bytes(8));
        set_error_handler(static fn (): bool => true);

        try {
            $made = mkdir($directory, 0o700);
        } finally {
            restore_error_handler();
        }

        if (!$made) {
            throw new AgentError("Could not create a private temporary directory in " . sys_get_temp_dir());
        }

        $this->scratch = $directory;
        $this->incognito = true;
        // Whatever way this process ends — `/quit`, Ctrl+C, a crash the handler catches — not only
        // through `dispose()`.
        register_shutdown_function($this->removeScratch(...));
        self::exitCleanlyOnSignals();

        if ($this->store !== null) {
            $this->memoryId = $this->store->id;
            $this->memoryCreatedAt = $this->store->createdAt();
            $this->writeTo(null);
        }
    }

    /**
     * Where a private session's temporary files go — a command's full output when it is too long
     * to show (`Run`), and what an extension saves for the session (`ExtensionApi::artifactsDirectory()`).
     * Removed, with everything in it, when the session is disposed or the process ends. Null for a
     * session that is not private, whose files go where they always went.
     */
    public function scratchDirectory(): ?string
    {
        return $this->scratch;
    }

    /**
     * A signal that would end the process — `kill`, a closed terminal, Ctrl+C in `-p` — ends it
     * through `exit()` instead, which runs the shutdown functions and so removes the private
     * directory; killed outright, PHP runs none. Only where nothing else handles the signal: the web
     * and MCP modes' own handlers, and the terminal's, are left as they are.
     */
    private static function exitCleanlyOnSignals(): void
    {
        if (!function_exists('pcntl_signal')) {
            return;
        }

        pcntl_async_signals(true);

        foreach ([SIGTERM, SIGHUP, SIGINT] as $signal) {
            if (pcntl_signal_get_handler($signal) === SIG_DFL) {
                pcntl_signal($signal, static function (int $received): never {
                    exit(128 + $received);
                });
            }
        }
    }

    /** Remove the private temporary directory and everything in it. Safe to call twice. */
    private function removeScratch(): void
    {
        if ($this->scratch === null || !is_dir($this->scratch)) {
            return;
        }

        set_error_handler(static fn (): bool => true);

        try {
            $items = new \RecursiveIteratorIterator(
                new \RecursiveDirectoryIterator($this->scratch, \FilesystemIterator::SKIP_DOTS),
                \RecursiveIteratorIterator::CHILD_FIRST,
            );

            foreach ($items as $item) {
                /** @var \SplFileInfo $item */
                $item->isDir() && !$item->isLink() ? rmdir($item->getPathname()) : unlink($item->getPathname());
            }

            rmdir($this->scratch);
        } catch (Throwable) {
            // Gone already, or not ours to remove: there is nobody left to tell at shutdown.
        } finally {
            restore_error_handler();
        }
    }

    /** The project directory, so a mode holding a session need not be handed it twice. */
    public function cwd(): string
    {
        return $this->cwd;
    }

    /** The settings this session reads, for an extension that has a key of its own in them — upstream's `pi.getSettings()`. */
    public function settings(): ?Settings
    {
        return $this->settings;
    }

    /**
     * Write somewhere else from now on.
     *
     * Not a setter for its own sake: this was `readonly`, and that was a data-losing bug.
     * `/resume` opened another session, put its messages into the agent, and then carried
     * on appending to the file pig had created at startup — so that file ended up holding
     * its own opening plus the continuation of a different conversation, and the resumed
     * one stopped growing at the moment it was resumed. `/new` did the same thing in one
     * file: the fresh conversation was appended as a continuation of the old one, and the
     * new session never existed as a session at all.
     *
     * Upstream's `AgentSession` owns its `sessionManager` and replaces it in
     * `switchSession()` and `newSession()`, so this is a missing piece of the port rather
     * than an addition. Null for a session that is not being written down.
     *
     * The conversation is not touched: a caller switching files decides separately what
     * the agent should be holding, because `/new` wants nothing and `/resume` wants
     * whatever was in the file.
     */
    public function writeTo(?SessionManager $store): void
    {
        // The entry being warmed belongs to the conversation being left, and so does its Codex
        // connection — upstream disposes the session it replaces.
        $this->cacheWarmer?->cancel();
        $this->closeSessionResources();
        $this->store = $store;
        $this->agent->sessionId = $this->sessionId();
        $this->extensionRunner?->setStore($store);
    }

    /**
     * Upstream's `sessionManager.getSessionId()`: the file's id, or — for a session that is not being
     * written down — the id its in-memory manager was made with. Never null, as upstream's is not:
     * `get_state.sessionId`, `PIG_SESSION_ID` and the JSON header all name it.
     */
    public function sessionId(): string
    {
        return $this->store?->id ?? $this->memoryId;
    }

    /**
     * Upstream's `sessionManager.getHeader()`: the file's header, or the one an in-memory session
     * keeps (`SessionManager::inMemoryHeader()`).
     *
     * @return array<string, mixed>
     */
    public function sessionHeader(): array
    {
        return $this->store?->header() ?? SessionManager::inMemoryHeader($this->memoryId, $this->memoryCreatedAt, $this->cwd);
    }

    /**
     * Pick a saved session up where it was left.
     *
     * The messages go straight into the agent: they are the conversation, and the model
     * is handed them on the next turn exactly as if they had just happened.
     *
     * @param list<mixed> $messages
     */
    public function restore(array $messages): void
    {
        $this->agent->replaceMessages($messages);

        // Upstream restores the recorded loadout when a session opens — its constructor, which a
        // switched or forked session goes through too — only when the tools came from the defaults,
        // and applies `--tools +name`/`-name` on top (#10785).
        if ($this->usesDefaultTools) {
            $this->restoreToolsFromTranscript($this->defaultToolModifiers);
        }
    }

    /**
     * Restore the active tool loadout declared by the session transcript, if it declares one —
     * upstream's `_restoreToolsFromTranscript()`, which it runs when a session opens and after tree
     * navigation (both reach `restore()` here). "Tools reachable only from other tools are never
     * declared, but they do not depend on the active set, so the transcript's declarations are the
     * whole loadout." The declared tools that are not registered yet — an MCP server still
     * connecting, a tool `tool_search` had loaded — are pending until they are.
     *
     * @param list<string> $modifiers `+name`/`-name` entries applied to the restored loadout
     */
    private function restoreToolsFromTranscript(array $modifiers = []): void
    {
        if ($this->loadout === null) {
            return;
        }

        $this->loadout->clearPending();
        // "All system messages on the branch, including those before a compaction. Compaction
        // snapshots are derived from these, so replaying them gives the current loadout."
        $systemMessages = array_values(array_filter(
            $this->store !== null
                ? array_map(static fn (SessionEntry $entry): mixed => $entry->message, $this->store->branchEntries())
                : $this->agent->state->messages,
            static fn (mixed $message): bool => $message instanceof SystemMessage,
        ));

        // "No recorded loadout: keep the current tools."
        if ($systemMessages === []) {
            return;
        }

        // "Tools the branch ever added or removed. Removed tools stay inactive."
        $mentioned = [];

        foreach ($systemMessages as $message) {
            foreach ([...($message->toolsAdded ?? []), ...($message->toolsRemoved ?? [])] as $tool) {
                $mentioned[$tool->name] = true;
            }
        }

        // "Extension tools the branch never mentioned were registered after it recorded its
        // loadout, so they are activated like newly registered tools. Built-in tools follow
        // `defaultTools` instead." (#11062)
        $newTools = array_values(array_filter(
            $this->loadout->customToolNames(),
            fn (string $name): bool => !isset($mentioned[$name]) && $this->loadout->isActivatedOnRegistration($name),
        ));

        // "The recorded loadout plus the new tools, with `--tools +name`/`-name` applied."
        $this->loadout->restore(Settings::applyToolModifiers(
            [...array_map(static fn (Tool $tool): string => $tool->name, Transcript::getCurrentTools($systemMessages)), ...$newTools],
            $modifiers,
        ));
    }

    /**
     * Whether $name is a tool the restored loadout declared that has not been registered yet. An
     * extension that holds a tool back until something asks for it — the MCP extension's
     * `deferred` tools — registers it when the session is waiting for it, which is what upstream's
     * registry of inactive deferred tools does by itself.
     */
    public function isToolPending(string $name): bool
    {
        return $this->loadout?->isPending($name) ?? false;
    }

    /**
     * Come back to the model and thinking level this conversation was being had with.
     *
     * Called when a session is resumed, after `restore()`. Silent about anything it cannot
     * honour: a session recorded on a model this machine has no key for, or a thinking level
     * this pig has no name for, is not a reason to refuse to open the conversation — and the
     * model it falls back to is said on the footer where anybody can see it.
     *
     * A model named on the command line wins, which is why this takes a flag rather than
     * deciding for itself: `--model sonnet` is someone saying what they want *now*, and the
     * file is saying what was true last time.
     */
    public function restoreSettings(bool $modelWasAskedFor = false): void
    {
        $recorded = $this->store?->settings();

        if ($recorded === null) {
            return;
        }

        if (!$modelWasAskedFor && $recorded['model'] !== null) {
            $model = Models::find($recorded['model']->provider, $recorded['model']->modelId)
                ?? Models::get($recorded['model']->modelId);

            // A key as well as a model. Upstream's `restoreModelFromSession()` checks both and
            // falls back on either — an afternoon on a borrowed `--api-key` comes back tomorrow
            // with no key for that provider, and restoring it would mean a conversation that
            // reopens onto a model whose every turn fails.
            $hasKey = $model !== null && ($this->auth !== null
                ? $this->auth->hasKeyFor($model->provider)
                : $this->keyFor($model) !== null);

            if ($hasKey) {
                $this->agent->setModel($model);
            }
        }

        // After the model, because which levels exist depends on it. Clamped rather than
        // taken on trust for the same reason `setModel()` clamps: a level the model cannot
        // do is a request the provider rejects, and the person resuming did not ask for it
        // — the file did.
        $level = $recorded['thinking']?->known() ?? $this->thinkingLevel();

        $this->agent->setThinkingLevel($this->clampThinking($level));
    }

    // ---- events ------------------------------------------------------------------

    /**
     * @param Closure(AgentEvent): void $listener
     * @return Closure(): void call it to stop listening
     */
    public function subscribe(Closure $listener): Closure
    {
        $id = $this->nextListenerId++;
        $this->listeners[$id] = $listener;

        return function () use ($id): void {
            unset($this->listeners[$id]);
        };
    }

    /** Drop every listener and let go of the agent. */
    public function dispose(): void
    {
        try {
            $this->abortRetry();
            $this->abortCompaction();
            $this->abortBash();
            $this->agent->abort();
            // Emptied without `clearQueue()`'s `queue_update`: nobody is left to redraw a queue for.
            $this->steering = [];
            $this->followUps = [];
            $this->agent->clearAllQueues();
        } catch (Throwable) {
            // Dispose must succeed even if an abort hook throws.
        }

        if ($this->unsubscribeAgent !== null) {
            ($this->unsubscribeAgent)();
            $this->unsubscribeAgent = null;
        }

        $this->listeners = [];
        $this->cacheWarmer?->cancel();
        $this->closeSessionResources();
        $this->removeScratch();
    }

    /**
     * Let the session name itself after its first prompt — pig's own (`SessionTitle`). A mode
     * turns it on, as it does cache warming: the terminal and RPC (and so the Web UI) do; `-p`
     * does not, since it ends with its answer and its session is seldom looked at again.
     */
    public function enableAutoSessionName(): void
    {
        $this->autoSessionName = true;
    }

    /**
     * After a prompt settles: ask the model for a name if the session has none yet, once per
     * session, in the background — the person's next prompt does not wait for it.
     */
    private function nameItself(): void
    {
        // Without settings (a bare SDK session) nothing extra is asked of the model.
        $store = $this->store;
        $model = $this->model();

        if (!$this->autoSessionName || $store === null || $model === null || isset($this->titleAsked[$store->id])
            || $this->sessionName() !== null || !($this->settings?->autoSessionNameEnabled() ?? false)) {
            return;
        }

        $excerpt = SessionTitle::excerpt($this->messages());
        if ($excerpt === null) {
            return;
        }

        $this->titleAsked[$store->id] = true;
        $inner = $this->innerStream;
        $key = $this->keyFor($model);

        Async::spawn(function () use ($store, $model, $key, $excerpt, $inner): void {
            try {
                $context = Transcript::normalizeContext(new Context([new UserMessage(SessionTitle::prompt($excerpt))]));
                // The session's headers, timeouts and transport, as a turn's request has them.
                $options = $this->buildRequestOptions($model, new SimpleStreamOptions(maxTokens: 1000, apiKey: $key, maxRetries: 0));
                $response = $inner !== null ? $inner($model, $context, $options) : Stream::simple($model, $context, $options);

                foreach ($response as $ignored) {
                    // Only the whole answer is used.
                }

                $message = $response->result()->await();
                if (!$message instanceof AssistantMessage || $message->stopReason === StopReason::Error || $message->stopReason === StopReason::Aborted) {
                    return;
                }

                $text = '';
                foreach ($message->content as $part) {
                    if ($part instanceof TextContent) {
                        $text .= $part->text;
                    }
                }

                // The session may have moved on meanwhile: another one opened, or a name given.
                if ($this->store !== $store) {
                    return;
                }

                $store->appendUsage('session_title', $message->provider, $message->responseModel ?? $message->model, $message->usage);
                $this->announceAppendedEntry();

                $title = SessionTitle::clean($text);
                if ($title !== null && $this->sessionName() === null) {
                    $this->setSessionName($title);
                }
            } catch (Throwable) {
                // Best effort, as cache warming is: a session without a name is still a session.
            }
        });
    }

    /** Upstream's `cleanupSessionResources(sessionId)`: Codex's cached WebSocket is the one there is. */
    private function closeSessionResources(): void
    {
        if ($this->agent->sessionId !== null) {
            OpenAiCodexResponses::closeWebSocketSessions($this->agent->sessionId);
        }
    }

    /**
     * Keep the prompt cache warm between requests — upstream's `CacheWarmer`, which its SDK always
     * builds. Here a mode turns it on: upstream `unref()`s the refresh timer so Node can exit with
     * one pending, pig's loop has no unref and would wait it out, and a `-p` run has no next
     * request to save anyway. The terminal and RPC modes call this.
     */
    public function enableCacheWarming(): void
    {
        if ($this->cacheWarmer !== null) {
            return;
        }

        $inner = $this->innerStream;
        $this->cacheWarmer = new CacheWarmer(
            static fn (Model $model, TranscriptContext $context, SimpleStreamOptions $options): mixed => $inner !== null
                ? $inner($model, $context, $options)
                : Stream::simple($model, $context, $options),
            fn (): string => $this->settings?->cacheWarmingMode() ?? 'streaming',
            fn (CacheWarmingDecisionEvent $event): string => $this->extensionRunner?->emitCacheWarmingDecision($event) ?? $event->action,
            fn (): int => $this->lastPromptTokens(),
            function (string $kind, string $provider, string $model, Usage $usage, ?string $note): ?UsageEntry {
                $entry = $this->store?->appendUsage($kind, $provider, $model, $usage, $note);

                if ($entry !== null) {
                    $this->announce(new CacheWarmedEvent($entry));
                    // Upstream's `onWarmed`: `entry_appended` for the usage entry.
                    $this->announceAppendedEntry();
                }

                return $entry;
            },
        );
    }

    /** Current cache-warming state and the policy inputs that produced it; null when it is off. */
    public function cacheWarmingStatus(): ?CacheWarmingStatus
    {
        return $this->cacheWarmer?->status();
    }

    /** Persist the cache-warming mode and reconcile active warming at once. */
    public function setCacheWarmingMode(string $mode): void
    {
        $this->settings?->setCacheWarmingMode($mode);
        $this->cacheWarmer?->onModeChanged();
    }

    /**
     * Warm only requests for the selected model, while the conversation still extends the request's
     * prefix — upstream's `cacheContextIsCurrent()`. Identity, not equality: the agent's list is the
     * same objects until something replaces them.
     *
     * @return Closure(): bool
     */
    private function cacheContextIsCurrent(Model $requestModel): Closure
    {
        $messages = $this->agent->state->messages;

        return function () use ($messages, $requestModel): bool {
            $current = $this->agent->state->model;
            $currentMessages = $this->agent->state->messages;

            if ($current === null || $current->provider !== $requestModel->provider || $current->id !== $requestModel->id) {
                return false;
            }

            if (count($messages) > count($currentMessages)) {
                return false;
            }

            foreach ($messages as $index => $message) {
                if (($currentMessages[$index] ?? null) !== $message) {
                    return false;
                }
            }

            return true;
        };
    }

    /** The prompt the latest answer was asked with, as its provider counted it — what a refresh would re-read. */
    private function lastPromptTokens(): int
    {
        $messages = $this->agent->state->messages;

        for ($i = count($messages) - 1; $i >= 0; $i--) {
            $message = $messages[$i];

            if ($message instanceof AssistantMessage) {
                return $message->usage->input + $message->usage->cacheRead + $message->usage->cacheWrite;
            }
        }

        return 0;
    }

    private function onAgentEvent(AgentEvent $event): void
    {
        // "An abort requested while the run was starting, e.g. during before_agent_start, stops it
        // here. agent_start is awaited before the first request."
        if ($event instanceof AgentStartEvent && $this->runAbortRequested) {
            $this->agent->abort();
        }

        $this->tellExtensions($event);

        // A queued message leaves the queue *before* the event goes out, so a listener
        // redrawing the "3 messages waiting" line sees three, not four.
        if ($event instanceof MessageStartEvent && $event->message instanceof UserMessage) {
            $this->overflowRecoveryAttempted = false;
            $this->dequeue(self::textOf($event->message));
        }

        if ($event instanceof MessageEndEvent
            && $event->message instanceof AssistantMessage
            && $event->message->stopReason !== StopReason::Error
            && $event->message->stopReason !== StopReason::Length) {
            $this->overflowRecoveryAttempted = false;
        }

        // Written when the message is finished, not when it starts: a streamed answer is
        // re-sent complete on every update, and only the last one is the whole of it.
        if ($event instanceof MessageEndEvent) {
            $this->store?->append($event->message);

            if ($event->message instanceof ToolResultMessage) {
                $this->toolProgress->clear();
            }
        }

        // A nested call (codemode's) is part of its caller's output, not a call of the run's own.
        if ($event instanceof ToolExecutionUpdateEvent && $event->parentToolCallId === null) {
            $this->toolProgress->update($event->toolCallId, $event->partialResult);
        }

        // The nested-call counters are the run's — upstream's `_nestedToolCalls.clear()`.
        if ($event instanceof AgentEndEvent) {
            $this->nestedCalls = [];
        }

        // Upstream emits to extensions first and then, to its own listeners, `agent_end` with
        // `willRetry` filled in (`_willRetryAfterAgentEnd()`).
        $forListeners = $event instanceof AgentEndEvent
            ? new AgentEndEvent($event->messages, $this->willRetryAfterAgentEnd($event))
            : $event;

        foreach ($this->listeners as $listener) {
            $listener($forListeners);
        }

        // Upstream: "Reset retry counter immediately on successful assistant response. This
        // prevents accumulation across multiple LLM calls within a turn."
        if ($event instanceof MessageEndEvent
            && $event->message instanceof AssistantMessage
            && $event->message->stopReason !== StopReason::Error
            && $this->attempt > 0) {
            $attempts = $this->attempt;
            $this->attempt = 0;
            $this->announce(new RetryEndEvent(true, $attempts));
        }

        // Upstream: "A turn ends after its assistant message and every tool result has been
        // appended, so this is the first point in the run where a context-only custom message can
        // be inserted without landing between a tool call and its result. Flushing after the
        // extension and listener dispatch above also picks up messages that turn_end handlers
        // queued."
        if ($event instanceof TurnEndEvent) {
            $this->flushPendingHookMessages();
        }

        // Nothing is decided here about what comes after the run — retry, summary, the queue.
        // That is `runAgentPrompt()`'s loop, after `agent->prompt()` has returned, as upstream
        // has it. Deciding it here, inside the run's own fan-out, is what made `agent_settled` a
        // per-*run* event: it went out on every end that did not start a retry, including the
        // ones with a queued message or a hook's turn about to run.
    }

    /**
     * Announce something of the session's own on the same stream.
     *
     * Retries and self-started compaction are not the agent loop's events — the loop is not
     * running when they happen — but they are the same listeners' business, so they go the
     * same way. See `AgentEvent`'s docblock.
     */
    private function announce(AgentEvent $event): void
    {
        foreach ($this->listeners as $listener) {
            $listener($event);
        }
    }

    /**
     * The four run events, translated for the hooks.
     *
     * The agent's own events and the hooks' events are not the same set and are not
     * meant to be: the agent reports every message and every delta, and a hook is
     * offered the four moments upstream chose. The turn counter is reset by
     * `agent_start` rather than kept per session, because upstream's `turnIndex` is
     * "which turn of this run", which is what a hook watching a long run wants.
     */
    private function tellExtensions(AgentEvent $event): void
    {
        if ($this->extensionRunner === null) {
            return;
        }

        if ($event instanceof AgentStartEvent) {
            $this->turnIndex = 0;
            $this->extensionRunner->emit(new ExtensionAgentStart());

            return;
        }

        if ($event instanceof TurnStartEvent) {
            $this->extensionRunner->emit(new ExtensionTurnStart($this->turnIndex));

            return;
        }

        if ($event instanceof TurnEndEvent) {
            // Upstream's `_lastActivityOutcome`, for `agent_before_settle`'s `outcome`.
            $this->lastOutcome = match ($event->message->stopReason ?? null) {
                StopReason::Aborted => 'aborted',
                StopReason::Error => 'error',
                default => 'completed',
            };
            $this->extensionRunner->emit(new ExtensionTurnEnd($event->message, $event->toolResults, $this->turnIndex));
            $this->turnIndex++;

            return;
        }

        if ($event instanceof MessageStartEvent) {
            $this->extensionRunner->emit(new ExtensionMessageStart($event->message));

            return;
        }

        if ($event instanceof MessageUpdateEvent) {
            $this->extensionRunner->emit(new ExtensionMessageUpdate($event->message, $event->assistantMessageEvent));

            return;
        }

        if ($event instanceof MessageEndEvent) {
            $this->extensionRunner->emit(new ExtensionMessageEnd($event->message));

            return;
        }

        if ($event instanceof ToolExecutionStartEvent) {
            $this->extensionRunner->emit(new ExtensionToolExecutionStart($event->toolCallId, $event->toolName, $event->arguments, $event->parentToolCallId));

            return;
        }

        if ($event instanceof ToolExecutionUpdateEvent) {
            $this->extensionRunner->emit(new ExtensionToolExecutionUpdate($event->toolCallId, $event->toolName, $event->arguments, $event->partialResult, $event->parentToolCallId));

            return;
        }

        if ($event instanceof ToolExecutionEndEvent) {
            $this->extensionRunner->emit(new ExtensionToolExecutionEnd($event->toolCallId, $event->toolName, $event->result, $event->isError, $event->durationMs, $event->parentToolCallId));

            return;
        }

        if ($event instanceof AgentEndEvent) {
            $this->extensionRunner->emit(new ExtensionAgentEnd($event->messages));
        }

        // `agent_settled` is **not** emitted here. `AgentEndEvent` is the end of a *run*, and a
        // prompt can be several runs: each failed attempt before a retry ends one, so does the
        // run an auto-compaction summarises, and so does a run with a message queued behind it.
        // Upstream emits `agent_settled` once per prompt, from `_emitAgentSettled()` in the
        // `finally` of `_runAgentPrompt()`; pig does the same from `emitAgentSettled()`.
    }

    // ---- what an extension can ask of the session ------------------------------------

    /** `tui`, `print`, `json`, `rpc` or `mcp` — set by whichever mode is driving. Upstream's `ctx.mode`, plus pig's `mcp`. */
    private string $mode = 'print';

    /** @var (Closure(): void)|null what the mode does when an extension asks pig to quit */
    private ?Closure $onShutdown = null;

    private bool $shutdownRequested = false;

    /** @param 'tui'|'print'|'json'|'rpc'|'mcp' $mode */
    public function setMode(string $mode): void
    {
        $this->mode = $mode;
    }

    public function mode(): string
    {
        return $this->mode;
    }

    /** What the session's tools are, for the mode that rebuilds them on `/reload`. */
    public function loadout(): ?ToolLoadout
    {
        return $this->loadout;
    }

    public function useLoadout(?ToolLoadout $loadout): void
    {
        $this->loadout = $loadout;
    }

    /** Whether `<cwd>/.pig/` was allowed to load. Upstream's `ctx.isProjectTrusted()`. */
    public function isProjectTrusted(): bool
    {
        return $this->projectTrusted;
    }

    public function setProjectTrusted(bool $trusted): void
    {
        $this->projectTrusted = $trusted;
    }

    /** @param (Closure(): void)|null $handler */
    public function onShutdownRequest(?Closure $handler): void
    {
        $this->onShutdown = $handler;
    }

    /**
     * An extension asked pig to quit. Upstream's `ctx.shutdown()`.
     *
     * Now if nothing is running, otherwise once the prompt has settled — upstream's rule, and
     * the reason is the same: a quit requested from a `turn_end` handler must not cut off the
     * retry or the compaction that turn is about to start, or the answer the person asked for.
     */
    public function requestShutdown(): void
    {
        if ($this->onShutdown === null) {
            return;
        }

        if ($this->isIdle()) {
            ($this->onShutdown)();

            return;
        }

        $this->shutdownRequested = true;
    }

    /** Nothing running and nothing about to: no turn, no retry, no summary. Upstream's `isIdle`. */
    public function isIdle(): bool
    {
        return !$this->isStreaming() && $this->compacting === null;
    }

    /**
     * The current effective system prompt, including changes not yet sent to the model —
     * upstream's `session.systemPrompt` (`ctx.getSystemPrompt()`): what the loadout would have the
     * prompt be, or, for a session with no loadout, what the transcript's system messages replay to.
     */
    public function systemPrompt(): string
    {
        return $this->renderSystemPrompt($this->runSystemPromptOptions);
    }

    /**
     * Upstream's `buildSystemPrompt(options)`: a forced prompt as it is, otherwise the sections —
     * the loadout's and the handlers' — rendered as the transcript replays them.
     */
    private function renderSystemPrompt(?SystemPromptOptions $options): string
    {
        if ($options?->forceSystemPrompt !== null) {
            return $options->forceSystemPrompt;
        }

        if ($this->loadout === null) {
            return $this->agent->state->systemPrompt();
        }

        return Text::getSystemMessageText(new SystemMessage('', SystemPrompt::withSections($this->loadout->systemPromptSections(), $options?->sections ?? [])));
    }

    /**
     * The system message that brings the transcript's prompt in line with the loadout's, or null
     * when it already is — upstream's `_preparePromptAndToolLoadout()`: "returns a system message
     * patching the prompt sections the model currently has (replayed from `messages`), or
     * undefined when the prompt is unchanged. Tool changes are declared by the agent loop before
     * the request." The first one a session sends declares every section, so it is the
     * transcript's leading system message and the session file's first.
     *
     * Null for a session with no loadout: nothing here knows what its prompt should be, and the
     * transcript's own system messages stand.
     *
     * @param list<mixed>|null         $messages the transcript to diff against; the agent's when null
     * @param SystemPromptOptions|null $options  the run's prompt options, as the handlers left them
     */
    private function preparePromptUpdate(?array $messages, ?SystemPromptOptions $options): ?SystemMessage
    {
        if ($this->loadout === null) {
            return null;
        }

        // The run's options as well as the loadout's, as upstream's next-turn refresh builds from
        // `_runSystemPromptOptions ?? _baseSystemPromptOptions`: a handler's section stays for every
        // request of the run it was added for. A forced prompt does not change what is recorded.
        $sections = SystemPrompt::diffSections(
            Transcript::getCurrentSystemMessage($messages ?? $this->agent->state->messages)?->sections ?? [],
            SystemPrompt::withSections($this->loadout->systemPromptSections(), $options?->sections ?? []),
        );

        return $sections !== null ? new SystemMessage('', $sections) : null;
    }

    /**
     * How full the context window is. Upstream's `getContextUsage()`.
     *
     * Null with no model, or a model that declares no window. `tokens` is null right after a
     * compaction until a turn has come back, because the last reading describes the conversation
     * before it was summarised and nothing has measured the one after — upstream's rule, and the
     * same one `Compaction::lastUsage()` is written to. Otherwise it is the last turn's own count
     * plus an estimate for whatever was said since, which is what the next request will carry.
     */
    public function contextUsage(): ?ContextUsage
    {
        $model = $this->limitsModel();

        if ($model === null || $model->contextWindow <= 0) {
            return null;
        }

        $messages = $this->messages();
        $usage = Compaction::lastUsage($messages);
        $compacted = array_filter($messages, static fn ($m): bool => $m instanceof CompactionSummary) !== [];

        if ($usage === null && $compacted) {
            return new ContextUsage(null, $model->contextWindow, null);
        }

        $tokens = 0;
        $since = $messages;

        if ($usage !== null) {
            $tokens = Compaction::calculateContextTokens($usage);

            for ($i = count($messages) - 1; $i >= 0; $i--) {
                if ($messages[$i] instanceof AssistantMessage && $messages[$i]->usage === $usage) {
                    $since = array_slice($messages, $i + 1);
                    break;
                }
            }
        }

        foreach ($since as $message) {
            $tokens += Compaction::estimateTokens($message);
        }

        return new ContextUsage($tokens, $model->contextWindow, $tokens / $model->contextWindow * 100);
    }

    /** @return list<string> the tools the model is offered now. Upstream's `getActiveTools()`. */
    public function activeTools(): array
    {
        return $this->loadout?->activeNames()
            ?? array_map(static fn (AgentTool $tool): string => $tool->definition()->name, $this->agent->state->tools);
    }

    /**
     * Every registered tool, active or not. Upstream's `getAllTools()`.
     *
     * @return list<array{name: string, description: string, parameters: array<string, mixed>, active: bool}>
     */
    public function allTools(): array
    {
        return $this->loadout?->describe() ?? array_map(static fn (AgentTool $tool): array => [
            'name' => $tool->definition()->name,
            'description' => $tool->definition()->description,
            'parameters' => $tool->definition()->parameters,
            'active' => true,
        ], $this->agent->state->tools);
    }

    /**
     * Offer the model only these, from its next request. Upstream's `setActiveTools()`. Names
     * nothing registered are ignored.
     *
     * @param list<string> $names
     */
    public function setActiveTools(array $names): void
    {
        if ($this->loadout === null) {
            throw new AgentError('This session has no tool loadout to narrow.');
        }

        // Upstream's `setActiveToolsByName()`: "A loadout that deactivates a tool replaces the
        // restored one, whose pending tools are dropped. One that only adds tools, like activating
        // tool_search, keeps them."
        $previous = $this->loadout->activeNames();
        $this->loadout->setActive($names);
        $active = $this->loadout->activeNames();

        if (array_diff($previous, $active) !== []) {
            $this->loadout->clearPending();
        }
    }

    private int $extensionCalls = 0;

    /**
     * Run one of the model's tools on an extension's behalf. Upstream's `ctx.executeTool()`.
     *
     * Through the same wrapped tool the model would get — so the arguments are checked against
     * the schema with the message the model would read, and a `tool_call` hook (the permission
     * gate) is asked exactly as it would be: an extension is not a way round a guard. Only an
     * active tool, for the same reason: a tool an extension switched off is off.
     *
     * Upstream records such a call on its caller's result as `nestedCalls` with a
     * `<parent>/<n>` id; pig has no parent to hang it on when the caller is a command or an
     * event handler, so it is not recorded, and the id says who made it.
     *
     * @param array<string, mixed> $arguments
     * @throws AgentError when no active tool has that name; whatever the tool throws otherwise
     */
    public function executeTool(string $name, array $arguments, ?\Pig\Async\AbortSignal $signal = null): AgentToolResult
    {
        foreach ($this->agent->state->tools as $tool) {
            if ($tool->definition()->name !== $name) {
                continue;
            }

            $id = 'extension-' . (++$this->extensionCalls);
            $arguments = ToolArguments::validate($tool->definition(), ToolArguments::prepare($tool, new ToolCall($id, $name, $arguments)));

            return $tool->execute($id, $arguments, $signal ?? $this->signal());
        }

        throw new AgentError("No active tool called '{$name}'.");
    }

    /** @var array<string, int> how many nested calls each tool call has made, by its id */
    private array $nestedCalls = [];

    /**
     * The id of the next call the tool call `$parentToolCallId` makes: `<parent>/<n>`, counted
     * from 1 — upstream's `NestedToolCallRunner` shape. A call below a nested call counts from
     * 1 again under its own id.
     */
    public function nestedToolCallId(string $parentToolCallId): string
    {
        $this->nestedCalls[$parentToolCallId] = ($this->nestedCalls[$parentToolCallId] ?? 0) + 1;

        return "{$parentToolCallId}/{$this->nestedCalls[$parentToolCallId]}";
    }

    /**
     * Run a call that the tool call `$parentToolCallId` made while it ran — a codemode script's
     * `$tools->read()`. Upstream's `_executeNestedToolCall()`, through `NestedToolCallRunner`.
     *
     * The call goes through the loop's own pipeline as far as the loop has one: the arguments
     * are checked against the schema with the message the model would read, `$tool` is the
     * hooked tool so a `tool_call` guard sees the call, and `tool_execution_start`, `_update`
     * and `_end` go to the hooks and the session's listeners with `parentToolCallId` set, so
     * the RPC port and a watching hook see the sub-call where the TUI, which draws one row per
     * model-issued call, leaves it out. The id is `nestedToolCallId()`'s, handed in so the
     * caller can show the call as running before this returns.
     *
     * Never throws for a failing tool: the failure comes back as an error result, the way the
     * loop hands one to the model. What upstream also keeps — a bounded `nestedCalls` record
     * on the tool result message — pig does not; the codemode tool's `details` lists the calls.
     *
     * @param array<string, mixed>                $arguments
     * @param ?Closure(AgentToolResult): void     $onUpdate
     * @return array{0: AgentToolResult, 1: bool} the result and whether it is an error
     */
    public function executeNestedTool(
        \Pig\Agent\AgentTool $tool,
        string $toolCallId,
        string $parentToolCallId,
        array $arguments,
        ?AbortSignal $signal = null,
        ?Closure $onUpdate = null,
    ): array {
        $name = $tool->definition()->name;
        $this->onAgentEvent(new ToolExecutionStartEvent($toolCallId, $name, $arguments, $parentToolCallId));
        $isError = false;
        $startedAt = null;
        $durationMs = null;

        try {
            $arguments = ToolArguments::validate($tool->definition(), ToolArguments::prepare($tool, new ToolCall($toolCallId, $name, $arguments)));
            $startedAt = hrtime(true);
            $result = $tool->execute(
                $toolCallId,
                $arguments,
                $signal ?? $this->signal(),
                function (AgentToolResult $partial) use ($toolCallId, $name, $arguments, $parentToolCallId, $onUpdate): void {
                    if ($onUpdate !== null) {
                        $onUpdate($partial);
                    }

                    $this->onAgentEvent(new ToolExecutionUpdateEvent($toolCallId, $name, $arguments, $partial, $parentToolCallId));
                },
            );
            $durationMs = AgentLoop::elapsedMs($startedAt);
        } catch (Throwable $error) {
            $durationMs = $startedAt === null ? null : AgentLoop::elapsedMs($startedAt);
            $result = $error instanceof AgentError
                ? new AgentToolResult([new TextContent($error->getMessage())], $error->details, $error->usage, $error->structuredContent)
                : new AgentToolResult([new TextContent($error->getMessage())]);
            $isError = true;
        }

        unset($this->nestedCalls[$toolCallId]);
        $this->onAgentEvent(new ToolExecutionEndEvent($toolCallId, $name, $result, $isError, $durationMs, $parentToolCallId));

        return [$result, $isError];
    }

    // ---- state -------------------------------------------------------------------

    public function state(): AgentState
    {
        return $this->agent->state;
    }

    private ?string $sessionName = null;

    /** @var list<Closure(string): void> */
    private array $nameListeners = [];

    public function model(): ?Model
    {
        return $this->agent->state->model;
    }

    /**
     * Under a virtual selection, the physical model of the latest successful response — upstream's
     * `routedModel`. Null under a physical selection, and before the first response.
     */
    public function routedModel(): ?RoutedModel
    {
        $model = $this->model();

        if ($model === null || !Models::isVirtual($model)) {
            return null;
        }

        $latest = VirtualModelRegistry::latestResponse($this->messages());
        $physical = $latest === null ? null : VirtualModelRegistry::physical($latest->provider, $latest->model);

        return $physical === null ? null : new RoutedModel($physical, $latest?->thinkingLevel === null ? null : ThinkingLevel::tryFrom($latest->thinkingLevel));
    }

    /** The model whose limits apply to the conversation — upstream's `_limitsModel()`. */
    private function limitsModel(): ?Model
    {
        return $this->routedModel()?->model ?? $this->model();
    }

    /**
     * The model whose limits apply to $message, or null when it came from another model —
     * upstream's `_modelForMessage()`. Under a virtual selection, the physical model that produced it.
     */
    private function modelForMessage(AssistantMessage $message): ?Model
    {
        $model = $this->model();

        if ($model !== null && Models::isVirtual($model)) {
            return VirtualModelRegistry::physical($message->provider, $message->model);
        }

        return $model?->provider === $message->provider && $model->id === $message->model ? $model : null;
    }

    /**
     * Route a virtual selection for one request of the agent loop. Upstream's reasons: `retry`
     * when a failed response is being sent again, `user` when a message the person wrote follows
     * the last response (extension messages can follow it too), `continuation` otherwise. The
     * router's state comes off the branch and a new one goes back on it as a `STATE_ENTRY` note.
     *
     * @param list<mixed> $messages
     */
    private function route(Model $model, ThinkingLevel $thinkingLevel, array $messages, ?AssistantMessage $failed, ?AbortSignal $signal): ModelRoute
    {
        $lastResponse = -1;

        for ($i = count($messages) - 1; $i >= 0; $i--) {
            if ($messages[$i] instanceof AssistantMessage) {
                $lastResponse = $i;
                break;
            }
        }

        $userTurn = array_filter(array_slice($messages, $lastResponse + 1), static fn (mixed $message): bool => $message instanceof UserMessage) !== [];
        $state = $this->store === null
            ? null
            : VirtualModelRegistry::stateIn($this->store->customEntries(VirtualModelRegistry::STATE_ENTRY), $model->provider, $model->id);

        $route = VirtualModelRegistry::current()->resolve(
            $model,
            $messages,
            $failed !== null ? ModelRouteRequest::RETRY : ($userTurn ? ModelRouteRequest::USER : ModelRouteRequest::CONTINUATION),
            $thinkingLevel,
            fn (Model $physical): bool => $this->keyFor($physical) !== null,
            $signal,
            $failed,
            $state,
        );

        if ($route->state !== null && $route->state !== $state) {
            $this->store?->appendCustomEntry(VirtualModelRegistry::STATE_ENTRY, [
                'provider' => $model->provider,
                'modelId' => $model->id,
                'state' => $route->state,
            ]);
        }

        return $route;
    }

    /**
     * The model and level a request outside the agent loop goes to — a summary. A virtual
     * selection is routed with reason `direct`, which carries no state; a physical one is itself.
     */
    private function directModel(Model $model, ?AbortSignal $signal): ModelRoute
    {
        if (!Models::isVirtual($model)) {
            return new ModelRoute($model, $this->thinkingLevel());
        }

        return VirtualModelRegistry::current()->resolve(
            $model,
            $this->messages(),
            ModelRouteRequest::DIRECT,
            $this->thinkingLevel(),
            fn (Model $physical): bool => $this->keyFor($physical) !== null,
            $signal,
        );
    }

    /**
     * Record the selection on the branch when the branch implies another one, so a resume
     * restores it — upstream's `_recordSelection()`. Tree navigation can leave the latest
     * `model_change` on another branch, and responses cannot record a virtual selection because
     * they name physical models. Responses do record a physical selection unless the branch holds
     * a virtual one; checking a physical selection against responses would record it on every
     * prompt while the routing redirects to another model.
     */
    private function recordSelection(): void
    {
        $model = $this->model();
        $recorded = $this->store?->settings()['model'];

        if ($model === null || $recorded === null || ($recorded->provider === $model->provider && $recorded->modelId === $model->id)) {
            return;
        }

        $recordedModel = Models::find($recorded->provider, $recorded->modelId);

        if (!Models::isVirtual($model) && !($recordedModel !== null && Models::isVirtual($recordedModel))) {
            return;
        }

        $this->store?->appendModelChange($model->provider, $model->id);
    }

    public function sessionName(): ?string
    {
        return $this->sessionName ?? $this->store?->sessionName();
    }

    public function getSessionName(): ?string
    {
        return $this->sessionName();
    }

    public function onSessionNameChanged(Closure $listener): void
    {
        $this->nameListeners[] = $listener;
    }

    /** @var list<Closure(string, ?string): void> */
    private array $switchListeners = [];

    /**
     * Told after `startNew()` or `switchTo()` has finished, with the reason and the file left.
     *
     * The hook events (`session_shutdown` then `session_start`, with the reason) are for hooks; this is for a front end that has to redraw
     * — the Web UI's tab bar, which otherwise cannot know the terminal just moved to another
     * conversation underneath it.
     *
     * @param Closure('new'|'resume', ?string): void $listener
     */
    public function onSessionSwitched(Closure $listener): void
    {
        $this->switchListeners[] = $listener;
    }

    private function tellSwitched(string $reason, ?string $previous): void
    {
        foreach ($this->switchListeners as $listener) {
            $listener($reason, $previous);
        }
    }

    public function setSessionName(string $name): void
    {
        $name = trim($name);
        $this->sessionName = $name !== '' ? $name : null;
        $this->store?->setSessionName($name);
        $event = new SessionInfoChangedEvent($name);
        $this->extensionRunner?->emit($event);
        $this->announce($event);

        foreach ($this->nameListeners as $listener) {
            $listener($name);
        }
    }

    /**
     * What `--models` narrowed this session to, empty when nothing did.
     *
     * For a caller that needs to say *that* there is a scope — the terminal's "only one model in
     * the scope" — rather than to draw one. Drawing goes through `modelsOnOffer()`.
     *
     * @return list<ModelChoice>
     */
    public function modelScope(): array
    {
        return $this->modelScope;
    }

    /**
     * Upstream's `summarizeForBugReport()`: the current model describes what went wrong, for a
     * `/bug` that leaves the transcript out. Through the session's stream function and retry
     * policy, as a compaction goes; a virtual model is routed to the model it stands for first.
     *
     * @throws AgentError when there is no model, or the summary could not be written
     */
    public function summarizeForBugReport(?string $hint, AbortSignal $signal): string
    {
        $model = $this->directModel($this->model() ?? throw new AgentError('No model selected'), $signal)->model;

        return \Pig\CodingAgent\BugReport::generateSummary(
            $this->messages(),
            $hint,
            $model,
            $this->keyFor($model),
            $signal,
            $this->agent->streamFunction,
            $this->retrySettings(),
            $this->store?->id,
        );
    }

    /**
     * Upstream's `setScopedModels()`: what `/scoped-models` narrows Ctrl+P to for the rest of the
     * session. Empty is the whole list again. Not saved — that is `enabledModels`, on `app.models.save`.
     *
     * @param list<ModelChoice> $scope
     */
    public function setModelScope(array $scope): void
    {
        $this->modelScope = $scope;
    }

    /**
     * The models this session offers: the scope when there is one, the whole list otherwise.
     *
     * One home for "which models are on offer", which is what the cycling, the `/model` picker,
     * its completions and `/model <pattern>` all need — and the first draft had this rule twice,
     * once here and once in the terminal, so the mutation check found a scope that could be
     * ignored in `cycleModel()` with only the RPC test noticing. Two answers to one question is
     * the shape every other entry in `docs/dev/traps/` has.
     *
     * The full list is a parameter because `Auth` lives with the modes, and it is deliberately
     * not reached from here: `Auth::apiKey()` renews an expiring token on the way past, and a
     * list being drawn is not a turn being sent.
     *
     * **A host's `get_available_models` is not narrowed**, as upstream does not narrow it: a
     * scope is what the keys in front of somebody walk through, not a restriction — `set_model`
     * takes any model a key reaches, here and upstream both.
     *
     * @param list<Model> $available
     * @return list<Model>
     */
    public function modelsOnOffer(array $available): array
    {
        return $this->modelScope === []
            ? $available
            : array_map(static fn (ModelChoice $choice): Model => $choice->model, $this->modelScope);
    }

    /**
     * The next model along, applied.
     *
     * Upstream's `cycleModel()`, and it is on the session for the reason its docblock on
     * `ModelResolver::next()` used to deny: with `--models sonnet:high,haiku:low` the answer is
     * not only *which* model but *how hard it thinks*, so the two have to be applied together.
     * ctrl+p, shift+ctrl+p and RPC's `cycle_model` all come through here.
     *
     * The list is the scope when there is one and everything a key reaches otherwise — which is
     * why the available models are a parameter: `Auth` is deliberately not asked from in here,
     * because `Auth::apiKey()` renews an expiring token on the way past and a list being drawn
     * is not a turn being sent.
     *
     * @param list<Model> $available in the order a list of them would show
     * @return ModelChoice|null null when there is nowhere to go: one model in the scope, or none
     * @throws AgentError when no key reaches the model that comes next
     */
    public function cycleModel(array $available, bool $backward = false): ?ModelChoice
    {
        $scope = [];

        foreach ($this->modelScope as $choice) {
            $scope["{$choice->model->provider}/{$choice->model->id}"] = $choice;
        }

        $next = ModelResolver::next($this->modelsOnOffer($available), $this->model(), $backward);

        if ($next === null) {
            return null;
        }

        // A scope entry's own level when its pattern named one; otherwise `setModel()`'s choice.
        $entry = $scope["{$next->provider}/{$next->id}"] ?? null;
        $this->setModel($next, $entry?->explicitThinking === true ? $entry->thinking : null, persistAsDefault: false);

        return new ModelChoice($next, $this->thinkingLevel());
    }

    /**
     * Switch models, and keep the thinking level honest about the new one.
     *
     * A level the new model cannot do is not carried over: leaving `high` set on a model
     * without reasoning sends a request the provider rejects, and the person who changed
     * model would have no idea why. Dropped silently to what the model can do, because
     * they asked for the model, not for the level.
     */
    public function setModel(Model $model, ?ThinkingLevel $thinking = null, bool $persistAsDefault = false): void
    {
        // Upstream's first two lines, and they were missing: switching to a model this machine
        // has no key for used to succeed, be written into the session file as the model this
        // conversation is on, and then fail on the next turn with `Stream`'s "No API key for
        // provider" — from inside a turn, where it looks like the provider's fault. Refused here
        // instead, before anything is recorded.
        if ($this->keyFor($model) === null) {
            throw new AgentError("No API key for {$model->provider}/{$model->id}");
        }

        $previous = $this->model();
        $changed = $previous?->id !== $model->id || $previous?->provider !== $model->provider;

        $this->agent->setModel($model);

        // Written down, so `--continue` comes back to the model this conversation was being
        // had with rather than to whatever a new one would open with. Only when it actually
        // changed: `setModel()` is also how the thinking level is clamped, and a line per
        // clamp would be a file full of a model changing to itself.
        if ($changed) {
            $this->store?->appendModelChange($model->provider, $model->id);
            $this->extensionRunner?->emit(new ModelSelectEvent($model, $previous));
        }

        // Remembered for the next run when enabled (e.g. CLI interactive mode).
        // Web UI and lightweight switches pass persistAsDefault: false so they don't overwrite settings.json.
        if ($persistAsDefault) {
            $this->settings?->setDefaultModel($model->id, $model->provider);
            $this->addPersistedDefaultToScope($model);
        }

        // Upstream's `_getThinkingLevelForModelSwitch()`: the level asked for, the model's own
        // `modelThinkingLevels` entry, `defaultThinkingLevel`, and only then the level already set.
        // Not persisted as the default: saving a model as the default does not rewrite the thinking
        // default, upstream's rule.
        $level = $thinking
            ?? $this->settings?->modelThinkingLevel($model->provider, $model->id)
            ?? $this->settings?->defaultThinkingLevel()
            ?? $this->thinkingLevel();

        // `setThinkingLevel()` clamps to what the new model can do, as upstream's does.
        $this->setThinkingLevel($level);
    }

    /**
     * Upstream's `_addPersistedDefaultToNonEmptyScope()`: a model saved as the default joins a
     * scope it is not in, and `enabledModels` when that is where the scope came from — or the
     * default would be a model ctrl+p could not reach.
     */
    private function addPersistedDefaultToScope(Model $model): void
    {
        if ($this->modelScope === []) {
            return;
        }

        foreach ($this->modelScope as $choice) {
            if ($choice->model->provider === $model->provider && $choice->model->id === $model->id) {
                return;
            }
        }

        $this->modelScope[] = new ModelChoice($model);
        $enabled = $this->settings?->enabledModels() ?? [];

        if ($enabled === []) {
            return;
        }

        $reference = "{$model->provider}/{$model->id}";

        foreach ($enabled as $pattern) {
            if (strtolower($pattern) === strtolower($reference)) {
                return;
            }
        }

        $this->settings?->setEnabledModels([...$enabled, $reference]);
    }

    /**
     * $level if this model has it, otherwise the nearest one it does have.
     *
     * Was `in_array(…) ? … : Off` at both call sites, which is the same thing only when every
     * reasoning model has every level — true while the list was hardcoded and false the moment a
     * `thinkingLevelMap` can take one away. Upstream searches up and then down, so a model
     * missing `low` lands on `medium` rather than having thinking switched off.
     */
    private function clampThinking(ThinkingLevel $level): ThinkingLevel
    {
        $model = $this->model();

        return $model === null ? $level : ThinkingLevel::clampedFor($model, $level);
    }

    /**
     * The key this model would be used with, or null when there is none.
     *
     * The agent's own answer, asked the way a turn asks it: the closure `CodingAgent` wires to
     * `Auth::apiKey()`, then the one key a caller handed in. Upstream asks its model registry
     * here; pig's `AgentSession` is given a closure instead, which is the same fact from the
     * same place — and asking it means an expiring token is renewed rather than pronounced
     * missing.
     */
    public function keyFor(Model $model): ?string
    {
        $options = $this->agent->options();

        return $options->getApiKey !== null
            ? ($options->getApiKey)($model->provider) ?? $options->apiKey
            : $options->apiKey;
    }

    /**
     * Whether a prompt is in progress. Upstream's `isStreaming`, which is `_isAgentRunActive`.
     *
     * The whole prompt and not just the run in flight: the agent is not streaming during a retry's
     * sleep, an overflow summary, or the moment between a run and the queued message that carries
     * it on, and something sent in those gaps used to become a prompt of its own — which settled
     * this one early, so the "task complete" notification went out over a screen still Working.
     * Asked here, it is queued into the prompt in progress instead, as upstream queues it.
     */
    public function isStreaming(): bool
    {
        return $this->runActive;
    }

    /**
     * Carry on a run the process before this one did not finish, from the last thing the session
     * file holds. pig's own, for the web daemon's scheduled runs; upstream has no counterpart.
     *
     * What the file ends on decides it:
     *
     * - a user message or a tool result: the model was owed an answer, so it is asked (`continue`);
     * - a turn that failed or was stopped: dropped as a retry drops it, then the same;
     * - an answer whose tool calls do not all have a result: the rest are answered
     *   (`Agent::resume()`) and the run goes on. Of those, the call that may have been running is
     *   run again only if its tool is `ToolReplay::Safe`; any other is answered `interrupted`, after what
     *   it had printed (`ToolProgress`), and the model decides, because running a command a second
     *   time is not something to do on nobody's say-so;
     * - an answer with no tool calls: the run had finished, and there is nothing to do.
     *
     * `$onStarted` is told `continued` or `finished` before the run starts, as `prompt()`'s caller is
     * told the disposition, so a host does not wait the whole run for its answer.
     *
     * @param (Closure(string): void)|null $onStarted
     * @return string `continued` or `finished`
     * @throws \RuntimeException when there is nothing to carry on
     */
    public function continueRun(?Closure $onStarted = null): string
    {
        if ($this->isStreaming()) {
            throw new \RuntimeException('A run is already going.');
        }

        $messages = $this->agent->state->messages;
        $last = $messages === [] ? null : $messages[count($messages) - 1];

        if ($last === null) {
            throw new \RuntimeException('There is nothing in this session to carry on from.');
        }

        if ($last instanceof AssistantMessage && in_array($last->stopReason, [StopReason::Error, StopReason::Aborted], true)) {
            $this->dropLastAssistantMessage();
        } elseif (($unanswered = AgentLoop::unansweredToolCalls($messages)) !== null) {
            $kept = $this->store !== null ? ToolProgress::read($this->store->path) : null;
            $soFar = $kept !== null && $kept['toolCallId'] === $unanswered[1][0]->id && $kept['output'] !== ''
                ? new AgentToolResult([new TextContent($kept['output'])])
                : null;

            if ($onStarted !== null) {
                $onStarted('continued');
            }

            $this->runAgentPrompt(fn () => $this->agent->resume($soFar));

            return 'continued';
        } elseif ($last instanceof AssistantMessage) {
            if ($onStarted !== null) {
                $onStarted('finished');
            }

            return 'finished';
        }

        if ($onStarted !== null) {
            $onStarted('continued');
        }

        $this->runAgentPrompt(fn () => $this->agent->continue());

        return 'continued';
    }

    /** The custom entry a prompt's `requestId` is kept in once it is accepted. */
    public const string REQUEST_ENTRY = 'pig.request';

    /**
     * `prompt()` under a `requestId`: taken once, `duplicate` after that. In memory from the moment
     * it arrives, so a second copy that comes while the first is still being taken is a duplicate
     * too, and written down when it is accepted.
     *
     * @param (Closure(string): void)|null $preflightResult
     * @param Closure(Closure(string): void): void $send
     */
    private function promptOnce(string $requestId, ?Closure $preflightResult, Closure $send): void
    {
        if (isset($this->requests[$requestId]) || $this->hasStoredRequest($requestId)) {
            if ($preflightResult !== null) {
                $preflightResult('duplicate');
            }

            return;
        }

        $this->requests[$requestId] = true;
        $accepted = false;

        try {
            $send(function (string $disposition) use ($requestId, $preflightResult, &$accepted): void {
                $accepted = true;
                $this->store?->appendCustomEntry(self::REQUEST_ENTRY, ['requestId' => $requestId]);

                if ($preflightResult !== null) {
                    $preflightResult($disposition);
                }
            });
        } finally {
            // Refused (no model, busy with no `streamingBehavior`): nothing was taken, so the same
            // id may be sent again.
            if (!$accepted) {
                unset($this->requests[$requestId]);
            }
        }
    }

    private function hasStoredRequest(string $requestId): bool
    {
        foreach ($this->store?->customEntries(self::REQUEST_ENTRY) ?? [] as $entry) {
            if (is_array($entry->data) && ($entry->data['requestId'] ?? null) === $requestId) {
                return true;
            }
        }

        return false;
    }

    /**
     * Whether the conversation stopped in the middle of a run — the process that had it went away
     * after the question, after a tool's result, or inside a tool call. What a screen opening it
     * says, so the person can `/continue` it (`continueRun()`); nothing is run on its own, because
     * a conversation opened a month later is not one to start running commands in. pig's own.
     *
     * Narrower than what `continueRun()` will carry on: a turn that failed or was stopped with escape
     * is the end of a run somebody saw, not one a process lost, so it does not count.
     */
    public function isStoppedMidRun(): bool
    {
        if ($this->isStreaming()) {
            return false;
        }

        $messages = $this->agent->state->messages;
        $last = $messages === [] ? null : $messages[count($messages) - 1];

        return $last instanceof UserMessage
            || $last instanceof ToolResultMessage
            || AgentLoop::unansweredToolCalls($messages) !== null;
    }

    /**
     * The signal for the turn in progress, or null between turns.
     *
     * What a hook's own waiting parks on, so escape cuts it short rather than the person
     * waiting out its timeout. `Agent::signal()`'s docblock says why it is null when idle.
     */
    public function signal(): ?AbortSignal
    {
        return $this->agent->signal();
    }

    /** @return list<mixed> the conversation, app messages included */
    public function messages(): array
    {
        return $this->agent->state->messages;
    }

    // ---- prompting ---------------------------------------------------------------

    /**
     * Send something and run until the agent is done.
     *
     * A slash command is dealt with here rather than by whoever is drawing a screen, which is
     * upstream's arrangement and was the one gap left in `agent-session.ts`' surface map. A
     * **hook's** command is code and is run; a command kept as a **file** is a stored prompt and
     * is expanded into the text that gets sent. Both used to happen in `InteractiveMode`, so both
     * worked in the terminal and nowhere else: `pig -p "/deploy"` and RPC's `prompt` handed the
     * model the line as text and left it to guess.
     *
     * The hook half goes **before** the streaming check, because a hook's command is not a
     * message and there is nothing for it to wait behind — upstream's own comment says so
     * ("Hook commands always run immediately, even during streaming") while its code throws
     * there, and pig takes the half with the reason attached, as it does elsewhere when
     * upstream disagrees with itself.
     *
     * There is no `expandSlashCommands: false` here. Upstream declares that option and nothing
     * in either tree passes it, so it would be a branch existing for a caller that does not
     * exist; a caller that ever needs to send a line beginning with a slash verbatim is what
     * decides its shape.
     *
     * `$streamingBehavior` and `$preflightResult` are upstream's `PromptOptions` of the same names.
     * While a prompt is in progress, `steer` or `followUp` queues this one the way `steer()` and
     * `followUp()` do, and without either it is refused. `$preflightResult` is told what became of
     * the prompt the moment that is known — `handled` (a hook's command, or an `input` handler took
     * it), `queued`, or `started` just before the run begins — which is what RPC's `prompt` answers
     * with: a host is told the prompt was accepted without waiting for the turn, and a failure
     * after that is the turn's to report, in its events.
     *
     * `$requestId` is pig's, from pi-durable's `submit({requestId})`: a prompt sent again under the
     * id of one this conversation already took is not taken twice, and `$preflightResult` is told
     * `duplicate` — so a host that lost the answer (the page's connection dropped mid-send) can send
     * again without asking twice. Kept as a `pig.request` custom entry once the prompt is accepted,
     * so it holds across a restart; one that was refused is not kept, and can be sent again.
     *
     * @param list<ImageContent> $images
     * @param 'steer'|'followUp'|null $streamingBehavior
     * @param (Closure('handled'|'queued'|'started'|'duplicate'): void)|null $preflightResult
     * @throws AgentError if the agent is already working and no `$streamingBehavior` was given, or
     *                    there is no model
     */
    public function prompt(
        string $text,
        array $images = [],
        string $source = 'interactive',
        ?string $streamingBehavior = null,
        ?Closure $preflightResult = null,
        ?string $requestId = null,
    ): void {
        if ($requestId !== null) {
            $this->promptOnce($requestId, $preflightResult, fn (Closure $accepted) => $this->prompt($text, $images, $source, $streamingBehavior, $accepted));

            return;
        }

        if ($this->runHookCommand($text)) {
            if ($preflightResult !== null) {
                $preflightResult('handled');
            }

            return;
        }

        if ($streamingBehavior !== null && $this->isStreaming()) {
            if ($streamingBehavior !== 'steer' && $streamingBehavior !== 'followUp') {
                throw new AgentError("No such streamingBehavior: '{$streamingBehavior}'. There is steer and followUp.");
            }

            $disposition = $this->queueUserInput($text, $images, $streamingBehavior, $source);

            if ($preflightResult !== null) {
                $preflightResult($disposition);
            }

            return;
        }

        // Between two runs of the prompt in progress — a retry sleeping, a summary being written —
        // wait it out rather than refusing: it is seconds, and what was sent goes after whatever
        // the retry was rescuing. pig's own difference: upstream refuses here as it does mid-run.
        // The screen never gets here (it asks `isStreaming()` and queues), so this is for a
        // caller without a queue — RPC's `prompt`, `pig -p` with several messages.
        if ($this->runActive && !$this->agent->state->isStreaming && !$this->startingRun) {
            $this->waitForIdle();
        }

        if ($this->isStreaming()) {
            throw new AgentError("Agent is already processing. Specify streamingBehavior ('steer' or 'followUp') to queue the message.");
        }

        if ($this->model() === null) {
            throw new AgentError('No model selected.');
        }

        // Before the stored prompt is expanded, as upstream has it: an `input` handler sees
        // `/review foo.php`, which is what was typed, and not forty lines of template.
        $input = $this->runInputHandlers($text, $images, $source, null);

        if ($input === null) {
            if ($preflightResult !== null) {
                $preflightResult('handled');
            }

            return;
        }

        [$text, $images] = $input;
        $text = $this->expandFileCommand($text);

        // Returns when the prompt has settled — after its retries, its summary and whatever was
        // queued behind it — so `bin/pig -p` exits with the answer and not with the 503 before it.
        $this->startRun(
            ['messageType' => 'user', 'prompt' => $text, 'images' => $images],
            $preflightResult === null ? null : static fn () => $preflightResult('started'),
        );
    }

    /**
     * Start a run from a user or custom message — upstream's `_startRun()`. "The session counts as
     * busy from here on, so messages sent while before_agent_start handlers run are queued into this
     * run instead of starting another, and an abort requested meanwhile aborts the run as soon as it
     * exists" (at `agent_start`, `onAgentEvent()`).
     *
     * @param array{messageType: 'user', prompt: string, images: list<ImageContent>}|array{messageType: 'custom', message: CustomMessage} $trigger
     * @param (Closure(): void)|null $onStarted called once the run's messages are prepared, before the first request
     */
    private function startRun(array $trigger, ?Closure $onStarted = null): void
    {
        $this->runActive = true;
        $this->runAbortRequested = false;
        $this->idle ??= new Deferred();
        $this->startingRun = true;

        try {
            $messages = $this->prepareRun($trigger);
        } catch (Throwable $error) {
            $this->startingRun = false;
            $this->runActive = false;
            $this->flushBash();
            $this->flushPendingHookMessages();
            $this->resolveIdleWaitIfIdle();

            throw $error;
        }

        $this->startingRun = false;
        // "Messages held while the run was starting go before its starting messages, as they would
        // have while idle. No run exists yet, so they cannot split a tool call from its result."
        $this->flushBash();
        $this->flushPendingHookMessages();

        if ($onStarted !== null) {
            $onStarted();
        }

        $this->runAgentPrompt(fn () => $this->agent->prompt($messages), resetAbort: false);
    }

    /**
     * Prepare a run and return its starting messages — upstream's `_prepareRun()`: "compact first
     * when needed, emit before_agent_start, apply the run's prompt options and tool loadout, and
     * build the starting message followed by pending nextTurn messages (consumed here) and handler
     * messages, with a system patch first when the prompt changed."
     *
     * @param array{messageType: 'user', prompt: string, images: list<ImageContent>}|array{messageType: 'custom', message: CustomMessage} $trigger
     * @return list<mixed>
     */
    private function prepareRun(array $trigger): array
    {
        // Upstream's `_checkCompaction(lastAssistant, false)` before the run: a context already
        // past the threshold (or an aborted turn that filled it) is compacted first, in every
        // mode. The starting message is sent below, so nothing is continued from here.
        $lastAssistant = null;

        foreach (array_reverse($this->messages()) as $message) {
            if ($message instanceof AssistantMessage) {
                $lastAssistant = $message;

                break;
            }
        }

        if ($lastAssistant !== null) {
            $this->checkCompaction($lastAssistant, skipAbortedCheck: false);
        }

        // The handlers get the prompt options to change — upstream's `systemPromptOptions` — and
        // what they leave is this run's (`$runSystemPromptOptions`).
        $options = new SystemPromptOptions();
        $handlerMessages = $this->extensionRunner?->emitBeforeAgentStart($trigger, $options, $this->renderSystemPrompt(...)) ?? [];

        if ($trigger['messageType'] === 'custom') {
            $messages = [$trigger['message']];
        } else {
            // Upstream's `_normalizePromptImages()`, after the hooks and before the message is
            // built: every picture fitted inside the model's limits, and what was done to one said
            // after the text — an image that could not be fitted is left out and the sentence says so.
            [$images, $hints] = $this->normalizePromptImages($trigger['images']);
            $text = $hints !== [] ? $trigger['prompt'] . "\n\n" . implode("\n", $hints) : $trigger['prompt'];
            $messages = [new UserMessage([new TextContent($text), ...$images])];
        }

        // "Inject any pending nextTurn messages as context alongside the starting message."
        $messages = [...$messages, ...$this->pendingNextTurnMessages];
        $this->pendingNextTurnMessages = [];

        // Each handler's message, stamped now, as upstream builds them.
        foreach ($handlerMessages as $message) {
            $messages[] = new CustomMessage($message->customType, $message->content, $message->display, $message->details);
        }

        // Upstream's `updateMessage`, put in front (`messages.unshift(updateMessage)`): the prompt
        // sections that changed since the transcript last said them.
        $update = $this->preparePromptUpdate(null, $options);
        $this->runSystemPromptOptions = $options;

        return $update !== null ? [$update, ...$messages] : $messages;
    }

    /**
     * Run a hook's slash command, and say whether there was one.
     *
     * A handler that throws is reported as a hook error and still counts as handled: the command
     * was found and it ran, and sending the line to the model afterwards would ask it to make
     * sense of `/deploy`. Not fatal, because a command that failed is one command and the session
     * it failed in is still a session.
     */
    private function runHookCommand(string $text): bool
    {
        if ($this->extensionRunner === null || !str_starts_with($text, '/')) {
            return false;
        }

        $name = strtok(substr($text, 1), " \t") ?: '';
        $command = $this->extensionRunner->command($name);

        if ($command === null) {
            return false;
        }

        try {
            ($command->handler)(trim(substr($text, strlen($name) + 1)), $this->extensionRunner->context());
        } catch (Throwable $error) {
            $this->extensionRunner->emitError(new ExtensionError($command->extensionPath, "/{$name}", $error->getMessage()));
        }

        return true;
    }

    /**
     * A stored prompt in place of its own name, or the text unchanged.
     *
     * `SlashCommands::expand()` answers null for a line that names no file command, where
     * upstream's hands back the text it was given — so the `??` here is the translation and not
     * a fallback papering over a failure.
     */
    /**
     * Upstream's `convertToLlmWithBlockImages` body: images out of user messages and tool results,
     * each run of them one "Image reading is disabled." line.
     *
     * @param list<mixed> $messages
     * @return list<mixed>
     */
    public static function withoutImages(array $messages): array
    {
        $disabled = 'Image reading is disabled.';

        return array_map(static function (mixed $message) use ($disabled): mixed {
            if (!($message instanceof UserMessage || $message instanceof ToolResultMessage)) {
                return $message;
            }

            $images = array_filter($message->content, static fn (mixed $block): bool => $block instanceof ImageContent);

            if ($images === []) {
                return $message;
            }

            $content = [];

            foreach ($message->content as $block) {
                $block = $block instanceof ImageContent ? new TextContent($disabled) : $block;
                $last = $content === [] ? null : $content[count($content) - 1];

                if ($block instanceof TextContent && $block->text === $disabled
                    && $last instanceof TextContent && $last->text === $disabled) {
                    continue;
                }

                $content[] = $block;
            }

            return $message instanceof UserMessage
                ? new UserMessage($content, $message->timestamp)
                : new ToolResultMessage(
                    $message->toolCallId,
                    $message->toolName,
                    $content,
                    $message->isError,
                    $message->details,
                    $message->timestamp,
                    $message->usage,
                );
        }, $messages);
    }

    /**
     * @param list<ImageContent> $images
     * @return array{0: list<ImageContent>, 1: list<string>}
     */
    private function normalizePromptImages(array $images): array
    {
        $normalized = [];
        $hints = [];

        foreach ($images as $image) {
            $bytes = base64_decode($image->data, true);
            $processed = ImageProcess::process(
                $bytes === false ? '' : $bytes,
                $image->mimeType,
                $this->settings?->imageAutoResize() ?? true,
                $this->limitsModel()?->inputLimits['images']['resize'] ?? null,
            );

            if (!$processed['ok']) {
                $hints[] = $processed['message'];

                continue;
            }

            $normalized[] = new ImageContent($processed['data'], $processed['mimeType']);
            $hints = [...$hints, ...$processed['hints']];
        }

        return [$normalized, $hints];
    }

    /**
     * What the `input` handlers made of a message, or null when one of them took it.
     * Upstream's `_runInputHandlers()`.
     *
     * @param list<ImageContent>      $images
     * @param 'steer'|'followUp'|null $streaming
     * @return array{0: string, 1: list<ImageContent>}|null
     */
    private function runInputHandlers(string $text, array $images, string $source, ?string $streaming): ?array
    {
        if ($this->extensionRunner === null) {
            return [$text, $images];
        }

        $result = $this->extensionRunner->emitInput(new InputEvent($text, $images, $source, $streaming));

        return match ($result->action) {
            'handled' => null,
            'transform' => [(string) $result->text, $result->images ?? $images],
            default => [$text, $images],
        };
    }

    private function expandFileCommand(string $text): string
    {
        $text = $this->expandSkillCommand($text);

        return SlashCommands::expand($text, $this->fileCommands) ?? $text;
    }

    /** @return list<Skill> the skills the system prompt names, as `/skill:name` reaches them */
    public function skills(): array
    {
        return $this->loadout?->skills() ?? [];
    }

    /**
     * Upstream's `_expandSkillCommand()`: `/skill:name args` becomes the skill's instructions in a
     * `<skill>` block, the arguments after it. Before the file commands, as upstream orders the two,
     * and whatever `enableSkillCommands` says — that setting is about the list, and a command typed
     * by hand still works. An unknown name is the text as it was; a file that cannot be read is
     * reported as a hook error would be and leaves the text as it was.
     */
    private function expandSkillCommand(string $text): string
    {
        if (!str_starts_with($text, '/skill:')) {
            return $text;
        }

        $space = strpos($text, ' ');
        $name = $space === false ? substr($text, 7) : substr($text, 7, $space - 7);
        $args = $space === false ? '' : trim(substr($text, $space + 1));
        $skill = null;

        foreach ($this->skills() as $candidate) {
            if ($candidate->name === $name) {
                $skill = $candidate;

                break;
            }
        }

        if ($skill === null) {
            return $text;
        }

        $content = is_readable($skill->path) ? file_get_contents($skill->path) : false;

        if ($content === false) {
            $this->extensionRunner?->emitError(new ExtensionError($skill->path, 'skill_expansion', "Could not read {$skill->path}"));

            return $text;
        }

        $body = trim(Skills::stripFrontmatter($content));
        $block = "<skill name=\"{$skill->name}\" location=\"{$skill->path}\">\nReferences are relative to {$skill->baseDir}.\n\n{$body}\n</skill>";

        return $args !== '' ? "{$block}\n\n{$args}" : $block;
    }

    /**
     * Put a hook's message in the conversation — upstream's `sendCustomMessage()`, branch for branch:
     *
     * - `deliverAs: 'nextTurn'`: held for the next run, beside its starting message.
     * - **Working**, and `triggerTurn` not false: steered in, or queued as a follow-up with
     *   `deliverAs: 'followUp'`.
     * - **Idle, and asked to trigger a turn**: a run started from it (`startRun()`), through
     *   `before_agent_start` like a prompt — a `session_start` hook that says "carry on where the
     *   last session left off" needs the turn as well as the message.
     * - **Working, `triggerTurn` false**: held until the turn ends — "appending now would put the
     *   message between an assistant tool call and its result, which providers that validate
     *   message order reject on replay".
     * - **Idle, not asked**: appended and left there, for the next thing anyone says.
     *
     * @param 'steer'|'followUp'|'nextTurn'|null $deliverAs
     */
    public function sendHookMessage(CustomMessage $message, ?bool $triggerTurn = null, ?string $deliverAs = null): void
    {
        if ($deliverAs === 'nextTurn') {
            $this->pendingNextTurnMessages[] = $message;

            return;
        }

        if ($this->isStreaming() && $triggerTurn !== false) {
            // Handed to the agent, which is the whole of what queuing means — and *not* added to
            // `$this->followUps`, which is upstream's choice too: that list is what a person typed,
            // it is what `clearQueue()` hands back to the editor.
            $deliverAs === 'followUp' ? $this->agent->followUp($message) : $this->agent->steer($message);

            return;
        }

        // pig's own guard, kept from before: an empty message has nothing to answer, and a run
        // started from it would send a request with an empty message in it (`toLlm()` drops it).
        if ($triggerTurn === true && $message->isEmpty()) {
            $this->appendHookMessage($message);

            return;
        }

        if ($triggerTurn === true) {
            // Asked for while the hooks hear `agent_settled`: after them, as upstream defers it —
            // its own run, with its own settle, once the one settling now has finished settling.
            if ($this->emittingSettled) {
                $this->deferredSettledActions[] = fn () => $this->sendHookMessage($message, $triggerTurn, $deliverAs);

                return;
            }

            // Spawned, because the caller is a hook's handler and `sendMessage()` does not wait for a
            // turn. Busy from now rather than from when the fiber starts, as upstream's flag is set
            // before its first `await`: a prompt sent in that tick would race this one into the agent.
            $this->runActive = true;
            $this->idle ??= new Deferred();

            Async::spawn(function () use ($message): void {
                try {
                    $this->startRun(['messageType' => 'custom', 'message' => $message]);
                } catch (Throwable $problem) {
                    // Nobody awaits this fiber, so the hook that asked is told — the same channel
                    // as a handler that threw. Without hooks there is no one to tell, and the throw
                    // goes to the spawned future as it is.
                    if ($this->extensionRunner === null) {
                        throw $problem;
                    }

                    $this->extensionRunner->emitError(new ExtensionError('<session>', 'sendMessage', $problem->getMessage()));
                }
            });

            return;
        }

        if ($this->isStreaming()) {
            $this->pendingHookMessages[] = $message;

            return;
        }

        $this->appendHookMessage($message);
    }

    /** Upstream's `_appendCustomMessage()`: into the conversation and the file, and told to the listeners. */
    private function appendHookMessage(CustomMessage $message): void
    {
        $this->agent->appendMessage($message);
        $this->store?->append($message);

        foreach ($this->listeners as $listener) {
            $listener(new MessageEndEvent($message));
        }
    }

    /**
     * Upstream's `_flushPendingCustomMessages()`: "Append custom messages queued while the agent was
     * running. Called once the current turn's tool results are in agent state and session history."
     */
    private function flushPendingHookMessages(): void
    {
        $pending = $this->pendingHookMessages;
        $this->pendingHookMessages = [];

        foreach ($pending as $message) {
            $this->appendHookMessage($message);
        }
    }

    /**
     * Write a hook's note into the session file, outside the conversation.
     *
     * Nothing happens when the session is not being saved: the whole point of one of these
     * is that it is still there next time, and there is no next time for `--no-session`.
     */
    public function appendHookEntry(string $customType, mixed $data = null): void
    {
        $this->store?->appendCustomEntry($customType, $data);
        $this->announceAppendedEntry();
    }

    /**
     * Cut in while the agent is working.
     *
     * Delivered after the tool that is running now, which is what someone means by
     * typing "no, the other file" mid-run.
     *
     * A file command is expanded on the way to the agent and **kept as it was typed** in the
     * queue: the list is what `clearQueue()` hands back to the editor, and putting a forty-line
     * stored prompt in front of somebody who typed `/review foo.php` is not putting their text
     * back. Upstream queues the raw line at both ends, so the model there is handed the literal
     * `/review foo.php` whenever the command was typed during a turn.
     *
     * Upstream's `steer(text, images, {source})`: the pictures go with the words, and a hook's
     * command is refused rather than queued.
     *
     * @param list<ImageContent> $images
     * @return 'handled'|'queued' upstream's `QueuedInputDisposition`
     * @throws AgentError for a hook's command
     */
    public function steer(string $text, array $images = [], string $source = 'interactive'): string
    {
        return $this->queueUserInput($text, $images, 'steer', $source);
    }

    /**
     * Upstream's `_queueUserInput()`, the one body of `steer()` and `followUp()`: a hook's command
     * is refused (it is code, not a message, and has nothing to wait behind — `prompt()` runs it),
     * the `input` handlers see what was typed, and what is left is queued.
     *
     * @param list<ImageContent> $images
     * @param 'steer'|'followUp' $behavior
     * @return 'handled'|'queued' upstream's `QueuedInputDisposition`: `handled` when an `input`
     *         handler consumed it, `queued` otherwise — including after a handler transformed it
     * @throws AgentError for a hook's command
     */
    private function queueUserInput(string $text, array $images, string $behavior, string $source): string
    {
        if (str_starts_with($text, '/')) {
            $this->throwIfHookCommand($text);
        }

        $input = $this->runInputHandlers($text, $images, $source, $this->isStreaming() ? $behavior : null);

        if ($input === null) {
            return 'handled';
        }

        [$text, $images] = $input;
        $message = new UserMessage([new TextContent($this->expandFileCommand($text)), ...$images]);

        if ($behavior === 'steer') {
            $this->steering[] = $text;
            $this->announceQueue();
            $this->agent->steer($message);
        } else {
            $this->followUps[] = $text;
            $this->announceQueue();
            $this->agent->followUp($message);
        }

        return 'queued';
    }

    /** Upstream's `_throwIfExtensionCommand()`, with its words. */
    private function throwIfHookCommand(string $text): void
    {
        $name = strtok(substr($text, 1), " \t") ?: '';

        if ($this->extensionRunner?->command($name) !== null) {
            throw new AgentError("Extension command \"/{$name}\" cannot be queued. Use prompt() or execute the command when not streaming.");
        }
    }

    /** Upstream's `_emitQueueUpdate()`: both queues, whole. */
    private function announceQueue(): void
    {
        $this->announce(new QueueUpdateEvent($this->steering, $this->followUps));
    }

    /**
     * Whether steering messages go over one at a time or all together.
     *
     * Upstream's pairs, and the settings write is upstream's too: `agent-session.ts` tells the
     * agent and the settings manager in the same method, so the choice survives the session it
     * was made in.
     */
    public function steeringMode(): QueueMode
    {
        return $this->agent->steeringMode();
    }

    public function setSteeringMode(QueueMode $mode): void
    {
        $this->agent->setSteeringMode($mode);
        $this->settings?->setSteeringMode($mode);
    }

    /** Whether follow-up messages go over one at a time or all together, once the agent stops. */
    public function followUpMode(): QueueMode
    {
        return $this->agent->followUpMode();
    }

    public function setFollowUpMode(QueueMode $mode): void
    {
        $this->agent->setFollowUpMode($mode);
        $this->settings?->setFollowUpMode($mode);
    }

    /**
     * Queue something for after the agent has finished the request it is on — upstream's
     * `followUp()`, which is `steer()`'s body with the other queue.
     *
     * @param list<ImageContent> $images
     * @return 'handled'|'queued'
     */
    public function followUp(string $text, array $images = [], string $source = 'interactive'): string
    {
        return $this->queueUserInput($text, $images, 'followUp', $source);
    }

    /** @return list<string> everything waiting, steering first */
    public function queued(): array
    {
        return [...$this->steering, ...$this->followUps];
    }

    /**
     * The same, kept apart — upstream's `getSteeringMessages()` / `getFollowUpMessages()`.
     *
     * The screen labels the two differently (`Steering:` cuts in after the current tool,
     * `Follow-up:` waits for the turn to end), so it needs to know which is which.
     *
     * @return array{steering: list<string>, followUp: list<string>}
     */
    public function queuedByKind(): array
    {
        return ['steering' => $this->steering, 'followUp' => $this->followUps];
    }

    /**
     * Throw the queue away and hand it back.
     *
     * Returned rather than dropped so the editor can put the text back in front of the
     * person who typed it — losing what someone wrote because they pressed Escape is
     * the kind of thing that stops people trusting the queue at all.
     *
     * @return list<string>
     */
    public function clearQueue(): array
    {
        $queued = $this->queued();
        $this->steering = [];
        $this->followUps = [];
        $this->agent->clearAllQueues();
        $this->announceQueue();

        return $queued;
    }

    /** Stop the prompt in progress; resolves once the session is idle. Upstream's `abort()`. */
    public function abort(): Future
    {
        // The prompt's post-run loop stops too: escape is not "this run", it is "this request",
        // and a queued message or a retry must not carry it on afterwards.
        if ($this->runActive) {
            $this->runAbortRequested = true;
        }

        // Before the agent, because neither of these has an agent to interrupt: a retry that is
        // sleeping and a summariser that is running both happen *between* runs, with the last one
        // over and the next one not started. Escape has to reach all three, and reaching them from
        // here rather than from each caller is what stops a caller reaching two and stopping.
        // Upstream's escape handler calls `abortCompaction()` itself, beside `abort()`.
        $this->abortRetry();
        $this->abortCompaction();
        $this->agent->abort();

        return $this->idleFuture();
    }

    /** Drop one copy of $text, steering first — the order it would be sent in. */
    private function dequeue(string $text): void
    {
        $at = array_search($text, $this->steering, true);

        if ($at !== false) {
            array_splice($this->steering, (int) $at, 1);
            $this->announceQueue();

            return;
        }

        $at = array_search($text, $this->followUps, true);

        if ($at !== false) {
            array_splice($this->followUps, (int) $at, 1);
            $this->announceQueue();
        }
    }

    // ---- running a command yourself ---------------------------------------------------

    /** Whether a `!` command is running right now. */
    public function isBashRunning(): bool
    {
        return $this->bash !== null;
    }

    /**
     * Run a command the person typed, and give them the result — upstream's `executeBash()`.
     *
     * Recorded either way, as upstream's `recordBashResult()` records it: `$excludeFromContext` is
     * `!!`, which keeps the command in the session and out of what the model is sent
     * (`CodingAgent::toLlm()`). It used to be `$remember`, the other way up, and a `!!` was not
     * written anywhere — so the transcript and the session file lost a command the person ran.
     *
     * Each piece of output is announced as a `BashExecutionUpdateEvent` carrying `$id`, upstream's
     * `bash_execution_update`; `$onOutput` is the tail so far, for a screen that redraws a card.
     *
     * @param Closure(string): void|null $onOutput called with the output so far as it arrives
     * @param string|null $id what the update events name this command by — RPC's command id
     */
    public function executeBash(string $command, bool $excludeFromContext = false, ?Closure $onOutput = null, ?string $id = null): BashExecution
    {
        if ($this->bash !== null) {
            throw new AgentError('A command is already running. Press esc to stop it first.');
        }

        // A hook may run it somewhere else — a container, a remote box — and hand back what
        // came of it. A hook that throws stops it here: falling back to running the command on
        // this machine is exactly what such a hook exists to prevent. Upstream's rule.
        $handled = $this->extensionRunner?->emitUserBash(new UserBashEvent($command, $excludeFromContext, $this->cwd));

        if ($handled !== null) {
            $result = $handled->result;
            $execution = $result->excludeFromContext === $excludeFromContext ? $result : new BashExecution(
                $result->command,
                $result->output,
                $result->exitCode,
                $result->cancelled,
                $result->truncated,
                $result->fullOutputPath,
                $result->timestamp,
                $excludeFromContext,
            );
            $this->append($execution);

            return $execution;
        }

        $this->bash = new AbortController();

        try {
            // Run hands its callback the partial output as a tool result, which is what
            // its other caller wants; here the text is enough.
            $onUpdate = $onOutput === null ? null : static function (AgentToolResult $partial) use ($onOutput): void {
                $block = $partial->content[0] ?? null;
                $onOutput($block instanceof TextContent ? $block->text : '');
            };

            // Upstream's `executeBash()`: `shellCommandPrefix` in front of the command, joined by a
            // newline — the command itself is what is recorded.
            $prefix = $this->settings?->shellCommandPrefix();
            $run = new Run(
                $this->cwd,
                $prefix !== null ? "{$prefix}\n{$command}" : $command,
                $onUpdate,
                onChunk: fn (string $delta) => $this->announce(new BashExecutionUpdateEvent($id, $delta)),
                spillDirectory: $this->scratch,
            );
            $run->start();
            $exit = $run->wait($this->bash->signal, null);
            $truncation = Truncate::tail($run->output());

            $execution = new BashExecution(
                $command,
                $truncation->content,
                $run->aborted ? null : $exit,
                $run->aborted,
                $truncation->truncated,
                $run->spillPath,
                excludeFromContext: $excludeFromContext,
            );
        } finally {
            $this->bash = null;
        }

        $this->append($execution);

        return $execution;
    }

    /** Stop the running command. Does nothing when none is. */
    public function abortBash(): void
    {
        $this->bash?->abort('Cancelled');
    }

    /**
     * Put it in the conversation — now, or once the agent has finished.
     *
     * A message added mid-run lands between a tool call and its result, and a provider
     * that sees those two separated rejects the whole request. So anything that arrives
     * while the agent is working waits for it to stop.
     */
    private function append(BashExecution $execution): void
    {
        if ($this->isStreaming()) {
            $this->pendingBash[] = $execution;

            return;
        }

        $this->agent->appendMessage($execution);

        // Appended directly rather than through a turn, so there is no message_end to
        // carry it to the file.
        $this->store?->append($execution);
    }

    /** @return list<BashExecution> what was held back, now in the conversation */
    private function flushBash(): array
    {
        $held = $this->pendingBash;
        $this->pendingBash = [];

        foreach ($held as $execution) {
            $this->agent->appendMessage($execution);
            $this->store?->append($execution);
        }

        return $held;
    }

    // ---- leaving this conversation ----------------------------------------------------

    /**
     * Throw this conversation away and start another.
     *
     * The checks live here rather than in the modes because that is what having them in one
     * mode and not the other cost: `/new` in the terminal asked the hooks first, and RPC's
     * `new_session` did not, so a hook that refused to leave a conversation worked for a
     * person and was ignored by a host. Neither of them emptied the queue, so text typed
     * into the conversation being thrown away was still waiting to be sent in the one that
     * replaced it. `goTo()` below already put its guards inside for the same reason: a rule
     * a caller has to remember is a rule the next caller will not.
     *
     * The new file is created before anything is thrown away, which upstream does the other
     * way round. If the directory is unwritable, the throw leaves this session exactly as it
     * was rather than aborted, emptied and still writing to the old file.
     *
     * Not the UI's share of the work: clearing the screen, saying "New session", and telling
     * the custom tools stay with the caller, which is where the screen and the tools are.
     *
     * `$parentSession` is upstream's `NewSessionOptions.parentSession`: the file this one is
     * descended from, written on the new header for a host tracking lineage (RPC's `new_session`).
     *
     * @throws \Throwable when a new session file cannot be created
     */
    public function startNew(?string $parentSession = null): SessionSwitch
    {
        $previous = $this->store?->path;

        // `'new'` rather than `'resume'`: a hook that refuses to leave a conversation usually
        // cares *why* it is being left, and upstream passes the same two words.
        $refusal = $this->extensionRunner?->emitBeforeSwitch(new SessionBeforeSwitchEvent('new'));

        if ($refusal !== null && $refusal->cancel) {
            return new SessionSwitch(switched: false, previous: $previous);
        }

        // A new file, not just an empty screen. Keeping the old one would append this
        // conversation onto the last one as if they were the same, and the new session would
        // never exist as a session — which is what this used to do. Only when this session
        // was being written at all: `--no-session` means no file, and `/new` should not start
        // saving.
        $fresh = $previous === null ? null : SessionManager::create($this->cwd, parentSession: $parentSession);

        // Unconditionally, as upstream does, because `isStreaming()` is the narrower question:
        // a retry that is sleeping is not streaming, and `abort()`'s own docblock says why it
        // has to reach both. Asked only when streaming, a `/new` pressed during those seconds
        // left the retry running — and what it woke up to rescue was a turn from the
        // conversation just walked away from, in an agent that had since been emptied.
        $this->abort()->await();
        $this->clearQueue();

        // Upstream tears the whole runtime down and builds a new one, so its hooks hear
        // `session_shutdown` with the target and then `session_start` with the previous file.
        // pig keeps the same hooks across the switch and tells them the same two things.
        $this->extensionRunner?->emit(new SessionShutdownEvent('new', $fresh?->path));

        if ($fresh !== null) {
            $this->writeTo($fresh);
        } else {
            // Upstream's `SessionManager.inMemory(this.cwd)` for `/new` without a file: a new
            // conversation is a new session, with an id of its own.
            $this->memoryId = SessionManager::createSessionId();
            $this->memoryCreatedAt = Timestamp::nowMs();
            $this->agent->sessionId = $this->memoryId;
        }

        // Upstream's `_refreshFinalizedContext()` reads the new, empty file: nothing, not even the
        // prompt — `reset()` alone keeps the replayed prompt and tool baseline. The next prompt
        // declares both again, so the new file starts with them as the old one did.
        $this->agent->reset();
        $this->agent->clearMessages();
        $this->extensionRunner?->emit(new SessionStartEvent('new', $previous));
        $this->tellSwitched('new', $previous);

        return new SessionSwitch(switched: true, previous: $previous);
    }

    /**
     * Open another conversation and carry on in it.
     *
     * The file is opened before the turn in flight is stopped, so a path that is not a
     * session costs nothing: nothing has moved when it throws. After that the order is
     * upstream's — whatever was in flight belongs to the conversation being left, and so
     * does whatever was queued, so both end here rather than crossing over.
     *
     * Aborted rather than refused, which is also upstream's choice: someone who asks to
     * switch has decided. The terminal never had to abort because `/resume` is unreachable
     * while streaming; a host has no such guard, and that asymmetry is exactly why this is
     * one method now.
     *
     * **The session carries on in its own working directory**, as upstream's `switchSession()`
     * does: a conversation from another project (the picker's "All" scope, `/import`, RPC's
     * `switch_session`) is resumed *there*. A directory that has gone is `MissingSessionCwdError`,
     * thrown before anything is torn down, so the caller can ask and try again with `$cwdOverride`
     * (upstream's `cwdOverride`). Everything bound to a directory — the tools, the context files,
     * `SYSTEM.md`, the project's settings, its trust, its hooks and extensions — belongs to that
     * directory, so upstream builds the whole runtime again for it; here that is `$relocate`, the
     * caller's runtime factory (`bin/pig` builds it around `CodingAgent::session()`): this session
     * is shut down and disposed, the factory opens the file in a new one for the new directory,
     * and `SessionSwitch::$replacement` hands it back for the caller to carry on with. Without a
     * factory (a library caller, a test) the session switches in place and keeps its directory.
     *
     * @param (Closure(string, SessionManager): \Pig\CodingAgent\StartedSession)|null $relocate
     *        the cwd to build for and the opened session file
     * @throws MissingSessionCwdError when the session's working directory no longer exists
     * @throws \Throwable when there is no such session file
     */
    public function switchTo(string $path, ?string $cwdOverride = null, ?Closure $relocate = null): SessionSwitch
    {
        $previous = $this->store?->path;

        $refusal = $this->extensionRunner?->emitBeforeSwitch(new SessionBeforeSwitchEvent('resume', $path));

        if ($refusal !== null && $refusal->cancel) {
            return new SessionSwitch(switched: false, previous: $previous);
        }

        $opened = SessionManager::open($path, $cwdOverride);
        SessionCwd::assertExists($opened, $this->cwd);

        // Unconditional, for `startNew()`'s reason: a sleeping retry is not streaming either.
        $this->abort()->await();
        $this->clearQueue();
        $this->extensionRunner?->emit(new SessionShutdownEvent('resume', $opened->path));

        // Another directory: upstream's `teardownCurrent()` then `createRuntime({cwd: …})`. The
        // replacement resumes the file itself and hears `session_start` from the caller, once it
        // has been given a screen.
        if ($relocate !== null && $opened->cwd !== '' && $opened->cwd !== $this->cwd) {
            $this->dispose();
            $replacement = $relocate($opened->cwd, $opened);
            $said = array_filter($replacement->session->messages(), static fn (mixed $message): bool => !$message instanceof SystemMessage);

            return new SessionSwitch(switched: true, previous: $previous, messages: count($said), replacement: $replacement);
        }

        // The file that was opened is the one written to from here on. Without this the
        // conversation on screen is the resumed one while everything said next is appended
        // to the file pig started with — two files, neither of them what happened.
        if ($previous !== null) {
            $this->writeTo($opened);
        }

        $this->restore($opened->messages());

        // And what it was being had with. Nothing was typed here — resuming takes no model —
        // so the file wins outright, which is what "resume" means.
        $this->restoreSettings();
        $this->extensionRunner?->emit(new SessionStartEvent('resume', $previous));
        $this->tellSwitched('resume', $previous);

        // The messages somebody would count: a system message is prompt state, not something said.
        $said = array_filter($opened->messages(), static fn (mixed $message): bool => !$message instanceof SystemMessage);

        return new SessionSwitch(switched: true, previous: $previous, messages: count($said));
    }

    /**
     * Fork a branch of this conversation into a session file of its own — upstream's `fork()`.
     *
     * `/tree` moves inside one file; this is for when one branch should become a conversation
     * of its own, resumable and listed on its own. The new file holds the path from the root to
     * the chosen point and names this file as its parent (`SessionManager::fork()`), and the
     * conversation carries on there: the hook is asked, the turn in flight and the queue end here
     * as they do for `switchTo()`, and the hooks hear `session_shutdown` then `session_start` with
     * the reason `fork`.
     *
     * **`before` goes back to before the chosen point**, which has to be something somebody said:
     * the message leaves the conversation and its words come back in `SessionSwitch::$editorText`
     * to be asked differently — `goTo()`'s rule, in a new file. A user message that opened the
     * conversation forks to an empty session, as upstream's does. **`at` ends the fork on the
     * point itself**, which is what `/clone` is: this conversation as it stands, in a second
     * file.
     *
     * Not for a session that is not being written down: upstream forks one in memory, and pig
     * has no second in-memory conversation to put it in — `--no-session` means there is nothing to
     * fork from, as there is nowhere to go back to.
     *
     * @param 'before'|'at' $position
     * @throws AgentError when there is no session on disk, nothing has been answered yet, there is
     *                    no such point, or `before` was asked of a point nobody said
     */
    public function fork(string $entryId, string $position = 'before'): SessionSwitch
    {
        if ($this->store === null) {
            throw new AgentError('This session is not being saved, so there is nothing to fork.');
        }

        if (!$this->store->isPersisted()) {
            // Upstream's sentence: a file that does not exist yet has no path to copy.
            throw new AgentError('This session has not been saved yet. Send a message before cloning or forking it.');
        }

        $previous = $this->store->path;

        $refusal = $this->extensionRunner?->emitBeforeFork(new SessionBeforeForkEvent($entryId, $position));

        if ($refusal !== null && $refusal->cancel) {
            return new SessionSwitch(switched: false, previous: $previous);
        }

        $entry = $this->store->entry($entryId);

        if ($entry === null) {
            throw new AgentError('No such point in this conversation.');
        }

        $editorText = null;

        if ($position === 'at') {
            $leaf = $entryId;
        } else {
            if (!$entry['message'] instanceof UserMessage) {
                throw new AgentError('Only something you said can be forked from.');
            }

            // A root's parent is written as its own id in a pi file.
            $leaf = $entry['parent'] === $entryId ? null : $entry['parent'];
            $editorText = self::textOf($entry['message']);
        }

        // The file is made before anything is thrown away, as `startNew()` makes its: a path
        // that cannot be written costs this conversation nothing.
        $forked = $leaf === null
            ? SessionManager::create($this->cwd, parentSession: $previous)
            : $this->store->fork($leaf);

        $this->abort()->await();
        $this->clearQueue();
        $this->extensionRunner?->emit(new SessionShutdownEvent('fork', $forked->path));

        $this->writeTo($forked);
        $this->restore($forked->messages());
        $this->restoreSettings();
        $this->extensionRunner?->emit(new SessionStartEvent('fork', $previous));
        $this->tellSwitched('fork', $previous);

        $said = array_filter($forked->messages(), static fn (mixed $message): bool => !$message instanceof SystemMessage);

        return new SessionSwitch(switched: true, previous: $previous, messages: count($said), editorText: $editorText);
    }

    /**
     * Every message somebody typed, on any branch, in file order, with its text — upstream's
     * `getUserMessagesForForking()`, which is what `/fork`'s list is made of. Every branch, not
     * the one being talked on: a fork is how an abandoned branch becomes a conversation again.
     *
     * @return list<array{entryId: string, text: string}>
     */
    public function userMessagesForForking(): array
    {
        $found = [];

        foreach ($this->store?->everyUserMessage() ?? [] as $point) {
            $text = self::textOf($point['message']);

            if ($text !== '') {
                $found[] = ['entryId' => $point['id'], 'text' => $text];
            }
        }

        return $found;
    }

    /**
     * Go back to an earlier point in the conversation.
     *
     * The session file keeps every branch, so this is a move rather than a deletion: the
     * road not taken is still there, and going back to it is the same call again.
     *
     * **Going back to something somebody said goes back to before it.** The leaf lands on that
     * message's parent, so the message leaves the conversation, and its words come back in
     * `TreeJump::$editorText` for the caller to put in the prompt — which is what going back to a
     * question is for: asking it differently. Upstream's `navigateTree()` does this and pig did
     * not: it moved the leaf *onto* the message, so the old wording stayed in the conversation and
     * the only way to re-ask was to type it again. Any other point — an answer, a summary, a
     * command's output — is where the leaf lands, as before.
     *
     * A `session_before_tree` hook that cancels is `TreeJump::$cancelled`, not an exception.
     *
     * @throws AgentError when there is no session on disk, no such point, or a summary was asked
     *                    for with no model to write it
     */
    public function goTo(
        ?string $entryId,
        bool $summarise = false,
        ?string $instructions = null,
        ?AbortSignal $signal = null,
        ?bool $replaceInstructions = null,
        ?string $label = null,
    ): TreeJump {
        if ($this->store === null) {
            throw new AgentError('This session is not being saved, so there is nowhere to go back to.');
        }

        if ($this->isStreaming()) {
            throw new AgentError('Agent is working. Let it finish, or press esc, then go back.');
        }

        $oldLeaf = $this->store->leaf();

        [$target, $editorText] = $this->target($entryId);

        // Already here: nothing to leave behind, nothing to summarise, and no hook to bother with
        // it. Upstream's first guard, and `moved: false` with `aborted: false` is the answer that
        // says so — a caller must not read it as the summary having been called off.
        if ($target === $oldLeaf && $editorText === null) {
            return new TreeJump(moved: false);
        }

        // Refused rather than moved without one: somebody who asked for the branch to be written
        // down and got the move without the summary has lost the branch. Upstream throws here too.
        if ($summarise && $this->model() === null) {
            throw new AgentError('No model to write the summary with.');
        }

        // Upstream's `collectEntriesForBranchSummary()`: from the old leaf back to the deepest
        // entry the two positions share. Read before the move, and read even when nothing asked
        // for a summary: a hook is told what is being left behind whether or not anyone is
        // writing it down.
        $collected = BranchSummarization::collectEntriesForBranchSummary($this->store, $oldLeaf, $entryId);

        // One controller, with the caller's signal forwarded into it, so the hook and the
        // summariser have one `aborted()` to ask — as `compactNow()` does.
        $controller = new AbortController();

        if ($signal?->aborted() === true) {
            $controller->abort('Cancelled');
        }

        $listener = $signal?->onAbort(static fn () => $controller->abort('Cancelled'));

        try {
            $answer = $this->extensionRunner?->emitBeforeTree(new SessionBeforeTreeEvent(
                new TreePreparation(
                    $entryId,
                    $oldLeaf,
                    $collected->commonAncestorId,
                    $collected->entries,
                    $summarise,
                    $instructions,
                    $replaceInstructions,
                    $label,
                ),
                $controller->signal,
            ));

            // Upstream's `if (result?.cancel) return { cancelled: true }`: a hook saying no is an
            // answer, and nothing has moved.
            if ($answer !== null && $answer->cancel) {
                return new TreeJump(moved: false, cancelled: true);
            }

            // A hook's prose is used only when a summary was asked for — upstream's condition. The
            // hook is told whether anyone wants one, so one that answers with prose anyway has
            // misread the event, and writing it into the conversation would be a branch summary
            // nobody asked for. Its overrides of the summariser's instructions and the label apply
            // either way.
            $fromExtension = $summarise && $answer?->summary !== null;
            $instructions = $answer?->customInstructions ?? $instructions;
            $replaceInstructions = $answer?->replaceInstructions ?? $replaceInstructions;
            $label = $answer?->label ?? $label;

            $summary = null;

            if ($fromExtension) {
                $given = $answer->summary;
                $details = is_array($given['details'] ?? null) ? $given['details'] : [];
                $summary = new BranchSummary(
                    (string) ($given['summary'] ?? ''),
                    self::fileList($details['readFiles'] ?? []),
                    self::fileList($details['modifiedFiles'] ?? []),
                    $oldLeaf,
                    fromHook: true,
                    usage: ($given['usage'] ?? null) instanceof Usage ? $given['usage'] : null,
                );
            } elseif ($summarise && $collected->entries !== []) {
                $summary = $this->generateBranchSummary($collected->entries, $oldLeaf, $instructions, $replaceInstructions, $controller->signal);

                // Cancelled part-way through summarising: nothing has moved, and the caller is
                // meant to put the person back where they were rather than jump without the
                // summary they asked for.
                if ($summary === null) {
                    return new TreeJump(moved: false, aborted: true, cancelled: true);
                }
            }
        } finally {
            if ($listener !== null) {
                $signal?->removeListener($listener);
            }
        }

        $this->store->goTo($target);

        // After the move, so it lands on the branch being joined — which is the whole point: it
        // is context for carrying on here, not a note on the branch it describes. Upstream's
        // `branchWithSummary()`; an empty summary is not written, as upstream's `if (summaryText)`.
        if ($summary !== null && $summary->summary !== '') {
            $this->store->append($summary);
        } else {
            $summary = null;
        }

        // The label goes on the summary when there is one, and on the point gone to otherwise —
        // upstream's two `appendLabelChange()` calls.
        if ($label !== null && $label !== '') {
            $labelled = $summary !== null ? $this->store->leaf() : $entryId;

            if ($labelled !== null) {
                $this->store->appendLabel($labelled, $label);
            }
        }

        // Upstream's `navigateTree()`: the branch's loadout, whatever the tools came from at startup.
        $this->agent->replaceMessages($this->store->messages());
        $this->restoreToolsFromTranscript();

        $this->extensionRunner?->emit(new SessionTreeEvent(
            $this->store->leaf(),
            $oldLeaf,
            $summary,
            $summary !== null ? $fromExtension : null,
        ));

        return new TreeJump(moved: true, summary: $summary, editorText: $editorText);
    }

    /**
     * A file list a hook handed over, as the strings it should be.
     *
     * @return list<string>
     */
    private static function fileList(mixed $paths): array
    {
        if (!is_array($paths)) {
            throw new AgentError('A hook\'s summary details must give readFiles and modifiedFiles as lists of paths.');
        }

        return array_values(array_map(static fn (mixed $path): string => is_string($path)
            ? $path
            : throw new AgentError('A hook\'s summary details must give readFiles and modifiedFiles as lists of paths.'), $paths));
    }

    /**
     * Where the leaf lands for a chosen point, and what goes back into the prompt.
     *
     * A message somebody said — theirs, or a hook's — resolves to the point *before* it, because
     * going back to a question means being able to ask it differently: the message leaves the
     * conversation and its words are handed back. Everything else resolves to itself.
     *
     * A hook's message is treated as upstream treats it, which is the same way: nothing is sent
     * from here, so the text is offered for editing rather than re-sent as the person's own — and
     * dropping the message while keeping nothing of it would lose it for no reason.
     *
     * An id this file has not got is passed through untouched, so `SessionManager::goTo()` is the
     * one place that refuses it by name.
     *
     * @return array{0: string|null, 1: string|null}
     */
    private function target(?string $entryId): array
    {
        $entry = $entryId === null ? null : $this->store?->entry($entryId);

        if ($entry === null) {
            return [$entryId, null];
        }

        $message = $entry['message'];

        if (!$message instanceof UserMessage && !$message instanceof CustomMessage) {
            return [$entryId, null];
        }

        return [
            // A root's parent is written as its own id in a pi file, and the point before a root
            // is the empty conversation.
            $entry['parent'] === $entryId ? null : $entry['parent'],
            $message instanceof UserMessage ? self::textOf($message) : $message->toText(),
        ];
    }

    /**
     * The model's summary of the branch being left — upstream's `generateBranchSummary()` call in
     * `navigateTree()`, routed first because a summary sizes its input and output from the model
     * it gets, with `branchSummary.reserveTokens` (upstream's own setting for this, not
     * compaction's) and the session's stream function, retry policy and retry announcements.
     *
     * @param list<SessionEntry> $entries
     * @return BranchSummary|null null when summarising was called off
     * @throws AgentError when the model failed
     */
    private function generateBranchSummary(
        array $entries,
        ?string $oldLeaf,
        ?string $instructions,
        ?bool $replaceInstructions,
        AbortSignal $signal,
    ): ?BranchSummary {
        // The routed level with the routed model, as upstream's `_getSummarizationRequestAuth()`.
        $direct = $this->directModel($this->model() ?? throw new AgentError('No model to write the summary with.'), $signal);
        $model = $direct->model;

        $result = BranchSummarization::generateBranchSummary(
            $entries,
            $model,
            $this->keyFor($model),
            signal: $signal,
            thinkingLevel: $direct->thinkingLevel,
            customInstructions: $instructions,
            replaceInstructions: $replaceInstructions,
            reserveTokens: $this->settings?->branchSummaryReserveTokens(BranchSummarization::RESERVE_TOKENS) ?? BranchSummarization::RESERVE_TOKENS,
            streamFn: $this->agent->streamFunction,
            retry: $this->retrySettings(),
            callbacks: $this->summarizationRetryCallbacks('branchSummary'),
        );

        if ($result->aborted) {
            return null;
        }

        if ($result->error !== null) {
            throw new AgentError($result->error);
        }

        return new BranchSummary(
            (string) $result->summary,
            $result->readFiles ?? [],
            $result->modifiedFiles ?? [],
            $oldLeaf,
            usage: $result->usage,
        );
    }

    /**
     * One assistant message in the web page's display language — pig's own, for the page's
     * "Translate messages" setting; `Translation` says how. Routed first as a branch summary is,
     * with the session's key, stream function and retry policy.
     *
     * @param list<string> $doNotTranslate
     * @return string|null null when the text is already in a language from `$doNotTranslate`
     * @throws AgentError when there is no model or it failed
     */
    public function translate(string $text, string $language, array $doNotTranslate): ?string
    {
        $model = $this->directModel($this->model() ?? throw new AgentError('No model to translate with.'), null)->model;

        return Translation::translate(
            $text,
            $language,
            $doNotTranslate,
            $model,
            $this->keyFor($model),
            $this->agent->streamFunction,
            $this->retrySettings(),
        );
    }

    // ---- making room -------------------------------------------------------------------

    /** What the last completed turn carried, or 0 when nothing has been answered yet. */
    public function contextTokens(): int
    {
        $usage = Compaction::lastUsage($this->messages());

        return $usage === null ? 0 : Compaction::calculateContextTokens($usage);
    }

    /**
     * Whether the next turn would be pushing against the model's window — case 3 of
     * `checkCompaction()` asked of the latest answer, which is the check the session itself makes
     * before a prompt.
     */
    public function shouldCompact(): bool
    {
        $model = $this->limitsModel();
        $last = null;

        foreach (array_reverse($this->messages()) as $message) {
            if ($message instanceof AssistantMessage) {
                $last = $message;

                break;
            }
        }

        if ($model === null || $last === null) {
            return false;
        }

        $compactedAt = $this->latestCompactionTimestamp();

        if ($compactedAt !== null && $last->timestamp <= $compactedAt) {
            return false;
        }

        return $this->thresholdExceeded($last, ($this->modelForMessage($last) ?? $model)->contextWindow, $compactedAt);
    }

    /**
     * Upstream's `settingsManager.getCompactionSettings(model)`: `compaction.enabled`, and the two
     * token budgets with the current model's `modelOverrides` applied.
     */
    private function compactionSettings(): CompactionSettings
    {
        $model = $this->model();

        return new CompactionSettings(
            $this->settings?->compactionEnabled() ?? true,
            $this->settings?->compactionReserveTokens(Compaction::RESERVE_TOKENS, $model) ?? Compaction::RESERVE_TOKENS,
            $this->settings?->compactionKeepRecentTokens(Compaction::KEEP_RECENT_TOKENS, $model) ?? Compaction::KEEP_RECENT_TOKENS,
        );
    }

    // ---- one prompt, from its first run to `agent_settled` -------------------------------

    /**
     * Run a prompt to the end: the run, then whatever it leaves to do, then `agent_settled`, once.
     *
     * Upstream's `_runAgentPrompt()`, and the shape is upstream's:
     *
     *     agent.prompt(...)
     *     while not aborted:
     *         if _handlePostAgentRun():          retry, overflow summary, or a queued message
     *             agent.continue(); continue
     *         if not _runBeforeSettleBoundary(): break
     *         agent.continue()
     *     finally: flush held-back commands; _emitAgentSettled()
     *
     * Everything happens in the caller's fiber, after `$firstRun` has returned — not in the run's
     * own event fan-out, which is where pig used to decide it, spawning the retry and settling on
     * every `AgentEndEvent` that did not start one. That made `agent_settled` a per-*run* event:
     * a hook's turn started from `agent_end`, a message queued as the run ended, a prompt sent
     * during a retry's sleep — each settled the prompt and then ran more of it, so the system
     * notification said "task complete" over a screen still saying Working.
     *
     * @param Closure(): void $firstRun `agent->prompt(...)` or `agent->continue()`
     * @param bool $resetAbort false from `startRun()`, which reset it before `before_agent_start`
     *        and must keep an abort requested since
     */
    private function runAgentPrompt(Closure $firstRun, bool $resetAbort = true): void
    {
        if ($resetAbort) {
            $this->runAbortRequested = false;
        }

        // Compaction before the prompt may have scheduled a retry; the new prompt replaces it.
        $this->failedResponse = null;
        $this->fallbacksTried = [];
        $this->recordSelection();
        // "The run records the loadout in the transcript; restored tools that did not register by
        // now are dropped, so a tool that never registers does not stay pending."
        $this->loadout?->clearPending();
        $this->runActive = true;
        $this->idle ??= new Deferred();

        try {
            $firstRun();

            while (!$this->runAbortRequested) {
                if ($this->handlePostAgentRun()) {
                    if ($this->runAbortRequested) {
                        break;
                    }

                    $this->agent->continue();

                    continue;
                }

                if ($this->runAbortRequested || !$this->runBeforeSettleBoundary()) {
                    break;
                }

                if ($this->runAbortRequested) {
                    break;
                }

                $this->agent->continue();
            }
        } finally {
            if ($this->runAbortRequested) {
                $this->finishCancelledRetry();
            }

            $this->failedResponse = null;
            $this->runSystemPromptOptions = null;
            $this->flushBash();
            $this->flushPendingHookMessages();
            $this->emitAgentSettled();
        }
    }

    /**
     * The run is over. Is there more of this prompt to run? Upstream's `_handlePostAgentRun()`, in
     * its order.
     *
     * Three things can carry a prompt on, told apart by how the run ended. A transient failure
     * (`isRetryableError()`) means try again, after a sleep. "Prompt is too long" means the request
     * itself was the problem — never retryable, it is summarised instead. And a message queued
     * after the loop last looked — by an `agent_end` handler, or a key pressed as the run was
     * ending — is the rest of the same request.
     *
     * @return bool true to `continue()` the agent
     */
    private function handlePostAgentRun(): bool
    {
        if ($this->runAbortRequested) {
            $this->finishCancelledRetry();

            return false;
        }

        $messages = $this->messages();
        $last = $messages === [] ? null : $messages[count($messages) - 1];

        if (!$last instanceof AssistantMessage) {
            return $this->agent->hasQueuedMessages();
        }

        if ($this->isRetryableError($last) && $this->prepareRetry($last)) {
            if ($this->runAbortRequested) {
                $this->finishCancelledRetry();
            }

            $this->failedResponse = $last;

            return !$this->runAbortRequested;
        }

        if ($this->runAbortRequested) {
            $this->finishCancelledRetry();

            return false;
        }

        // The retrying's failure: the last attempt failed in a way that is not retried again, or
        // the budget ran out.
        if ($last->stopReason === StopReason::Error && $this->attempt > 0) {
            $attempts = $this->attempt;
            $this->attempt = 0;
            $this->announce(new RetryEndEvent(false, $attempts, $last->errorMessage));
        }

        // pig's own step, after the retry and before the overflow check: a quota wall is not
        // transient and not too long, it is this model being done for now. With a fallback model
        // to move on to, the turn goes again there.
        if (Retry::isProviderLimitError($last) && $this->switchToFallbackModel($last)) {
            return !$this->runAbortRequested;
        }

        // Upstream's `_checkCompaction(message, true)`: overflow, then the threshold.
        if ($this->checkCompaction($last, skipAbortedCheck: true)) {
            return !$this->runAbortRequested;
        }

        // The loop drains both queues before `agent_end`; anything queued after that needs a
        // fresh run, and it is still this prompt's.
        return !$this->runAbortRequested && $this->agent->hasQueuedMessages();
    }

    /**
     * Move the conversation on to the next model in `fallbackModels` that has not been tried this
     * prompt, and take the failed turn off the agent so `continue()` sends it again.
     *
     * The developer's feature, with no upstream counterpart: a run that should go on through the
     * night cannot stop at the first quota wall when a second key for the same work is at hand. The
     * list is walked in order, past the model that just failed and past anything already tried this
     * prompt or without a key; a pattern that resolves to nothing is skipped, because a stale entry
     * in a settings file is not a reason to stop the turn. Nothing moves *back*: the switch is the
     * same as a `/model` typed by hand, kept for the session and not written to `defaultModel`, so
     * the next session starts on the primary again.
     *
     * `:level` on an entry sets the thinking level, as `--models` does; without one the current
     * level carries over, clamped to what the new model can do — which differs from `--models`'
     * "no suffix is off", on purpose: a fallback is the same work on another key, not a new choice.
     *
     * @return bool true when a switch happened and the turn should go again
     */
    private function switchToFallbackModel(AssistantMessage $failed): bool
    {
        $patterns = $this->settings?->fallbackModels() ?? [];
        $current = $this->model();

        if ($patterns === [] || $current === null) {
            return false;
        }

        $this->fallbacksTried["{$current->provider}/{$current->id}"] = true;

        foreach ($patterns as $pattern) {
            $choice = ModelResolver::parse($pattern);

            if ($choice === null) {
                continue;
            }

            $key = "{$choice->model->provider}/{$choice->model->id}";

            if (isset($this->fallbacksTried[$key]) || $this->keyFor($choice->model) === null) {
                continue;
            }

            $this->fallbacksTried[$key] = true;

            // No suffix carries the current level over, which is this feature's own rule: a fallback
            // is the same work on another key, so neither `modelThinkingLevels` nor the default
            // gets a say.
            $this->setModel($choice->model, $choice->explicitThinking ? $choice->thinking : $this->thinkingLevel(), persistAsDefault: false);
            $this->announce(new ModelFallbackEvent(
                $current,
                $choice->model,
                $failed->errorMessage !== null && $failed->errorMessage !== '' ? $failed->errorMessage : 'Unknown error',
            ));
            $this->dropLastAssistantMessage();

            return true;
        }

        return false;
    }

    /**
     * Whether the post-run step will send this run's failed turn again — upstream's
     * `_willRetryAfterAgentEnd()`: not after escape, not with retries off or used up, and otherwise
     * whether the run's last assistant message is a retryable error.
     */
    private function willRetryAfterAgentEnd(AgentEndEvent $event): bool
    {
        if ($this->runAbortRequested) {
            return false;
        }

        $settings = $this->retrySettings();

        if (!$settings['enabled'] || $this->attempt >= $settings['maxRetries']) {
            return false;
        }

        for ($i = count($event->messages) - 1; $i >= 0; $i--) {
            if ($event->messages[$i] instanceof AssistantMessage) {
                return $this->isRetryableError($event->messages[$i]);
            }
        }

        return false;
    }

    /**
     * Upstream's `_isRetryableError()`: "Context overflow is handled by compaction, not retry", and
     * otherwise `isRetryableAssistantError()` — the error's text against upstream's pattern lists.
     */
    private function isRetryableError(AssistantMessage $message): bool
    {
        if (Overflow::happened($message, $this->modelForMessage($message)?->contextWindow)) {
            return false;
        }

        return Retry::isRetryableAssistantError($message);
    }

    /**
     * Wait, then say to send the same turn again. Upstream's `_prepareRetry()`, line for line.
     *
     * The settings decide (`retry.enabled`, `retry.maxRetries`, `retry.baseDelayMs`,
     * `retry.maxAgentDelayMs`): an attempt past the budget is not counted, so the post-run step can
     * report the attempts that were made; the wait is `retryDelayMs()` — doubling from the base,
     * capped. The failed message is taken off the agent's state before the wait (upstream's
     * `_omitRecoveryAttempt()`) and stays in the session file, because it happened.
     *
     * @return bool true when the sleep ran out and the turn should go again
     */
    private function prepareRetry(AssistantMessage $failed): bool
    {
        $settings = $this->retrySettings();

        if (!$settings['enabled']) {
            return false;
        }

        $this->attempt++;

        if ($this->attempt > $settings['maxRetries']) {
            // "Preserve the completed attempt count so post-run handling can emit the final failure."
            $this->attempt--;

            return false;
        }

        $delayMs = Retry::retryDelayMs($settings['baseDelayMs'], $this->attempt, $settings['maxAgentDelayMs']);

        $this->announce(new RetryStartEvent(
            $this->attempt,
            $settings['maxRetries'],
            $delayMs / 1000,
            $failed->errorMessage !== null && $failed->errorMessage !== '' ? $failed->errorMessage : 'Unknown error',
        ));

        $this->dropLastAssistantMessage();

        // Wait with exponential backoff (abortable).
        $this->retrying = new AbortController();

        try {
            if (!$this->sleep($delayMs / 1000, $this->retrying->signal)) {
                // "Aborted during sleep - emit end event so UI can clean up".
                $this->finishCancelledRetry();

                return false;
            }
        } finally {
            $this->retrying = null;
        }

        return true;
    }

    /**
     * Upstream's `_finishCancelledRetry()`: whoever drew "Retrying (2/3)" hears that it is over.
     */
    private function finishCancelledRetry(): void
    {
        if ($this->attempt === 0) {
            return;
        }

        $attempts = $this->attempt;
        $this->attempt = 0;
        $this->announce(new RetryEndEvent(false, $attempts, 'Retry cancelled'));
    }

    /**
     * Upstream's `getRetrySettings()`, with its defaults when there is no settings file.
     *
     * @return array{enabled: bool, maxRetries: int, baseDelayMs: float, maxAgentDelayMs: float}
     */
    private function retrySettings(): array
    {
        return $this->settings?->retrySettings()
            ?? ['enabled' => true, 'maxRetries' => 3, 'baseDelayMs' => 2000.0, 'maxAgentDelayMs' => (float) Retry::DEFAULT_MAX_AGENT_RETRY_DELAY_MS];
    }

    /**
     * Upstream's `buildRequestOptions()` (`createAgentSession()`), which every request of the agent
     * goes through: `timeoutMs` (the request's, else `retry.provider.timeoutMs`, else
     * `httpIdleTimeoutMs` — 0 meaning `2147483647`), `maxRetries` (the request's, else
     * `retry.provider.maxRetries`), `maxRetryDelayMs` (the request's, else
     * `retry.provider.maxRetryDelayMs`), and the request's headers through the
     * `before_provider_headers` handlers when there are any (`transformHeaders`).
     *
     * `websocketConnectTimeoutMs` (the request's, else the setting) goes the same way, and so does
     * `transport`, which upstream's agent carries from the setting into every request.
     *
     * The headers start from the session's OpenCode routing header (`ProviderAttribution::merge()`),
     * under the request's own headers and before the hooks see them; the identity — the
     * `User-Agent` and the attribution headers — is `ProviderAttribution::identity()`, which the
     * providers send under all of them.
     */
    private function buildRequestOptions(Model $model, SimpleStreamOptions $options): SimpleStreamOptions
    {
        $provider = $this->settings?->providerRetrySettings() ?? ['timeoutMs' => null, 'maxRetries' => null, 'maxRetryDelayMs' => 60_000];
        $httpIdleTimeoutMs = $this->settings?->httpIdleTimeoutMs() ?? 300_000;
        $effectiveTimeoutMs = $httpIdleTimeoutMs === 0 ? 2_147_483_647 : $httpIdleTimeoutMs;
        $headers = ProviderAttribution::merge($model, $options->sessionId, $options->headers);

        if ($this->extensionRunner?->hasHandlers('before_provider_headers') === true) {
            $headers = $this->extensionRunner->emitBeforeProviderHeaders($headers ?? []);
        }

        return new SimpleStreamOptions(...[
            ...$options->baseArgs(),
            'reasoning' => $options->reasoning,
            'toolChoice' => $options->toolChoice,
            'timeoutMs' => $options->timeoutMs ?? $provider['timeoutMs'] ?? $effectiveTimeoutMs,
            'maxRetries' => $options->maxRetries ?? $provider['maxRetries'],
            'maxRetryDelayMs' => $options->maxRetryDelayMs ?? $provider['maxRetryDelayMs'],
            'headers' => $headers,
            // Upstream's agent carries `thinkingBudgets` from the settings into every request.
            'thinkingBudgets' => $options->thinkingBudgets ?? $this->settings?->thinkingBudgets(),
            'transport' => $options->transport ?? $this->settings?->transport(),
            'websocketConnectTimeoutMs' => $options->websocketConnectTimeoutMs ?? $this->settings?->websocketConnectTimeoutMs(),
            // "Replaces the agent loop's default identity; read per request so telemetry changes apply at once."
            'identity' => $this->settings !== null ? ProviderAttribution::identity($this->settings) : $options->identity,
        ]);
    }

    /**
     * Upstream's `_checkCompaction()`: whether this assistant message calls for an automatic
     * compaction, and if so run it (`runAutoCompaction()`). The three automatic cases, in
     * upstream's order:
     *
     * 1. **Overflow with retry** — a context-overflow error (or a length stop): the failed turn is
     *    taken off the conversation with the tool results that answered it (`omitRecoveryAttempt()`),
     *    the session compacted, and the turn sent again.
     * 2. **Overflow without retry** — a response that completed but used more than the window:
     *    compacted, and the response kept, since a completed answer cannot be continued.
     * 3. **The threshold** — the context the message reports (or, for a failed or usage-less one,
     *    the estimate from the last good reading) is past `contextWindow - reserveTokens`:
     *    compacted, nothing retried.
     *
     * Called after every run (`handlePostAgentRun()`, `$skipAbortedCheck` true) and before every
     * prompt (`prompt()`, false: an aborted turn still filled the context), which is where upstream
     * calls it — in the session, so the terminal, RPC and print mode all compact the same way.
     * Nothing happens when `compaction.enabled` is off, when the message came from another model
     * than the current one (its window is not this one's), or when it predates the latest
     * compaction (its usage measured a context that no longer exists).
     *
     * @return bool true when the run should `continue()`: an overflow retry, or messages queued
     *              while the summary was written
     */
    private function checkCompaction(AssistantMessage $message, bool $skipAbortedCheck): bool
    {
        $settings = $this->compactionSettings();

        if (!$settings->enabled) {
            return false;
        }

        if ($skipAbortedCheck && $message->stopReason === StopReason::Aborted) {
            return false;
        }

        $messageModel = $this->modelForMessage($message);
        $contextWindow = ($messageModel ?? $this->limitsModel())?->contextWindow ?? 0;
        $compactedAt = $this->latestCompactionTimestamp();

        if ($compactedAt !== null && $message->timestamp <= $compactedAt) {
            return false;
        }

        // Cases 1 and 2. Only for the model that produced the message: an overflow on a smaller
        // model is not a reason to compact for the larger one somebody has since switched to.
        // Upstream's `recoverableLength` too: "A length stop is recoverable when output ended below
        // the model's original desired limit" — while the attempt is still in the context, since an
        // omitted one has already been recovered from.
        $contextOverflow = $messageModel !== null && Overflow::happened($message, $messageModel->contextWindow);
        $recoverableLength = $messageModel !== null
            && in_array($message, $this->agent->state->messages, true)
            && Overflow::isRecoverableLength($message, $messageModel->maxTokens);

        if ($contextOverflow || $recoverableLength) {
            // pig's own, before either: a system prompt that is past the window on its own — a
            // project's context files grown beyond a smaller model — leaves a summary nothing to
            // make room in, and upstream's way round compacts, retries, overflows again and ends on
            // "recovery failed", with the provider's 400 the only clue. Said once, plainly.
            $tooLarge = $contextOverflow ? $this->promptTooLarge($messageModel) : null;

            if ($tooLarge !== null) {
                if ($this->promptTooLargeSaidFor !== $message) {
                    $this->promptTooLargeSaidFor = $message;
                    $this->announce(new CompactionEndEvent('overflow', null, false, false, $tooLarge));
                    $this->extensionRunner?->emit(new SessionCompactFailedEvent('overflow', aborted: false, errorMessage: $tooLarge, willRetry: false, fromExtension: false));
                }

                return false;
            }

            if ($message->stopReason === StopReason::Stop) {
                return $this->runAutoCompaction('overflow', willRetry: false);
            }

            // Upstream's guard: the retry after a summary overflowed again, so a second summary
            // would only go round once more. Said as a `compaction_end` with nothing started.
            if ($this->overflowRecoveryAttempted) {
                $errorMessage = $contextOverflow
                    ? 'Context overflow recovery failed after one compact-and-retry attempt. Try reducing context or switching to a larger-context model.'
                    : 'Truncated response recovery failed after one compact-and-retry attempt.';
                $this->announce(new CompactionEndEvent('overflow', null, false, false, $errorMessage));
                $this->extensionRunner?->emit(new SessionCompactFailedEvent('overflow', aborted: false, errorMessage: $errorMessage, willRetry: false, fromExtension: false));

                return false;
            }

            $this->overflowRecoveryAttempted = true;
            $this->omitRecoveryAttempt($message);

            return $this->runAutoCompaction('overflow', willRetry: true);
        }

        // Case 3, which `shouldCompact()` answers for the latest message on its own.
        if ($this->thresholdExceeded($message, $contextWindow, $compactedAt)) {
            return $this->runAutoCompaction('threshold', willRetry: false);
        }

        return false;
    }

    /**
     * Why compacting cannot help, when the system prompt alone does not fit $model's window — with
     * the project's context files by size, since they are what grows — or null when it fits.
     */
    private function promptTooLarge(Model $model): ?string
    {
        $tokens = Compaction::estimateTokens(new SystemMessage($this->systemPrompt()));

        if ($model->contextWindow <= 0 || $tokens < $model->contextWindow) {
            return null;
        }

        // `ContextFiles` writes each file under a `## <path>` heading; a file's own `##` headings
        // are not paths, so only an absolute one starts a file.
        $files = [];
        $context = $this->loadout?->systemPromptSections()['project_context'] ?? null;

        if (is_string($context) && preg_match_all('~^## ((?:/|[A-Za-z]:[\\\\/]).*)$~m', $context, $found, PREG_OFFSET_CAPTURE) > 0) {
            foreach ($found[0] as $i => [, $at]) {
                $end = $found[0][$i + 1][1] ?? strlen($context);
                $files[$found[1][$i][0]] = Compaction::estimateTokens(new SystemMessage(substr($context, $at, $end - $at)));
            }

            arsort($files);
        }

        $largest = array_map(
            static fn (string $path, int $size): string => sprintf('%s (~%s tokens)', $path, number_format($size)),
            array_keys(array_slice($files, 0, 3, true)),
            array_slice($files, 0, 3, true),
        );

        return sprintf(
            'The system prompt alone is about %s tokens, more than the %s-token context window of %s, so compacting the conversation cannot make room.%s Start pig with --no-context-files (-nc) to leave the project\'s context files out, or make them shorter.',
            number_format($tokens),
            number_format($model->contextWindow),
            $model->id,
            $largest === [] ? '' : ' Most of it is the project\'s context: ' . implode(', ', $largest) . '.',
        );
    }

    /**
     * Upstream's case 3 of `_checkCompaction()`: the provider's count for this message, or — when
     * it failed or reported nothing — `estimateContextTokens()` over the conversation, unless the
     * reading that estimate starts from predates the latest compaction.
     */
    private function thresholdExceeded(AssistantMessage $message, int $contextWindow, ?int $compactedAt): bool
    {
        $direct = Compaction::calculateContextTokens($message->usage);

        if ($message->stopReason === StopReason::Error || $direct === 0) {
            $messages = $this->messages();
            $estimate = Compaction::estimateContextTokens($messages);

            if ($estimate->lastUsageIndex !== null && $compactedAt !== null) {
                $usageMessage = $messages[$estimate->lastUsageIndex];

                if ($usageMessage instanceof AssistantMessage && $usageMessage->timestamp <= $compactedAt) {
                    return false;
                }
            }

            $tokens = $estimate->tokens;
        } else {
            $tokens = $direct;
        }

        return Compaction::shouldCompact($tokens, $contextWindow, $this->compactionSettings());
    }

    /** When the newest compaction summary in the conversation was written, or null for none. */
    private function latestCompactionTimestamp(): ?int
    {
        $latest = null;

        foreach ($this->messages() as $message) {
            if ($message instanceof CompactionSummary && ($latest === null || $message->timestamp > $latest)) {
                $latest = $message->timestamp;
            }
        }

        return $latest;
    }

    /**
     * Upstream's `_runAutoCompaction()`: threshold or overflow compaction. `prepareCompaction()`
     * first, and **when there is nothing to cut, nothing is announced at all** — no
     * `compaction_start`, no `compaction_end`, no `session_compact_failed` — which is upstream's
     * behaviour. What the person sees then is what upstream shows: the turn's own error (an
     * overflow's "prompt is too long") already on screen and in the events, with nothing
     * claiming to have tried. Otherwise `compactNow()` announces the start and the end, and a
     * failure there in upstream's words (`Context overflow recovery failed: …` /
     * `Auto-compaction failed: …`) — so the `false` here is only "do not continue".
     *
     * @param 'overflow'|'threshold' $reason
     * @return bool true to `continue()`: the retry after an overflow, or queued messages
     */
    private function runAutoCompaction(string $reason, bool $willRetry): bool
    {
        if ($this->model() === null) {
            return false;
        }

        $session = $this->store ?? SessionManager::previewOf($this->cwd, $this->messages());
        $preparation = Compaction::prepareCompaction($session->branchEntries(), $this->compactionSettings());

        if ($preparation === null) {
            return false;
        }

        try {
            $summary = $this->compactNow(null, null, $reason, $willRetry, $preparation);
        } catch (Throwable) {
            return false;
        }

        if ($summary === null) {
            return false;
        }

        return $willRetry || $this->agent->hasQueuedMessages();
    }

    /**
     * Take the failed turn off the agent's state, leaving it in the session file — and write
     * down that it was taken off.
     *
     * The model must not be shown its own error as though it were part of the conversation:
     * the next request would carry "Anthropic returned 503" in the transcript, and the model
     * would try to make sense of it. The `context_edit` is upstream's `_omitRecoveryAttempt()`
     * and the half pig was missing: without it the message came back into the agent's state on
     * the next `--resume`, which is the one time nobody is there to see it being retried.
     */
    private function dropLastAssistantMessage(): void
    {
        $messages = $this->agent->state->messages;
        $last = $messages === [] ? null : $messages[count($messages) - 1];

        if (!$last instanceof AssistantMessage) {
            return;
        }

        $this->agent->replaceMessages(array_slice($messages, 0, -1));

        // The same object `append()` was handed on `message_end`, so identity finds it. A
        // failed turn in a session that was never written has nothing to edit, which is fine:
        // there is no file for a resume to put it back from.
        $entryId = $this->store?->entryOf($last);

        if ($entryId !== null) {
            $this->store?->appendContextEdit($entryId, null);
            $this->announceAppendedEntry();
        }
    }

    /**
     * Upstream's `_omitRecoveryAttempt()`: take a failed attempt off the agent's state **with the
     * tool results that answered its calls**, and write a context edit for each. "An unpaired result
     * fails the next request (#11227)": a length stop's truncated tool call still ran — and failed —
     * so its result follows it, and the attempt is not always the last message. Before the run the
     * attempt comes from `prepareRun()`'s look back for the last assistant message, which may be
     * followed by its results; leaving those behind made every later request a 400.
     */
    private function omitRecoveryAttempt(AssistantMessage $message): void
    {
        $messages = $this->agent->state->messages;
        $index = array_search($message, $messages, true);

        if ($index === false) {
            return;
        }

        $toolCallIds = [];

        foreach ($message->content as $block) {
            if ($block instanceof ToolCall) {
                $toolCallIds[$block->id] = true;
            }
        }

        $targets = [$index => $message];

        for ($i = $index + 1, $n = count($messages); $i < $n; $i++) {
            if ($messages[$i] instanceof AssistantMessage) {
                break;
            }

            if ($messages[$i] instanceof ToolResultMessage && isset($toolCallIds[$messages[$i]->toolCallId])) {
                $targets[$i] = $messages[$i];
            }
        }

        $this->agent->replaceMessages(array_values(array_diff_key($messages, $targets)));

        foreach ($targets as $target) {
            $entryId = $this->store?->entryOf($target);

            if ($entryId !== null) {
                $this->store?->appendContextEdit($entryId, null);
                $this->announceAppendedEntry();
            }
        }
    }

    /**
     * Upstream's `entry_appended` for the entry just written — the store's leaf, which `append()`
     * has just moved onto it. For the entries no `message_end` carries: a hook's custom entry, a
     * context edit, the cache warmer's usage. Nothing for a session that is not being saved.
     */
    private function announceAppendedEntry(): void
    {
        $id = $this->store?->leaf();
        $entry = $id === null ? null : $this->store?->entry($id);

        if ($id === null || $entry === null) {
            return;
        }

        $this->announce(new EntryAppendedEvent(new SessionEntry($id, $entry['parent'], $entry['message'])));
    }

    /**
     * Wait, unless somebody says not to.
     *
     * `Async::delay()` cannot be interrupted, and eight seconds that escape cannot reach is
     * eight seconds of a terminal that will not answer. So: a timer and an abort listener
     * racing to complete the same `Deferred`, whichever gets there first. The timer is
     * cancelled on an abort rather than left to fire into nothing, because a pending timer
     * keeps `Loop::isIdle()` false and `bin/pig` would not exit.
     *
     * @return bool false if it was interrupted
     */
    private function sleep(float $seconds, AbortSignal $signal): bool
    {
        if ($signal->aborted()) {
            return false;
        }

        $done = new Deferred();
        $timer = Loop::get()->delay($seconds, static function () use ($done): void {
            if (!$done->isComplete()) {
                $done->complete(true);
            }
        });

        $listener = $signal->onAbort(static function () use ($done, $timer): void {
            Loop::get()->cancel($timer);

            if (!$done->isComplete()) {
                $done->complete(false);
            }
        });

        try {
            return $done->future->await() === true;
        } finally {
            $signal->removeListener($listener);
        }
    }

    /**
     * Whether a retry is being waited out right now.
     *
     * The controller, which exists from the `RetryStartEvent` to the end of the sleep — upstream's
     * `_retryAbortController`. A summarisation is not a retry and does not make this true.
     */
    public function isRetrying(): bool
    {
        return $this->retrying !== null;
    }

    /**
     * Stop retrying. Upstream's `abortRetry()`.
     *
     * Safe to call when nothing is being retried, because that is how `abort()` calls it:
     * escape means stop, and whether there was a sleep to interrupt is not the caller's
     * business. The sleeping `prepareRetry()` wakes, says the retrying was cancelled, and the
     * prompt settles — or carries on with what was queued, if only the retry was called off.
     */
    public function abortRetry(): void
    {
        $this->retrying?->abort();
    }

    /** Resolves when the session is next idle — at once, if it is. Upstream's `waitForIdle()`. */
    private function idleFuture(): Future
    {
        if ($this->isIdle()) {
            return Future::complete(null);
        }

        return ($this->idle ??= new Deferred())->future;
    }

    private function waitForIdle(): void
    {
        $this->idleFuture()->await();
    }

    /**
     * Upstream's `_runBeforeSettleBoundary()`: with nobody listening, the prompt carries on only
     * for what is queued; with handlers, they are asked (`ExtensionRunner::emitBoundary()`), what they
     * drafted is appended, and the prompt carries on if they said so or something is queued —
     * unless the context as it then stands could not be sent, which is reported and refused.
     *
     * @return bool true to `continue()` the agent
     */
    private function runBeforeSettleBoundary(): bool
    {
        if ($this->extensionRunner === null || !$this->extensionRunner->listensTo('agent_before_settle')) {
            return $this->agent->hasQueuedMessages();
        }

        $result = $this->extensionRunner->emitBoundary(
            fn (array $entries, bool $continue, BoundaryContextPreview $context): AgentBeforeSettleEvent => new AgentBeforeSettleEvent($entries, $continue, $context, $this->lastOutcome),
            fn (array $entries): BoundaryContextPreview => $this->buildBoundaryContext($entries),
        );

        $this->commitBoundaryDrafts($result->entries);

        if ($this->runAbortRequested) {
            return false;
        }

        $final = $this->buildBoundaryContext([]);
        $shouldContinue = $result->continue || $this->agent->hasQueuedMessages();

        if ($shouldContinue && !$final->canContinue) {
            if ($result->continue) {
                $this->extensionRunner->emitError(new ExtensionError('<boundary>', 'agent_before_settle', 'agent_before_settle requested continuation without runnable model context'));
            }

            return false;
        }

        return $shouldContinue;
    }

    /**
     * Upstream's `_buildBoundaryContext()`: the session with the drafts applied, as the model
     * would be sent it. Against a copy of the store (`SessionManager::preview()`), so a draft that
     * cannot be applied — an edit of an entry that is not there — throws here, into
     * `emitBoundary()`'s report, and changes nothing.
     *
     * @param list<SessionBoundaryDraft> $drafts
     */
    private function buildBoundaryContext(array $drafts): BoundaryContextPreview
    {
        $preview = $this->store?->preview() ?? SessionManager::previewOf($this->cwd, $this->messages());
        $this->applyBoundaryDrafts($preview, $drafts);
        $messages = $preview->messages();
        $llm = CodingAgent::toLlm($messages);
        $endsOnAssistant = $llm !== [] && $llm[count($llm) - 1] instanceof AssistantMessage;
        $hasConversation = false;

        foreach ($llm as $message) {
            if (!$message instanceof SystemMessage) {
                $hasConversation = true;

                break;
            }
        }

        return new BoundaryContextPreview(
            $preview->branch(),
            $messages,
            $llm,
            $this->agent->peekQueuedMessages(),
            ($hasConversation && !$endsOnAssistant) || ($endsOnAssistant && $this->agent->hasQueuedMessages()),
        );
    }

    /**
     * Upstream's `_applyBoundaryDrafts()`, against the store or a preview of it.
     *
     * @param list<SessionBoundaryDraft> $drafts
     * @return list<CustomMessage> the messages among them, for the agent's own state
     */
    private function applyBoundaryDrafts(SessionManager $manager, array $drafts): array
    {
        $messages = [];

        foreach ($drafts as $draft) {
            if ($draft instanceof CustomEntryDraft) {
                $manager->appendCustomEntry($draft->customType, $draft->data);
            } elseif ($draft instanceof CustomMessageDraft) {
                $message = new CustomMessage(
                    $draft->customType,
                    is_string($draft->content) ? [new TextContent($draft->content)] : $draft->content,
                    $draft->display,
                    $draft->details,
                );
                $manager->append($message);
                $messages[] = $message;
            } elseif ($draft instanceof ContextEditDraft) {
                $manager->appendContextEdit($draft->targetId, $draft->replacement);
            } elseif ($draft instanceof CompactionDraft) {
                $current = $manager->messages();
                $tokensBefore = 0;

                foreach ($current as $message) {
                    $tokensBefore += Compaction::estimateTokens($message);
                }

                $manager->append(new CompactionSummary(
                    $draft->summary,
                    tokensBefore: $tokensBefore,
                    firstKeptEntryId: $draft->firstKeptEntryId,
                    fromHook: true,
                    systemMessage: Transcript::getCurrentSystemMessage($current),
                ));
            } else {
                throw new AgentError('Not a boundary draft: ' . get_debug_type($draft));
            }
        }

        return $messages;
    }

    /**
     * Upstream's `_commitBoundaryDrafts()`: appended to the store for good, and the agent's state
     * brought up to what the store now projects — a context edit or a compaction changes what the
     * model is shown, which `restore()` is also what does on a resume.
     *
     * @param list<SessionBoundaryDraft> $drafts
     */
    private function commitBoundaryDrafts(array $drafts): void
    {
        if ($drafts === []) {
            return;
        }

        if ($this->store === null) {
            // Nothing is written down, so only what reaches the agent's state exists: its messages.
            foreach ($this->applyBoundaryDrafts(SessionManager::previewOf($this->cwd, []), $drafts) as $message) {
                $this->agent->appendMessage($message);
                $this->announce(new MessageEndEvent($message));
            }

            return;
        }

        $messages = $this->applyBoundaryDrafts($this->store, $drafts);
        $this->agent->replaceMessages($this->store->messages());

        foreach ($messages as $message) {
            $this->announce(new MessageEndEvent($message));
        }
    }

    /**
     * The prompt is over: tell the hooks, run what they asked for, release whoever is waiting.
     * Upstream's `_emitAgentSettled()`.
     *
     * The hooks first, as upstream emits before the idle wait resolves, so a `-p` that exits when
     * `prompt()` returns has already let the notification hook run. Reached exactly once per
     * prompt, from `runAgentPrompt()`'s `finally` — whichever way the prompt ended — and that is
     * the property `agent_settled` promises: final, and once.
     */
    private function emitAgentSettled(): void
    {
        $this->runActive = false;
        $this->cacheWarmer?->onAgentSettled();
        $this->emittingSettled = true;
        $aborted = $this->runAbortRequested;

        try {
            $this->extensionRunner?->emit(new ExtensionAgentSettled($this->messages(), $aborted));
            $this->announce(new AgentSettledEvent($aborted));
        } finally {
            $this->emittingSettled = false;
        }

        $this->nameItself();

        $deferred = $this->deferredSettledActions;
        $this->deferredSettledActions = [];

        try {
            foreach ($deferred as $action) {
                $action();
            }
        } finally {
            $this->resolveIdleWaitIfIdle();
        }
    }

    /** Upstream's `_resolveIdleWaitIfIdle()`, plus the quit an extension asked for while busy. */
    private function resolveIdleWaitIfIdle(): void
    {
        if (!$this->isIdle()) {
            return;
        }

        $waiting = $this->idle;
        $this->idle = null;

        if ($waiting !== null && !$waiting->isComplete()) {
            $waiting->complete(null);
        }

        // A quit an extension asked for while this was running. After the waiter is released, so
        // a `-p` exiting on `prompt()`'s return has already had its answer.
        if ($this->shutdownRequested && $this->onShutdown !== null) {
            $this->shutdownRequested = false;
            ($this->onShutdown)();
        }
    }

    /**
     * Summarise the older part of the conversation and carry on from the summary.
     *
     * The summary is an entry like any other, so it is appended to the file and the
     * messages it replaced are not removed from it — a session log is a record of what
     * happened, and what happened is that these messages were said and then summarised.
     * Replaying it puts the conversation back the way compaction left it.
     *
     * Upstream's `compact()`: the manual one — `/compact`, RPC's `compact`, a hook's
     * `$ctx->compact()`. The automatic ones (`threshold`, `overflow`) are the session's own, from
     * `checkCompaction()`, and are not started from outside.
     *
     * @param string|null $instructions what to pay particular attention to, from `/compact foo`
     * @return CompactionSummary|null the entry written, or null when it was called off part-way
     * @throws AgentError if the agent is working, there is no model, there is nothing to
     *                    compact, a hook cancelled it, or the model fails
     */
    public function compact(?string $instructions = null, ?AbortSignal $signal = null): ?CompactionSummary
    {
        if ($this->isStreaming()) {
            throw new AgentError('Agent is working. Let it finish, or press esc, then compact.');
        }

        return $this->compactNow($instructions, $signal, 'manual', willRetry: false);
    }

    /**
     * `compact()` without the "is a prompt in progress" check, for the callers that are the prompt
     * in progress: the automatic summaries (`runAutoCompaction()`), which hand in the preparation
     * they already made.
     *
     * @param 'manual'|'threshold'|'overflow' $reason
     */
    private function compactNow(?string $instructions, ?AbortSignal $signal, string $reason, bool $willRetry, ?CompactionPreparation $preparation = null): ?CompactionSummary
    {
        // One controller for both doors, so `isCompacting()` and `abortCompaction()` answer for a
        // summarisation whoever started it. A signal the caller brought is *forwarded* into it
        // rather than carried alongside: what goes downstream then has one `aborted()` to ask, and
        // pig has no combinator for two — see the note on `Future` in docs/dev/decisions.md.
        $this->compacting = new AbortController();

        if ($signal?->aborted() === true) {
            $this->compacting->abort('Cancelled');
        }

        $listener = $signal?->onAbort(fn () => $this->compacting?->abort('Cancelled'));

        $this->hookCancelledCompaction = false;
        $this->compactionFromExtension = false;
        $compacting = $this->compacting;
        $done = null;
        $failure = null;

        // Upstream's `compaction_start`: the manual one before anything is looked at (so "Nothing
        // to compact" arrives as its `compaction_end`), the automatic ones only once
        // `runAutoCompaction()` has found something to cut.
        $this->announce(new CompactionStartEvent($reason));

        try {
            $done = $this->summariseAndSwapIn($instructions, $compacting->signal, $reason, $willRetry, $preparation);
        } catch (Throwable $problem) {
            $failure = $problem;
        } finally {
            $this->compacting = null;

            if ($listener !== null) {
                $signal?->removeListener($listener);
            }

            // A summary is part of "busy" (`isIdle()`), so its end can be the moment somebody
            // waiting on `abort()` is let go. Inside a prompt this does nothing: still busy.
            $this->resolveIdleWaitIfIdle();
        }

        if ($failure !== null) {
            // Upstream's `compaction_end` and `session_compact_failed`. A hook's own cancel is an
            // abort, as escape is: nothing went wrong, somebody decided. `willRetry` is false, as
            // upstream's always is here — the turn a failed recovery was for is not sent again.
            $aborted = $compacting->signal->aborted() || $this->hookCancelledCompaction;
            $errorMessage = $aborted ? null : self::compactionFailure($reason, $failure->getMessage());

            $this->announce(new CompactionEndEvent($reason, null, $aborted, false, $errorMessage));
            $this->extensionRunner?->emit(new SessionCompactFailedEvent(
                $reason,
                aborted: $aborted,
                errorMessage: $errorMessage,
                willRetry: false,
                fromExtension: $this->compactionFromExtension,
            ));

            throw $failure;
        }

        if ($done === null) {
            $this->announce(new CompactionEndEvent($reason, null, true, false));
            $this->extensionRunner?->emit(new SessionCompactFailedEvent($reason, aborted: true, willRetry: false, fromExtension: $this->compactionFromExtension));

            return null;
        }

        [$summary, $result] = $done;
        $this->announce(new CompactionEndEvent($reason, $result, false, $willRetry, null, $summary));

        return $summary;
    }

    /** Upstream's wording for a failed compaction, by what started it. */
    private static function compactionFailure(string $reason, string $message): string
    {
        return match ($reason) {
            'overflow' => "Context overflow recovery failed: {$message}",
            'threshold' => "Auto-compaction failed: {$message}",
            default => "Compaction failed: {$message}",
        };
    }

    /** Set when the last compaction was stopped by a `session_before_compact` handler, which is an abort and not an error. */
    private bool $hookCancelledCompaction = false;

    /** Set when the last compaction's content came from a `session_before_compact` handler. */
    private bool $compactionFromExtension = false;

    /** Whether a summariser is running right now, from either door. */
    public function isCompacting(): bool
    {
        return $this->compacting !== null;
    }

    /**
     * Stop the summariser. Does nothing when none is running.
     *
     * Upstream's `abortCompaction()`, which its escape handler calls beside `abort()`; here
     * `abort()` calls this itself, so one call reaches everything escape has to stop.
     */
    public function abortCompaction(): void
    {
        $this->compacting?->abort('Cancelled');
    }

    /**
     * The body of `compact()`, with the signal already settled — upstream's compaction body,
     * shared by its three doors.
     *
     * `Compaction::prepareCompaction()` over the branch, `session_before_compact`, then the hook's
     * `CompactionResult` or `Compaction::compact()`'s, written as a `CompactionSummary` and the
     * agent's messages rebuilt from the projection — upstream's `appendCompaction()` and
     * `_refreshFinalizedContext()`. A session that is not being saved compacts a copy of itself
     * held in memory (`SessionManager::previewOf()`), so the cut, the ids and the rebuilt context
     * are worked out the one way either way.
     *
     * @return array{0: CompactionSummary, 1: CompactionResult}|null the entry as the conversation
     *         now holds it, and upstream's `CompactionResult` for `compaction_end` and RPC's
     *         `compact` — `estimatedTokensAfter` measured over the rebuilt conversation, as
     *         upstream's `estimateMessagesTokens()` measures it; null when it was called off
     */
    private function summariseAndSwapIn(?string $instructions, AbortSignal $signal, string $reason, bool $willRetry, ?CompactionPreparation $preparation = null): ?array
    {
        $model = $this->model() ?? throw new AgentError('No model selected.');
        $session = $this->store ?? SessionManager::previewOf($this->cwd, $this->messages());
        $pathEntries = $session->branchEntries();
        $preparation ??= Compaction::prepareCompaction($pathEntries, $this->compactionSettings());

        if ($preparation === null) {
            $last = $pathEntries[count($pathEntries) - 1] ?? null;

            // Upstream's wording, because it is the wording someone will search for. The
            // conversation being smaller than the recent window compaction always keeps is
            // the usual reason, and the footer does not show it — that percentage is the
            // provider's count of a whole request, tool schemas and system prompt included.
            throw new AgentError($last?->message instanceof CompactionSummary ? 'Already compacted' : 'Nothing to compact (session too small)');
        }

        $answer = $this->extensionRunner?->emitBeforeCompact(new SessionBeforeCompactEvent(
            $preparation,
            $pathEntries,
            $instructions,
            $reason,
            $willRetry,
            $signal,
        ));

        if ($answer !== null && $answer->cancel) {
            $this->hookCancelledCompaction = true;

            throw new AgentError('Compaction cancelled');
        }

        if ($signal->aborted()) {
            return null;
        }

        $result = $answer?->compaction;
        $this->compactionFromExtension = $result !== null;

        if ($result === null) {
            // Routed only when pig summarises itself, as upstream's `_runDefaultCompaction()`:
            // routing may call models or fail, and a hook's summary needs neither.
            $direct = $this->directModel($model, $signal);

            $result = Compaction::compact(
                $preparation,
                $direct->model,
                $this->keyFor($direct->model),
                customInstructions: $instructions,
                signal: $signal,
                thinkingLevel: $direct->thinkingLevel,
                streamFn: $this->agent->streamFunction,
                retry: $this->retrySettings(),
                callbacks: $this->summarizationRetryCallbacks('compaction', $reason),
            );
        }

        if ($signal->aborted()) {
            return null;
        }

        // pi's `appendCompaction()`: the prompt and tool state the projection replays to, stamped
        // with the compaction's own time, goes on the entry in front of the summary.
        $compactedAt = Timestamp::nowMs();
        $systemState = Transcript::getCurrentSystemMessage($session->messages());
        $systemMessage = $systemState === null ? null : new SystemMessage(
            $systemState->content,
            $systemState->sections,
            $systemState->toolsAdded,
            $systemState->toolsRemoved,
            $compactedAt,
        );

        $session->append(new CompactionSummary(
            $result->summary,
            self::fileList($result->details['readFiles'] ?? []),
            self::fileList($result->details['modifiedFiles'] ?? []),
            $result->tokensBefore,
            $result->firstKeptEntryId,
            0,
            $compactedAt,
            // Marked as the hook's, which is pi's own field on this entry (`fromHook`, kept for
            // session-file compatibility). It keeps the next compaction from carrying these file
            // lists forward as though pig had found them.
            fromHook: $this->compactionFromExtension,
            systemMessage: $systemMessage,
            usage: $result->usage,
        ));

        $messages = $session->messages();
        $this->agent->replaceMessages($messages);

        // The entry as the projection reads it back, with how many messages it replaced filled in.
        $summary = null;

        foreach ($messages as $message) {
            if ($message instanceof CompactionSummary) {
                $summary = $message;
            }
        }

        if ($summary === null) {
            throw new AgentError('The compaction was written but is not in the conversation it was written to.');
        }

        $this->extensionRunner?->emit(new SessionCompactEvent($summary, $this->compactionFromExtension, $reason, $willRetry));

        $estimatedTokensAfter = 0;

        foreach ($messages as $message) {
            $estimatedTokensAfter += Compaction::estimateTokens($message);
        }

        return [$summary, new CompactionResult(
            $result->summary,
            $result->firstKeptEntryId,
            $result->tokensBefore,
            $estimatedTokensAfter,
            $result->usage,
            $result->details,
        )];
    }

    /**
     * Upstream's `_summarizationRetryCallbacks()`: each retry of a summary request announced as a
     * `SummarizationRetryEvent`.
     *
     * @param 'compaction'|'branchSummary' $source
     * @return array<string, Closure>
     */
    private function summarizationRetryCallbacks(string $source, ?string $reason = null): array
    {
        return [
            'onRetryScheduled' => fn (int $attempt, int $maxAttempts, float $delayMs, string $error) => $this->announce(new SummarizationRetryEvent(
                SummarizationRetryEvent::SCHEDULED,
                $source,
                $reason,
                $attempt,
                $maxAttempts,
                $delayMs / 1000,
                $error,
            )),
            'onRetryAttemptStart' => fn () => $this->announce(new SummarizationRetryEvent(SummarizationRetryEvent::ATTEMPT_START, $source, $reason)),
            'onRetryFinished' => fn () => $this->announce(new SummarizationRetryEvent(SummarizationRetryEvent::FINISHED, $source, $reason)),
        ];
    }

    /**
     * The session as the `bash` and `powershell` tools describe it to a command in `PIG_*`
     * variables — upstream's `resolveSpawnContext()` reading `ctx` — asked as each command starts.
     */
    private function sessionEnvironment(): \Pig\CodingAgent\Tools\SessionEnvironment
    {
        return \Pig\CodingAgent\Tools\SessionEnvironment::of($this);
    }

    // ---- thinking ----------------------------------------------------------------

    public function thinkingLevel(): ThinkingLevel
    {
        return $this->agent->state->thinkingLevel;
    }

    /**
     * Upstream's `setThinkingLevel()`: **clamped to the model's capabilities**, not refused — a level
     * the model does not have becomes the nearest one it does (`clampThinking()`, up first, then
     * down). The clamped level is what the session records and announces, and only when it
     * changes; `$persistAsDefault` writes the level that was *asked for*, as upstream's
     * `settingsManager.setDefaultThinkingLevel(level)` does, so a default chosen on a model without
     * `xhigh` is still `xhigh` for the next model that has it.
     */
    public function setThinkingLevel(ThinkingLevel $level, bool $persistAsDefault = false): void
    {
        $effective = $this->clampThinking($level);
        $previous = $this->thinkingLevel();
        $changed = $previous !== $effective;

        $this->agent->setThinkingLevel($effective);

        // Remembered for the next run when enabled.
        // Web UI passes persistAsDefault: false so it does not overwrite settings.json.
        if ($persistAsDefault) {
            $this->settings?->setDefaultThinkingLevel($level);
        }

        if ($changed) {
            $this->store?->appendThinkingLevelChange($effective->value);
            // Upstream's `thinking_level_changed`, beside the entry, before the hooks hear of it.
            $this->announce(new ThinkingLevelChangedEvent($effective));
            $this->extensionRunner?->emit(new ThinkingLevelSelectEvent($effective, $previous));
        }
    }

    /**
     * The next level up, wrapping round at the top.
     *
     * @return ThinkingLevel|null null when the model cannot think at all
     */
    public function cycleThinkingLevel(): ?ThinkingLevel
    {
        $levels = $this->availableThinkingLevels();

        if ($levels === []) {
            return null;
        }

        $at = array_search($this->thinkingLevel(), $levels, true);

        // A level the model does not offer — xhigh on a model without it — is not a
        // position in this list, so the cycle starts over rather than guessing one.
        $next = $at === false ? $levels[0] : $levels[($at + 1) % count($levels)];
        $this->setThinkingLevel($next, persistAsDefault: false);

        return $next;
    }

    /** @return list<ThinkingLevel> empty when the model does not support thinking */
    public function availableThinkingLevels(): array
    {
        $model = $this->model();

        // **The empty list is pig's way of saying "no thinking here at all"**, and it is load
        // bearing: `cycleThinkingLevel()` answers null on it, and the settings list uses it to
        // decide whether there is a thinking row to draw. Upstream's `supportedBy()` answers
        // `[off]` for a model that cannot reason — one level, which is true and is a different
        // statement. Handing that to these callers turns "no row" into "a row with one choice",
        // which is what seven tests said the first time this was written without the guard.
        //
        // So the rule about *which* levels a reasoning model has lives on the enum, and the rule
        // about whether there are any at all stays here.
        return $model === null || !$model->reasoning ? [] : ThinkingLevel::supportedBy($model);
    }

    // ---- what it has cost ---------------------------------------------------------

    public function stats(): SessionStats
    {
        $users = $assistants = $results = $calls = 0;
        $input = $output = $cacheRead = $cacheWrite = 0;
        $cost = 0.0;

        foreach ($this->messages() as $message) {
            if ($message instanceof UserMessage) {
                $users++;

                continue;
            }

            if ($message instanceof ToolResultMessage) {
                $results++;

                continue;
            }

            if (!$message instanceof AssistantMessage) {
                continue;
            }

            $assistants++;

            foreach ($message->content as $block) {
                if ($block instanceof ToolCall) {
                    $calls++;
                }
            }
        }

        // **The counts are about the conversation and the money is about the session**, which are
        // two questions and were one sum. Summed over `messages()`, a compaction erased the bill:
        // it replaces what it summarised with one summary carrying no usage, so the footer and
        // `/session` both dropped back towards zero at exactly the point a conversation has been
        // long enough to be expensive. The file is what was paid for — every assistant message in
        // it came back from a provider that charged, including on a branch later abandoned, and
        // neither compacting nor walking away is a refund. Upstream's footer sums the file too;
        // its own `/session` sums the messages, which is two answers to one question in one tool.
        //
        // With no file there is nothing else to count, and then the two questions share an answer.
        //
        // A tool result's `usage` is what the tool itself spent on models (a codemode script's
        // classifier calls) and was paid for the same way; upstream's cost breakdown books it
        // under "Tools/summaries". A `usage` entry — a cache-warming refresh, pig's or pi's — is
        // money that bought no message, and upstream's `getSessionStats()` adds it the same way.
        // So is a summary's.
        foreach ($this->store?->everyMessage() ?? $this->messages() as $message) {
            $usage = match (true) {
                $message instanceof AssistantMessage => $message->usage,
                $message instanceof ToolResultMessage => $message->usage,
                $message instanceof UsageEntry => $message->usage,
                // Upstream's compaction and branch-summary `usage`: "included in session token and
                // cost totals".
                $message instanceof CompactionSummary, $message instanceof BranchSummary => $message->usage,
                default => null,
            };

            if ($usage === null) {
                continue;
            }

            $input += $usage->input;
            $output += $usage->output;
            $cacheRead += $usage->cacheRead;
            $cacheWrite += $usage->cacheWrite;
            $cost += $usage->cost->total;
        }

        return new SessionStats(
            $users,
            $assistants,
            $calls,
            $results,
            count($this->messages()),
            $input,
            $output,
            $cacheRead,
            $cacheWrite,
            $cost,
        );
    }

    /**
     * The last thing the assistant actually said, for `/copy`.
     *
     * An aborted message with nothing in it is skipped: someone who interrupts and then
     * copies means the answer before the interruption, not the empty shell of it.
     */
    public function lastAssistantText(): ?string
    {
        foreach (array_reverse($this->messages()) as $message) {
            if (!$message instanceof AssistantMessage) {
                continue;
            }

            if ($message->stopReason === StopReason::Aborted && $message->content === []) {
                continue;
            }

            $text = '';

            foreach ($message->content as $block) {
                if ($block instanceof TextContent) {
                    $text .= $block->text;
                }
            }

            return trim($text) === '' ? null : trim($text);
        }

        return null;
    }

    private static function textOf(UserMessage $message): string
    {
        $text = '';

        foreach ($message->content as $block) {
            if ($block instanceof TextContent) {
                $text .= $block->text;
            }
        }

        return $text;
    }
}
