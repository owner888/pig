<?php

declare(strict_types=1);

namespace Pig\CodingAgent\Tools;

use Closure;
use Pig\Agent\Agent;
use Pig\Agent\AgentTool;
use Pig\Ai\SystemMessage;
use Pig\Ai\Utils\Text;
use Pig\CodingAgent\CustomTools\CustomToolSet;
use Pig\CodingAgent\CustomTools\WrappedCustomTool;
use Pig\CodingAgent\Extensions\ExtensionGuardedTool;
use Pig\CodingAgent\Extensions\ExtensionRunner;
use Pig\CodingAgent\Prompt\ContextFile;
use Pig\CodingAgent\Prompt\Skill;
use Pig\CodingAgent\Prompt\SystemPrompt;

/**
 * Which tools the model is offered, and what the system prompt says about them.
 *
 * There were three copies of "built-ins beside the custom tools, wrapped with the hooks, and a
 * system prompt to match": `CodingAgent::create()`, the `onChange()` listener for a tool that
 * arrives after startup, and `/reload`. They had already drifted — `/reload` built its custom
 * tool set without the `--tools` filter, so a reload put back every tool the command line had
 * left out. This is the one place now, and it is also what upstream's active-tool set needed:
 * `setActive()` narrows what the model is offered **without unregistering anything**, so an
 * extension can switch a tool off for a phase of work and back on later.
 *
 * Narrowing is by name, and a name nothing registered is ignored rather than refused —
 * upstream's rule, and the right one for a list an extension builds from what it hopes is there.
 *
 * A custom tool registered with `defaultActive: false` (upstream's `ToolDefinition.defaultActive`)
 * is registered but not active: it is left out of "every registered tool" unless the run named it
 * — `--tools` or `defaultTools`, which `$named` answers for — or `setActive()` lists it. That is
 * upstream's `_isActivatedOnRegistration()` beside the `allowedTools(toolName)` and
 * `initialActiveToolNames` halves of `_refreshToolRegistry()`.
 */
final class ToolLoadout
{
    /** @var list<string>|null null is every registered tool */
    private ?array $active = null;

    /**
     * The prompt sections `apply()` last worked out — upstream's `_baseSystemPromptOptions`, built.
     * The loadout no longer writes the prompt into the agent: the session diffs these against the
     * sections the transcript has and sends what changed as a system message
     * (`AgentSession::preparePromptUpdate()`).
     *
     * @var array<string, string>
     */
    private array $sections = [];

    /**
     * Tools of the restored or reloaded loadout that are not registered yet — upstream's
     * `_pendingToolNames`: "such as tools of MCP servers that are still connecting. They are
     * activated when they are registered, and dropped when `setActiveToolsByName()` deactivates a
     * tool or the next agent run starts."
     *
     * @var array<string, true>
     */
    private array $pending = [];

    /** @var list<string>|null every tool registered as of the last `apply()`; null before the first */
    private ?array $registered = null;

    /** @var (Closure(): array<string, array<string, mixed>>)|null upstream's tool options, asked at each `apply()` */
    private ?Closure $toolOptions = null;

    /** @var (Closure(list<mixed>): list<mixed>)|null what a tool's pictures go through after the hooks */
    private ?Closure $resultImages = null;

    /**
     * Whether the run named a tool — `--tools` (by name or pattern, upstream's `allowedTools`) or
     * the resolved `defaultTools` list (upstream's `initialActiveToolNames`). A named tool is
     * active even when it is registered with `defaultActive: false`. Null: nothing was named.
     *
     * @var (Closure(string): bool)|null
     */
    private ?Closure $named = null;

    /**
     * @param list<string>            $builtIn      built-in tool names, as `ToolSet` knows them
     * @param list<ContextFile>|null  $contextFiles
     * @param list<Skill>             $skills
     */
    public function __construct(
        private readonly Agent $agent,
        private readonly string $cwd,
        private readonly array $builtIn,
        private CustomToolSet $customTools,
        private readonly ExtensionRunner $extensionRunner,
        private ?array $contextFiles = null,
        private array $skills = [],
        private readonly ?string $systemPrompt = null,
        private readonly ?string $appendSystemPrompt = null,
    ) {
    }

    /**
     * What `--tools` or `defaultTools` named — see `$named`. A loadout already applied is applied again.
     *
     * @param (Closure(string): bool)|null $named
     */
    public function useNamed(?Closure $named): void
    {
        $this->named = $named;
        $this->reapply();
    }

    /**
     * What `/reload` read off disk this time. The active set survives a reload by name, so an
     * extension that narrowed it does not see its choice undone by somebody else's `/reload`.
     *
     * @param list<ContextFile>|null $contextFiles
     * @param list<Skill>            $skills
     */
    public function reloaded(CustomToolSet $customTools, ?array $contextFiles, array $skills): void
    {
        // Upstream's `reload()`: "Tools the new extensions register later, such as MCP tools, are
        // pending until then."
        foreach ($this->activeNames() as $name) {
            $this->pending[$name] = true;
        }

        $this->customTools = $customTools;
        $this->contextFiles = $contextFiles;
        $this->skills = $skills;
        $this->apply();
    }

    /** @return list<Skill> the skills the prompt names now, extensions' included */
    public function skills(): array
    {
        return $this->skills;
    }

    /**
     * The skills extensions added through `resources_discover`, on top of what was loaded off
     * disk; a same-named one replaces it, as a later root replaces an earlier one in `Skills`.
     *
     * @param list<Skill> $skills
     */
    public function addSkills(array $skills): void
    {
        $byName = [];

        foreach ([...$this->skills, ...$skills] as $skill) {
            $byName[$skill->name] = $skill;
        }

        $this->skills = array_values($byName);
        $this->apply();
    }

    /**
     * Upstream's `_buildRuntime()` options for the built-in tools — `read`'s image settings,
     * `bash`'s command prefix — asked each time the tools are built, so a setting changed in the
     * session reaches the next build. A loadout already applied is applied again.
     *
     * @param Closure(): array<string, array<string, mixed>> $options
     */
    public function useToolOptions(Closure $options): void
    {
        $this->toolOptions = $options;
        $this->reapply();
    }

    /**
     * Upstream's image half of `_afterToolCall()`: every tool's result, after the `tool_result`
     * hooks, goes through $normalize. A loadout already applied is applied again.
     *
     * @param Closure(list<mixed>): list<mixed> $normalize
     */
    public function useResultImages(Closure $normalize): void
    {
        $this->resultImages = $normalize;
        $this->reapply();
    }

    private function reapply(): void
    {
        if ($this->registered !== null) {
            $this->apply();
        }
    }

    /**
     * Hand the agent the tools that are active now, and work out the system prompt that names them.
     *
     * Upstream's `_applyToolLoadout()` and `_rebuildSystemPrompt()`: the tools go on the agent,
     * whose loop declares any difference from what the transcript says before the next request;
     * the prompt is kept here as sections (`systemPromptSections()`) for the session to send.
     */
    public function apply(): void
    {
        $active = $this->activeNames();
        $builtIn = array_values(array_filter($this->builtIn, static fn (string $name): bool => in_array($name, $active, true)));

        $custom = array_values(array_filter(
            $this->customTools->agentTools(),
            static fn (AgentTool $tool): bool => in_array($tool->definition()->name, $active, true),
        ));

        // A registered tool with a built-in's name replaces the built-in, as upstream's does: an
        // extension that registers `bash` is offering its own `bash`, and the model is told one.
        $customNames = array_map(static fn (AgentTool $tool): string => $tool->definition()->name, $custom);
        $builtIn = array_values(array_filter($builtIn, static fn (string $name): bool => !in_array($name, $customNames, true)));

        $tools = ExtensionGuardedTool::wrap([...ToolSet::create($this->cwd, $builtIn, $this->toolOptions !== null ? ($this->toolOptions)() : []), ...$custom], $this->extensionRunner);

        if ($this->resultImages !== null) {
            $tools = array_map(fn (AgentTool $tool): AgentTool => new ResultImagesTool($tool, $this->resultImages), $tools);
        }

        $this->agent->setTools($this->prepared($tools, $active));

        // Upstream's `_setActiveTools()`: a pending tool that is active now is pending no longer.
        foreach ($active as $name) {
            unset($this->pending[$name]);
        }

        $this->registered = $this->names();

        [$snippets, $guidelines] = $this->customTools->promptContributions($active);
        $this->sections = SystemPrompt::sections(
            $this->cwd,
            $builtIn,
            SystemPrompt::resolve($this->systemPrompt),
            SystemPrompt::resolve($this->appendSystemPrompt),
            $this->contextFiles,
            $this->skills,
            $snippets,
            $guidelines,
        );
    }

    /**
     * Upstream's `prepareLoadout` step of `_applyToolLoadout()`: each active custom tool with a
     * `prepareLoadout` is asked, with the whole active list, what to change — descriptions to
     * show in place of the tools' own (`DescribedTool`), and tools to keep callable but not
     * declare (left off what the agent is handed; the asker keeps its own reference). A later
     * answer wins where two name one tool, which is upstream's `Object.assign` order.
     *
     * @param list<AgentTool> $tools
     * @param list<string>    $active the active tools' names
     * @return list<AgentTool>
     */
    private function prepared(array $tools, array $active): array
    {
        $descriptions = [];
        $hidden = [];

        foreach ($this->customTools->loaded() as $one) {
            if ($one->tool->prepareLoadout === null || !in_array($one->tool->name, $active, true)) {
                continue;
            }

            $changes = ($one->tool->prepareLoadout)($tools);

            foreach ($changes['descriptions'] ?? [] as $name => $description) {
                $descriptions[$name] = $description;
            }

            foreach ($changes['hiddenDeclarations'] ?? [] as $name) {
                $hidden[$name] = true;
            }
        }

        if ($descriptions === [] && $hidden === []) {
            return $tools;
        }

        $out = [];

        foreach ($tools as $tool) {
            $name = $tool->definition()->name;

            if (isset($hidden[$name])) {
                continue;
            }

            $out[] = isset($descriptions[$name]) && $descriptions[$name] !== $tool->definition()->description
                ? new DescribedTool($tool, $descriptions[$name])
                : $tool;
        }

        return $out;
    }

    /**
     * The registry changed after startup — an extension registered or removed a tool, an MCP
     * server connected. Upstream's `_refreshToolRegistry()` without a new loadout: the tools that
     * were active stay active, a tool that was not registered before is activated when it is
     * activated on registration (`_isActivatedOnRegistration()`: not `defaultActive: false`) or
     * the run named it (upstream's `allowedTools(toolName)`), and so is a pending tool that is
     * registered now. pig has no exposure on a registered tool, so `defaultActive` is the only
     * thing that keeps a new one off.
     *
     * With no narrowed set, `activeNames()` already works that out from what is registered. The
     * set is kept by name rather than narrowed to what is registered, so a tool that goes away and
     * comes back is still active.
     */
    public function refresh(): void
    {
        if ($this->active !== null) {
            $names = $this->names();
            $this->active = array_values(array_unique([
                ...$this->active,
                ...array_filter(array_diff($names, $this->registered ?? []), $this->isActivatedByDefault(...)),
                ...array_intersect($names, array_keys($this->pending)),
            ]));
        }

        $this->apply();
    }

    /**
     * Restore the active tools a session transcript declared — the second half of upstream's
     * `_restoreToolsFromTranscript()`. The ones not registered yet are pending; `--tools` and
     * `--exclude-tools` keep out of the pending set what they would keep out of the registry.
     *
     * @param list<string> $names
     */
    public function restore(array $names): void
    {
        $filter = $this->customTools->filter();
        $this->pending = array_fill_keys(
            $filter === null ? $names : array_values(array_filter($names, static fn (string $name): bool => $filter($name))),
            true,
        );
        $this->setActive($names);
    }

    /** The registered custom tools' names — every registered tool that is not a built-in. @return list<string> */
    public function customToolNames(): array
    {
        return $this->customTools->names();
    }

    /**
     * Upstream's `_isActivatedOnRegistration()`: a registered custom tool that was not registered
     * with `defaultActive: false`. pig has no undeclarable tools, so that is the whole test.
     */
    public function isActivatedOnRegistration(string $name): bool
    {
        $tool = $this->customTools->find($name);

        return $tool !== null && $tool->defaultActive !== false;
    }

    /** Forget the pending tools. Upstream's `_pendingToolNames.clear()`. */
    public function clearPending(): void
    {
        $this->pending = [];
    }

    /** Whether $name is a restored tool waiting to be registered. */
    public function isPending(string $name): bool
    {
        return isset($this->pending[$name]);
    }

    /**
     * The prompt sections for the tools active now, as of the last `apply()`.
     *
     * @return array<string, string>
     */
    public function systemPromptSections(): array
    {
        return $this->sections;
    }

    /** The prompt those sections render to — upstream's `buildSystemPrompt()` of the current options. */
    public function systemPrompt(): string
    {
        return Text::getSystemMessageText(new SystemMessage('', $this->sections));
    }

    /** Every registered tool's name, active or not. Upstream's `getAllTools()`, by name. @return list<string> */
    public function names(): array
    {
        return [...$this->builtIn, ...$this->customTools->names()];
    }

    /**
     * What the model is offered now. With no narrowed set, every registered tool that is active
     * by default (`isActivatedByDefault()`).
     *
     * @return list<string>
     */
    public function activeNames(): array
    {
        return $this->active === null
            ? array_values(array_filter($this->names(), $this->isActivatedByDefault(...)))
            : array_values(array_filter($this->names(), fn (string $name): bool => in_array($name, $this->active, true)));
    }

    /**
     * Whether a registered tool is active without anybody calling `setActive()`: every built-in
     * here (`$builtIn` is already what the run selected), a custom tool unless it was registered
     * with `defaultActive: false`, and such a tool too when `--tools` or `defaultTools` named it.
     * Upstream's `_isActivatedOnRegistration()` or `allowedTools(toolName)` / `initialActiveToolNames`.
     */
    private function isActivatedByDefault(string $name): bool
    {
        if ($this->customTools->find($name)?->defaultActive !== false) {
            return true;
        }

        return $this->named !== null && ($this->named)($name);
    }

    /**
     * Offer the model only these. Takes effect from the next request, because `AgentLoop` asks
     * for the tools before every model call.
     *
     * @param list<string> $names
     */
    public function setActive(array $names): void
    {
        $known = $this->names();
        $this->active = array_values(array_unique(array_filter($names, static fn (string $name): bool => in_array($name, $known, true))));
        $this->apply();
    }

    /**
     * Name, description and schema of every registered tool. Upstream's `getAllTools()`.
     *
     * @return list<array{name: string, description: string, parameters: array<string, mixed>, active: bool}>
     */
    public function describe(): array
    {
        $active = $this->activeNames();
        $tools = [...ToolSet::create($this->cwd, $this->builtIn), ...$this->customTools->agentTools()];

        return array_map(static function (AgentTool $tool) use ($active): array {
            $reaches = $tool instanceof WrappedCustomTool ? $tool->inner()->reachesTools : null;

            return [
                'name' => $tool->definition()->name,
                'description' => $tool->definition()->description,
                'parameters' => $tool->definition()->parameters,
                'active' => in_array($tool->definition()->name, $active, true),
                // Upstream's `...(definition.reachesTools ? { reachesTools } : {})`.
                ...($reaches === null ? [] : ['reachesTools' => $reaches]),
            ];
        }, $tools);
    }
}
