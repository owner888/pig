<?php

declare(strict_types=1);

namespace Pig\CodingAgent\Extensions;

use Closure;
use Pig\Ai\ImageContent;
use Pig\Async\AbortSignal;
use Pig\Async\Async;
use Pig\Ai\Model;
use Pig\Ai\SystemMessage;
use Pig\Ai\Utils\Transcript;
use Pig\CodingAgent\Extensions\Events\BeforeAgentStartEvent;
use Pig\CodingAgent\Extensions\Events\ContextEvent;
use Pig\CodingAgent\Extensions\Events\McpServersChangeEvent;
use Pig\CodingAgent\Extensions\Events\ContextWithSystemEvent;
use Pig\CodingAgent\Extensions\Events\BeforeProviderRequestEvent;
use Pig\CodingAgent\Extensions\Events\BeforeProviderHeadersEvent;
use Pig\CodingAgent\Extensions\Events\SessionBeforeCompactEvent;
use Pig\CodingAgent\Extensions\Boundary\BoundaryContextPreview;
use Pig\CodingAgent\Extensions\Boundary\BoundaryDispatch;
use Pig\CodingAgent\Extensions\Boundary\SessionBoundaryDraft;
use Pig\CodingAgent\Extensions\Events\AgentBeforeSettleEvent;
use Pig\CodingAgent\Extensions\Events\ProjectTrustEvent;
use Pig\CodingAgent\Extensions\Events\ResourcesDiscoverEvent;
use Pig\CodingAgent\Extensions\Events\CacheWarmingDecisionEvent;
use Pig\CodingAgent\Extensions\Events\SessionBeforeForkEvent;
use Pig\CodingAgent\Extensions\Events\SessionBeforeSwitchEvent;
use Pig\CodingAgent\Extensions\Events\SessionBeforeTreeEvent;
use Pig\CodingAgent\Extensions\Events\ToolCallEvent;
use Pig\CodingAgent\Extensions\Events\ToolResultEvent;
use Pig\CodingAgent\Extensions\Events\InputEvent;
use Pig\CodingAgent\Extensions\LoadedExtension;
use Pig\CodingAgent\McpServerRegistry;
use Pig\CodingAgent\Extensions\Events\UserBashEvent;
use Pig\CodingAgent\Extensions\Results\InputEventResult;
use Pig\CodingAgent\Extensions\Results\UserBashEventResult;
use Pig\CodingAgent\Extensions\Results\BeforeAgentStartEventResult;
use Pig\CodingAgent\Extensions\Results\ContextEventResult;
use Pig\CodingAgent\Extensions\Results\BeforeProviderRequestResult;
use Pig\CodingAgent\Extensions\Results\SessionBeforeCompactResult;
use Pig\CodingAgent\Extensions\Results\BoundaryResult;
use Pig\CodingAgent\Extensions\Results\ProjectTrustEventResult;
use Pig\CodingAgent\Extensions\Results\ResourcesDiscoverResult;
use Pig\CodingAgent\Extensions\Results\CacheWarmingDecisionEventResult;
use Pig\CodingAgent\Extensions\Results\SessionBeforeForkResult;
use Pig\CodingAgent\Extensions\Results\SessionBeforeSwitchResult;
use Pig\CodingAgent\Extensions\Results\SessionBeforeTreeResult;
use Pig\CodingAgent\Extensions\Results\ToolCallEventResult;
use Pig\CodingAgent\Extensions\Results\ToolResultEventResult;
use Pig\CodingAgent\Prompt\SystemPromptOptions;
use Pig\CodingAgent\Session\AgentSession;
use Pig\CodingAgent\Session\CustomMessage;
use Pig\CodingAgent\Session\SessionManager;
use Pig\CodingAgent\Tools\Paths;
use Throwable;

/**
 * Firing events at the hooks that asked for them.
 *
 * Upstream has one `emit()` returning a union of every result type, plus three special
 * cases beside it. Here each event that can answer back has its own method with its own
 * return type, because a union is what TypeScript has instead of that — and a caller
 * that has to cast the result of `emit()` to know what it got is one rename away from
 * casting it to the wrong thing.
 *
 * **What happens when a handler throws** depends on what the event is for:
 *
 * - Something that only reports — `agent_end`, `tool_result`, `session_compact` — is
 *   caught and reported. A hook that watches is not allowed to stop the thing it watches.
 * - `tool_call` is not caught here. A hook that was asked whether a tool may run and
 *   answered with an exception has not said yes, and the call is blocked. `ExtensionGuardedTool`
 *   is where that is turned into an error the model reads.
 *
 * A handler that returns the wrong kind of object is reported and ignored: silently
 * treating it as "no opinion" would turn a typo into a hook that appears to work.
 */
final class ExtensionRunner
{
    /** @var list<LoadedExtension> */
    private array $extensions;

    /** @var array<int, Closure(ExtensionError): void> */
    private array $listeners = [];

    private int $nextListenerId = 0;

    private ?Closure $getModel = null;

    private ?Closure $isIdle = null;

    private ?Closure $abort = null;

    private ?Closure $hasPendingMessages = null;

    private ?Closure $getSignal = null;

    private ?Closure $getApiKey = null;

    private ?\Pig\CodingAgent\Session\AgentSession $session = null;

    private ?ExtensionUi $ui = null;

    /** @var array<string, true> servers already reported as connected by nobody */
    private array $reportedMcpServers = [];

    private readonly ExtensionState $state;

    /** @param list<LoadedExtension> $extensions in the order they were loaded, which is the order they run */
    public function __construct(
        array $extensions = [],
        private readonly string $cwd = '.',
        private ?SessionManager $store = null,
    ) {
        $this->extensions = $extensions;
        $this->state = new ExtensionState();
    }

    public function setStore(?SessionManager $store): void
    {
        $this->store = $store;
    }

    public function setSession(?\Pig\CodingAgent\Session\AgentSession $session): void
    {
        $this->session = $session;
    }

    /**
     * Tell the runner how to answer the questions a handler's context can ask.
     *
     * Separate from the constructor because the session does not exist yet when the
     * hooks are loaded: the loader runs before `bin/pig` has a model or an agent, and a
     * hook that asks for the model at startup would be told there is none for the rest
     * of the session if these were captured values rather than closures.
     *
     * @param Closure(): (Model|null) $getModel
     * @param Closure(): bool|null    $isIdle
     * @param Closure(): void|null    $abort
     * @param Closure(): bool|null    $hasPendingMessages
     * @param Closure(): (AbortSignal|null)|null $signal the turn in progress's
     * @param ExtensionUi|null                     $ui   the terminal's, when there is one
     * @param Closure(CustomMessage, ?bool, ?string): void|null $send `$pig->sendMessage()`: the message, `triggerTurn`, `deliverAs`
     * @param Closure(string, mixed): void|null     $note `$pig->appendEntry()`
     */
    /**
     * `initialize()` over a session: the closures every mode hands over are the same twelve,
     * and only the UI differs — a terminal's, the RPC host's, or `NoUi` when nobody is there.
     * Written once here after the fifth copy; what each mode still does for itself is
     * `onError()`, since where a broken hook is reported is the thing that differs.
     */
    public function wire(AgentSession $session, ?ExtensionUi $ui): void
    {
        $this->initialize(
            getModel: static fn () => $session->model(),
            isIdle: static fn (): bool => !$session->isStreaming(),
            abort: static function () use ($session): void {
                $session->abort();
            },
            hasPendingMessages: static fn (): bool => $session->queued() !== [],
            signal: static fn () => $session->signal(),
            ui: $ui,
            send: static function (CustomMessage $message, ?bool $triggerTurn, ?string $deliverAs) use ($session): void {
                $session->sendHookMessage($message, $triggerTurn, $deliverAs);
            },
            note: static function (string $customType, mixed $data) use ($session): void {
                $session->appendHookEntry($customType, $data);
            },
            getApiKey: static fn (Model $m) => $session->keyFor($m),
            setSessionName: static fn (string $name) => $session->setSessionName($name),
            getSessionName: static fn () => $session->getSessionName(),
        );
    }

    public function initialize(
        Closure $getModel,
        ?Closure $isIdle = null,
        ?Closure $abort = null,
        ?Closure $hasPendingMessages = null,
        ?Closure $signal = null,
        ?ExtensionUi $ui = null,
        ?Closure $send = null,
        ?Closure $note = null,
        ?Closure $getApiKey = null,
        ?Closure $setSessionName = null,
        ?Closure $getSessionName = null,
    ): void {
        $this->getModel = $getModel;
        $this->isIdle = $isIdle;
        $this->abort = $abort;
        $this->hasPendingMessages = $hasPendingMessages;
        $this->getSignal = $signal;
        $this->getApiKey = $getApiKey;

        // Servers registered from now on reach the extension that connects them right away; the
        // ones registered during loading are read with `getMcpServers()` on `session_start`.
        // On the loop rather than inside the registering call, as upstream's `void this.emit()`
        // is: a handler that connects a server awaits, and a factory registering one at load time
        // is not in a fiber.
        $registry = McpServerRegistry::current();
        $registry->setChangeListener(function () use ($registry): void {
            $servers = $registry->list();
            Async::spawn(function () use ($servers): void {
                $this->emit(new McpServersChangeEvent($servers));
                $this->reportUnhandledMcpServers();
            });
        });

        // `NoUi` answers without asking anybody, so there is no prompt to report around it.
        $this->ui = $ui === null || $ui instanceof NoUi ? $ui : new PromptingUi($ui, $this->emit(...));

        // Handed to each hook's own API object rather than kept here, because that is the
        // object the hook closed over — `$pig->sendMessage()` inside a handler is a call on
        // the thing the factory was given at load time, long before a session existed.
        //
        // One at a time, as upstream wires them: `$send !== null && $note !== null` was one
        // condition for two independent facts, so a mode that offered only one got neither —
        // and what a hook would then read is `sendMessage() needs a session — call it from a
        // handler`, which is an explanation of something that did not happen.
        foreach ($this->extensions as $extension) {
            $extension->api->writesTo($send, $note);
            $extension->api->bindSessionNames($setSessionName, $getSessionName);
            // The context rather than the signal itself: it is built fresh per emit, so what
            // `$pig->exec()` reads off it is the signal for the turn running *now* rather than
            // whichever one existed when the hooks were wired.
            $extension->api->withContext($this->context(...));
        }
    }

    /**
     * Every renderer the hooks registered, by the type it draws.
     *
     * Later hooks win a clash, which is the same rule `registerMessageRenderer()` applies
     * within one hook — and unlike a command clash it is not worth complaining about: a
     * renderer only ever draws its own hook's messages, so two hooks claiming one type
     * means one of them is drawing messages it did not send and would not recognise.
     *
     * @return array<string, Closure>
     */
    public function renderers(): array
    {
        $renderers = [];

        foreach ($this->extensions as $extension) {
            foreach ($extension->api->renderers() as $type => $renderer) {
                $renderers[$type] = $renderer;
            }
        }

        return $renderers;
    }

    /** @return array<string, Closure> */
    public function entryRenderers(): array
    {
        $renderers = [];

        foreach ($this->extensions as $extension) {
            foreach ($extension->api->entryRenderers() as $type => $renderer) {
                $renderers[$type] = $renderer;
            }
        }

        return $renderers;
    }

    /** @return list<Closure(string, array{role: string, isStreaming: bool}): string> */
    public function markdownTransformers(): array
    {
        $transformers = [];

        foreach ($this->extensions as $extension) {
            foreach ($extension->api->markdownTransformers() as $t) {
                $transformers[] = $t;
            }
        }

        return $transformers;
    }

    /** @return array<string, array{key: string, handler: Closure, description: string, extensionPath: string}> */
    public function shortcuts(): array
    {
        $shortcuts = [];

        foreach ($this->extensions as $extension) {
            foreach ($extension->api->shortcuts() as $key => $spec) {
                $shortcuts[$key] = [...$spec, 'extensionPath' => $extension->path];
            }
        }

        return $shortcuts;
    }

    /**
     * Resolve custom tool renderers through the registered resolvers onion chain.
     * Upstream's `resolveToolRenderers()`.
     *
     * @return array{renderCall?: Closure, renderResult?: Closure}|null
     */
    public function resolveToolRenderers(string $toolName, ?Closure $base = null): ?array
    {
        $resolvers = [];

        foreach ($this->extensions as $extension) {
            foreach ($extension->api->toolRenderers() as $r) {
                $resolvers[] = $r;
            }
        }

        if ($resolvers === []) {
            return $base !== null ? $base() : null;
        }

        $chain = static function (int $index) use (&$chain, $resolvers, $toolName, $base): ?array {
            if (!isset($resolvers[$index])) {
                return $base !== null ? $base() : null;
            }

            $resolver = $resolvers[$index];

            return $resolver($toolName, static fn (): ?array => $chain($index + 1));
        };

        return $chain(0);
    }

    /** Where every hook that loaded came from. @return list<string> */
    public function paths(): array
    {
        return array_map(static fn (LoadedExtension $extension): string => $extension->path, $this->extensions);
    }

    public function isEmpty(): bool
    {
        return $this->extensions === [];
    }

    /** Whether firing this event would reach anyone. */
    /**
     * Report registered MCP servers when no hook handles `mcp_servers_change`, which means nothing
     * connects them (for example when another MCP extension replaced the built-in one).
     */
    public function reportUnhandledMcpServers(): void
    {
        if ($this->hasHandlers('mcp_servers_change')) {
            return;
        }

        foreach (McpServerRegistry::current()->list() as $server) {
            if (isset($this->reportedMcpServers[$server->name])) {
                continue;
            }

            $this->reportedMcpServers[$server->name] = true;
            $this->emitError(new ExtensionError(
                $server->extensionPath,
                'register_mcp_server',
                "MCP server \"{$server->name}\" is registered, but no loaded extension connects MCP servers; another extension may have replaced the built-in MCP support",
            ));
        }
    }

    public function hasHandlers(string $event): bool
    {
        foreach ($this->extensions as $extension) {
            if ($extension->api->handlers($event) !== []) {
                return true;
            }
        }

        return false;
    }

    /**
     * Every slash command the hooks added, by name.
     *
     * First one wins, so two hooks registering `/deploy` leaves the earlier one working
     * and the later one reported — rather than the two silently taking turns.
     *
     * @return array{0: array<string, RegisteredCommand>, 1: list<ExtensionError>}
     */
    public function commands(): array
    {
        $commands = [];
        $clashes = [];

        foreach ($this->extensions as $extension) {
            foreach ($extension->api->commands() as $name => $command) {
                if (isset($commands[$name])) {
                    $clashes[] = new ExtensionError(
                        $extension->path,
                        'register_command',
                        "/{$name} was already registered by {$commands[$name]->extensionPath}",
                    );

                    continue;
                }

                $commands[$name] = $command;
            }
        }

        return [$commands, $clashes];
    }

    /**
     * The command that answers to this name, or null.
     *
     * Upstream's `getCommand()`, and it is `commands()` asked one question rather than a second
     * walk over the hooks: the first-one-wins rule has one implementation, so a lookup and a
     * listing cannot come to disagree about which of two `/deploy`s is the live one.
     */
    public function command(string $name): ?RegisteredCommand
    {
        [$commands] = $this->commands();

        return $commands[$name] ?? null;
    }

    /**
     * @param Closure(ExtensionError): void $listener
     * @return Closure(): void call it to stop listening
     */
    public function onError(Closure $listener): Closure
    {
        $id = $this->nextListenerId++;
        $this->listeners[$id] = $listener;

        return function () use ($id): void {
            unset($this->listeners[$id]);
        };
    }

    public function emitError(ExtensionError $error): void
    {
        foreach ($this->listeners as $listener) {
            $listener($error);
        }
    }

    /** The session as a handler sees it, built fresh each time so nothing is stale. */
    public function context(): ExtensionContext
    {
        return new ExtensionContext(
            $this->cwd,
            $this->store,
            $this->getModel === null ? null : ($this->getModel)(),
            $this->isIdle,
            $this->abort,
            $this->hasPendingMessages,
            $this->ui,
            // `NoUi` is not a UI. It answers every question without asking anybody, which is
            // exactly what a hook checking `hasUi` is trying to find out before it asks —
            // `$this->ui !== null` said yes to it, so a hook in `--mode text` was told there
            // was somebody there and then heard nothing back.
            $this->ui !== null && !$this->ui instanceof NoUi,
            $this->getSignal === null ? null : ($this->getSignal)(),
            $this->state,
            $this->getApiKey,
            $this->session,
        );
    }

    /**
     * Fire an event nobody can answer.
     *
     * Every handler runs even if an earlier one threw, because they belong to different
     * hooks and one person's broken hook is not another's.
     */
    public function emit(ExtensionEvent $event): void
    {
        $context = $this->context();

        foreach ($this->extensions as $extension) {
            foreach ($extension->api->handlers($event->type()) as $handler) {
                try {
                    $handler($event, $context);
                } catch (Throwable $error) {
                    $this->fail($extension, $event->type(), $error);
                }
            }
        }
    }

    /**
     * Ask the hooks whether a tool may run.
     *
     * The first block stops the rest: the answer is already no, and running the others
     * would only give them a chance to disagree with it.
     *
     * Throwables are **not** caught — see the class docblock.
     */
    public function emitToolCall(ToolCallEvent $event): ?ToolCallEventResult
    {
        $context = $this->context();

        foreach ($this->extensions as $extension) {
            foreach ($extension->api->handlers('tool_call') as $handler) {
                $result = $handler($event, $context);

                if ($result === null) {
                    continue;
                }

                if (!$result instanceof ToolCallEventResult) {
                    $this->wrongType($extension, 'tool_call', ToolCallEventResult::class, $result);

                    continue;
                }

                if ($result->block) {
                    return $result;
                }
            }
        }

        return null;
    }

    /**
     * Show the hooks what a tool produced, and let them change it.
     *
     * Last one wins, and each sees what the tool produced rather than what the hook
     * before it said — chaining is `context`'s job, and doing it here would mean a hook
     * could not tell the tool's own output from another hook's edit of it.
     */
    public function emitToolResult(ToolResultEvent $event): ?ToolResultEventResult
    {
        $context = $this->context();
        $last = null;

        foreach ($this->extensions as $extension) {
            foreach ($extension->api->handlers('tool_result') as $handler) {
                try {
                    $result = $handler($event, $context);
                } catch (Throwable $error) {
                    $this->fail($extension, 'tool_result', $error);

                    continue;
                }

                if ($result === null) {
                    continue;
                }

                if (!$result instanceof ToolResultEventResult) {
                    $this->wrongType($extension, 'tool_result', ToolResultEventResult::class, $result);

                    continue;
                }

                $last = $result;
            }
        }

        return $last;
    }

    /**
     * Run the conversation past the hooks on its way to the model — upstream's `emitContext()`, in
     * its two phases.
     *
     * The `context` handlers are chained: each is given what the last one returned, so two hooks
     * can both edit the context without either having to know about the other. They see the
     * conversation only; "the system messages belong to Pi", so after each handler they are put
     * back (`restoreSystemMessages()`). Then the `context_with_system` handlers see the whole
     * transcript and their output is used as returned.
     *
     * @param list<mixed> $messages
     * @return list<mixed>
     */
    public function emitContext(array $messages): array
    {
        $context = $this->context();
        $current = $messages;

        foreach ($this->extensions as $extension) {
            foreach ($extension->api->handlers('context') as $handler) {
                $visible = array_values(array_filter($current, static fn (mixed $message): bool => !$message instanceof SystemMessage));

                try {
                    $result = $handler(new ContextEvent($visible), $context);
                } catch (Throwable $error) {
                    $this->fail($extension, 'context', $error);

                    continue;
                }

                if ($result === null) {
                    continue;
                }

                if (!$result instanceof ContextEventResult) {
                    $this->wrongType($extension, 'context', ContextEventResult::class, $result);

                    continue;
                }

                $current = self::restoreSystemMessages($current, $visible, $result->messages);
            }
        }

        foreach ($this->extensions as $extension) {
            foreach ($extension->api->handlers('context_with_system') as $handler) {
                $hadLeadingSystemMessage = ($current[0] ?? null) instanceof SystemMessage;

                try {
                    $result = $handler(new ContextWithSystemEvent($current), $context);
                } catch (Throwable $error) {
                    $this->fail($extension, 'context_with_system', $error);

                    continue;
                }

                if ($result !== null && !$result instanceof ContextEventResult) {
                    $this->wrongType($extension, 'context_with_system', ContextEventResult::class, $result);

                    continue;
                }

                $current = $result?->messages ?? $current;

                // "Providers read the prompt and initial tools from the leading system message.
                // Losing it is never intended; report it but honor the handler's output."
                if ($hadLeadingSystemMessage && !(($current[0] ?? null) instanceof SystemMessage)) {
                    $this->emitError(new ExtensionError(
                        $extension->path,
                        'context_with_system',
                        'Handler removed the leading system message; the request has no prompt or initial tool declarations. Keep it at index 0 or replace a dropped prefix with getCurrentSystemMessage().',
                    ));
                }
            }
        }

        return $current;
    }

    /**
     * Re-attach the prompt and tool state after a `context` handler — upstream's
     * `restoreSystemMessages()`: "An unchanged conversation keeps every system message in place,
     * so models with mid-conversation support keep their cached prefix. A changed one gets the
     * replayed prompt sections and tool declarations as one leading system message, so pruning,
     * windowing, or slicing from a compaction summary cannot drop them."
     *
     * Unchanged is upstream's `sameMessages()`: the same objects in the same order.
     *
     * @param list<mixed> $current
     * @param list<mixed> $visible
     * @param list<mixed> $returned
     * @return list<mixed>
     */
    private static function restoreSystemMessages(array $current, array $visible, array $returned): array
    {
        if (array_values($returned) === $visible) {
            return $current;
        }

        $head = Transcript::getCurrentSystemMessage($current);

        return $head !== null ? [$head, ...array_values($returned)] : array_values($returned);
    }

    /**
     * Upstream's `emitBeforeAgentStart(trigger, systemPromptOptions)`: every handler sees the run's
     * trigger and the one options object, and what they return is combined — each handler's custom
     * message in order, and a `systemPrompt` answer applied to the options in turn, so the last
     * handler's is the one sent.
     *
     * @param array{messageType: 'user', prompt: string, images?: list<ImageContent>}|array{messageType: 'custom', message: CustomMessage} $trigger
     * @param SystemPromptOptions|null                    $systemPromptOptions mutated in place; a fresh one when null
     * @param (Closure(SystemPromptOptions): string)|null $renderSystemPrompt  what `$event->systemPrompt()` renders
     * @return list<CustomMessage> the handlers' messages, in order
     */
    public function emitBeforeAgentStart(array $trigger, ?SystemPromptOptions $systemPromptOptions = null, ?Closure $renderSystemPrompt = null): array
    {
        // One options object for every handler, as upstream's `currentOptions`: a section one
        // handler adds is there for the next, and a `systemPrompt` answer becomes
        // `forceSystemPrompt`, which later handlers observe.
        $options = $systemPromptOptions ?? new SystemPromptOptions();
        $render = $renderSystemPrompt === null ? null : static fn (): string => $renderSystemPrompt($options);
        $event = $trigger['messageType'] === 'custom'
            ? new BeforeAgentStartEvent('custom', null, [], $options, $render, $trigger['message'])
            : new BeforeAgentStartEvent('user', $trigger['prompt'], $trigger['images'] ?? [], $options, $render);
        $context = $this->context();
        $messages = [];

        foreach ($this->extensions as $extension) {
            foreach ($extension->api->handlers('before_agent_start') as $handler) {
                try {
                    $result = $handler($event, $context);
                } catch (Throwable $error) {
                    $this->fail($extension, 'before_agent_start', $error);

                    continue;
                }

                if ($result === null) {
                    continue;
                }

                if (!$result instanceof BeforeAgentStartEventResult) {
                    $this->wrongType($extension, 'before_agent_start', BeforeAgentStartEventResult::class, $result);

                    continue;
                }

                if ($result->message !== null) {
                    $messages[] = $result->message;
                }

                if ($result->systemPrompt !== null) {
                    $options->forceSystemPrompt = $result->systemPrompt;
                }
            }
        }

        return $messages;
    }

    /**
     * Upstream's `emitBeforeProviderRequest(payload)`: each handler given the payload the last one
     * left, a non-null answer replacing it. A handler that throws is reported and skipped.
     */
    public function emitBeforeProviderRequest(mixed $payload): mixed
    {
        $context = $this->context();
        $currentPayload = $payload;

        foreach ($this->extensions as $extension) {
            foreach ($extension->api->handlers('before_provider_request') as $handler) {
                try {
                    $result = $handler(new BeforeProviderRequestEvent($currentPayload), $context);
                } catch (Throwable $error) {
                    $this->fail($extension, 'before_provider_request', $error);

                    continue;
                }

                if ($result === null) {
                    continue;
                }

                if (!$result instanceof BeforeProviderRequestResult) {
                    $this->wrongType($extension, 'before_provider_request', BeforeProviderRequestResult::class, $result);

                    continue;
                }

                $currentPayload = $result->payload;
            }
        }

        return $currentPayload;
    }

    /**
     * Upstream's `emitBeforeProviderHeaders(headers)`: one event for every handler, which mutate its
     * `headers` in place; what is left is the answer. A handler that throws is reported and skipped.
     *
     * @param array<string, string|null> $headers
     * @return array<string, string|null>
     */
    public function emitBeforeProviderHeaders(array $headers): array
    {
        $context = $this->context();
        $event = new BeforeProviderHeadersEvent($headers);

        foreach ($this->extensions as $extension) {
            foreach ($extension->api->handlers('before_provider_headers') as $handler) {
                try {
                    $handler($event, $context);
                } catch (Throwable $error) {
                    $this->fail($extension, 'before_provider_headers', $error);
                }
            }
        }

        return $event->headers;
    }

    /**
     * Whether to send this cache refresh — upstream's `emitCacheWarmingDecision()`. Every handler
     * is asked and the last one with an answer wins; one that throws is reported and pig's own
     * decision stands, because a broken hook must not decide what the person pays for.
     *
     * @return 'warm'|'stop'
     */
    public function emitCacheWarmingDecision(CacheWarmingDecisionEvent $event): string
    {
        $context = $this->context();
        $action = $event->action;

        foreach ($this->extensions as $extension) {
            foreach ($extension->api->handlers('cache_warming_decision') as $handler) {
                try {
                    $result = $handler($event, $context);
                } catch (Throwable $error) {
                    $this->fail($extension, 'cache_warming_decision', $error);

                    continue;
                }

                if ($result === null) {
                    continue;
                }

                if (!$result instanceof CacheWarmingDecisionEventResult) {
                    $this->wrongType($extension, 'cache_warming_decision', CacheWarmingDecisionEventResult::class, $result);

                    continue;
                }

                if ($result->action === 'warm' || $result->action === 'stop') {
                    $action = $result->action;
                }
            }
        }

        return $action;
    }

    /**
     * Ask whether a hook will run a typed `!command` itself. Upstream's `emitUserBash()`.
     *
     * The first handler with an answer decides. A handler that **throws** is reported and the
     * throw goes on to the caller, which is upstream's rule and the reason is worth keeping: a
     * hook that exists to send commands somewhere else (a container, a remote machine) and
     * fails must not fall back to running the command here, on the machine the person was
     * keeping it away from.
     */
    public function emitUserBash(UserBashEvent $event): ?UserBashEventResult
    {
        $context = $this->context();

        foreach ($this->extensions as $extension) {
            foreach ($extension->api->handlers('user_bash') as $handler) {
                try {
                    $result = $handler($event, $context);
                } catch (Throwable $error) {
                    $this->fail($extension, 'user_bash', $error);

                    throw $error;
                }

                if ($result === null) {
                    continue;
                }

                if (!$result instanceof UserBashEventResult) {
                    $this->wrongType($extension, 'user_bash', UserBashEventResult::class, $result);

                    continue;
                }

                return $result;
            }
        }

        return null;
    }

    /**
     * Show the hooks what is about to be sent, and let them change it or take it.
     * Upstream's `emitInput()`.
     *
     * Chained, like `context`: each handler is given the text the one before it transformed,
     * because two extensions that each rewrite input — one expanding an abbreviation, one
     * redacting a key — have to compose. `handled` stops the walk and nothing is sent. A
     * handler that throws is reported and skipped; the input goes on as it was.
     *
     * Answers `continue` when nothing changed, `transform` with the final text when something
     * did, and `handled` when a handler took it.
     */
    public function emitInput(InputEvent $event): InputEventResult
    {
        if (!$this->listensTo('input')) {
            return InputEventResult::continue();
        }

        $context = $this->context();
        $text = $event->text;
        $images = $event->images;

        foreach ($this->extensions as $extension) {
            foreach ($extension->api->handlers('input') as $handler) {
                try {
                    $result = $handler(new InputEvent($text, $images, $event->source, $event->streamingBehavior), $context);
                } catch (Throwable $error) {
                    $this->fail($extension, 'input', $error);

                    continue;
                }

                if ($result === null) {
                    continue;
                }

                if (!$result instanceof InputEventResult) {
                    $this->wrongType($extension, 'input', InputEventResult::class, $result);

                    continue;
                }

                if ($result->action === 'handled') {
                    return $result;
                }

                if ($result->action === 'transform') {
                    $text = (string) $result->text;
                    $images = $result->images ?? $images;
                }
            }
        }

        return $text !== $event->text || $images !== $event->images
            ? InputEventResult::transform($text, $images)
            : InputEventResult::continue();
    }

    /** Whether any hook subscribed to this event, so a caller can skip building one for nobody. */
    public function listensTo(string $event): bool
    {
        foreach ($this->extensions as $extension) {
            if ($extension->api->handlers($event) !== []) {
                return true;
            }
        }

        return false;
    }

    /**
     * Ask the loaded extensions whether this project may be trusted, before its own `.pig/` is
     * loaded. The first yes or no wins; `undecided` falls through. Upstream's
     * `emitProjectTrustEvent()`, over the extensions loaded before trust — so the runner this is
     * called on is a pre-trust one, built for the question.
     */
    public function emitProjectTrust(ProjectTrustEvent $event): ?ProjectTrustEventResult
    {
        return $this->ask($event, ProjectTrustEventResult::class, static fn (object $r): bool => $r->decided());
    }

    /**
     * Collect the resource directories every `resources_discover` handler adds. Nothing stops
     * the rest: each extension's directories are its own, and a handler that threw is reported
     * and the others still answer. A relative path is resolved against the extension's directory.
     */
    public function emitResourcesDiscover(string $cwd, string $reason): DiscoveredResources
    {
        $event = new ResourcesDiscoverEvent($cwd, $reason);
        $context = $this->context();
        $skills = [];
        $prompts = [];
        $themes = [];

        foreach ($this->extensions as $extension) {
            foreach ($extension->api->handlers($event->type()) as $handler) {
                try {
                    $result = $handler($event, $context);
                } catch (Throwable $error) {
                    $this->fail($extension, $event->type(), $error);

                    continue;
                }

                if ($result === null) {
                    continue;
                }

                if (!$result instanceof ResourcesDiscoverResult) {
                    $this->wrongType($extension, $event->type(), ResourcesDiscoverResult::class, $result);

                    continue;
                }

                $base = dirname($extension->path);
                $found = static fn (string $path): array => ['path' => Paths::resolve($path, $base), 'extensionPath' => $extension->path];
                $skills = [...$skills, ...array_map($found, $result->skillPaths)];
                $prompts = [...$prompts, ...array_map($found, $result->promptPaths)];
                $themes = [...$themes, ...array_map($found, $result->themePaths)];
            }
        }

        return new DiscoveredResources($skills, $prompts, $themes);
    }

    /**
     * Upstream's `emitBoundary()`: every `agent_before_settle` handler in turn, each handed the
     * entries and the `continue` the ones before it settled on and a fresh preview of the context
     * with those entries applied. A handler's answer replaces either field it sets; a throw is
     * reported and leaves them as they were. A preview that cannot be built from the entries is
     * reported too, and the dispatch comes back `valid: false` — nothing of it is then appended.
     *
     * @param Closure(list<SessionBoundaryDraft>, bool, BoundaryContextPreview): AgentBeforeSettleEvent $event
     * @param Closure(list<SessionBoundaryDraft>): BoundaryContextPreview $buildContext
     */
    public function emitBoundary(Closure $event, Closure $buildContext): BoundaryDispatch
    {
        $context = $this->context();
        $entries = [];
        $continue = false;
        $preview = $buildContext($entries);
        $valid = true;
        $type = $event($entries, $continue, $preview)->type();

        foreach ($this->extensions as $extension) {
            foreach ($extension->api->handlers($type) as $handler) {
                try {
                    $result = $handler($event($entries, $continue, $preview), $context);

                    if ($result instanceof BoundaryResult) {
                        $entries = $result->entries ?? $entries;
                        $continue = $result->continue ?? $continue;
                    } elseif ($result !== null) {
                        $this->wrongType($extension, $type, BoundaryResult::class, $result);
                    }
                } catch (Throwable $error) {
                    $this->fail($extension, $type, $error);
                }

                try {
                    $preview = $buildContext($entries);
                    $valid = true;
                } catch (Throwable $error) {
                    $valid = false;
                    $this->emitError(new ExtensionError($extension->path, $type, 'Invalid boundary entries: ' . $error->getMessage()));
                }
            }
        }

        return $valid
            ? new BoundaryDispatch($entries, $continue, $preview, true)
            : new BoundaryDispatch([], false, $preview, false);
    }

    /** Ask whether to fork this conversation. The first refusal stops the rest. */
    public function emitBeforeFork(SessionBeforeForkEvent $event): ?SessionBeforeForkResult
    {
        return $this->askBefore($event, SessionBeforeForkResult::class);
    }

    /** Ask whether to leave this conversation. The first refusal stops the rest. */
    public function emitBeforeSwitch(SessionBeforeSwitchEvent $event): ?SessionBeforeSwitchResult
    {
        return $this->askBefore($event, SessionBeforeSwitchResult::class);
    }

    /**
     * Ask whether to jump, and whether a hook would rather write the handover itself or change
     * what the default summariser is given. The first refusal stops the rest; otherwise the last
     * handler's answer is the one that counts, as upstream's.
     */
    public function emitBeforeTree(SessionBeforeTreeEvent $event): ?SessionBeforeTreeResult
    {
        return $this->askBefore($event, SessionBeforeTreeResult::class);
    }

    /**
     * Ask whether to compact, and whether a hook would rather do it itself. The first refusal
     * stops the rest; otherwise the last handler's answer is the one that counts.
     */
    public function emitBeforeCompact(SessionBeforeCompactEvent $event): ?SessionBeforeCompactResult
    {
        return $this->askBefore($event, SessionBeforeCompactResult::class);
    }

    /**
     * The shape the four cancellable `session_before_*` events share — upstream's
     * `ExtensionRunner.emit()` for them: every handler runs in turn until one cancels, which
     * ends the question with its answer; otherwise the last handler that answered at all is the
     * answer. A handler that returns null has nothing to say and does not replace an earlier one.
     *
     * @template T of object
     * @param class-string<T> $expected
     * @return T|null
     */
    private function askBefore(ExtensionEvent $event, string $expected): ?object
    {
        return $this->ask($event, $expected, static fn (object $result): bool => $result->cancel, keepLast: true);
    }

    /**
     * Ask every handler in turn until one gives a decisive answer.
     *
     * @template T of object
     * @param class-string<T>  $expected
     * @param Closure(T): bool $decisive whether this answer ends the question
     * @param bool             $keepLast with no decisive answer, return the last one given
     *                                   rather than null
     * @return T|null
     */
    private function ask(ExtensionEvent $event, string $expected, Closure $decisive, bool $keepLast = false): ?object
    {
        $context = $this->context();
        $answer = null;

        foreach ($this->extensions as $extension) {
            foreach ($extension->api->handlers($event->type()) as $handler) {
                try {
                    $result = $handler($event, $context);
                } catch (Throwable $error) {
                    $this->fail($extension, $event->type(), $error);

                    continue;
                }

                if ($result === null) {
                    continue;
                }

                if (!$result instanceof $expected) {
                    $this->wrongType($extension, $event->type(), $expected, $result);

                    continue;
                }

                if ($decisive($result)) {
                    return $result;
                }

                $answer = $result;
            }
        }

        return $keepLast ? $answer : null;
    }

    private function fail(LoadedExtension $extension, string $event, Throwable $error): void
    {
        $this->emitError(new ExtensionError($extension->path, $event, $error::class . ': ' . $error->getMessage()));
    }

    private function wrongType(LoadedExtension $extension, string $event, string $expected, mixed $got): void
    {
        $this->emitError(new ExtensionError(
            $extension->path,
            $event,
            'handler returned ' . get_debug_type($got) . ', expected ' . $expected . ' or null',
        ));
    }
}
