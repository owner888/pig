<?php

declare(strict_types=1);

namespace Pig\CodingAgent\Extensions;

use Closure;
use InvalidArgumentException;
use Pig\Agent\ThinkingLevel;
use Pig\Ai\Extension\Provider;
use Pig\Ai\Extension\ProviderRegistry;
use Pig\Ai\ImageContent;
use Pig\Ai\Model;
use Pig\Ai\TextContent;
use Pig\CodingAgent\Auth;
use Pig\CodingAgent\CustomTools\CustomTool;
use Pig\CodingAgent\CustomTools\RenderOptions;
use Pig\CodingAgent\Extensions\ExecResult;
use Pig\CodingAgent\Extensions\ExtensionContext;
use Pig\CodingAgent\Extensions\RegisteredCommand;
use Pig\CodingAgent\McpServerRegistry;
use Pig\CodingAgent\McpServers;
use Pig\CodingAgent\ModelRouteRequest;
use Pig\CodingAgent\RegisteredMcpServer;
use Pig\CodingAgent\Session\CustomMessage;
use Pig\CodingAgent\Settings;
use Pig\CodingAgent\Theme\Theme;
use Pig\CodingAgent\VirtualModelDefinition;
use Pig\CodingAgent\VirtualModelRegistry;
use Pig\Tui\Process;

/**
 * What an extension factory is handed, and the whole of what it may do.
 *
 * An extension is a PHP file that returns a callable; the callable is given one of these and
 * registers what it wants — event handlers, slash commands, tools, providers, renderers, UI:
 *
 * ```php
 * <?php // ~/.pig/agent/extensions/no-force-push.php
 *
 * use Pig\CodingAgent\Extensions\ExtensionApi;
 * use Pig\CodingAgent\Extensions\Results\ToolCallEventResult;
 *
 * return function (ExtensionApi $pig): void {
 *     $pig->on('tool_call', function ($event) {
 *         if ($event->toolName === 'bash' && str_contains($event->input['command'] ?? '', '--force')) {
 *             return new ToolCallEventResult(block: true, reason: 'No force pushes from here.');
 *         }
 *
 *         return null;
 *     });
 * };
 * ```
 *
 * Upstream's `ExtensionAPI` interface in `core/extensions/types.ts`, whose `on()` overloads exist
 * to give each event its own handler type. PHP has no overloads, so the names live in `EVENTS`
 * and an unknown one is a loading error rather than a subscription that silently never fires —
 * which is what a typo costs upstream.
 */
final class ExtensionApi
{
    /** Every event an extension may subscribe to. */
    public const array EVENTS = [
        'session_start',
        'session_before_switch',
        'session_before_fork',
        'session_before_compact',
        'session_compact',
        'session_before_tree',
        'session_tree',
        'session_shutdown',
        'session_info_changed',
        'context',
        'context_with_system',
        'before_agent_start',
        'agent_start',
        'agent_end',
        'agent_settled',
        'turn_start',
        'turn_end',
        'message_start',
        'message_update',
        'message_end',
        'tool_call',
        'tool_result',
        'before_provider_request',
        'before_provider_headers',
        'after_provider_response',
        'provider_stream_event',
        'model_select',
        'thinking_level_select',
        'cache_warming_decision',
        'tool_execution_start',
        'tool_execution_update',
        'tool_execution_end',
        'session_compact_failed',
        'user_bash',
        'input',
        'ui_prompt_start',
        'ui_prompt_end',
        'mcp_servers_change',
        'project_trust',
        'resources_discover',
        'agent_before_settle',
    ];

    /** How long a command an extension runs may take before it is killed. */
    private const float EXEC_TIMEOUT = 30.0;

    /** @var array<string, list<Closure>> */
    private array $handlers = [];

    /** @var array<string, RegisteredCommand> */
    private array $commands = [];

    /** @var array<string, Closure> one renderer per custom message type */
    private array $renderers = [];

    /** @var array<string, Closure> one renderer per custom entry type */
    private array $entryRenderers = [];

    /** Handed in once the session exists; null while the extension file is being read. */
    private ?Closure $send = null;

    private ?Closure $note = null;

    private ?Closure $setSessionName = null;

    private ?Closure $getSessionName = null;

    /** @var Closure(): ExtensionContext|null */
    private ?Closure $context = null;

    /** @var list<CustomTool> */
    private array $tools = [];

    /** @var array<string, array{label: string, translations: array<string, string>}> */
    private static array $registeredLocales = [];

    /** Told when `tools()` changes after load — see `onToolsChanged()`. */
    private ?Closure $toolsChanged = null;

    /** @var list<string> the providers this extension registered, to take back on unload */
    private array $providers = [];

    /**
     * @var array<string, array{type: 'boolean'|'string', description: string, default: bool|string|null}>
     *      declared across every extension — `--flag` on the command line is only knowable once
     *      the extensions have loaded, so `bin/pig` asks here after loading and before refusing
     *      an option it does not know
     */
    private static array $flags = [];

    /** @var array<string, bool|string> what the command line said for a declared flag */
    private static array $flagValues = [];

    /** The settings this run was started with; null until `CodingAgent::session()` wires it. */
    private static ?Settings $settings = null;

    /**
     * @var array<string, Closure(string, array{method: string, body: string, query: array<string, string>}): array{status: int, body: mixed}|null>
     *      HTTP routes the extensions registered, by path prefix — see `registerHttpRoute()`
     */
    private static array $httpRoutes = [];

    /** @var array<string, WebPanel> the web UI's extension panels, by id — see `registerWebPanel()` */
    private static array $webPanels = [];

    /** @var array<string, array{key: string, handler: Closure, description: string}> */
    private array $shortcuts = [];

    /** @var list<Closure(string, array{role: string, isStreaming: bool}): string> */
    private array $markdownTransformers = [];

    /** @var list<Closure(string, Closure(): ?array): ?array> */
    private array $toolRenderers = [];

    public readonly string $name;

    private readonly EventBus $events;

    /**
     * @param string      $cwd  the working directory the extension was loaded for
     * @param string      $path the file it was loaded from, which is what a registration is owned by
     * @param string|null $name the extension's name; its file or folder name when not given
     */
    public function __construct(
        private readonly string $cwd = '.',
        private readonly string $path = '',
        ?string $name = null,
        private readonly ?Auth $auth = null,
        ?EventBus $events = null,
    ) {
        $this->name = $name ?? ExtensionLoader::nameOf($path);
        $this->events = $events ?? new EventBus();
    }

    /**
     * Run $handler whenever $event happens.
     *
     * Several handlers for one event run in the order they were registered, and several
     * extensions run in the order they were loaded.
     *
     * @param callable(mixed, ExtensionContext): mixed $handler returns a result object, or null
     * @throws InvalidArgumentException when there is no such event
     */
    public function on(string $event, callable $handler): void
    {
        if (!in_array($event, self::EVENTS, true)) {
            throw new InvalidArgumentException(
                "No event called '{$event}'. There is: " . implode(', ', self::EVENTS),
            );
        }

        $this->handlers[$event][] = Closure::fromCallable($handler);
    }

    /**
     * Put something in the conversation, from the extension.
     *
     * The model sees it, as a user message: this is for telling it something it had no way
     * to find out — a build that just failed, a file that changed underneath it, a rule
     * about this repository. `display` decides whether a person sees it too, and `details`
     * is the extension's own metadata, kept in the session file and never sent to the model.
     *
     * Upstream's `options: { triggerTurn?, deliverAs? }`. `$deliverAs: 'nextTurn'` holds it for the
     * next run, beside that run's first message. While the agent is working it is steered in
     * (`steer`, the default) or queued as a follow-up (`followUp`) — unless `$triggerTurn` is
     * false, which holds it until the turn ends, since a message between a tool call and its
     * result is a request every provider rejects. Idle, `$triggerTurn: true` starts a run from
     * it, through `before_agent_start` as a prompt does; otherwise it is appended for the next
     * thing anyone says.
     *
     * @param string|list<TextContent|ImageContent> $content
     * @param 'steer'|'followUp'|'nextTurn'|null      $deliverAs
     * @throws InvalidArgumentException when the type or `$deliverAs` is unusable
     */
    public function sendMessage(
        string $customType,
        string|array $content,
        bool $display = true,
        mixed $details = null,
        ?bool $triggerTurn = null,
        ?string $deliverAs = null,
    ): void {
        if ($deliverAs !== null && !in_array($deliverAs, ['steer', 'followUp', 'nextTurn'], true)) {
            throw new InvalidArgumentException("No such deliverAs: '{$deliverAs}'. There is steer, followUp and nextTurn.");
        }

        $message = new CustomMessage(
            self::customType($customType),
            is_string($content) ? [new TextContent($content)] : array_values($content),
            $display,
            $details,
        );

        // Before the session exists there is nothing to send to: an extension file is read at
        // startup, and its factory runs before a mode has wired anything up. Saying so
        // beats a message that silently goes nowhere.
        if ($this->send === null) {
            throw new InvalidArgumentException(
                'sendMessage() needs a session — call it from a handler, not while the extension file is being read.',
            );
        }

        ($this->send)($message, $triggerTurn, $deliverAs);
    }

    /**
     * Write something down that the model will never see.
     *
     * For extension state that should survive a restart: "this session was granted full
     * permissions". It is in the session file and not in the conversation, so it costs no
     * context — the opposite trade from `sendMessage()`. Read it back on the next
     * `session_start` from `$ctx->store?->customEntries('your-type')`.
     *
     * @throws InvalidArgumentException when the type is unusable
     */
    public function appendEntry(string $customType, mixed $data = null): void
    {
        $type = self::customType($customType);

        if ($this->note === null) {
            throw new InvalidArgumentException(
                'appendEntry() needs a session — call it from a handler, not while the extension file is being read.',
            );
        }

        ($this->note)($type, $data);
    }

    /**
     * Draw this extension's own messages your own way.
     *
     * The renderer is handed the message, whether the transcript is expanded, and the
     * theme, and returns a `Pig\Tui\Component` — or null for "draw it normally", which
     * is not a failure. Same shape as a custom tool's `renderResult`, and the same reason:
     * a message whose content is a table should not be squeezed through formatting meant
     * for prose.
     *
     * One per type, last registration wins, because two renderers for one message is a
     * question with no answer.
     *
     * @param callable(CustomMessage, RenderOptions, Theme): mixed $renderer
     */
    public function registerMessageRenderer(string $customType, callable $renderer): void
    {
        $this->renderers[self::customType($customType)] = Closure::fromCallable($renderer);
    }

    /**
     * @return array<string, Closure>
     * @internal
     */
    public function renderers(): array
    {
        return $this->renderers;
    }

    /**
     * Draw this extension's custom session entries in the transcript.
     * Upstream's `registerEntryRenderer`. Custom entries do not participate in LLM context.
     *
     * @param callable(CustomEntry, RenderOptions, Theme): mixed $renderer
     */
    public function registerEntryRenderer(string $customType, callable $renderer): void
    {
        $this->entryRenderers[self::customType($customType)] = Closure::fromCallable($renderer);
    }

    /**
     * @return array<string, Closure>
     * @internal
     */
    public function entryRenderers(): array
    {
        return $this->entryRenderers;
    }

    /**
     * Where to read the session from, once there is one.
     *
     * The provider rather than a `ExtensionContext`, because the runner builds one fresh per emit:
     * what `exec()` reads off it has to be the turn running now.
     *
     * @param Closure(): ExtensionContext $context
     * @internal called by `ExtensionRunner::initialize()`
     */
    /** The working directory the extension was loaded for. */
    public function cwd(): string
    {
        return $this->cwd;
    }

    /** The file this extension was loaded from, which is what a registration is owned by. */
    public function path(): string
    {
        return $this->path;
    }

    /** @internal */
    public function withContext(Closure $context): void
    {
        $this->context = $context;
    }

    /** The context as it stands now, or null before a mode has wired one. */
    private function contextNow(): ?ExtensionContext
    {
        return $this->context === null ? null : ($this->context)();
    }

    /** The friendly session name, or null if unset. */
    public function getSessionName(): ?string
    {
        if ($this->getSessionName !== null) {
            return ($this->getSessionName)();
        }

        return $this->context === null ? null : ($this->context)()->sessionName();
    }

    /** Set or update the session display name. */
    public function setSessionName(string $name): void
    {
        if ($this->setSessionName !== null) {
            ($this->setSessionName)($name);

            return;
        }

        if ($this->context !== null) {
            ($this->context)()->setSessionName($name);
        }
    }

    /**
     * Wire the writers, once there is a session to write to.
     *
     * Either on its own: they are two independent facts, and one missing must not take the
     * other with it. Whichever is not given stays null, which is what `sendMessage()` and
     * `appendEntry()` already have an answer for.
     *
     * @param Closure(CustomMessage, ?bool, ?string): void|null $send
     * @param Closure(string, mixed): void|null     $note
     * @internal called by `ExtensionRunner::initialize()`
     */
    public function writesTo(?Closure $send, ?Closure $note): void
    {
        $this->send = $send ?? $this->send;
        $this->note = $note ?? $this->note;
    }

    /** @internal */
    public function bindSessionNames(?Closure $setSessionName, ?Closure $getSessionName): void
    {
        $this->setSessionName = $setSessionName ?? $this->setSessionName;
        $this->getSessionName = $getSessionName ?? $this->getSessionName;
    }

    /**
     * A usable name for an extension's own kind of message.
     *
     * The same rule as a command's, because it is used the same way — an extension filters its own
     * messages out of a resumed session by matching on it, and a type with a quote or a
     * newline in it is one nobody can match reliably.
     */
    private static function customType(string $customType): string
    {
        if (preg_match('/^[a-zA-Z0-9][a-zA-Z0-9_-]*$/', $customType) !== 1) {
            throw new InvalidArgumentException(
                "'{$customType}' cannot be a custom type: letters, digits, dashes and underscores only.",
            );
        }

        return $customType;
    }

    /**
     * Add a slash command.
     *
     * A built-in of the same name wins, so an extension cannot take `/compact` away from the
     * person using it.
     *
     * @param callable(string, ExtensionContext): void $handler
     * @throws InvalidArgumentException when the name is unusable or already taken
     */
    public function registerCommand(string $name, callable $handler, string $description = ''): void
    {
        $name = ltrim($name, '/');

        if ($name === '' || preg_match('/^[a-zA-Z0-9][a-zA-Z0-9._-]*$/', $name) !== 1) {
            throw new InvalidArgumentException(
                "'{$name}' cannot be a command name: letters, digits, dots, dashes and underscores only.",
            );
        }

        if (isset($this->commands[$name])) {
            throw new InvalidArgumentException("This extension already registered /{$name}.");
        }

        $this->commands[$name] = new RegisteredCommand(
            $name,
            $description,
            Closure::fromCallable($handler),
            $this->path,
        );
    }

    /**
     * Run a command and wait for it.
     *
     * Here because the timeout and the argv array are worth having by default: an extension
     * that reaches for `shell_exec` gets neither, and an extension that hangs hangs pig.
     *
     * Three differences from upstream's `execCommand`, and the third is the one to know:
     *
     * - **There is a timeout by default.** Upstream's is opt-in, so an extension that forgets it
     *   parks the turn for as long as its command wants. Thirty seconds is long enough for a
     *   test run and short enough to be survivable.
     * - **`killed` is `ExecResult::stopped()`**, which is upstream's field under pig's
     *   `Process::STOPPED`. It is wider by one case and says so on itself: a program that is
     *   not on this machine answers the same way as one that ran too long, where upstream
     *   reports that as `code: 1, killed: false`.
     * - **Escape stops it**, and the screen stays alive while it runs: the command goes on the
     *   loop (`Process::runAsync()`) and parks on the turn's own `AbortSignal`, so it comes
     *   back as `stopped()` the moment somebody interrupts. **Upstream cannot do this** —
     *   its `ExecOptions` has a `signal` field and its `ExtensionContext` has no signal to put in
     *   it, so an extension there can only be waited out. The signal is not a parameter here for the
     *   same reason: one an extension had to remember to pass is one whose author did not. A handler
     *   that waits on something of its own reads `$ctx->signal` and parks on that.
     *
     * @param list<string> $command   the program and its arguments, unquoted
     * @param string|null  $cwd       defaults to the directory pig is working in
     * @param int          $maxBuffer upstream's `ExecOptions.maxBuffer`: stdout and stderr together past
     *                                this stop the command, and the result says `truncated`
     */
    public function exec(array $command, ?string $cwd = null, float $timeout = self::EXEC_TIMEOUT, int $maxBuffer = ExecResult::MAX_BUFFER): ExecResult
    {
        [$exit, $stdout, $stderr, $truncated] = Process::runAsync(
            $command,
            $timeout,
            $cwd ?? $this->cwd,
            // The turn's signal, without the extension having to pass it: escape means stop, and an
            // extension that had to remember to opt in is one whose author did not.
            $this->context === null ? null : ($this->context)()->signal,
            $maxBuffer,
        );

        return new ExecResult($exit, $stdout, $stderr, $truncated);
    }

    /**
     * @return list<Closure>
     * @internal
     */
    public function handlers(string $event): array
    {
        return $this->handlers[$event] ?? [];
    }

    /**
     * @return array<string, RegisteredCommand>
     * @internal
     */
    public function commands(): array
    {
        return $this->commands;
    }

    /** The channel every extension of this load shares. Upstream's `pi.events`. */
    public function events(): EventBus
    {
        return $this->events;
    }

    /** @return list<string> the tools the model is offered now. Upstream's `getActiveTools()`. */
    public function getActiveTools(): array
    {
        return $this->session()?->activeTools() ?? [];
    }

    /**
     * Every registered tool, active or not, with its description and schema — and `reachesTools`
     * for one that declares it (`CustomTool::$reachesTools`). Upstream's `getAllTools()`.
     *
     * @return list<array{name: string, description: string, parameters: array<string, mixed>, active: bool, reachesTools?: \Closure(array<string, mixed>): ('all'|list<string>)}>
     */
    public function getAllTools(): array
    {
        return $this->session()?->allTools() ?? [];
    }

    /**
     * Offer the model only these tools, from its next request. Upstream's `setActiveTools()`.
     * Nothing is unregistered, so a later call can put any of them back; a name nothing
     * registered is ignored.
     *
     * @param list<string> $names
     */
    public function setActiveTools(array $names): void
    {
        ($this->session() ?? throw new \LogicException('setActiveTools() needs a session — call it from a handler.'))
            ->setActiveTools($names);
    }

    /**
     * Whether the session restored $name from its transcript and is waiting for it to be
     * registered — see `AgentSession::isToolPending()`. False with no session.
     */
    public function isToolPending(string $name): bool
    {
        return $this->session()?->isToolPending($name) ?? false;
    }

    /**
     * Register a tool that the model can call.
     */
    public function registerTool(CustomTool $tool): void
    {
        // A second registration under one name replaces the first, as upstream's does: an MCP
        // server that reconnects lists its tools again, and the new list is the list.
        $this->tools = array_values(array_filter($this->tools, static fn (CustomTool $t): bool => $t->name !== $tool->name));
        $this->tools[] = $tool;
        $this->notifyToolsChanged();
    }

    /**
     * Take tools away again — the ones `$which` says yes to. An MCP server that dropped a tool,
     * or was disabled, has nothing to offer under that name any more.
     *
     * @param Closure(CustomTool): bool $which
     */
    public function removeTools(Closure $which): void
    {
        $before = count($this->tools);
        $this->tools = array_values(array_filter($this->tools, static fn (CustomTool $t): bool => !$which($t)));

        if (count($this->tools) !== $before) {
            $this->notifyToolsChanged();
        }
    }

    /**
     * Who is told when the tool list changes after load. The loader reads `tools()` once at
     * startup; a tool that arrives later — an MCP server connecting — has to reach the agent by
     * another door, and this is it. `CustomToolSet::adopt()` is what sets it.
     *
     * @internal
     */
    public function onToolsChanged(Closure $listener): void
    {
        $this->toolsChanged = $listener;
    }

    private function notifyToolsChanged(): void
    {
        if ($this->toolsChanged !== null) {
            ($this->toolsChanged)($this);
        }
    }

    /**
     * Access authentication storage and credentials if available.
     */
    public function auth(): ?Auth
    {
        return $this->auth;
    }

    // ---- providers ---------------------------------------------------------------------

    /**
     * Bring a provider: models, a protocol, a sign-in. Upstream's `registerProvider()`, in both its
     * forms: a complete `Provider`, or a provider name and upstream's legacy `ProviderConfig` as an
     * array — `registerProvider('media-tools', ['apiKey' => '$MEDIA_TOOLS_API_KEY', 'models' => […]])`
     * — which `ProviderConfig::toProvider()` turns into one. Only a `baseUrl` or `headers` for an
     * existing provider keeps its models; a `models` list replaces them until it is unregistered.
     *
     * Everything a built-in provider is spread across four core classes arrives as one object
     * and goes into `ProviderRegistry`, which those four classes ask when their own tables come
     * up empty — so from the moment this returns, `--model`, `/model`, `/login` and `Stream`
     * all know the provider as if it had shipped with pig. Taken back by `unregisterProvider()`
     * and on `/reload`, which loads the extensions again.
     *
     * @param array<string, mixed>|null $config the legacy form's `ProviderConfig`, with a name
     * @throws \InvalidArgumentException for a config that is wrong, naming the key
     */
    public function registerProvider(Provider|string $provider, ?array $config = null): void
    {
        if (is_string($provider)) {
            $provider = ProviderConfig::toProvider(
                $provider,
                $config ?? throw new \InvalidArgumentException('Provider config is required when registering by name'),
            );
        }

        ProviderRegistry::register($provider);
        $this->providers[] = $provider->id;

        // A provider whose catalog is fetched starts from the one it stored, without the network —
        // upstream's `refresh({allowNetwork: false})` when a provider is registered.
        $auth = $this->auth();

        if ($provider->refreshModels !== null && $auth !== null) {
            \Pig\CodingAgent\ModelRefresh::refresh($auth, [$provider->id], allowNetwork: false);
        }
    }

    public function unregisterProvider(string $id): void
    {
        ProviderRegistry::unregister($id);
        $this->providers = array_values(array_filter($this->providers, static fn (string $one): bool => $one !== $id));
    }

    /** @return list<string> @internal */
    public function providers(): array
    {
        return $this->providers;
    }

    // ---- virtual models ----------------------------------------------------------------

    /**
     * Bring a virtual model: a catalogue entry that routes each request to a physical model.
     * Upstream's `registerVirtualModel()`.
     *
     * Listed under `$definition->provider`, which may also list physical models or several virtual
     * ones; a provider of nothing but virtual models needs no key. The same provider and id again
     * replaces it. Selecting it records the virtual model (`model_change`); the responses record
     * the physical models the router sent each request to. The router's state is kept on the
     * session branch as a `pi.virtual-model-state` entry. Not saved: register again on every load.
     *
     * @throws \InvalidArgumentException for an empty provider or id, or an id that is a physical
     *         model's of that provider
     */
    public function registerVirtualModel(VirtualModelDefinition $definition): void
    {
        // Upstream's `ExtensionVirtualModel.route(request, ctx)`: "Routing runs after the runner binds,
        // so the context is created per request" — `ctx.modelRegistry` to find the physical model,
        // `ctx->store->branch()` for upstream's `ctx.sessionManager.getBranch()`.
        $route = $definition->route;
        VirtualModelRegistry::current()->register(new VirtualModelDefinition(
            $definition->provider,
            $definition->id,
            $definition->name,
            fn (ModelRouteRequest $request): mixed => $route($request, $this->contextNow() ?? new ExtensionContext($this->cwd())),
            $definition->thinkingLevels,
            $definition->contextWindow,
            $definition->maxTokens,
            $definition->input,
        ));
    }

    public function unregisterVirtualModel(string $provider, string $id): void
    {
        VirtualModelRegistry::current()->unregister($provider, $id);
    }

    // ---- MCP servers -------------------------------------------------------------------

    /**
     * Add an MCP server for the current session, as an `mcpServers` entry of `mcp.json` is: stdio
     * with `command`, `args`, `env`, `cwd`; streamable HTTP with `url`, `headers`, `oauth`; plus
     * `exposure`, `toolExposure`, `description`, `enabled`, `timeout`. Registered while loading, it
     * connects when the session starts beside the `mcp.json` servers; registered later, it
     * connects right away (`mcp_servers_change`). Not saved: register again on every load. A server
     * in `mcp.json` with the same name takes precedence, and `/mcp` shows the override.
     *
     * @param array<string, mixed> $config
     * @throws \InvalidArgumentException for an invalid name or config, a name another extension
     *         registered, or one whose tool namespace (`-` and `_` read alike) another server has
     */
    public function registerMcpServer(string $name, array $config): void
    {
        $validated = McpServers::validate($name, $config);

        if (is_string($validated)) {
            throw new \InvalidArgumentException("Invalid MCP server registered by extension \"{$this->path()}\": {$validated}");
        }

        $registry = McpServerRegistry::current();
        $owner = $registry->get($name)?->extensionPath;

        if ($owner !== null && $owner !== $this->path()) {
            throw new \InvalidArgumentException("MCP server \"{$name}\" is already registered by extension \"{$owner}\"");
        }

        foreach ($registry->list() as $server) {
            if ($server->name !== $name && McpServers::namespace($server->name) === McpServers::namespace($name)) {
                throw new \InvalidArgumentException("MCP server \"{$name}\" conflicts with registered server \"{$server->name}\"");
            }
        }

        $registry->register(new RegisteredMcpServer($name, $validated, $this->path()));
    }

    /** Closes the connection and makes the server's tools unreachable. Another extension's server is left alone. */
    public function unregisterMcpServer(string $name): void
    {
        McpServerRegistry::current()->unregister($name, $this->path());
    }

    /** @return list<RegisteredMcpServer> every server any extension registered, in registration order */
    public function getMcpServers(): array
    {
        return McpServerRegistry::current()->list();
    }

    // ---- flags -------------------------------------------------------------------------

    /**
     * Declare a command-line flag. Upstream's `registerFlag()`.
     *
     * `--name` for a boolean, `--name <value>` for a string. The value is what `bin/pig` saw;
     * `getFlag()` answers the default until the command line has been read, which is after
     * every extension has loaded — so a factory must not read its own flag at load, only a
     * handler may. Declared under the extension's own name: two extensions declaring one flag
     * is the second one's mistake and is said so.
     *
     * @param 'boolean'|'string' $type
     */
    public function registerFlag(string $name, string $type = 'boolean', string $description = '', bool|string|null $default = null): void
    {
        $name = ltrim(trim($name), '-');

        if ($name === '' || !in_array($type, ['boolean', 'string'], true)) {
            throw new \InvalidArgumentException("A flag needs a name and a type of 'boolean' or 'string'.");
        }

        if (isset(self::$flags[$name])) {
            throw new \InvalidArgumentException("--{$name} is already declared by another extension.");
        }

        self::$flags[$name] = ['type' => $type, 'description' => $description, 'default' => $default];
    }

    /** What the command line said for a declared flag, or its default; null for one nobody declared. */
    public function getFlag(string $name): bool|string|null
    {
        $name = ltrim($name, '-');

        if (!isset(self::$flags[$name])) {
            return null;
        }

        return self::$flagValues[$name] ?? self::$flags[$name]['default'];
    }

    /**
     * Every flag the loaded extensions declared, for `bin/pig` to accept and for `--help`.
     *
     * @return array<string, array{type: 'boolean'|'string', description: string, default: bool|string|null}>
     */
    public static function declaredFlags(): array
    {
        return self::$flags;
    }

    /**
     * What the command line said. `bin/pig` calls this once, after parsing, with the options it
     * did not recognise itself; a boolean flag's presence is `true`, a string flag's value is
     * the string.
     *
     * @param array<string, string> $options
     */
    public static function applyFlags(array $options): void
    {
        foreach (self::$flags as $name => $flag) {
            if (!array_key_exists($name, $options)) {
                continue;
            }

            self::$flagValues[$name] = $flag['type'] === 'boolean' ? true : $options[$name];
        }
    }

    /** For tests and `/reload`. */
    public static function forgetFlags(): void
    {
        self::$flags = [];
        self::$flagValues = [];
    }

    // ---- the web UI --------------------------------------------------------------------

    /**
     * Answer HTTP requests under a path prefix in `pig web`.
     *
     * pig's own, with no upstream counterpart: pi-web is a separate package that imports nothing
     * from an extension. Here the web shell loads the extensions as the terminal does, and an
     * extension with something to show a browser — the Antigravity accounts panel — registers
     * the endpoints its page calls rather than having them written into `HttpServer`. The handler
     * gets the path and the request and answers a status and a JSON-encodable body; null means
     * "not mine", so a prefix can be shared. A throw is a 500 with the message, which is the
     * same fault isolation every other handler in the server has.
     *
     * @param Closure(string, array{method: string, body: string, query: array<string, string>}): (array{status: int, body: mixed}|null) $handler
     */
    public function registerHttpRoute(string $prefix, Closure $handler): void
    {
        $prefix = '/' . trim($prefix, '/');

        if ($prefix === '/') {
            throw new \InvalidArgumentException('An HTTP route needs a prefix under the root.');
        }

        self::$httpRoutes[$prefix] = $handler;
    }

    /**
     * The handler for a path, by longest matching prefix, or null.
     *
     * @return Closure(string, array{method: string, body: string, query: array<string, string>}): (array{status: int, body: mixed}|null)|null
     */
    public static function httpRouteFor(string $path): ?Closure
    {
        $best = null;
        $length = 0;

        foreach (self::$httpRoutes as $prefix => $handler) {
            if (($path === $prefix || str_starts_with($path, $prefix . '/')) && strlen($prefix) > $length) {
                $best = $handler;
                $length = strlen($prefix);
            }
        }

        return $best;
    }

    /** For tests and `/reload`. */
    public static function forgetHttpRoutes(): void
    {
        self::$httpRoutes = [];
    }

    /**
     * Put a panel in `pig web`: an entry in the sidebar's Extensions group that opens a window the
     * page draws from the blocks `$render` returns — see `WebPanel` for the blocks and the actions —
     * or, with `placement: 'header'`, an entry in the ⋯ menu of the page's header instead.
     *
     * pig's own, with no upstream counterpart. A panel is described rather than scripted, so it
     * looks like the rest of the page, follows its theme, and runs nothing of the extension in the
     * browser. The same id registered again replaces the panel.
     *
     * @param string|array<string, string> $title by locale (`['en' => …, 'zh-CN' => …]`) or one for all
     * @param Closure(array{locale: string, section: ?string}): list<array<string, mixed>> $render
     * @param (Closure(string, array<string, mixed>, array{locale: string, section: ?string}, \Pig\CodingAgent\Extensions\ExtensionUi): ?string)|null $action
     *        its last argument asks the person, as `$ctx->ui` does: `confirm()`, `select()`, `input()`…
     * @param string $icon the glyph the sidebar shows before the title, as it is — an emoji, say; a default one when empty
     * @param list<string> $commands slash commands that open it in the page, without the slash
     * @param 'sidebar'|'header' $placement where the page puts it by default; the person can move it
     * @param string|array<string, string>|null $label a short name for the header's ⋯ menu entry
     */
    public function registerWebPanel(
        string $id,
        string|array $title,
        Closure $render,
        ?Closure $action = null,
        string $icon = '',
        array $commands = [],
        string $placement = 'sidebar',
        string|array|null $label = null,
    ): void {
        self::$webPanels[$id] = new WebPanel($id, $title, $render, $action, $icon, array_values($commands), $placement, $label);
    }

    /**
     * @return list<WebPanel> in the order they were registered
     * @internal
     */
    public static function webPanels(): array
    {
        return array_values(self::$webPanels);
    }

    /** @internal */
    public static function webPanel(string $id): ?WebPanel
    {
        return self::$webPanels[$id] ?? null;
    }

    /**
     * For tests and `/reload`.
     *
     * @internal
     */
    public static function forgetWebPanels(): void
    {
        self::$webPanels = [];
    }

    // ---- the session, from an extension's side ------------------------------------------

    /**
     * The settings this run started with. Upstream's `getSettings()`.
     *
     * @internal
     */
    public static function useSettings(?Settings $settings): void
    {
        self::$settings = $settings;
    }

    public function getSettings(): ?Settings
    {
        return self::$settings;
    }

    /**
     * pig's own: whether the session is private (`--incognito`, `/incognito`) — an extension that
     * keeps records of its own (recently opened files, a history, a cache of what was asked) keeps
     * none for this one. Asked when it is about to write, not once at load: `/incognito` can come
     * part way through. False with no session yet.
     */
    public function isIncognito(): bool
    {
        return $this->session()?->isIncognito() ?? false;
    }

    /**
     * pig's own: where an extension saves what it makes for the session — screenshots, recordings,
     * downloaded files. `<agent-dir>/artifacts` ordinarily; in a private session its own temporary
     * directory (`AgentSession::scratchDirectory()`), removed with everything in it when the session
     * ends. Not created here: the ordinary one is made by whoever first writes to it, as before.
     */
    public function artifactsDirectory(): string
    {
        return $this->session()?->scratchDirectory() ?? \Pig\CodingAgent\Config::home() . '/artifacts';
    }

    /**
     * Switch the session's model. Upstream's `setModel()`: false when there is no key for it
     * or no session to switch — a refusal, not a failure, because an extension asking for a model
     * this machine cannot reach has nothing to do about it.
     */
    public function setModel(Model $model): bool
    {
        $session = $this->session();

        if ($session === null) {
            return false;
        }

        try {
            $session->setModel($model);
        } catch (\Throwable) {
            return false;
        }

        return true;
    }

    public function getModel(): ?Model
    {
        return $this->session()?->model();
    }

    public function getThinkingLevel(): ?ThinkingLevel
    {
        return $this->session()?->thinkingLevel();
    }

    public function setThinkingLevel(ThinkingLevel $level): void
    {
        $this->session()?->setThinkingLevel($level);
    }

    /**
     * Put a *user* message into the conversation, as if typed. Upstream's `sendUserMessage()`.
     *
     * Different from `sendMessage()`, which is an extension's own message under its own type: this is
     * the person's voice, and reaches the model as a user turn. `steer` cuts in after the tool
     * that is running; `followUp` waits for the turn to end; with the agent idle either one
     * starts a turn.
     *
     * @param 'steer'|'followUp' $deliverAs
     */
    public function sendUserMessage(string $text, string $deliverAs = 'followUp'): void
    {
        $session = $this->session() ?? throw new \LogicException('sendUserMessage() needs a session — call it from a handler.');

        if (!$session->isStreaming()) {
            $session->prompt($text, source: 'extension');

            return;
        }

        $deliverAs === 'steer' ? $session->steer($text, source: 'extension') : $session->followUp($text, source: 'extension');
    }

    /** Name a point in the conversation, or clear the name with null. Upstream's `setLabel()`. */
    public function setLabel(string $entryId, ?string $label): void
    {
        $this->session()?->store()?->appendLabel($entryId, $label);
    }

    /** The commands every extension registered, by name, for a help screen of its own. @return list<string> */
    public function getCommands(): array
    {
        $session = $this->session();

        if ($session === null) {
            return array_keys($this->commands());
        }

        [$all] = $session->extensionRunner()?->commands() ?? [[]];

        return array_keys($all);
    }

    private function session(): ?\Pig\CodingAgent\Session\AgentSession
    {
        return $this->contextNow()?->session;
    }

    /**
     * Register a keyboard shortcut. Upstream's `registerShortcut()`.
     *
     * @param callable(\Pig\CodingAgent\Extensions\ExtensionContext): void $handler
     */
    public function registerShortcut(string $shortcut, callable $handler, string $description = ''): void
    {
        $this->shortcuts[strtolower($shortcut)] = [
            'key' => $shortcut,
            'handler' => Closure::fromCallable($handler),
            'description' => $description,
        ];
    }

    /**
     * @return array<string, array{key: string, handler: Closure, description: string}>
     * @internal
     */
    public function shortcuts(): array
    {
        return $this->shortcuts;
    }

    /**
     * Transform user and assistant Markdown before it is rendered in the transcript.
     * Upstream's `registerMarkdownTransformer()`.
     *
     * @param callable(string, array{role: string, isStreaming: bool}): string $transformer
     */
    public function registerMarkdownTransformer(callable $transformer): void
    {
        $this->markdownTransformers[] = Closure::fromCallable($transformer);
    }

    /**
     * @return list<Closure(string, array{role: string, isStreaming: bool}): string>
     * @internal
     */
    public function markdownTransformers(): array
    {
        return $this->markdownTransformers;
    }

    /**
     * Choose how calls to a tool are drawn. Upstream's `registerToolRenderer()`.
     *
     * The resolver is `fn (string $toolName, Closure $next): ?array{renderCall?: Closure, renderResult?: Closure}`.
     * Resolvers run in extension load order as an onion chain.
     */
    public function registerToolRenderer(callable $resolver): void
    {
        $this->toolRenderers[] = Closure::fromCallable($resolver);
    }

    /**
     * @return list<Closure>
     * @internal
     */
    public function toolRenderers(): array
    {
        return $this->toolRenderers;
    }

    /**
     * @return list<CustomTool>
     * @internal
     */
    public function tools(): array
    {
        return $this->tools;
    }

    /**
     * Register a custom language pack / locale from this extension.
     *
     * @param string $locale E.g. 'ja', 'es', 'zh-TW'
     * @param string $label E.g. '日本語', 'Español', '繁體中文'
     * @param array<string, string> $translations Key-value translation dictionary
     */
    public function registerLocale(string $locale, string $label, array $translations): void
    {
        $cleanLocale = trim($locale);
        if ($cleanLocale === '') {
            return;
        }

        self::$registeredLocales[$cleanLocale] = [
            'label' => $label !== '' ? $label : $cleanLocale,
            'translations' => $translations,
        ];
    }

    /**
     * Get all custom locales registered across loaded extensions.
     *
     * @return array<string, array{label: string, translations: array<string, string>}>
     * @internal
     */
    public static function registeredLocales(): array
    {
        return self::$registeredLocales;
    }

    /**
     * Reset registered locales (for testing).
     *
     * @internal
     */
    public static function resetRegisteredLocales(): void
    {
        self::$registeredLocales = [];
    }
}
