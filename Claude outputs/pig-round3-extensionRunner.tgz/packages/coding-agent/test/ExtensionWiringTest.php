<?php

declare(strict_types=1);

namespace Pig\CodingAgent\Test;

use Closure;
use PHPUnit\Framework\TestCase;
use Pig\Agent\Agent;
use Pig\Agent\AgentError;
use Pig\Agent\AgentOptions;
use Pig\Ai\Api;
use Pig\Ai\AssistantMessage;
use Pig\Ai\Context;
use Pig\Ai\DoneEvent;
use Pig\Ai\Model;
use Pig\Ai\SimpleStreamOptions;
use Pig\Ai\StartEvent;
use Pig\Ai\StopReason;
use Pig\Ai\TextContent;
use Pig\Ai\Usage;
use Pig\Ai\UserMessage;
use Pig\Ai\Utils\AssistantMessageEventStream;
use Pig\Ai\TranscriptContext;
use Pig\Async\AbortController;
use Pig\Async\Async;
use Pig\Async\Loop;
use Pig\CodingAgent\CodingAgent;
use Pig\CodingAgent\Extensions\ExtensionApi;
use Pig\CodingAgent\Extensions\ExtensionGuardedTool;
use Pig\CodingAgent\Extensions\ExtensionError;
use Pig\CodingAgent\Extensions\ExtensionRunner;
use Pig\CodingAgent\Extensions\LoadedExtension;
use Pig\CodingAgent\Extensions\Results\BeforeAgentStartEventResult;
use Pig\CodingAgent\Extensions\Results\ContextEventResult;
use Pig\CodingAgent\Extensions\Events\SessionBeforeCompactEvent;
use Pig\CodingAgent\Extensions\Results\SessionBeforeCompactResult;
use Pig\CodingAgent\Session\CompactionResult;
use Pig\CodingAgent\Extensions\Results\SessionBeforeTreeResult;
use Pig\CodingAgent\Session\AgentSession;
use Pig\CodingAgent\Session\BranchSummary;
use Pig\CodingAgent\Session\CompactionSummary;
use Pig\CodingAgent\Session\CustomMessage;
use Pig\CodingAgent\Session\SessionManager;
use Pig\Test\AssertsThrows;
use RuntimeException;

/**
 * Where the hooks are actually fired from.
 *
 * `ExtensionRunnerTest` checks what the runner does with a handler; this checks that the
 * session calls it at all, and at the right moment — which is the half of a hook system
 * that goes wrong silently.
 */
final class ExtensionWiringTest extends TestCase
{
    use AssertsThrows;

    /** @var list<array{0: string, 1: mixed}> every event a hook saw, in order */
    private array $seen = [];

    private string $home = '';

    #[\Override]
    protected function setUp(): void
    {
        Loop::reset();
        $this->seen = [];

        // Session files land under the agent's home, and a test must not write into the
        // real one.
        $this->home = sys_get_temp_dir() . '/pig-hook-home-' . bin2hex(random_bytes(4));
        putenv("PIG_CODING_AGENT_DIR={$this->home}");
    }

    #[\Override]
    protected function tearDown(): void
    {
        putenv('PIG_CODING_AGENT_DIR');

        foreach (glob($this->home . '/sessions/*/*.jsonl') ?: [] as $file) {
            unlink($file);
        }
    }

    // ---- the run events ----------------------------------------------------------------

    /**
     * Every event a plain run fires, in order.
     *
     * `input` comes first — it sees what was typed, before anything is expanded or sent — and
     * `before_agent_start` next, because it is the last that can still change what is about to
     * be sent: by the time `agent_start` goes out, the prompt is already in the conversation.
     */
    public function testARunReportsItselfFromStartToEnd(): void
    {
        $session = $this->session(['hello there'], $this->watching(ExtensionApi::EVENTS));

        Async::run(static fn () => $session->prompt('are you there'));

        $this->assertSame(
            [
                'input',
                'before_agent_start',
                'agent_start',
                'turn_start',
                'message_start',
                'message_end',
                // Upstream's `transformHeaders`: a hook listening for `before_provider_headers` is
                // asked for every request's headers, just before the request goes.
                'before_provider_headers',
                'message_start',
                'message_end',
                'turn_end',
                'agent_end',
                'agent_before_settle',
                'agent_settled',
            ],
            array_column($this->seen, 0),
        );
    }

    public function testTheTurnEndCarriesTheAnswer(): void
    {
        $session = $this->session(['the answer'], $this->watching(['turn_end']));

        Async::run(static fn () => $session->prompt('ask'));

        $this->assertSame('the answer', $this->seen[0][1]->message->content[0]->text);
        $this->assertSame(0, $this->seen[0][1]->turnIndex);
    }

    public function testTheTurnCounterStartsOverForEachRun(): void
    {
        $session = $this->session(['one', 'two'], $this->watching(['turn_start']));

        Async::run(static fn () => $session->prompt('first'));
        Async::run(static fn () => $session->prompt('second'));

        $this->assertSame([0, 0], array_map(static fn (array $e): int => $e[1]->turnIndex, $this->seen));
    }

    public function testASessionWithNoHooksStillRuns(): void
    {
        $session = $this->session(['fine']);

        Async::run(static fn () => $session->prompt('hello'));

        $this->assertSame('fine', $session->lastAssistantText());
    }

    // ---- before_agent_start ------------------------------------------------------------

    public function testAHooksMessageFollowsThePrompt(): void
    {
        // Upstream's `_prepareRun()`: the starting message, then what hooks returned.
        $session = $this->session(['ok'], [
            'before_agent_start' => static fn () => new BeforeAgentStartEventResult(new CustomMessage('git', [new TextContent('on branch main')])),
        ]);

        Async::run(static fn () => $session->prompt('what changed'));

        $messages = $session->messages();

        $this->assertInstanceOf(UserMessage::class, $messages[0]);
        $this->assertSame('what changed', $messages[0]->content[0]->text);
        $this->assertInstanceOf(CustomMessage::class, $messages[1]);
        $this->assertSame('on branch main', $messages[1]->content[0]->text);
    }

    /** The hook's message is a message like any other, so a resumed session still has it. */
    public function testTheHooksMessageIsWrittenToTheSessionFile(): void
    {
        $store = SessionManager::create(sys_get_temp_dir() . '/pig-hook-note-' . bin2hex(random_bytes(3)));
        $session = $this->session(['ok'], [
            'before_agent_start' => static fn () => new BeforeAgentStartEventResult(new CustomMessage('git', [new TextContent('on branch main')])),
        ], $store);

        Async::run(static fn () => $session->prompt('what changed'));

        $reopened = SessionManager::open($store->path)->messages();
        unlink($store->path);

        $this->assertSame('what changed', $reopened[0]->content[0]->text);
        $this->assertSame('on branch main', $reopened[1]->content[0]->text);
    }

    public function testImagesStillReachTheModelWhenAHookAddsAMessage(): void
    {
        $session = $this->session(['ok'], [
            'before_agent_start' => static fn () => new BeforeAgentStartEventResult(new CustomMessage('note', [new TextContent('note')])),
        ]);

        Async::run(static fn () => $session->prompt('look at this', [new \Pig\Ai\ImageContent(TinyImages::PNG_BASE64, 'image/png')]));

        $this->assertCount(2, $session->messages()[0]->content);
    }

    // ---- context -----------------------------------------------------------------------

    /** The agent a coding agent builds is the one that runs the `context` event. */
    public function testCodingAgentInstallsTheContextHook(): void
    {
        $extensionRunner = $this->extensionRunner([
            'context' => static fn ($event) => new ContextEventResult(
                [...$event->messages, new UserMessage('added for this request only')],
            ),
        ]);

        $transform = CodingAgent::create(
            $this->model(),
            sys_get_temp_dir(),
            [],
            apiKey: 'test-key',
            extensionRunner: $extensionRunner,
        )->options()->transformContext;

        $this->assertNotNull($transform);

        $sent = $transform([new UserMessage('the only thing I said')], null);

        $this->assertCount(2, $sent);
        $this->assertSame('added for this request only', $sent[1]->content[0]->text);
    }

    public function testNoHooksMeansNoContextStepAtAll(): void
    {
        $agent = CodingAgent::create($this->model(), sys_get_temp_dir(), [], apiKey: 'test-key');

        $this->assertNull($agent->options()->transformContext);
    }

    public function testTheToolsACodingAgentIsGivenAreWrappedWhenThereAreHooks(): void
    {
        $extensionRunner = $this->extensionRunner(['tool_call' => static fn () => null]);
        $agent = CodingAgent::create($this->model(), sys_get_temp_dir(), ['read'], apiKey: 'test-key', extensionRunner: $extensionRunner);

        $this->assertInstanceOf(ExtensionGuardedTool::class, $agent->state->tools[0]);
    }

    public function testTheToolsAreLeftAloneWhenThereAreNone(): void
    {
        $agent = CodingAgent::create($this->model(), sys_get_temp_dir(), ['read'], apiKey: 'test-key');

        $this->assertFalse($agent->state->tools[0] instanceof ExtensionGuardedTool);
    }

    /**
     * A hook that edits the context has not edited the conversation.
     *
     * That is the whole point of the event running on the way out: a hook that trims what
     * one request carries has not deleted anybody's messages.
     */
    public function testAContextHookDoesNotChangeTheConversationThatIsKept(): void
    {
        $asked = null;
        $extensionRunner = $this->extensionRunner([
            'context' => static fn ($event) => new ContextEventResult(
                [...$event->messages, new UserMessage('added for this request only')],
            ),
        ]);

        $agent = new Agent(new AgentOptions(
            transformContext: static fn (array $messages): array => $extensionRunner->emitContext($messages),
            streamFn: function (Model $model, TranscriptContext $context, SimpleStreamOptions $options) use (&$asked) {
                $asked = $context;

                return $this->replay('ok');
            },
            apiKey: 'test-key',
        ));

        $agent->setModel($this->model());
        $session = new AgentSession($agent, sys_get_temp_dir(), null, null, $extensionRunner);
        Async::run(static fn () => $session->prompt('the only thing I said'));

        $sent = array_map(static fn (mixed $m): string => $m->content[0]->text ?? '', $asked?->messages ?? []);

        $this->assertContains('added for this request only', $sent);
        $this->assertSame(
            ['the only thing I said', 'ok'],
            array_map(static fn (mixed $m): string => $m->content[0]->text, $session->messages()),
        );
    }

    // ---- compaction --------------------------------------------------------------------

    public function testAHookCanStopACompaction(): void
    {
        $session = $this->session([], [
            'session_before_compact' => static fn () => new SessionBeforeCompactResult(cancel: true),
        ]);
        $session->restore($this->longConversation());

        $this->assertThrows(
            AgentError::class,
            static fn () => Async::run(static fn () => $session->compact()),
            'Compaction cancelled',
        );
    }

    public function testAHookCanWriteTheSummaryItself(): void
    {
        $session = $this->session([], [
            'session_before_compact' => static fn (SessionBeforeCompactEvent $event) => new SessionBeforeCompactResult(
                compaction: new CompactionResult(
                    'a hook wrote this',
                    $event->preparation->firstKeptEntryId,
                    1234,
                    details: ['readFiles' => ['a.php'], 'modifiedFiles' => ['b.php']],
                ),
            ),
            'session_compact' => $this->record('session_compact'),
        ]);
        $session->restore($this->longConversation());

        $summary = Async::run(static fn () => $session->compact());

        $this->assertSame('a hook wrote this', $summary?->summary);
        $this->assertSame(['a.php'], $summary->readFiles);
        $this->assertSame(1234, $summary->tokensBefore, "the hook's figure, as upstream writes it");
        $this->assertTrue($summary->fromHook);
        $this->assertGreaterThan(0, $summary->replaced);
        $this->assertSame('session_compact', $this->seen[0][0]);
        $this->assertTrue($this->seen[0][1]->fromExtension);
        $this->assertSame($summary, $this->seen[0][1]->compactionEntry);
        $this->assertSame('manual', $this->seen[0][1]->reason);
        $this->assertFalse($this->seen[0][1]->willRetry);
    }

    public function testAHooksFirstKeptEntryIsWhereTheKeptPartStarts(): void
    {
        // Upstream writes the extension's `firstKeptEntryId` as given, so a hook can keep more (or
        // less) than pig's cut would have.
        $kept = null;
        $session = $this->session([], [
            'session_before_compact' => static function (SessionBeforeCompactEvent $event) use (&$kept): SessionBeforeCompactResult {
                $kept = $event->branchEntries[count($event->branchEntries) - 2]->id;

                return new SessionBeforeCompactResult(compaction: new CompactionResult('kept the last two', $kept, 0));
            },
        ]);
        $session->restore($this->longConversation());

        $summary = Async::run(static fn () => $session->compact());

        $this->assertSame($kept, $summary?->firstKeptEntryId);
        $this->assertCount(3, $session->messages(), 'the summary and the two messages the hook kept');
    }

    public function testACompactionByTheModelIsReportedAsNotFromAHook(): void
    {
        $session = $this->session(['it was about the tests', 'and the turn it was in'], [
            'session_compact' => $this->record('session_compact'),
            'session_before_compact' => static fn () => null,
        ]);
        $session->restore($this->longConversation());

        Async::run(static fn () => $session->compact());

        $this->assertFalse($this->seen[0][1]->fromExtension);
    }

    public function testTheBeforeCompactEventCarriesWhatWouldBeReplaced(): void
    {
        $session = $this->session(['summary', 'turn'], [
            'session_before_compact' => $this->record('session_before_compact'),
        ]);
        $session->restore($this->longConversation());

        $summary = Async::run(static fn () => $session->compact('focus on the tests'));

        $event = $this->seen[0][1];

        $this->assertInstanceOf(SessionBeforeCompactEvent::class, $event);
        $this->assertNotSame([], $event->preparation->messagesToSummarize);
        $this->assertSame($summary?->firstKeptEntryId, $event->preparation->firstKeptEntryId);
        $this->assertGreaterThan(0, $event->preparation->tokensBefore);
        $this->assertSame(20_000, $event->preparation->settings->keepRecentTokens);
        $this->assertCount(16, $event->branchEntries);
        $this->assertSame('focus on the tests', $event->customInstructions);
        $this->assertSame('manual', $event->reason);
        $this->assertFalse($event->willRetry);
        $this->assertFalse($event->signal->aborted());
    }

    // ---- the tree ----------------------------------------------------------------------

    public function testAHookCanStopAJump(): void
    {
        [$session, $store, $target] = $this->savedConversation([
            'session_before_tree' => static fn () => new SessionBeforeTreeResult(cancel: true),
        ]);

        $before = $store->leaf();

        // Upstream's `{ cancelled: true }`: an answer, not an error, and nothing moved.
        $jump = $session->goTo($target);

        $this->assertTrue($jump->cancelled);
        $this->assertFalse($jump->moved);
        $this->assertFalse($jump->aborted);
        $this->assertSame($before, $store->leaf());

        unlink($store->path);
    }

    public function testTheJumpEventSaysWhereItWentAndWhatWasLeft(): void
    {
        [$session, $store, $target] = $this->savedConversation([
            'session_before_tree' => $this->record('session_before_tree'),
            'session_tree' => $this->record('session_tree'),
        ]);

        $before = $store->leaf();
        $session->goTo($target);

        [$beforeName, $beforeEvent] = $this->seen[0];
        [$afterName, $afterEvent] = $this->seen[1];

        $this->assertSame('session_before_tree', $beforeName);
        $this->assertSame($target, $beforeEvent->preparation->targetId);
        $this->assertSame($before, $beforeEvent->preparation->oldLeafId);
        $this->assertSame($target, $beforeEvent->preparation->commonAncestorId, 'jumping back along the branch: the target is the ancestor');
        $this->assertCount(2, $beforeEvent->preparation->entriesToSummarize);
        $this->assertFalse($beforeEvent->preparation->userWantsSummary);

        $this->assertSame('session_tree', $afterName);
        $this->assertSame($target, $afterEvent->newLeafId);
        $this->assertSame($before, $afterEvent->oldLeafId);
        $this->assertNull($afterEvent->summaryEntry);
        $this->assertNull($afterEvent->fromExtension, 'no summary, so nobody wrote one');

        unlink($store->path);
    }

    // ---- the branch that was left behind -----------------------------------------------

    public function testNoSummaryIsWrittenUnlessOneIsAskedFor(): void
    {
        [$session, $store, $target] = $this->savedConversation([]);

        $jump = Async::run(static fn () => $session->goTo($target));

        $this->assertTrue($jump->moved);
        $this->assertNull($jump->summary);
        $this->assertCount(2, $session->messages());

        unlink($store->path);
    }

    public function testAskingForOneWritesItOntoTheBranchBeingJoined(): void
    {
        [$session, $store, $target] = $this->savedConversation([], ['## Goal' . "\n" . 'It was about the tests.']);

        $jump = Async::run(static fn () => $session->goTo($target, summarise: true));

        $this->assertTrue($jump->moved);
        $this->assertStringContainsString('It was about the tests.', (string) $jump->summary?->summary);

        // Two from the branch that was joined, then the summary of the one that was left.
        $messages = $session->messages();

        $this->assertCount(3, $messages);
        $this->assertInstanceOf(BranchSummary::class, $messages[2]);

        unlink($store->path);
    }

    /** It has to survive a restart, or the next session starts without the handover. */
    public function testItIsWrittenToTheSessionFile(): void
    {
        [$session, $store, $target] = $this->savedConversation([], ['written down']);

        Async::run(static fn () => $session->goTo($target, summarise: true));

        $reopened = SessionManager::open($store->path)->messages();
        unlink($store->path);

        $this->assertInstanceOf(BranchSummary::class, $reopened[2] ?? null);
    }

    public function testTheSummaryReachesTheModelAsSomethingItReads(): void
    {
        [$session, $store, $target] = $this->savedConversation([], ['what happened over there']);

        Async::run(static fn () => $session->goTo($target, summarise: true));

        $sent = CodingAgent::toLlm($session->messages());
        $last = $sent[count($sent) - 1];

        $this->assertInstanceOf(UserMessage::class, $last);
        $this->assertStringContainsString('what happened over there', $last->content[0]->text);
        // Upstream's own sentence, and the tags that say where the summary ends.
        $this->assertStringContainsString('summary of a branch that this conversation came back from', $last->content[0]->text);
        $this->assertStringContainsString('</summary>', $last->content[0]->text);

        unlink($store->path);
    }

    /** Escape during the summary means "put me back", not "go anyway". */
    public function testCancellingTheSummaryLeavesTheLeafWhereItWas(): void
    {
        [$session, $store, $target] = $this->savedConversation([], ['never reached']);
        $before = $store->leaf();

        $controller = new AbortController();
        $controller->abort();

        $jump = Async::run(static fn () => $session->goTo($target, summarise: true, signal: $controller->signal));

        $this->assertFalse($jump->moved);
        $this->assertTrue($jump->aborted);
        $this->assertSame($before, $store->leaf());

        unlink($store->path);
    }

    public function testAHookCanWriteTheHandoverItself(): void
    {
        [$session, $store, $target] = $this->savedConversation([
            'session_before_tree' => static fn () => new SessionBeforeTreeResult(summary: [
                'summary' => 'a hook wrote this',
                'details' => ['readFiles' => ['hook.php'], 'modifiedFiles' => []],
            ]),
            'session_tree' => $this->record('session_tree'),
        ]);

        $jump = Async::run(static fn () => $session->goTo($target, summarise: true));

        $this->assertSame('a hook wrote this', $jump->summary?->summary);
        $this->assertTrue($jump->summary->fromHook);
        $this->assertSame(['hook.php'], $jump->summary->readFiles, "the hook's details, as upstream stores them");
        $this->assertSame('a hook wrote this', $this->seen[0][1]->summaryEntry?->summary);
        $this->assertTrue($this->seen[0][1]->fromExtension);

        unlink($store->path);
    }

    public function testAHooksLabelGoesOnTheSummaryOrOnThePointGoneTo(): void
    {
        // Upstream's `label` override and its two `appendLabelChange()` calls: on the summary entry
        // when one is written, on the target otherwise.
        [$session, $store, $target] = $this->savedConversation([
            'session_before_tree' => static fn () => new SessionBeforeTreeResult(label: 'from the hook'),
        ], ['what happened']);

        Async::run(static fn () => $session->goTo($target, summarise: true, label: 'from the caller'));

        // The label is an entry of its own, after the summary it names.
        $summaryId = (string) $store->entry((string) $store->leaf())['parent'];
        $this->assertInstanceOf(BranchSummary::class, $store->entry($summaryId)['message'] ?? null);
        $this->assertSame('from the hook', $store->labelOf($summaryId));
        unlink($store->path);

        [$session, $store, $target] = $this->savedConversation([]);

        Async::run(static fn () => $session->goTo($target, label: 'here'));

        $this->assertSame('here', $store->labelOf($target));
        unlink($store->path);
    }

    public function testAHooksProseIsNotWrittenWhenNoSummaryWasAskedFor(): void
    {
        [$session, $store, $target] = $this->savedConversation([
            'session_before_tree' => static fn () => new SessionBeforeTreeResult(summary: ['summary' => 'unasked']),
        ]);

        $jump = Async::run(static fn () => $session->goTo($target));

        $this->assertTrue($jump->moved);
        $this->assertNull($jump->summary);
        unlink($store->path);
    }

    public function testTheBeforeTreeEventSaysWhetherASummaryWasAskedFor(): void
    {
        [$session, $store, $target] = $this->savedConversation([
            'session_before_tree' => $this->record('session_before_tree'),
        ]);

        Async::run(static fn () => $session->goTo($target));

        $this->assertFalse($this->seen[0][1]->preparation->userWantsSummary);

        unlink($store->path);
    }

    // ---- errors ------------------------------------------------------------------------

    public function testAHookThatThrowsDuringARunDoesNotStopTheRun(): void
    {
        $errors = [];
        $extensionRunner = $this->extensionRunner(['turn_end' => static function (): void {
            throw new RuntimeException('bad hook');
        }]);
        $extensionRunner->onError(static function (ExtensionError $error) use (&$errors): void {
            $errors[] = $error;
        });

        $session = $this->sessionWith($extensionRunner, ['still answered']);
        Async::run(static fn () => $session->prompt('hello'));

        $this->assertSame('still answered', $session->lastAssistantText());
        $this->assertCount(1, $errors);
        $this->assertSame('turn_end', $errors[0]->stage);
    }

    // ---- scaffolding -------------------------------------------------------------------

    /** @param array<string, callable> $handlers */
    private function extensionRunner(array $handlers): ExtensionRunner
    {
        $api = new ExtensionApi('.', 'test.php');

        foreach ($handlers as $event => $handler) {
            $api->on($event, $handler);
        }

        return new ExtensionRunner([new LoadedExtension('test.php', 'test.php', $api->name, $api)], sys_get_temp_dir());
    }

    /** A handler that records the event under its name. */
    private function record(string $name): Closure
    {
        return function (mixed $event) use ($name) {
            $this->seen[] = [$name, $event];

            return null;
        };
    }

    /**
     * One recording handler per event named.
     *
     * @param list<string> $events
     * @return array<string, callable>
     */
    private function watching(array $events): array
    {
        $handlers = [];

        foreach ($events as $event) {
            $handlers[$event] = $this->record($event);
        }

        return $handlers;
    }

    /**
     * @param list<string>            $answers  one per model call
     * @param array<string, callable> $handlers
     */
    private function session(array $answers, array $handlers = [], ?SessionManager $store = null): AgentSession
    {
        return $this->sessionWith($handlers === [] ? null : $this->extensionRunner($handlers), $answers, $store);
    }

    /** @param list<string> $answers */
    private function sessionWith(?ExtensionRunner $extensionRunner, array $answers, ?SessionManager $store = null): AgentSession
    {
        $index = 0;
        $agent = new Agent(new AgentOptions(
            streamFn: function (
                Model $model,
                TranscriptContext $context,
                SimpleStreamOptions $options,
            ) use ($answers, &$index): AssistantMessageEventStream {
                // A real provider answers an already-aborted request with an aborted
                // message rather than a refusal, and the difference matters here: it is
                // what escape during a summary looks like from the session's side.
                if ($options->signal?->aborted() === true) {
                    return $this->replay('', StopReason::Aborted);
                }

                return $this->replay($answers[$index++] ?? throw new RuntimeException('out of scripted answers'));
            },
            apiKey: 'test-key',
        ));

        $agent->setModel($this->model());

        return new AgentSession($agent, sys_get_temp_dir(), $store, null, $extensionRunner);
    }

    /**
     * A conversation long enough to be worth compacting.
     *
     * The usage on the last answer is what `shouldCompact` and `tokensBefore` read, and
     * the length is what `cutPoint` needs to find somewhere to cut.
     *
     * @return list<mixed>
     */
    private function longConversation(): array
    {
        $messages = [];
        $filler = str_repeat('a lot has been said about this already. ', 400);

        for ($turn = 0; $turn < 8; $turn++) {
            $messages[] = new UserMessage("question {$turn}: {$filler}");
            $messages[] = new AssistantMessage(
                [new TextContent("answer {$turn}: {$filler}")],
                Api::AnthropicMessages,
                'anthropic',
                'test-model',
                new Usage(50_000, 2_000),
                StopReason::Stop,
            );
        }

        return $messages;
    }

    /**
     * A saved two-message conversation, and a point two messages back to jump to.
     *
     * @param array<string, callable> $handlers
     * @param list<string>            $answers  what the summariser would say; an empty list
     *        makes the model call abort, which is what escape does
     * @return array{0: AgentSession, 1: SessionManager, 2: string}
     */
    private function savedConversation(array $handlers, array $answers = []): array
    {
        $store = SessionManager::create(sys_get_temp_dir() . '/pig-hook-tree-' . bin2hex(random_bytes(3)));
        $store->append(new UserMessage('one'));
        $store->append($this->answer('first'));
        $target = $store->branch()[1]['id'];
        $store->append(new UserMessage('two'));
        $store->append($this->answer('second'));

        $session = $this->session($answers, $handlers, $store);
        $session->restore($store->messages());

        return [$session, $store, $target];
    }

    private function answer(string $text): AssistantMessage
    {
        return new AssistantMessage(
            [new TextContent($text)],
            Api::AnthropicMessages,
            'anthropic',
            'test-model',
            new Usage(),
            StopReason::Stop,
        );
    }

    private function replay(string $text, StopReason $stop = StopReason::Stop): AssistantMessageEventStream
    {
        $stream = new AssistantMessageEventStream();
        $message = new AssistantMessage(
            [new TextContent($text)],
            Api::AnthropicMessages,
            'anthropic',
            'test-model',
            new Usage(),
            $stop,
        );

        Async::spawn(static function () use ($stream, $message, $stop): void {
            $stream->push(new StartEvent($message));
            $stream->push(new DoneEvent($stop, $message));
            $stream->end();
        });

        return $stream;
    }

    private function model(): Model
    {
        return new Model('test-model', 'Test', Api::AnthropicMessages, 'anthropic', 'http://127.0.0.1:1', 200_000, 64_000);
    }
}
