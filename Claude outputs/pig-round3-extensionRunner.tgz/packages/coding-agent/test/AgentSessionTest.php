<?php

declare(strict_types=1);

namespace Pig\CodingAgent\Test;

use Closure;
use PHPUnit\Framework\TestCase;
use Pig\Agent\Agent;
use Pig\Agent\AgentEndEvent;
use Pig\Agent\AgentError;
use Pig\Agent\AgentEvent;
use Pig\Agent\AgentOptions;
use Pig\Agent\AgentTool;
use Pig\Agent\AgentToolResult;
use Pig\Agent\MessageEndEvent;
use Pig\Agent\MessageStartEvent;
use Pig\Agent\ReplayableTool;
use Pig\Agent\ThinkingLevel;
use Pig\Agent\ToolReplay;
use Pig\Ai\Api;
use Pig\Ai\AssistantMessage;
use Pig\Ai\Context;
use Pig\Ai\Cost;
use Pig\Ai\DoneEvent;
use Pig\Ai\ErrorEvent;
use Pig\Ai\ImageContent;
use Pig\Ai\Model;
use Pig\Ai\Models;
use Pig\Ai\Pricing;
use Pig\Ai\SimpleStreamOptions;
use Pig\Ai\StartEvent;
use Pig\Ai\StopReason;
use Pig\Ai\TextContent;
use Pig\Ai\Timestamp;
use Pig\Ai\Tool;
use Pig\Ai\ToolCall;
use Pig\Ai\ToolResultMessage;
use Pig\CodingAgent\Auth;
use Pig\Ai\Usage;
use Pig\Ai\UserMessage;
use Pig\Ai\Utils\AssistantMessageEventStream;
use Pig\Ai\TranscriptContext;
use Pig\Ai\Utils\Transcript;
use Pig\Async\AbortController;
use Pig\Async\AbortSignal;
use Pig\Async\Async;
use Pig\Async\Deferred;
use Pig\Async\Loop;
use Pig\CodingAgent\CodingAgent;
use Pig\CodingAgent\Extensions\Events\SessionBeforeCompactEvent;
use Pig\CodingAgent\Extensions\Events\SessionCompactEvent;
use Pig\CodingAgent\Extensions\Events\SessionCompactFailedEvent;
use Pig\CodingAgent\Extensions\ExtensionApi;
use Pig\CodingAgent\Extensions\ExtensionRunner;
use Pig\CodingAgent\Session\ToolProgress;
use Pig\CodingAgent\CustomTools\CustomToolSet;
use Pig\CodingAgent\Tools\ToolLoadout;
use Pig\CodingAgent\Prompt\Skill;
use Pig\CodingAgent\ModelChoice;
use Pig\CodingAgent\Extensions\LoadedExtension;
use Pig\CodingAgent\Extensions\Results\SessionBeforeCompactResult;
use Pig\CodingAgent\Extensions\Results\SessionBeforeForkResult;
use Pig\CodingAgent\Extensions\Results\SessionBeforeSwitchResult;
use Pig\CodingAgent\Session\AgentSession;
use Pig\CodingAgent\Session\BashExecution;
use Pig\CodingAgent\Session\CompactionSummary;
use Pig\CodingAgent\Session\CompactionEndEvent;
use Pig\CodingAgent\StartedSession;
use Pig\CodingAgent\Session\SessionCwdIssue;
use Pig\CodingAgent\Session\SessionCwd;
use Pig\CodingAgent\Session\MissingSessionCwdError;
use Pig\CodingAgent\Session\CompactionStartEvent;
use Pig\CodingAgent\Session\RetryEndEvent;
use Pig\CodingAgent\Session\ModelFallbackEvent;
use Pig\CodingAgent\Session\RetryStartEvent;
use Pig\CodingAgent\Session\SessionManager;
use Pig\CodingAgent\Session\SessionSwitch;
use Pig\CodingAgent\Settings;
use Pig\Test\AssertsThrows;
use Throwable;
use RuntimeException;

/**
 * The layer the interactive mode talks to instead of the agent.
 *
 * Nothing here reaches a provider: the agent is wired to a scripted one, the same way
 * `AgentTest` does it, so what is under test is the session's own bookkeeping.
 */
final class AgentSessionTest extends TestCase
{
    use AssertsThrows;

    private ?Agent $current = null;
    private string $tempHome = '';

    #[\Override]
    protected function setUp(): void
    {
        Loop::reset();
        $this->current = null;
        $this->tempHome = sys_get_temp_dir() . '/pig-test-home-' . bin2hex(random_bytes(4));
        putenv("PIG_CODING_AGENT_DIR={$this->tempHome}");
    }

    #[\Override]
    protected function tearDown(): void
    {
        putenv('PIG_CODING_AGENT_DIR');
        if (is_dir($this->tempHome)) {
            self::removeDir($this->tempHome);
        }
    }

    private static function removeDir(string $path): void
    {
        if (is_dir($path) && !is_link($path)) {
            foreach (scandir($path) ?: [] as $entry) {
                if ($entry !== '.' && $entry !== '..') {
                    self::removeDir($path . '/' . $entry);
                }
            }
            rmdir($path);
        } elseif (is_file($path) || is_link($path)) {
            unlink($path);
        }
    }

    // ---- the turn's signal -------------------------------------------------------

    public function testThereIsASignalDuringATurnAndNoneBetweenThem(): void
    {
        $session = $this->session(['hello']);
        $during = null;

        $this->assertNull($session->signal(), 'idle');

        $session->subscribe(static function (AgentEvent $event) use ($session, &$during): void {
            if ($event instanceof MessageStartEvent) {
                $during = $session->signal();
            }
        });

        Async::run(static fn () => $session->prompt('hi'));

        // What a hook's own waiting parks on, so escape reaches a command it started. Null
        // afterwards, and that half matters as much: handing back the last turn's signal would
        // mean an already-aborted one for everything asking after an interrupted turn.
        $this->assertNotNull($during);
        $this->assertFalse($during->aborted());
        $this->assertNull($session->signal(), 'between turns');
    }

    // ---- events ------------------------------------------------------------------

    public function testListenersSeeWhatTheAgentEmits(): void
    {
        $session = $this->session(['hello']);
        $seen = [];

        $session->subscribe(static function (AgentEvent $event) use (&$seen): void {
            $seen[] = $event::class;
        });

        Async::run(static fn () => $session->prompt('hi'));

        $this->assertContains(MessageStartEvent::class, $seen);
    }

    public function testUnsubscribingStopsOneListenerAndNotTheOthers(): void
    {
        $session = $this->session(['hello']);
        $kept = $dropped = 0;

        $session->subscribe(static function () use (&$kept): void {
            $kept++;
        });

        $stop = $session->subscribe(static function () use (&$dropped): void {
            $dropped++;
        });

        $stop();
        Async::run(static fn () => $session->prompt('hi'));

        $this->assertGreaterThan(0, $kept);
        $this->assertSame(0, $dropped);
    }

    public function testDisposeLetsGoOfTheAgentToo(): void
    {
        $session = $this->session(['hello']);
        $seen = 0;

        $session->subscribe(static function () use (&$seen): void {
            $seen++;
        });

        $session->dispose();
        Async::run(static fn () => $session->agent->prompt('hi'));

        $this->assertSame(0, $seen);
    }

    // ---- prompting ---------------------------------------------------------------

    public function testPromptingWhileWorkingIsAnError(): void
    {
        // Mid-run is exactly when someone types, so this has to name the way out.
        $session = $this->session(['one'], function (Agent $agent) use (&$session): void {
            $this->assertThrows(
                AgentError::class,
                static fn () => $session->prompt('again'),
                'steer() or followUp()',
            );
        });

        Async::run(static fn () => $session->prompt('hi'));
    }

    public function testPromptingWithNoModelSaysSo(): void
    {
        $agent = new Agent(new AgentOptions(streamFn: $this->provider([], null), apiKey: 'test-key'));

        // Cleared rather than never set: an `AgentState` fills in a default model, so the only way
        // to have none is to have lost one — the registry no longer carrying the default, which is
        // what `Models::find()` answering null means.
        $agent->state->model = null;
        $session = new AgentSession($agent);

        $this->assertThrows(
            AgentError::class,
            static fn () => $session->prompt('hi'),
            'No model selected',
        );
    }

    // ---- the queue ---------------------------------------------------------------

    public function testQueuedMessagesAreListedSteeringFirst(): void
    {
        $session = $this->session(['one']);
        $session->followUp('later');
        $session->steer('now');

        $this->assertSame(['now', 'later'], $session->queued());
    }

    public function testAQueuedMessageLeavesTheQueueBeforeItsEventGoesOut(): void
    {
        $seen = null;
        $steered = false;

        // Once, by a flag: the agent's listeners now run before its loop goes on, so the queue is
        // already empty again when the model is asked for the second answer — and steering
        // whenever it is empty steered on every turn, for ever.
        $session = $this->session(['one', 'two'], static function (Agent $agent) use (&$session, &$steered): void {
            if (!$steered) {
                $steered = true;
                $session->steer('and also this');
            }
        });

        $session->subscribe(static function (AgentEvent $event) use (&$seen, &$session): void {
            if ($event instanceof MessageStartEvent
                && $event->message instanceof UserMessage
                && $event->message->content[0]->text === 'and also this'
            ) {
                $seen = $session->queued();
            }
        });

        Async::run(static fn () => $session->prompt('hi'));

        // A footer redrawing on this event must not still be showing the message that
        // is being delivered as it fires.
        $this->assertSame([], $seen);
    }

    public function testClearingTheQueueHandsTheTextBack(): void
    {
        $session = $this->session(['one']);
        $session->steer('first');
        $session->followUp('second');

        // Handed back rather than dropped: it goes into the editor, so nobody loses
        // what they typed by pressing Escape.
        $this->assertSame(['first', 'second'], $session->clearQueue());
        $this->assertSame([], $session->queued());
    }

    // ---- a private session -------------------------------------------------------------

    public function testGoingIncognitoKeepsTheIdAndWritesNothingMore(): void
    {
        $store = SessionManager::create(sys_get_temp_dir());
        $session = $this->session(['an answer', 'another'], store: $store);
        Async::run(static fn () => $session->prompt('hi'));
        $this->assertTrue($store->isPersisted());
        $written = (string) file_get_contents($store->path);
        $id = $session->sessionId();

        $session->goIncognito();

        $this->assertTrue($session->isIncognito());
        $this->assertNull($session->store());
        // The same id: the provider's prompt cache is keyed by it.
        $this->assertSame($id, $session->sessionId());
        $this->assertSame($id, $session->agent->sessionId);
        $this->assertSame($store->header()['timestamp'], $session->sessionHeader()['timestamp']);

        Async::run(static fn () => $session->prompt('again'));
        $this->assertCount(4, $session->messages(), 'the conversation carried on');
        $this->assertSame($written, (string) file_get_contents($store->path), 'and the file did not hear of it');

        $scratch = (string) $session->scratchDirectory();
        $this->assertDirectoryExists($scratch);
        $this->assertSame(0o700, fileperms($scratch) & 0o777);

        $session->dispose();
        $this->assertDirectoryDoesNotExist($scratch);
    }

    public function testAnExtensionIsToldTheSessionIsPrivateAndWhereToSaveThings(): void
    {
        $session = $this->session([]);
        $context = new \Pig\CodingAgent\Extensions\ExtensionContext(sys_get_temp_dir(), session: $session);

        $this->assertFalse($context->isIncognito());
        $this->assertSame(\Pig\CodingAgent\Config::home() . '/artifacts', $context->artifactsDirectory());

        // Asked when it is about to write, so `/incognito` part way through is heard.
        $session->goIncognito();
        $this->assertTrue($context->isIncognito());
        $this->assertSame($session->scratchDirectory(), $context->artifactsDirectory());
        $session->dispose();
    }

    public function testAnOrdinarySessionHasNoScratchDirectory(): void
    {
        $session = $this->session([]);

        $this->assertFalse($session->isIncognito());
        $this->assertNull($session->scratchDirectory());
    }

    public function testAPrivateSessionsLongOutputIsKeptInItsOwnDirectoryAndGoesWithIt(): void
    {
        $session = $this->session([]);
        $session->goIncognito();
        $scratch = (string) $session->scratchDirectory();

        // Past `Truncate::MAX_LINES`, so the whole output is spilled to a file.
        $execution = Async::run(static fn () => $session->executeBash('seq 1 5000'));

        $this->assertTrue($execution->truncated);
        $this->assertNotNull($execution->fullOutputPath);
        $this->assertStringStartsWith($scratch . '/', (string) $execution->fullOutputPath);
        $this->assertFileExists((string) $execution->fullOutputPath);

        $session->dispose();
        $this->assertFileDoesNotExist((string) $execution->fullOutputPath);
    }

    // ---- running a command yourself ---------------------------------------------------

    public function testABangCommandJoinsTheConversationAndReachesTheModel(): void
    {
        $session = $this->session(['ok']);

        $execution = Async::run(static fn () => $session->executeBash('echo hi'));

        $this->assertSame('hi', trim($execution->output));
        $this->assertSame(0, $execution->exitCode);
        $this->assertSame([$execution], $session->messages());

        // The whole point of typing `!` is that the output reaches the model.
        $this->assertStringContainsString('Ran `echo hi`', $execution->toText());
        $this->assertStringContainsString('hi', $execution->toText());
    }

    public function testWhatACommandPrintedIsCleanedAtTheSourceAndNotOnlyOnScreen(): void
    {
        $session = $this->session([]);

        // `npm`, `cargo` and `docker` colour their output whether or not anybody is looking, and
        // anything with a progress line writes `\r` to redraw it. Upstream cleans this in
        // `bash-executor.ts` — "sanitize once at the source" — so what reaches the model, the
        // session file and the screen is the same clean text. pig cleaned it at the display
        // boundary only, so the model and the file got the escapes.
        $execution = Async::run(
            static fn () => $session->executeBash("printf 'a\\033[32mb\\033[0m\\rc\\n'"),
        );

        $this->assertSame("abc\n", $execution->output);
        // And it is the text the model reads, which is the half a display-layer fix cannot reach.
        $this->assertStringContainsString('abc', $execution->toText());
        $this->assertStringNotContainsString("\033", $execution->toText());
        $this->assertStringNotContainsString("\r", $execution->toText());
    }

    public function testTwoBangsRunItKeptInTheSessionAndOutOfTheModelsSight(): void
    {
        $session = $this->session([]);

        $execution = Async::run(static fn () => $session->executeBash('echo hi', excludeFromContext: true));

        // Upstream's `recordBashResult()` records `!!` too, flagged; `convertToLlm()` drops it.
        $this->assertSame('hi', trim($execution->output));
        $this->assertTrue($execution->excludeFromContext);
        $this->assertSame([$execution], array_values(array_filter($session->messages(), static fn ($m) => $m instanceof BashExecution)));
        $this->assertSame([], CodingAgent::toLlm([$execution]));
    }

    public function testABangsOutputIsAnnouncedAsItArrivesUnderTheIdItWasGiven(): void
    {
        $session = $this->session([]);
        $updates = [];
        $session->subscribe(static function (AgentEvent $event) use (&$updates): void {
            if ($event instanceof \Pig\CodingAgent\Session\BashExecutionUpdateEvent) {
                $updates[] = $event;
            }
        });

        Async::run(static fn () => $session->executeBash('echo one; echo two', id: 'b7'));

        $this->assertNotSame([], $updates);
        $this->assertSame(['b7'], array_values(array_unique(array_map(static fn ($u) => $u->id, $updates))));
        $this->assertSame("one\ntwo\n", implode('', array_map(static fn ($u) => $u->delta, $updates)));
    }

    public function testAFailingCommandCarriesItsExitCode(): void
    {
        $session = $this->session([]);

        $execution = Async::run(static fn () => $session->executeBash('echo bad >&2; exit 7'));

        $this->assertSame(7, $execution->exitCode);
        $this->assertStringContainsString('bad', $execution->output);
        $this->assertStringContainsString('Command exited with code 7', $execution->toText());
    }

    public function testOutputArrivesWhileItIsStillRunning(): void
    {
        $session = $this->session([]);
        $seen = [];

        Async::run(static function () use ($session, &$seen): void {
            $session->executeBash('echo one; sleep 0.1; echo two', onOutput: static function (string $output) use (&$seen): void {
                $seen[] = $output;
            });
        });

        // Not one lump at the end: a command that takes a while has to show something
        // while it takes it.
        $this->assertNotSame([], $seen);
        $this->assertStringContainsString('one', $seen[0]);
    }

    public function testASecondCommandIsRefusedWhileOneIsRunning(): void
    {
        $session = $this->session([]);

        Async::run(function () use ($session): void {
            Async::spawn(static fn () => $session->executeBash('sleep 0.3'));
            Async::delay(0.05);

            $this->assertTrue($session->isBashRunning());
            $this->assertThrows(
                AgentError::class,
                static fn () => $session->executeBash('echo second'),
                'already running',
            );

            $session->abortBash();
        });
    }

    public function testACommandRunDuringATurnWaitsForTheTurnToEnd(): void
    {
        // A message added between a tool call and its result is a request the provider
        // rejects outright, so anything that arrives mid-run waits for the run to end.
        $during = null;
        $session = null;
        $session = $this->session(['answer'], static function (Agent $agent) use (&$session, &$during): void {
            if ($during !== null) {
                return;
            }

            $session->executeBash('echo mid-run');
            $during = count($session->messages());
        });

        Async::run(static fn () => $session->prompt('hi'));

        $this->assertSame(1, $during, 'held back while the agent was working');
        $this->assertCount(3, $session->messages());
        $this->assertInstanceOf(BashExecution::class, $session->messages()[2]);
    }

    // ---- making room -------------------------------------------------------------

    public function testAShortConversationSaysThereIsNothingToCompact(): void
    {
        $session = $this->session(['answer']);
        Async::run(static fn () => $session->prompt('hi'));

        $before = $session->messages();

        // Nothing is old enough to be worth dropping. Said rather than silently skipped:
        // someone who typed `/compact` and saw nothing happen goes looking for a bug.
        $this->assertThrows(
            AgentError::class,
            static fn () => Async::run(static fn () => $session->compact()),
            'Nothing to compact (session too small)',
        );
        $this->assertSame($before, $session->messages());
    }

    public function testAPromptPastTheThresholdIsCompactedFirstWhateverTheMode(): void
    {
        // Upstream's `_checkCompaction(lastAssistant, false)` in `prompt()`: in the session, so RPC
        // and print mode compact before the turn as the terminal does — with upstream's events.
        $session = $this->session(['the summary', 'and the answer']);

        foreach (range(1, 6) as $ignored) {
            $session->agent->appendMessage(new UserMessage(str_repeat('x', 40_000)));
        }

        $session->agent->appendMessage(new AssistantMessage(
            [new TextContent('so far so good')],
            Api::AnthropicMessages,
            'anthropic',
            'test-model',
            new Usage(0, 0, 0, 0, 190_000),
            StopReason::Stop,
            null,
            Timestamp::nowMs() - 1_000,
        ));

        $reasons = [];
        $session->subscribe(static function (AgentEvent $event) use (&$reasons): void {
            if ($event instanceof CompactionStartEvent) {
                $reasons[] = $event->reason;
            }
        });

        Async::run(static fn () => $session->prompt('one more thing'));

        $this->assertSame(['threshold'], $reasons);
        $this->assertInstanceOf(CompactionSummary::class, $session->messages()[0]);
        $this->assertSame('and the answer', $session->lastAssistantText());
    }

    public function testCompactingDoesNotLeaveTheSessionAskingToCompactAgain(): void
    {
        $session = $this->session(['the summary']);

        foreach (range(1, 6) as $ignored) {
            $session->agent->appendMessage(new UserMessage(str_repeat('x', 40_000)));
        }

        // The last turn reported 190k of a 200k window, which is what asks for a
        // compaction in the first place.
        $session->agent->appendMessage(new AssistantMessage(
            [new TextContent('so far so good')],
            Api::AnthropicMessages,
            'anthropic',
            'test-model',
            new Usage(0, 0, 0, 0, 190_000),
            StopReason::Stop,
            null,
            Timestamp::nowMs() - 1_000,
        ));

        $this->assertTrue($session->shouldCompact());

        Async::run(static fn () => $session->compact());

        // That reading described a request that no longer exists. Trusting it after the
        // compaction means compacting again before every turn, for ever.
        $this->assertFalse($session->shouldCompact());
    }

    public function testCompactingWhatIsAlreadyASummarySaysSo(): void
    {
        $session = $this->session([]);
        $session->agent->appendMessage(new CompactionSummary('already summarised'));

        $this->assertThrows(
            AgentError::class,
            static fn () => Async::run(static fn () => $session->compact()),
            'Already compacted',
        );
    }

    public function testTheOlderHalfIsReplacedByASummaryAndTheRecentHalfIsKept(): void
    {
        $session = $this->session(['the summary']);
        $long = str_repeat('x', 40_000);

        foreach (range(1, 6) as $ignored) {
            $session->agent->appendMessage(new UserMessage($long));
        }

        $session->agent->appendMessage(new UserMessage('the last thing I said'));

        $summary = Async::run(static fn () => $session->compact());
        $messages = $session->messages();

        $this->assertInstanceOf(CompactionSummary::class, $summary);
        $this->assertSame('the summary', $summary->summary);
        $this->assertSame($summary, $messages[0]);
        $this->assertSame('the last thing I said', self::textOf($messages[count($messages) - 1]));
        $this->assertGreaterThan(0, $summary->replaced);
    }

    public function testASummaryReachesTheModelAsSomethingItCanRead(): void
    {
        $session = $this->session(['answer']);
        $session->agent->appendMessage(new CompactionSummary('what happened earlier', ['a.php']));

        // The agent's own converter keeps the three LLM message types and drops the rest;
        // a summary dropped there would compact the conversation into nothing at all.
        $converted = CodingAgent::toLlm($session->messages());

        $this->assertInstanceOf(UserMessage::class, $converted[0]);
        $this->assertStringContainsString('what happened earlier', self::textOf($converted[0]));
        $this->assertStringContainsString('a.php', self::textOf($converted[0]));
    }

    public function testASavedSessionResumesTheWayCompactionLeftIt(): void
    {
        $path = sys_get_temp_dir() . '/pig-compaction-' . bin2hex(random_bytes(4)) . '.jsonl';
        $store = SessionManager::create(sys_get_temp_dir(), $path);
        $session = $this->session(['an answer', 'the summary'], null, null, null, $store);

        Async::run(static fn () => $session->prompt('hi'));

        foreach (range(1, 6) as $ignored) {
            $session->agent->appendMessage(new UserMessage(str_repeat('x', 40_000)));
            $store->append($session->messages()[count($session->messages()) - 1]);
        }

        Async::run(static fn () => $session->compact());

        try {
            $reopened = SessionManager::open($path)->messages();

            // The point of writing the summary down: the conversation that comes back is
            // the compacted one, not the one that was compacted away.
            $this->assertSame(count($session->messages()), count($reopened));
            $this->assertInstanceOf(CompactionSummary::class, $reopened[0]);
        } finally {
            if (is_file($path)) {
                unlink($path);
            }
        }
    }

    public function testCompactingWhileTheAgentIsWorkingIsRefusedRatherThanQueued(): void
    {
        // Replacing the conversation from under a running turn is how a tool result ends
        // up with no call in front of it.
        $thrown = null;
        $session = null;
        $session = $this->session(['answer'], static function (Agent $agent) use (&$session, &$thrown): void {
            try {
                $session->compact();
            } catch (Throwable $error) {
                $thrown = $error;
            }
        });

        Async::run(static fn () => $session->prompt('hi'));

        $this->assertInstanceOf(AgentError::class, $thrown);
    }

    public function testCancellingTheSummariserLeavesTheConversationAlone(): void
    {
        // Escape is the signal being aborted while the summariser is answering, which is what
        // upstream checks once the summary comes back ("Compaction cancelled").
        $escape = new AbortController();
        $session = $this->session([], null, null, static function (Model $model, TranscriptContext $context, SimpleStreamOptions $options) use ($escape): AssistantMessageEventStream {
            $escape->abort();
            $stream = new AssistantMessageEventStream();
            $cancelled = new AssistantMessage(
                [],
                Api::AnthropicMessages,
                'anthropic',
                'test-model',
                new Usage(),
                StopReason::Aborted,
            );

            Async::spawn(static function () use ($stream, $cancelled): void {
                $stream->push(new DoneEvent(StopReason::Aborted, $cancelled));
                $stream->end();
            });

            return $stream;
        });

        foreach (range(1, 6) as $ignored) {
            $session->agent->appendMessage(new UserMessage(str_repeat('x', 40_000)));
        }

        $before = $session->messages();

        // Pressing escape halfway through is not a reason to lose the conversation.
        $this->assertNull(Async::run(static fn () => $session->compact(null, $escape->signal)));
        $this->assertSame($before, $session->messages());
    }

    public function testASummariserThatFailsSaysSoRatherThanCompactingIntoNothing(): void
    {
        $session = $this->session([], null, null, static function (Model $model, TranscriptContext $context, SimpleStreamOptions $options): AssistantMessageEventStream {
            $stream = new AssistantMessageEventStream();
            $failed = new AssistantMessage(
                [],
                Api::AnthropicMessages,
                'anthropic',
                'test-model',
                new Usage(),
                StopReason::Error,
                'overloaded_error',
            );

            Async::spawn(static function () use ($stream, $failed): void {
                $stream->push(new DoneEvent(StopReason::Error, $failed));
                $stream->end();
            });

            return $stream;
        }, settings: Settings::inMemory(['retry' => ['baseDelayMs' => 1]])); // the retries between, without their seconds

        foreach (range(1, 6) as $ignored) {
            $session->agent->appendMessage(new UserMessage(str_repeat('x', 40_000)));
        }

        $this->assertThrows(
            AgentError::class,
            static fn () => Async::run(static fn () => $session->compact()),
            'overloaded_error',
        );
    }

    public function testWhatTheSummariserIsAskedIsTheConversationAndNotTheTools(): void
    {
        $asked = null;
        $session = $this->session([], null, null, function (Model $model, TranscriptContext $context, SimpleStreamOptions $options) use (&$asked): AssistantMessageEventStream {
            $asked = $context;

            return $this->replay('the summary');
        });

        foreach (range(1, 6) as $ignored) {
            $session->agent->appendMessage(new UserMessage(str_repeat('x', 40_000)));
        }

        Async::run(static fn () => $session->compact('the parser bug'));

        // A transcript now, as every stream function is handed: the summariser's prompt is its
        // leading system message, and nothing in it declares a tool.
        $this->assertInstanceOf(TranscriptContext::class, $asked);
        $this->assertCount(2, $asked->messages);
        $this->assertSame([], Transcript::getCurrentTools($asked->messages), 'a summariser with tools is an agent, not a summariser');
        $this->assertStringContainsString('summarization assistant', Transcript::getCurrentSystemPrompt($asked->messages));
        $this->assertStringContainsString('Additional focus: the parser bug', self::textOf($asked->messages[1]));
    }

    // ---- images and the shell ---------------------------------------------------------

    public function testWithBlockImagesNoPictureReachesTheProviderAndTheConversationKeepsThem(): void
    {
        $sent = null;
        $session = $this->session(
            [],
            streamFn: function (Model $model, TranscriptContext $context) use (&$sent): AssistantMessageEventStream {
                $sent = $context;

                return $this->replay('ok');
            },
            settings: Settings::inMemory(['images' => ['blockImages' => true]]),
        );
        $image = new ImageContent(TinyImages::PNG_BASE64, 'image/png');

        Async::run(static fn () => $session->prompt('look', [$image, $image]));

        $user = array_values(array_filter($sent->messages, static fn (mixed $m): bool => $m instanceof UserMessage))[0];
        $this->assertEquals([new TextContent('look'), new TextContent('Image reading is disabled.')], $user->content, 'two pictures, one line');
        $this->assertInstanceOf(ImageContent::class, $session->messages()[0]->content[1]);
    }

    public function testWithoutImagesLeavesAMessageWithNoneAlone(): void
    {
        $plain = new UserMessage('just words');
        $result = new ToolResultMessage('c', 'read', [new ImageContent('x', 'image/png'), new TextContent('note')]);

        $out = AgentSession::withoutImages([$plain, $result]);

        $this->assertSame($plain, $out[0]);
        $this->assertEquals([new TextContent('Image reading is disabled.'), new TextContent('note')], $out[1]->content);
        $this->assertSame('c', $out[1]->toolCallId);
    }

    public function testAPromptsImageThatCannotBeReadIsLeftOutAndTheTextSaysSo(): void
    {
        $session = $this->session(['ok']);

        Async::run(static fn () => $session->prompt('look', [new ImageContent(base64_encode('not a picture'), 'image/tiff')]));

        $this->assertEquals(
            [new TextContent("look\n\n[Image omitted: could not be converted to a supported inline image format.]")],
            $session->messages()[0]->content,
        );
    }

    public function testEveryToolsPicturesAreFittedAndReadTakesTheSessionsImageSettings(): void
    {
        $agent = new Agent(new AgentOptions(streamFn: $this->provider([], null), apiKey: 'test-key'));
        $agent->setModel($this->model());
        $loadout = new ToolLoadout($agent, sys_get_temp_dir(), ['read', 'bash'], new CustomToolSet(), new ExtensionRunner());
        $loadout->apply();
        new AgentSession($agent, sys_get_temp_dir(), settings: Settings::inMemory([
            'images' => ['autoResize' => false],
            'shellCommandPrefix' => 'GREETING=hello',
        ]), loadout: $loadout);

        $tools = $agent->tools();
        $this->assertContainsOnlyInstancesOf(\Pig\CodingAgent\Tools\ResultImagesTool::class, $tools);

        // Read built with `autoResizeImages: false`: an oversized picture is sent as it is.
        $path = sys_get_temp_dir() . '/pig-wide-' . bin2hex(random_bytes(4)) . '.png';
        $png = "\x89PNG\r\n\x1a\n" . pack('N', 13) . 'IHDR' . pack('NN', 3000, 1000) . "\x08\x06\x00\x00\x00";
        file_put_contents($path, $png);
        $read = $tools[0]->execute('c1', ['path' => $path]);
        unlink($path);
        $this->assertSame(base64_encode($png), $read->content[1]->data);

        // And bash with the prefix.
        $said = Async::run(static fn () => $tools[1]->execute('c2', ['command' => 'echo $GREETING']));
        $this->assertSame("hello\n", $said->content[0]->text);
    }

    public function testTheShellCommandPrefixRunsInFrontOfATypedCommand(): void
    {
        $session = $this->session([], settings: Settings::inMemory(['shellCommandPrefix' => 'GREETING=hello']));

        $execution = Async::run(static fn () => $session->executeBash('echo $GREETING'));

        $this->assertSame('hello', trim($execution->output));
        $this->assertSame('echo $GREETING', $execution->command, 'what is recorded is what was typed');
    }

    // ---- skill commands --------------------------------------------------------------

    public function testASkillCommandSendsTheSkillsInstructionsAndTheArgumentsAfterThem(): void
    {
        $dir = sys_get_temp_dir() . '/pig-skillcmd-' . bin2hex(random_bytes(4)) . '/review';
        mkdir($dir, 0o755, true);
        file_put_contents("{$dir}/SKILL.md", "---\nname: review\ndescription: Review code\n---\n\nRead the diff first.\n");

        $agent = new Agent(new AgentOptions(streamFn: $this->provider(['ok', 'ok'], null), apiKey: 'test-key'));
        $agent->setModel($this->model());
        $skill = new Skill('review', 'Review code', "{$dir}/SKILL.md", $dir, 'test');
        $loadout = new ToolLoadout($agent, sys_get_temp_dir(), [], new CustomToolSet(), new ExtensionRunner(), [], [$skill]);
        $session = new AgentSession($agent, sys_get_temp_dir(), loadout: $loadout);

        Async::run(static fn () => $session->prompt('/skill:review src/a.php'));

        $said = self::textOf($session->messages()[0]);
        $this->assertSame(
            "<skill name=\"review\" location=\"{$dir}/SKILL.md\">\nReferences are relative to {$dir}.\n\nRead the diff first.\n</skill>\n\nsrc/a.php",
            $said,
        );

        // An unknown name is the text as it was typed.
        Async::run(static fn () => $session->prompt('/skill:nope'));
        $this->assertContains('/skill:nope', array_map(self::textOf(...), array_filter($session->messages(), static fn (mixed $m): bool => $m instanceof UserMessage)));
    }

    // ---- switching models ------------------------------------------------------------

    public function testSwitchingToAModelThatCannotThinkDropsTheThinkingLevel(): void
    {
        $session = $this->session([], null, $this->thinkingModel());
        $session->setThinkingLevel(ThinkingLevel::High);

        $session->setModel($this->plainModel());

        // Left at `high`, the next turn asks a model without reasoning to reason, and the
        // person who changed model would have no idea why the request failed.
        $this->assertSame(ThinkingLevel::Off, $session->thinkingLevel());
    }

    public function testSwitchingBetweenThinkingModelsKeepsTheLevel(): void
    {
        $session = $this->session([], null, $this->thinkingModel());
        $session->setThinkingLevel(ThinkingLevel::Medium);

        $session->setModel($this->thinkingModel('test-thinker-2'));

        $this->assertSame(ThinkingLevel::Medium, $session->thinkingLevel());
        $this->assertSame('test-thinker-2', $session->model()?->id);
    }

    public function testAModelsOwnThinkingLevelComesBeforeTheDefaultAndTheCurrentOne(): void
    {
        $settings = Settings::inMemory(['modelThinkingLevels' => ['anthropic/test-thinker-2' => 'high']]);
        $session = $this->session([], null, $this->thinkingModel(), settings: $settings);
        $session->setThinkingLevel(ThinkingLevel::Low);

        $session->setModel($this->thinkingModel('test-thinker-2'));
        $this->assertSame(ThinkingLevel::High, $session->thinkingLevel(), "the model's own");

        $settings->setDefaultThinkingLevel(ThinkingLevel::Medium);
        $session->setModel($this->thinkingModel('test-thinker-3'));
        $this->assertSame(ThinkingLevel::Medium, $session->thinkingLevel(), 'then the default, as upstream switches');

        $session->setModel($this->thinkingModel('test-thinker-2'), ThinkingLevel::Minimal);
        $this->assertSame(ThinkingLevel::Minimal, $session->thinkingLevel(), 'and what was asked for beats both');
    }

    public function testSavingADefaultOutsideTheScopeAddsItToTheScopeAndToEnabledModels(): void
    {
        $settings = Settings::inMemory(['enabledModels' => ['anthropic/test-thinker']]);
        $agent = new Agent(new AgentOptions(streamFn: $this->provider([], null), apiKey: 'test-key'));
        $agent->setModel($this->thinkingModel());
        $session = new AgentSession($agent, sys_get_temp_dir(), null, $settings, modelScope: [new ModelChoice($this->thinkingModel())]);

        $session->setModel($this->thinkingModel('test-thinker-2'), persistAsDefault: true);

        $this->assertCount(2, $session->modelScope());
        $this->assertSame(['anthropic/test-thinker', 'anthropic/test-thinker-2'], $settings->enabledModels());
        $this->assertSame('test-thinker-2', $settings->defaultModel());
        $this->assertNull($settings->defaultThinkingLevel(), 'saving the model is not saving the level');
    }

    public function testAskingForALevelAModelLacksLandsOnTheNearestItHas(): void
    {
        $session = $this->session([]);

        $session->setModel($this->thinkingModel(), ThinkingLevel::Xhigh);

        // **This reverses a decision this file used to record.** The old rule was `off`, on the
        // grounds that sending `high` for `xhigh` answers a different question from the one
        // asked. That reads well for xhigh and falls apart everywhere else: once a
        // `thinkingLevelMap` can take *any* level away, the same rule turns "medium, please" on a
        // model that goes low-or-high into thinking switched off entirely — which is a further
        // answer from the question than `high` ever was. Upstream searches up from what was
        // asked for and then down, so the most this can do is move one step.
        $this->assertSame(ThinkingLevel::High, $session->thinkingLevel());
    }

    // ---- thinking ----------------------------------------------------------------

    public function testAModelThatCannotThinkOffersNoLevels(): void
    {
        $session = $this->session(['one']);

        $this->assertSame([], $session->availableThinkingLevels());
        $this->assertNull($session->cycleThinkingLevel());
    }

    public function testCyclingWrapsRoundAtTheTop(): void
    {
        $session = $this->session(['one'], null, $this->thinkingModel());

        $this->assertSame(ThinkingLevel::Minimal, $session->cycleThinkingLevel());
        $session->setThinkingLevel(ThinkingLevel::High);
        $this->assertSame(ThinkingLevel::Off, $session->cycleThinkingLevel());
    }

    public function testXhighIsOnlyOfferedByModelsThatTakeIt(): void
    {
        $ordinary = $this->session(['one'], null, $this->thinkingModel());
        $this->assertNotContains(ThinkingLevel::Xhigh, $ordinary->availableThinkingLevels());

        // The map says so, as upstream requires; the id alone used to (`gpt-5.2` was on an id list
        // pig kept because its OpenAI rows had no maps — they carry upstream's now).
        $capable = $this->session(['one'], null, $this->thinkingModel('gpt-5.2', ['xhigh' => 'xhigh']));
        $this->assertContains(ThinkingLevel::Xhigh, $capable->availableThinkingLevels());
    }

    public function testALevelTheModelDoesNotOfferCyclesBackToTheStart(): void
    {
        $session = $this->session(['one'], null, $this->thinkingModel());
        $session->setThinkingLevel(ThinkingLevel::Xhigh);

        // Not a position in this model's list, so there is no "next" to guess at.
        $this->assertSame(ThinkingLevel::Off, $session->cycleThinkingLevel());
    }

    // ---- what it has cost ----------------------------------------------------------

    public function testStatsCountMessagesToolCallsAndTokens(): void
    {
        $session = $this->session(['one']);
        Async::run(static fn () => $session->prompt('hi'));

        $session->agent->appendMessage(new AssistantMessage(
            [new TextContent('and'), new ToolCall('call-1', 'read', [])],
            Api::AnthropicMessages,
            'anthropic',
            'test-model',
            new Usage(10, 20, 30, 40, 100, new Cost(total: 0.5)),
            StopReason::Stop,
        ));

        $stats = $session->stats();

        $this->assertSame(1, $stats->userMessages);
        $this->assertSame(2, $stats->assistantMessages);
        $this->assertSame(1, $stats->toolCalls);
        $this->assertSame(10, $stats->input);
        $this->assertSame(100, $stats->totalTokens());
        $this->assertSame(0.5, $stats->cost);

        // What a tool itself spent on models (a codemode script's classifier calls) is on its
        // result message, and was paid for the same way — upstream books it under "Tools/summaries".
        $session->agent->appendMessage(new ToolResultMessage('call-1', 'read', [new TextContent('ok')], usage: new Usage(5, 0, 0, 0, 5, new Cost(total: 0.25))));

        $billed = $session->stats();

        $this->assertSame(15, $billed->input);
        $this->assertSame(0.75, $billed->cost);
        $this->assertSame(1, $billed->toolResults);
    }

    public function testACompactionDoesNotRefundWhatTheSessionSpent(): void
    {
        // Summed over the messages in memory, a compaction *erased* the bill: what it replaces
        // them with is one summary carrying no usage, so the footer and `/session` both dropped
        // back towards zero at exactly the point a session has been long enough to be expensive.
        // Upstream's footer sums the session file for this reason; its own `/session` does not,
        // which is two answers to one question in one tool.
        $store = SessionManager::create(sys_get_temp_dir());
        // Two answers: with almost nothing kept the cut lands on the last answer, inside its turn,
        // so the history and the turn's beginning are summarised separately (upstream's split turn).
        $session = $this->session(['the summary', 'the turn so far'], store: $store, settings: self::quickRetries(['keepRecentTokens' => 1]));

        foreach (range(1, 3) as $turn) {
            $session->agent->appendMessage(new UserMessage(str_repeat('x', 20_000)));
            $session->agent->appendMessage(new AssistantMessage(
                [new TextContent("answer {$turn}")],
                Api::AnthropicMessages,
                'anthropic',
                'test-model',
                new Usage(1_000, 200, 0, 0, 1_200, new Cost(total: 0.25)),
                StopReason::Stop,
            ));
            $store->append($session->messages()[count($session->messages()) - 2]);
            $store->append($session->messages()[count($session->messages()) - 1]);
        }

        $before = $session->stats();
        $this->assertSame(0.75, $before->cost);
        $this->assertSame(3_000, $before->input);

        Async::run(static fn () => $session->compact());

        $after = $session->stats();

        $this->assertSame(0.75, $after->cost, 'the money was spent whatever the conversation now looks like');
        $this->assertSame(3_000, $after->input);

        // The counts are the other question and stay on the conversation: after a compaction it
        // *is* one summary and whatever was kept, and saying "you said 3 things" about a
        // transcript showing one is the answer to a question nobody asked.
        $this->assertLessThan($before->userMessages, $after->userMessages);
    }

    public function testTheLastAssistantTextIsWhatCopyWouldTake(): void
    {
        $session = $this->session(['the answer']);
        Async::run(static fn () => $session->prompt('hi'));

        $this->assertSame('the answer', $session->lastAssistantText());
    }

    public function testAnEmptyAbortedMessageIsSkippedInFavourOfTheRealOne(): void
    {
        $session = $this->session(['the answer']);
        Async::run(static fn () => $session->prompt('hi'));

        $session->agent->appendMessage(new AssistantMessage(
            [],
            Api::AnthropicMessages,
            'anthropic',
            'test-model',
            new Usage(),
            StopReason::Aborted,
        ));

        // Interrupting and then copying means the answer before the interruption.
        $this->assertSame('the answer', $session->lastAssistantText());
    }

    public function testNoAssistantMessageAtAllIsNull(): void
    {
        $this->assertNull($this->session([])->lastAssistantText());
    }

    // ---- scaffolding ---------------------------------------------------------------

    /**
     * @param list<string>              $answers one per model call, in order
     * @param Closure(Agent): void|null $hook    run at the top of every model call
     */
    // ---- picking a failed turn back up ------------------------------------------------

    public function testA503IsWaitedOutAndTheTurnIsSentAgain(): void
    {
        $session = $this->session(
            [],
            streamFn: $this->flaky([['error' => 'Anthropic returned 503: overloaded'], 'here you go']),
            settings: self::quickRetries(),
        );

        $seen = [];
        $session->subscribe(static function (AgentEvent $event) use (&$seen): void {
            $seen[] = $event;
        });

        Async::run(static function () use ($session): void {
            $session->prompt('hi');
        });
        self::settle();

        $starts = array_values(array_filter($seen, static fn ($e) => $e instanceof RetryStartEvent));
        $ends = array_values(array_filter($seen, static fn ($e) => $e instanceof RetryEndEvent));

        $this->assertCount(1, $starts);
        $this->assertSame(1, $starts[0]->attempt);
        $this->assertStringContainsString('503', $starts[0]->error);

        $this->assertCount(1, $ends);
        $this->assertTrue($ends[0]->succeeded);

        // The answer it was retrying for is the last thing in the conversation, and the
        // failure is not in front of it.
        $messages = $session->messages();
        $this->assertSame('here you go', self::textOf($messages[count($messages) - 1]));
    }

    public function testTheFailedTurnIsNotLeftInTheConversationForTheModelToRead(): void
    {
        $session = $this->session(
            [],
            streamFn: $this->flaky([['error' => 'Anthropic returned 503: overloaded'], 'here you go']),
            settings: self::quickRetries(),
        );

        Async::run(static function () use ($session): void {
            $session->prompt('hi');
        });
        self::settle();

        // Two: the question and the answer. "Anthropic returned 503" is not part of the
        // conversation, and a model shown it would try to make sense of it.
        $this->assertCount(2, $session->messages());

        foreach ($session->messages() as $message) {
            $this->assertStringNotContainsString('503', self::textOf($message));
        }
    }

    public function testAFailedTurnTakenOffTheStateStaysOffItWhenTheSessionIsResumed(): void
    {
        $store = SessionManager::create(sys_get_temp_dir());
        $session = $this->session(
            [],
            streamFn: $this->flaky([['error' => 'Anthropic returned 503: overloaded'], 'here you go']),
            store: $store,
            settings: self::quickRetries(),
        );

        Async::run(static function () use ($session): void {
            $session->prompt('hi');
        });
        self::settle();

        // The file is the record: the failed turn is still in it, and so is the line saying the
        // model is not to be shown it — upstream's `_omitRecoveryAttempt()`. Before this the message
        // was taken off the agent's state and nothing was written, so a `--resume` put it back.
        $lines = array_values(array_filter(explode("\n", (string) file_get_contents($store->path))));
        $this->assertStringContainsString('"type":"context_edit"', implode("\n", $lines));
        $this->assertStringContainsString('503', implode("\n", $lines), 'the failure is still in the file');

        $reopened = SessionManager::open($store->path)->messages();
        $this->assertCount(2, $reopened);

        foreach ($reopened as $message) {
            $this->assertStringNotContainsString('503', self::textOf($message));
        }

        $this->assertSame('here you go', self::textOf($reopened[1]));
    }

    public function testItGivesUpAfterTheAttemptsRunOut(): void
    {
        $session = $this->session(
            [],
            streamFn: $this->flaky(array_fill(0, 6, ['error' => 'Anthropic returned 503: overloaded'])),
            settings: self::quickRetries(['maxRetries' => 2]),
        );

        $ends = [];
        $session->subscribe(static function (AgentEvent $event) use (&$ends): void {
            if ($event instanceof RetryEndEvent) {
                $ends[] = $event;
            }
        });

        Async::run(static function () use ($session): void {
            $session->prompt('hi');
        });
        self::settle();

        $this->assertCount(1, $ends);
        $this->assertFalse($ends[0]->succeeded);
        $this->assertSame(2, $ends[0]->attempts);
        $this->assertStringContainsString('503', $ends[0]->error ?? '');
        $this->assertFalse($session->isRetrying());
    }

    public function testTheWaitsDouble(): void
    {
        $session = $this->session(
            [],
            streamFn: $this->flaky(array_fill(0, 6, ['error' => 'Anthropic returned 503: overloaded'])),
            settings: self::quickRetries(['maxRetries' => 3, 'baseDelayMs' => 2]),
        );

        $delays = [];
        $session->subscribe(static function (AgentEvent $event) use (&$delays): void {
            if ($event instanceof RetryStartEvent) {
                $delays[] = $event->delaySeconds;
            }
        });

        Async::run(static function () use ($session): void {
            $session->prompt('hi');
        });
        self::settle();

        // The point of backing off: a fixed delay brings the whole crowd back at once and
        // the provider that was overloaded is overloaded again.
        $this->assertSame([0.002, 0.004, 0.008], $delays);
    }

    public function testSomethingNotWorthRetryingIsNotRetried(): void
    {
        $session = $this->session(
            [],
            streamFn: $this->flaky([['error' => 'Anthropic returned 401: invalid api key']]),
            settings: self::quickRetries(),
        );

        $seen = [];
        $session->subscribe(static function (AgentEvent $event) use (&$seen): void {
            $seen[] = $event::class;
        });

        Async::run(static function () use ($session): void {
            $session->prompt('hi');
        });
        self::settle();

        // A bad key is a bad key in four seconds too.
        $this->assertNotContains(RetryStartEvent::class, $seen);
    }

    public function testAProvidersQuotaWallIsNotRetriedAndItsSentenceIsKept(): void
    {
        // Upstream's session reads no stated wait: a quota wall is the provider's to word so that
        // it matches none of the retryable patterns — pi-antigravity's "Quota reached. …" — and the
        // turn ends on it as written. pig used to parse "reset after 10m15s" here and rewrite the
        // message into that sentence itself.
        $wall = 'Quota reached. Please wait 10m15s. Next: switch models or retry later.';
        $session = $this->session(
            [],
            streamFn: $this->flaky([['error' => $wall]]),
            settings: self::quickRetries(),
        );

        $seen = [];
        $session->subscribe(static function (AgentEvent $event) use (&$seen): void {
            $seen[] = $event;
        });

        Async::run(static function () use ($session): void {
            $session->prompt('hi');
        });
        self::settle();

        $this->assertNotContains(RetryStartEvent::class, array_map('get_class', $seen));

        $messages = $session->messages();
        $last = $messages[count($messages) - 1];

        $this->assertInstanceOf(AssistantMessage::class, $last);
        $this->assertSame($wall, $last->errorMessage);
    }

    public function testAQuotaWallMovesTheTurnOnToTheNextFallbackModel(): void
    {
        // pig's own: with `fallbackModels` set, the wall is not the end of the turn — the same
        // turn goes again on the next entry, and the switch is kept for the session.
        $wall = 'Quota reached. Please wait 10m15s. Next: switch models or retry later.';
        $session = $this->session(
            [],
            streamFn: $this->flaky([['error' => $wall], 'carried on']),
            settings: Settings::inMemory(['fallbackModels' => ['anthropic/claude-haiku-4-5:low']]),
        );

        $switches = [];
        $session->subscribe(static function (AgentEvent $event) use (&$switches): void {
            if ($event instanceof ModelFallbackEvent) {
                $switches[] = $event;
            }
        });

        Async::run(static function () use ($session): void {
            $session->prompt('hi');
        });
        self::settle();

        $this->assertCount(1, $switches);
        $this->assertSame('test-model', $switches[0]->from->id);
        $this->assertSame('claude-haiku-4-5', $switches[0]->to->id);
        $this->assertSame($wall, $switches[0]->error);

        // The answer that came back is the fallback's, the failed turn is off the agent's state,
        // and the session is now on the fallback with the level the entry named.
        $this->assertSame('carried on', self::textOf($session->messages()[count($session->messages()) - 1]));
        $this->assertSame('claude-haiku-4-5', $session->model()?->id);
        $this->assertSame(ThinkingLevel::Low, $session->thinkingLevel());
    }

    public function testAQuotaWallWithEveryFallbackTriedEndsTheTurnAsBefore(): void
    {
        // Two walls, one fallback: the second wall has nowhere to go, so the turn ends on the
        // fallback's sentence — not on a loop back to the primary, which is the one model known
        // to be out of quota.
        $wall = 'Quota reached. Please wait 10m15s. Next: switch models or retry later.';
        $session = $this->session(
            [],
            streamFn: $this->flaky([['error' => $wall], ['error' => $wall]]),
            settings: Settings::inMemory(['fallbackModels' => ['anthropic/claude-haiku-4-5']]),
        );

        $seen = [];
        $session->subscribe(static function (AgentEvent $event) use (&$seen): void {
            $seen[] = $event::class;
        });

        Async::run(static function () use ($session): void {
            $session->prompt('hi');
        });
        self::settle();

        $this->assertSame(1, count(array_keys($seen, ModelFallbackEvent::class, true)));
        $this->assertNotContains(RetryStartEvent::class, $seen);

        $messages = $session->messages();
        $last = $messages[count($messages) - 1];

        $this->assertInstanceOf(AssistantMessage::class, $last);
        $this->assertSame($wall, $last->errorMessage);
        $this->assertSame('claude-haiku-4-5', $session->model()?->id);
    }

    public function testRetryingCanBeTurnedOff(): void
    {
        $session = $this->session(
            [],
            streamFn: $this->flaky([['error' => 'Anthropic returned 503: overloaded']]),
            settings: Settings::inMemory(['retry' => ['enabled' => false]]),
        );

        $seen = [];
        $session->subscribe(static function (AgentEvent $event) use (&$seen): void {
            $seen[] = $event::class;
        });

        Async::run(static function () use ($session): void {
            $session->prompt('hi');
        });
        self::settle();

        $this->assertNotContains(RetryStartEvent::class, $seen);
    }

    public function testRetryingIsOnWhenNobodySaid(): void
    {
        $session = $this->session(
            [],
            streamFn: $this->flaky([['error' => 'Anthropic returned 503: overloaded'], 'here you go']),
            settings: self::quickRetries(),
        );

        Async::run(static function () use ($session): void {
            $session->prompt('hi');
        });
        self::settle();

        // Nothing in the settings turned it on. Someone who never asked for auto-retry still
        // did not ask to lose a turn because the provider was busy for two seconds.
        $this->assertSame('here you go', self::textOf($session->messages()[1]));
    }

    public function testAgentSettledFiresOnceAPromptAndNotOncePerAttempt(): void
    {
        // Upstream's `agent_settled` is "final and notification-only": emitted once, after the
        // retry loop, when pig will not continue on its own. pig emitted it beside `agent_end`,
        // which is the end of a *run* — so a turn that retried twice settled three times, and the
        // system notification hook said "task complete" twice while the task was still going.
        $settled = [];
        $ended = 0;
        $extensionRunner = $this->extensionRunner([
            'agent_end' => static function () use (&$ended): void {
                $ended++;
            },
            'agent_settled' => static function ($event) use (&$settled): void {
                $settled[] = count($event->messages);
            },
        ]);
        $session = $this->session(
            [],
            streamFn: $this->flaky([
                ['error' => 'Anthropic returned 503: overloaded'],
                ['error' => 'Anthropic returned 503: overloaded'],
                'here you go',
            ]),
            settings: self::quickRetries(),
            extensionRunner: $extensionRunner,
        );

        Async::run(static function () use ($session): void {
            $session->prompt('hi');
        });
        self::settle();

        $this->assertSame('here you go', self::textOf($session->messages()[1]));
        $this->assertSame(3, $ended, 'three runs: two failed attempts and the one that worked');
        $this->assertCount(1, $settled, 'but the agent settled once, at the end of the last one');
        $this->assertSame(2, $settled[0], 'with the conversation as it stands: the prompt and the answer');
    }

    public function testAgentSettledStillFiresWhenNothingWasRetried(): void
    {
        $settled = 0;
        $session = $this->session(['hello'], extensionRunner: $this->extensionRunner([
            'agent_settled' => static function () use (&$settled): void {
                $settled++;
            },
        ]));

        Async::run(static function () use ($session): void {
            $session->prompt('hi');
        });

        $this->assertSame(1, $settled);
    }

    public function testA429ThatNamesItsResetIsWaitedOutOnTheDoublingLikeAnyOther(): void
    {
        // Upstream's `_prepareRetry()` waits `retryDelayMs(settings, attempt)` whatever the
        // message says. pig used to wait the stated thirty seconds plus one instead.
        $session = $this->session(
            [],
            streamFn: $this->flaky(array_fill(0, 4, [
                'error' => 'google returned 429: Your quota will reset after 30s',
            ])),
            settings: self::quickRetries(['baseDelayMs' => 40_000]),
        );

        $starts = [];
        $session->subscribe(static function (AgentEvent $event) use (&$starts): void {
            if ($event instanceof RetryStartEvent) {
                $starts[] = $event;
            }
        });

        // Parked on the timer rather than waiting it out — the delay is the subject, so the
        // test must not sit through it.
        self::startTurnAndParkOnTheRetry($session);

        $this->assertCount(1, $starts);
        $this->assertSame(40.0, $starts[0]->delaySeconds, 'the base delay, not the thirty seconds the message names');

        $session->abortRetry();
        self::settle();
    }

    public function testAbortingStopsTheWaiting(): void
    {
        $session = $this->session(
            [],
            // Half a minute, so the sleep cannot finish on its own while the test works.
            streamFn: $this->flaky(array_fill(0, 4, ['error' => 'Anthropic returned 503: overloaded'])),
            settings: self::quickRetries(['baseDelayMs' => 30_000]),
        );

        $ends = [];
        $session->subscribe(static function (AgentEvent $event) use (&$ends): void {
            if ($event instanceof RetryEndEvent) {
                $ends[] = $event;
            }
        });

        self::startTurnAndParkOnTheRetry($session);

        $this->assertTrue($session->isRetrying());

        $session->abortRetry();
        self::settle();

        $this->assertCount(1, $ends);
        $this->assertFalse($ends[0]->succeeded);
        $this->assertStringContainsString('cancelled', $ends[0]->error ?? '');
        $this->assertFalse($session->isRetrying());
    }

    public function testAbortingTheSessionStopsTheWaitingToo(): void
    {
        $session = $this->session(
            [],
            streamFn: $this->flaky(array_fill(0, 4, ['error' => 'Anthropic returned 503: overloaded'])),
            settings: self::quickRetries(['baseDelayMs' => 30_000]),
        );

        self::startTurnAndParkOnTheRetry($session);

        $this->assertTrue($session->isRetrying());

        // Escape means stop, and a retry that is sleeping has no agent to interrupt: the run
        // is already over and the next one has not started. `abort()` has to reach both.
        Async::run(static function () use ($session): void {
            $session->abort()->await();
        });
        self::settle();

        $this->assertFalse($session->isRetrying());
    }

    public function testStartingANewSessionStopsARetryThatWasStillWaiting(): void
    {
        $session = $this->session(
            [],
            streamFn: $this->flaky(array_fill(0, 4, ['error' => 'Anthropic returned 503: overloaded'])),
            settings: self::quickRetries(['baseDelayMs' => 30_000]),
        );

        self::startTurnAndParkOnTheRetry($session);

        $this->assertTrue($session->isRetrying());

        // No settling afterwards, deliberately: the sleep is half a minute, so a `settle()`
        // here would wait it out and watch the retry end *by itself* — green whatever
        // `startNew()` did, which is how the first version of this test passed.
        Async::run(static function () use ($session): void {
            $session->startNew();
        });

        // A sleeping retry is not "streaming", so a guard on that alone leaves it running —
        // and what it is rescuing is a turn from the conversation just walked away from.
        $this->assertFalse($session->isRetrying());
    }

    public function testTheAgentCarriesTheSessionFilesIdAsItsSessionId(): void
    {
        // Upstream's agent is handed the session manager's id as `sessionId`, and every request
        // carries it: Anthropic's session affinity and the Responses API's `prompt_cache_key` key on
        // it. pig had no session id on a request at all. A switch of file switches it; a session
        // that is not written down has none.
        $store = SessionManager::create(sys_get_temp_dir());
        $other = SessionManager::create(sys_get_temp_dir());
        $session = $this->session([], store: $store);

        $this->assertSame($store->id, $session->agent->sessionId);

        $session->writeTo($other);
        $this->assertSame($other->id, $session->agent->sessionId);

        // Upstream's in-memory session has an id too, and the agent carries it.
        $session->writeTo(null);
        $this->assertNotNull($session->agent->sessionId);
        $this->assertSame($session->sessionId(), $session->agent->sessionId);
    }

    /** A saved conversation whose header names `$cwd`, as another project's would. */
    private static function conversationIn(string $cwd): SessionManager
    {
        $file = SessionManager::create($cwd);
        $file->append(new UserMessage('from another project'));
        $file->append(new AssistantMessage(
            [new TextContent('and its answer')],
            Api::AnthropicMessages,
            'anthropic',
            'test-model',
            new Usage(),
            StopReason::Stop,
        ));

        return $file;
    }

    public function testASessionFromAnotherDirectoryIsResumedThereThroughTheRuntimeFactory(): void
    {
        // Upstream's `switchSession()`: `createRuntime({ cwd: sessionManager.getCwd() })` — the
        // conversation carries on in its own project, in a runtime built for that directory.
        $elsewhere = sys_get_temp_dir() . '/pig-elsewhere-' . bin2hex(random_bytes(4));
        mkdir($elsewhere);
        $file = self::conversationIn($elsewhere);
        $session = $this->session([], store: SessionManager::create(sys_get_temp_dir()));
        $replacement = $this->session([]);
        $asked = null;

        $relocate = function (string $cwd, SessionManager $opened) use (&$asked, $replacement): StartedSession {
            $asked = [$cwd, $opened->path];
            $replacement->writeTo($opened);
            $replacement->restore($opened->messages());

            return new StartedSession(
                $replacement,
                $this->model(),
                ThinkingLevel::Off,
                [],
                [],
                [],
                new ExtensionRunner([], $cwd),
                new CustomToolSet(),
                $opened,
                [],
                true,
            );
        };
        $switch = Async::run(static fn (): SessionSwitch => $session->switchTo($file->path, relocate: $relocate));

        $this->assertSame([$elsewhere, $file->path], $asked);
        $this->assertTrue($switch->switched);
        $this->assertSame($replacement, $switch->replacement?->session);
        $this->assertSame(2, $switch->messages);

        // The same directory switches in place, as before: nothing is rebuilt.
        $here = self::conversationIn(sys_get_temp_dir());
        $inPlace = $this->session([], store: SessionManager::create(sys_get_temp_dir()));
        $same = Async::run(static fn (): SessionSwitch => $inPlace->switchTo($here->path, relocate: static fn () => throw new RuntimeException('not called')));
        $this->assertNull($same->replacement);
        $this->assertSame($here->path, $inPlace->store()?->path);

        unlink($file->path);
        unlink($here->path);
    }

    public function testASessionWhoseDirectoryHasGoneIsRefusedUntilACwdIsGiven(): void
    {
        // Upstream's `assertSessionCwdExists()` before anything is torn down, in its words; and
        // `cwdOverride`, the answer to "continue in current cwd".
        $gone = sys_get_temp_dir() . '/pig-gone-' . bin2hex(random_bytes(4));
        mkdir($gone);
        $file = self::conversationIn($gone);
        rmdir($gone);
        $store = SessionManager::create(sys_get_temp_dir());
        $session = $this->session([], store: $store);

        try {
            Async::run(static fn () => $session->switchTo($file->path));
            $this->fail('expected MissingSessionCwdError');
        } catch (MissingSessionCwdError $error) {
            $this->assertSame($gone, $error->issue->sessionCwd);
            $this->assertSame(sys_get_temp_dir(), $error->issue->fallbackCwd);
            $this->assertStringStartsWith("Stored session working directory does not exist: {$gone}\nSession file: {$file->path}", $error->getMessage());
            $this->assertSame($store, $session->store(), 'nothing was torn down');
        }

        $switch = Async::run(static fn (): SessionSwitch => $session->switchTo($file->path, sys_get_temp_dir()));
        $this->assertTrue($switch->switched);
        $this->assertSame(sys_get_temp_dir(), $session->store()?->cwd);
        $this->assertSame("cwd from session file does not exist\n{$gone}\n\ncontinue in current cwd\n/x", SessionCwd::prompt(new SessionCwdIssue($file->path, $gone, '/x')));

        unlink($file->path);
    }

    public function testSwitchingSessionStopsARetryThatWasStillWaiting(): void
    {
        $store = SessionManager::create(sys_get_temp_dir());
        $other = SessionManager::create(sys_get_temp_dir());
        $other->append(new UserMessage('something else entirely'));
        $other->append(new AssistantMessage(
            [new TextContent('and its answer')],
            Api::AnthropicMessages,
            'anthropic',
            'test-model',
            new Usage(),
            StopReason::Stop,
        ));

        $session = $this->session(
            [],
            streamFn: $this->flaky(array_fill(0, 4, ['error' => 'Anthropic returned 503: overloaded'])),
            store: $store,
            settings: self::quickRetries(['baseDelayMs' => 30_000]),
        );

        self::startTurnAndParkOnTheRetry($session);

        $this->assertTrue($session->isRetrying());

        Async::run(static function () use ($session, $other): void {
            $session->switchTo($other->path);
        });

        $this->assertFalse($session->isRetrying());
    }

    public function testARetryDoesNotCarryOnIntoTheSessionThatReplacedIt(): void
    {
        $session = $this->session(
            [],
            streamFn: $this->flaky(array_fill(0, 4, ['error' => 'Anthropic returned 503: overloaded'])),
            settings: self::quickRetries(['baseDelayMs' => 2]),
        );

        self::startTurnAndParkOnTheRetry($session);

        Async::run(static function () use ($session): void {
            $session->startNew();
        });

        // Everything after the switch belongs to the new conversation, so nothing the old
        // one's retry has to say may arrive here: left running, it wakes from its sleep and
        // asks the *emptied* agent to carry on, which comes back as "Retry failed: cannot
        // continue, no messages in context" in a conversation nobody has said anything in.
        $after = [];
        $session->subscribe(static function (AgentEvent $event) use (&$after): void {
            $after[] = $event::class;
        });
        self::settle();

        $this->assertSame([], $after);
        $this->assertSame([], $session->messages());
    }

    public function testATurnAbortedByANewSessionLeavesNothingBehindInIt(): void
    {
        // Upstream unsubscribes from the agent for the length of the abort in all three places
        // that throw a conversation away (`_disconnectFromAgent`), so none of the aborted
        // turn's events reach its session object at all. pig has no such shield, and this is
        // what says it does not need one: the events *are* delivered, and every one of them is
        // filed against the conversation being left, which is where the aborted half of a turn
        // belongs. If this ever goes red, the shield is the thing to port.
        $store = SessionManager::create(sys_get_temp_dir());
        $session = $this->session([], null, null, self::parksUntilAborted(), $store);

        $switched = false;
        $seen = [];
        $session->subscribe(static function (AgentEvent $event) use (&$seen, &$switched): void {
            $seen[] = ($switched ? 'after:' : 'before:') . $event::class;
        });

        Async::run(function () use ($session, &$switched): void {
            Async::spawn(static fn () => $session->prompt('hi'));

            // Long enough for the turn to be in flight and short enough that it still is.
            Async::delay(0.01);
            $this->assertTrue($session->isStreaming());

            $session->startNew();
            $switched = true;
        });
        self::settle();

        $after = array_values(array_filter($seen, static fn (string $s): bool => str_starts_with($s, 'after:')));

        // The other half of the claim, and what stops `$after` being empty for the trivial
        // reason: the events of the aborted turn were delivered, all of them before the reset.
        $this->assertContains('before:' . AgentEndEvent::class, $seen);

        // No second turn — the scripted provider would throw if it were asked again — and no
        // retry, no auto-compaction and no held-back command arriving in the new conversation.
        $this->assertSame([], $after);
        $this->assertSame([], $session->messages());
        $this->assertFalse($session->isRetrying());

        // And the half a turn that did happen is in the file it happened in, not in the new
        // one, which is the half upstream drops on the floor.
        $this->assertNotSame($store->path, $session->store()?->path);
        $this->assertNotSame([], $store->messages());

        // Nothing at all in the new one — not even a file, since nothing is written until the
        // first assistant message, and the new conversation has had none.
        $this->assertFileDoesNotExist((string) $session->store()?->path);
    }

    public function testAbortingWhenNothingIsBeingRetriedIsHarmless(): void
    {
        $session = $this->session(['hello']);

        $session->abortRetry();

        $this->assertFalse($session->isRetrying());
    }

    public function testNoRetriesInTheSettingsMeansNone(): void
    {
        // `settings.retry?.maxRetries ?? 3` takes 0 at its word: the first attempt is past the
        // budget, so nothing is announced and the failure stands.
        $session = $this->session(
            [],
            streamFn: $this->flaky([['error' => 'Anthropic returned 503: overloaded'], 'never sent']),
            settings: self::quickRetries(['maxRetries' => 0]),
        );

        $events = [];
        $session->subscribe(static function (AgentEvent $event) use (&$events): void {
            if ($event instanceof RetryStartEvent || $event instanceof RetryEndEvent) {
                $events[] = $event;
            }
        });

        Async::run(static fn () => $session->prompt('hi'));

        $this->assertSame([], $events);
        $last = $session->messages()[count($session->messages()) - 1];
        $this->assertInstanceOf(AssistantMessage::class, $last);
        $this->assertSame('Anthropic returned 503: overloaded', $last->errorMessage);
    }

    public function testARetryBudgetThatRunsOutReportsTheAttemptsThatWereMade(): void
    {
        // Upstream's `_prepareRetry()` does not count the attempt past the budget ("Preserve the
        // completed attempt count"), and the post-run step reports the failure with that count and
        // the last error.
        $session = $this->session(
            [],
            streamFn: $this->flaky(array_fill(0, 3, ['error' => 'Anthropic returned 503: overloaded'])),
            settings: self::quickRetries(['maxRetries' => 2]),
        );

        $starts = $ends = [];
        $session->subscribe(static function (AgentEvent $event) use (&$starts, &$ends): void {
            if ($event instanceof RetryStartEvent) {
                $starts[] = [$event->attempt, $event->maxAttempts, $event->delaySeconds];
            }

            if ($event instanceof RetryEndEvent) {
                $ends[] = [$event->succeeded, $event->attempts, $event->error];
            }
        });

        Async::run(static fn () => $session->prompt('hi'));

        $this->assertSame([[1, 2, 0.001], [2, 2, 0.002]], $starts);
        $this->assertSame([[false, 2, 'Anthropic returned 503: overloaded']], $ends);
    }

    public function testEveryRequestCarriesTheProviderRequestOptions(): void
    {
        // Upstream's `buildRequestOptions()`: `timeoutMs` from `retry.provider.timeoutMs`, else
        // `httpIdleTimeoutMs` (300 s; `disabled` is 2147483647), `maxRetries` and
        // `maxRetryDelayMs` from `retry.provider`, and the agent's provider hooks on every request.
        $captured = [];
        $capture = function (Model $model, TranscriptContext $context, SimpleStreamOptions $options) use (&$captured): AssistantMessageEventStream {
            $captured[] = $options;

            return $this->replay('ok');
        };

        $session = $this->session([], streamFn: $capture, settings: Settings::inMemory());
        Async::run(static fn () => $session->prompt('hi'));

        $this->assertSame(300_000, $captured[0]->timeoutMs);
        $this->assertNull($captured[0]->maxRetries);
        $this->assertSame(60_000, $captured[0]->maxRetryDelayMs);
        $this->assertNotNull($captured[0]->onPayload);
        $this->assertNotNull($captured[0]->onResponse);
        $this->assertNotNull($captured[0]->onProviderStreamEvent);

        $session = $this->session([], streamFn: $capture, settings: Settings::inMemory([
            'httpIdleTimeoutMs' => 'disabled',
            'retry' => ['provider' => ['maxRetries' => 2, 'maxRetryDelayMs' => 5000]],
        ]));
        Async::run(static fn () => $session->prompt('hi'));

        $this->assertSame(2_147_483_647, $captured[1]->timeoutMs);
        $this->assertSame(2, $captured[1]->maxRetries);
        $this->assertSame(5000, $captured[1]->maxRetryDelayMs);

        $session = $this->session([], streamFn: $capture, settings: Settings::inMemory([
            'retry' => ['provider' => ['timeoutMs' => 1234]],
        ]));
        Async::run(static fn () => $session->prompt('hi'));

        $this->assertSame(1234, $captured[2]->timeoutMs);
        $this->assertSame('auto', $captured[2]->transport);
        $this->assertNull($captured[2]->websocketConnectTimeoutMs);

        $session = $this->session([], streamFn: $capture, settings: Settings::inMemory([
            'transport' => 'sse',
            'websocketConnectTimeoutMs' => 2500,
        ]));
        Async::run(static fn () => $session->prompt('hi'));

        $this->assertSame('sse', $captured[3]->transport);
        $this->assertSame(2500, $captured[3]->websocketConnectTimeoutMs);
    }

    // ---- the overflow half --------------------------------------------------------------

    public function testAPromptTooLongIsSummarisedAndSentAgainRatherThanRetried(): void
    {
        $session = $this->session(
            [],
            streamFn: $this->flaky([
                'first answer',
                'second answer',
                ['error' => 'prompt is too long: 213462 tokens > 200000 maximum'],
                'the summary',
                'answered after summarising',
            ]),
            // A cut has to be legal *and* worth making: `cutPoint()` works in tokens, and
            // four short messages are nowhere near the default budget, so nothing would be
            // cut and the summary would refuse as "too small".
            settings: self::quickRetries(['keepRecentTokens' => 1]),
        );

        $seen = [];
        $session->subscribe(static function (AgentEvent $event) use (&$seen): void {
            $seen[] = $event;
        });

        Async::run(static function () use ($session): void {
            $session->prompt('one');
            $session->prompt('two');
            $session->prompt('three');
        });
        self::settle();

        $starts = array_values(array_filter($seen, static fn ($e) => $e instanceof CompactionStartEvent));
        $ends = array_values(array_filter($seen, static fn ($e) => $e instanceof CompactionEndEvent));

        $this->assertCount(1, $starts);
        $this->assertSame('overflow', $starts[0]->reason);

        $this->assertCount(1, $ends);
        $this->assertSame('overflow', $ends[0]->reason);
        $this->assertNotNull($ends[0]->result);
        $this->assertFalse($ends[0]->aborted);
        $this->assertTrue($ends[0]->willRetry, 'the summary is the fix, so the turn goes again');
        $this->assertInstanceOf(CompactionSummary::class, $ends[0]->summary);
        $this->assertSame($ends[0]->summary->summary, $ends[0]->result->summary);
        $this->assertIsInt($ends[0]->result->estimatedTokensAfter);

        // Not retried: the request was too big, and it would be exactly as big in four
        // seconds. Nothing waited.
        $this->assertNotContains(
            RetryStartEvent::class,
            array_map(static fn ($e) => $e::class, $seen),
        );

        $messages = $session->messages();
        $this->assertSame('answered after summarising', self::textOf($messages[count($messages) - 1]));
    }

    public function testAnOverflowSummaryTellsTheHooksTheTurnGoesAgain(): void
    {
        // Upstream's `session_before_compact` and `session_compact` for overflow recovery:
        // `reason: overflow`, `willRetry: true`.
        $seen = [];
        $record = static function (object $event) use (&$seen): void {
            $seen[] = $event;
        };
        $session = $this->session(
            [],
            streamFn: $this->flaky([
                'first answer',
                'second answer',
                ['error' => 'prompt is too long: 213462 tokens > 200000 maximum'],
                'the summary',
                'answered after summarising',
            ]),
            settings: self::quickRetries(['keepRecentTokens' => 1]),
            extensionRunner: $this->extensionRunner(['session_before_compact' => $record, 'session_compact' => $record]),
        );

        Async::run(static function () use ($session): void {
            $session->prompt('one');
            $session->prompt('two');
            $session->prompt('three');
        });
        self::settle();

        $this->assertCount(2, $seen);
        $this->assertInstanceOf(SessionBeforeCompactEvent::class, $seen[0]);
        $this->assertSame('overflow', $seen[0]->reason);
        $this->assertTrue($seen[0]->willRetry);
        $this->assertNull($seen[0]->customInstructions);
        $this->assertInstanceOf(SessionCompactEvent::class, $seen[1]);
        $this->assertSame('overflow', $seen[1]->reason);
        $this->assertTrue($seen[1]->willRetry);
        $this->assertFalse($seen[1]->fromExtension);
    }

    /**
     * Upstream's #11227: recovering from a response cut off at the output limit omitted the
     * truncated tool call but kept the result that answered it, and every later request was
     * rejected for a result with no call. Here the session was resumed with the attempt and its
     * result as the last two messages, which is the pre-prompt path.
     */
    public function testRecoveringFromAResumedLengthStopOmitsTheTruncatedCallAndItsResult(): void
    {
        $dir = sys_get_temp_dir() . '/pig-11227-' . bin2hex(random_bytes(3));
        $store = SessionManager::create($dir);
        $now = (int) (microtime(true) * 1000);
        $truncated = new AssistantMessage(
            [new ToolCall('call_truncated', 'bash', ['command' => 'echo'])],
            Api::AnthropicMessages,
            'anthropic',
            'test-model',
            new Usage(input: 100, output: 16, totalTokens: 116),
            StopReason::Length,
            timestamp: $now - 500,
        );

        foreach ([
            new UserMessage('check status', timestamp: $now - 1000),
            $truncated,
            new ToolResultMessage('call_truncated', 'bash', [new TextContent('Not executed: output token limit reached.')], true, timestamp: $now - 400),
        ] as $message) {
            $store->append($message);
        }

        $requests = [];
        $session = $this->session(
            [],
            streamFn: function (Model $model, TranscriptContext $context) use (&$requests): AssistantMessageEventStream {
                $requests[] = $context->messages;

                return $this->replay('done');
            },
            store: $store,
            extensionRunner: $this->extensionRunner(['session_before_compact' => static fn (SessionBeforeCompactEvent $event) => new SessionBeforeCompactResult(
                compaction: new \Pig\CodingAgent\Session\CompactionResult('summary', $event->preparation->firstKeptEntryId, $event->preparation->tokensBefore),
            )]),
        );
        $session->restore($store->messages());

        Async::run(static fn () => $session->prompt('continue'));
        self::settle();

        $reopened = SessionManager::open($store->path)->messages();
        unlink($store->path);

        $this->assertCount(1, $requests);
        $this->assertSame([], array_values(array_filter($requests[0], static fn (mixed $m): bool => $m instanceof ToolResultMessage)), 'no result without its call');
        $this->assertSame([], array_values(array_filter($requests[0], static fn (mixed $m): bool => $m instanceof AssistantMessage && $m->stopReason === StopReason::Length)));
        $this->assertSame([], array_values(array_filter($reopened, static fn (mixed $m): bool => $m instanceof ToolResultMessage)), 'and a resume does not bring it back');
    }

    public function testAFailedCompactionIsReportedInUpstreamsWords(): void
    {
        $failed = [];
        $session = $this->session([], settings: self::quickRetries(['keepRecentTokens' => 1]), extensionRunner: $this->extensionRunner([
            'session_before_compact' => static fn () => new SessionBeforeCompactResult(cancel: true),
            'session_compact_failed' => static function (SessionCompactFailedEvent $event) use (&$failed): void {
                $failed[] = $event;
            },
        ]));
        $session->agent->appendMessage(new UserMessage(str_repeat('x', 400)));
        $session->agent->appendMessage(new UserMessage(str_repeat('y', 400)));

        $this->assertThrows(AgentError::class, static fn () => Async::run(static fn () => $session->compact()), 'Compaction cancelled');

        // A hook's cancel is an abort, not an error.
        $this->assertCount(1, $failed);
        $this->assertSame('manual', $failed[0]->reason);
        $this->assertTrue($failed[0]->aborted);
        $this->assertNull($failed[0]->errorMessage);
        $this->assertFalse($failed[0]->willRetry);
        $this->assertFalse($failed[0]->fromExtension);
    }

    public function testEscapeReachesASummarisationNobodyAskedFor(): void
    {
        // The screen says "esc to cancel" while this runs, and for the *auto* compaction there was
        // nothing behind the label: `compactAndCarryOn()` called `compact()` with no signal at all,
        // so the summariser's own turn — a whole conversation, at high reasoning — could not be
        // stopped. Which is the failure `Retry`'s abortable sleep exists to prevent, one method
        // over: a wait that escape cannot reach looks exactly like a hang.
        $session = $this->overflowingIntoASummariserThatParks();

        $starts = $ends = [];
        $session->subscribe(static function (AgentEvent $event) use (&$starts, &$ends): void {
            if ($event instanceof CompactionStartEvent) {
                $starts[] = $event;
            }

            if ($event instanceof CompactionEndEvent) {
                $ends[] = $event;
            }
        });

        self::runUntilTheSummariserIsGoing($session);

        $this->assertCount(1, $starts);
        $this->assertTrue($session->isCompacting());

        // And not a retry: the waiting handle `prompt()` parks on is pending for both, so keying
        // this off it would have the session claiming to retry every time it summarises.
        $this->assertFalse($session->isRetrying());

        $session->abortCompaction();

        for ($tick = 0; $tick < 200 && $ends === []; $tick++) {
            self::tickWithoutWaiting();
        }

        // Escape is somebody deciding, not a failure: `aborted`, and no error message.
        $this->assertCount(1, $ends);
        $this->assertNull($ends[0]->result);
        $this->assertTrue($ends[0]->aborted);
        $this->assertNull($ends[0]->errorMessage);
        $this->assertFalse($session->isCompacting());
    }

    public function testStoppingTheRunStopsASummarisationWithIt(): void
    {
        // One call reaches all three things escape has to stop — the run, a sleeping retry and a
        // summarisation — so a caller cannot reach two of them and believe it has finished.
        $session = $this->overflowingIntoASummariserThatParks();

        $ends = $retries = [];
        $session->subscribe(static function (AgentEvent $event) use (&$ends, &$retries): void {
            if ($event instanceof CompactionEndEvent) {
                $ends[] = $event;
            }

            if ($event instanceof RetryEndEvent) {
                $retries[] = $event;
            }
        });

        self::runUntilTheSummariserIsGoing($session);

        Async::run(static function () use ($session): void {
            $session->abort()->await();
        });

        for ($tick = 0; $tick < 200 && $ends === []; $tick++) {
            self::tickWithoutWaiting();
        }

        $this->assertCount(1, $ends);
        $this->assertNull($ends[0]->result);

        // `abort()` calls `abortRetry()` first, and there is no retry here — so it has to say
        // nothing rather than announce one ending. Its guard is the controller for that reason.
        $this->assertSame([], $retries);
    }

    public function testATypedCompactionCanBeStoppedFromEitherEnd(): void
    {
        // `/compact` brings a signal of its own, and `abortCompaction()` has to reach that
        // summariser too — otherwise there are two facts about one summarisation and only the
        // caller holds the one that works. The forwarding in `compact()` is what makes it one.
        foreach (['the caller', 'the session'] as $who) {
            $session = $this->session(
                [],
                null,
                null,
                self::parksUntilAborted(),
                settings: self::quickRetries(['keepRecentTokens' => 1]),
            );

            foreach (range(1, 6) as $ignored) {
                $session->agent->appendMessage(new UserMessage(str_repeat('x', 40_000)));
            }

            $mine = new AbortController();
            $answer = 'not yet';

            Async::run(static function () use ($session, $mine, &$answer): void {
                Async::spawn(static function () use ($session, $mine, &$answer): void {
                    $answer = $session->compact(null, $mine->signal);
                });
            });

            for ($tick = 0; $tick < 200 && !$session->isCompacting(); $tick++) {
                self::tickWithoutWaiting();
            }

            $this->assertTrue($session->isCompacting(), $who);

            if ($who === 'the caller') {
                $mine->abort('Cancelled');
            } else {
                $session->abortCompaction();
            }

            for ($tick = 0; $tick < 200 && $session->isCompacting(); $tick++) {
                self::tickWithoutWaiting();
            }

            $this->assertNull($answer, "stopped by {$who}");
            $this->assertFalse($session->isCompacting(), $who);
        }
    }

    /**
     * Two answered turns, a third that overflows, and a summariser that never finishes.
     *
     * Two real turns first because a compaction has to be *worth making*: `cutPoint()` works in
     * tokens, and a conversation of one failed message is refused as "too small" before the
     * summariser is ever reached — which is how the first version of these two tests came back
     * green about something that had not happened.
     */
    private function overflowingIntoASummariserThatParks(): AgentSession
    {
        $at = 0;

        return $this->session(
            [],
            streamFn: function (
                Model $model,
                TranscriptContext $context,
                SimpleStreamOptions $options,
            ) use (&$at): AssistantMessageEventStream {
                $at++;

                return match (true) {
                    $at === 1 => $this->replay('first answer'),
                    $at === 2 => $this->replay('second answer'),
                    $at === 3 => $this->fails('prompt is too long: 213462 tokens > 200000 maximum'),
                    default => (self::parksUntilAborted())($model, $context, $options),
                };
            },
            settings: self::quickRetries(['keepRecentTokens' => 1]),
        );
    }

    /** Three turns, spawned, and the loop turned until the summariser is actually running. */
    private static function runUntilTheSummariserIsGoing(AgentSession $session): void
    {
        Async::run(static function () use ($session): void {
            Async::spawn(static function () use ($session): void {
                $session->prompt('one');
                $session->prompt('two');
                $session->prompt('three');
            });
        });

        // `isCompacting()` and not the start event: that is announced before `compact()` is
        // called, so it says the overflow was noticed rather than that a summariser exists.
        for ($tick = 0; $tick < 400 && !$session->isCompacting(); $tick++) {
            self::tickWithoutWaiting();
        }
    }

    public function testAnOverflowWithNothingToCompactAnnouncesNoCompaction(): void
    {
        // Upstream's `_runAutoCompaction()`: `prepareCompaction()` first, and with nothing to cut
        // no `compaction_start`, no `compaction_end` — and no second request. What says what
        // happened is the turn's own error, which every mode has already shown.
        $session = $this->session(
            [],
            streamFn: $this->flaky([
                ['error' => 'prompt is too long: 213462 tokens > 200000 maximum'],
            ]),
            settings: self::quickRetries(),
        );

        $compactions = [];
        $errors = [];
        $session->subscribe(static function (AgentEvent $event) use (&$compactions, &$errors): void {
            if ($event instanceof CompactionStartEvent || $event instanceof CompactionEndEvent) {
                $compactions[] = $event;
            }

            if ($event instanceof MessageEndEvent && $event->message instanceof AssistantMessage && $event->message->stopReason === StopReason::Error) {
                $errors[] = $event->message->errorMessage;
            }
        });

        Async::run(static function () use ($session): void {
            $session->prompt('hi');
        });
        self::settle();

        $this->assertSame([], $compactions);
        $this->assertSame(['prompt is too long: 213462 tokens > 200000 maximum'], $errors);
    }

    public function testAnOverflowAfterTheRetryEndsItInUpstreamsWords(): void
    {
        // Upstream's `_overflowRecoveryAttempted`: one compact-and-retry per overflow. The retry
        // overflowing as well is a `compaction_end` with the error, not a second summary.
        $turns = $this->flaky([
            'first answer',
            'second answer',
            ['error' => 'prompt is too long: 213462 tokens > 200000 maximum'],
            'the summary',
            ['error' => 'prompt is too long: 205000 tokens > 200000 maximum'],
        ]);
        $session = $this->session(
            [],
            // A millisecond apart, so the retry's failure is newer than the summary it follows —
            // an answer from before the latest compaction is not looked at again.
            streamFn: static function (mixed ...$arguments) use ($turns): AssistantMessageEventStream {
                usleep(2000);

                return $turns(...$arguments);
            },
            settings: self::quickRetries(['keepRecentTokens' => 1]),
        );

        $seen = [];
        $session->subscribe(static function (AgentEvent $event) use (&$seen): void {
            if ($event instanceof CompactionStartEvent || $event instanceof CompactionEndEvent) {
                $seen[] = $event;
            }
        });

        Async::run(static function () use ($session): void {
            $session->prompt('one');
            $session->prompt('two');
            $session->prompt('three');
        });
        self::settle();

        $this->assertCount(3, $seen, 'one start and end for the summary, one end for the refusal');
        $this->assertInstanceOf(CompactionStartEvent::class, $seen[0]);
        $this->assertNotNull($seen[1]->result);
        $this->assertInstanceOf(CompactionEndEvent::class, $seen[2]);
        $this->assertNull($seen[2]->result);
        $this->assertFalse($seen[2]->willRetry);
        $this->assertSame(
            'Context overflow recovery failed after one compact-and-retry attempt. Try reducing context or switching to a larger-context model.',
            $seen[2]->errorMessage,
        );
    }

    public function testASystemPromptPastTheWindowIsSaidPlainlyInsteadOfCompacted(): void
    {
        // A project whose context files outgrew a smaller model: the prompt alone is past the
        // window, so a summary has nothing to make room in. Said once per overflow, with the way
        // out, and the provider is not asked for a summary that could not help.
        $calls = 0;
        $turns = $this->flaky([
            ['error' => 'prompt is too long: 2100 tokens > 1000 maximum'],
            ['error' => 'prompt is too long: 2110 tokens > 1000 maximum'],
        ]);
        $session = $this->session(
            [],
            model: new Model('test-model', 'Small', Api::AnthropicMessages, 'anthropic', 'http://127.0.0.1:1', 1_000, 100),
            streamFn: static function (mixed ...$arguments) use ($turns, &$calls): AssistantMessageEventStream {
                $calls++;
                usleep(2000);

                return $turns(...$arguments);
            },
            settings: self::quickRetries(),
        );
        $this->current->state->messages = [new \Pig\Ai\SystemMessage(str_repeat('x', 8_000))];

        $seen = [];
        $session->subscribe(static function (AgentEvent $event) use (&$seen): void {
            if ($event instanceof CompactionStartEvent || $event instanceof CompactionEndEvent) {
                $seen[] = $event;
            }
        });

        Async::run(static function () use ($session): void {
            $session->prompt('one');
            $session->prompt('two');
        });
        self::settle();

        $this->assertSame(2, $calls, 'one request per prompt, and no summary');
        $this->assertCount(2, $seen, 'one refusal per overflow, not one more for the prompt sent after it');

        foreach ($seen as $event) {
            $this->assertInstanceOf(CompactionEndEvent::class, $event);
            $this->assertNull($event->result);
            $this->assertFalse($event->willRetry);
            $this->assertSame(
                'The system prompt alone is about 2,000 tokens, more than the 1,000-token context window of test-model, so compacting the conversation cannot make room. Start pig with --no-context-files (-nc) to leave the project\'s context files out, or make them shorter.',
                $event->errorMessage,
            );
        }
    }

    public function testSwitchingModelIsWrittenDown(): void
    {
        $store = SessionManager::create(sys_get_temp_dir());
        $session = $this->session(['hello'], store: $store);

        Async::run(static fn () => $session->prompt('hi'));
        $session->setModel(new Model('other-model', 'Other', Api::AnthropicMessages, 'openai', 'http://127.0.0.1:1', 1_000, 100));

        $this->assertSame('other-model', SessionManager::open($store->path)->settings()['model']?->modelId);
        $this->assertSame('openai', SessionManager::open($store->path)->settings()['model']?->provider);
    }

    public function testSettingTheSameModelAgainWritesNothing(): void
    {
        $store = SessionManager::create(sys_get_temp_dir());
        $session = $this->session(['hello'], store: $store);

        Async::run(static fn () => $session->prompt('hi'));
        $before = substr_count((string) file_get_contents($store->path), "\n");

        $session->setModel($this->model());
        $session->setModel($this->model());

        // `setModel()` is also how the thinking level gets clamped, so a line per call would
        // be a file full of a model changing to itself.
        $this->assertSame($before, substr_count((string) file_get_contents($store->path), "\n"));
    }

    public function testResumingComesBackToTheModelTheConversationWasOn(): void
    {
        $store = SessionManager::create(sys_get_temp_dir());
        $first = $this->session(['hello'], store: $store);

        Async::run(static fn () => $first->prompt('hi'));

        // A real model from the registry, not an invented one: restoring means looking the
        // recorded provider and id back up, and a made-up id is not in there to find. Which
        // is itself a thing to know — see the test below about a model this machine lacks.
        $recorded = Models::find('anthropic', 'claude-haiku-4-5');
        self::assertNotNull($recorded);

        $first->setModel($recorded);
        $first->setThinkingLevel(ThinkingLevel::High);

        // A second session, as `--continue` builds one: the default model, then the file.
        $reopened = SessionManager::open($store->path);
        $second = $this->session([], store: $reopened);
        $second->restore($reopened->messages());
        $second->restoreSettings();

        // The whole point of "carry on where I left off": before this, an afternoon on one
        // model came back on whatever the settings said.
        $this->assertSame('claude-haiku-4-5', $second->model()?->id);
        $this->assertSame(ThinkingLevel::High, $second->thinkingLevel());
    }

    public function testAModelNamedOnTheCommandLineBeatsTheFile(): void
    {
        $store = SessionManager::create(sys_get_temp_dir());
        $first = $this->session(['hello'], store: $store);

        Async::run(static fn () => $first->prompt('hi'));

        $recorded = Models::find('anthropic', 'claude-haiku-4-5');
        self::assertNotNull($recorded);
        $first->setModel($recorded);

        $reopened = SessionManager::open($store->path);
        $second = $this->session([], store: $reopened);
        $second->restore($reopened->messages());
        $second->restoreSettings(modelWasAskedFor: true);

        // `--model` is someone saying what they want now; the file says what was true last
        // time. The thinking level still comes from the file — nothing overrode that.
        $this->assertSame('test-model', $second->model()?->id);
    }

    public function testALevelTheRestoredModelCannotDoIsClampedRatherThanSent(): void
    {
        $store = SessionManager::create(sys_get_temp_dir());
        $first = $this->session(['hello'], store: $store, model: $this->thinkingModel());

        Async::run(static fn () => $first->prompt('hi'));
        $first->setThinkingLevel(ThinkingLevel::High);
        $first->setModel($this->model());

        $reopened = SessionManager::open($store->path);
        $second = $this->session([], store: $reopened, model: $this->model());
        $second->restore($reopened->messages());
        $second->restoreSettings();

        // `test-model` cannot reason. Asking it to think hard is a request the provider
        // rejects, and the person resuming did not ask for it — the file did.
        $this->assertSame(ThinkingLevel::Off, $second->thinkingLevel());
    }

    public function testAFileNamingAModelThisMachineDoesNotHaveStillOpens(): void
    {
        $store = SessionManager::create(sys_get_temp_dir());
        $session = $this->session(['hello'], store: $store);

        Async::run(static fn () => $session->prompt('hi'));
        $store->appendModelChange('some-vendor', 'a-model-nobody-here-has');

        $reopened = SessionManager::open($store->path);
        $second = $this->session([], store: $reopened);
        $second->restore($reopened->messages());
        $second->restoreSettings();

        // Not a reason to refuse to open the conversation: it falls back to what it had,
        // and the footer says which model is answering.
        $this->assertSame('test-model', $second->model()?->id);
        $this->assertCount(2, $second->messages());
    }

    // ---- which model -------------------------------------------------------------------

    public function testAModelWithNoKeyIsRefusedAndNotWrittenDown(): void
    {
        $store = SessionManager::create(sys_get_temp_dir());
        $session = $this->session(['hello'], store: $store, getApiKey: static fn (string $provider): ?string
            => $provider === 'anthropic' ? 'a-key' : null);

        Async::run(static fn () => $session->prompt('hi'));
        $before = (string) file_get_contents($store->path);

        $openai = new Model('other-model', 'Other', Api::AnthropicMessages, 'openai', 'http://127.0.0.1:1', 1_000, 100);
        $error = $this->assertThrows(AgentError::class, static fn () => $session->setModel($openai));

        // Upstream's message, and upstream's order: the key is checked before anything is applied.
        // It used to switch, write a `model_change` into the file, and fail on the next turn from
        // inside `Stream` — where a conversation recorded as being on a model nobody can talk to
        // is left in the file for `--continue` to find.
        $this->assertStringContainsString('No API key for openai/other-model', $error->getMessage());
        $this->assertSame('test-model', $session->model()?->id);
        $this->assertSame($before, (string) file_get_contents($store->path), 'and the file says nothing about it');
    }

    public function testAModelWithAKeyIsSetAsBefore(): void
    {
        $session = $this->session([], getApiKey: static fn (string $provider): ?string
            => $provider === 'anthropic' ? 'a-key' : null);

        $session->setModel($this->thinkingModel());

        // The other half, so the test above cannot pass by `setModel()` refusing everything.
        $this->assertSame('test-thinker', $session->model()?->id);
    }

    // ---- going back ---------------------------------------------------------------------

    /** @return array{0: AgentSession, 1: SessionManager, 2: list<array{id: string, message: mixed, branches: int, label: string|null}>} */
    private function twoExchanges(): array
    {
        $store = SessionManager::create(sys_get_temp_dir());
        $session = $this->session(['first answer', 'second answer'], store: $store);

        Async::run(static fn () => $session->prompt('the first question'));
        Async::run(static fn () => $session->prompt('the second question'));

        return [$session, $store, $store->branch()];
    }

    public function testGoingBackToSomethingYouSaidTakesItBackAndHandsItToTheEditor(): void
    {
        [$session, $store, $points] = $this->twoExchanges();

        $jump = Async::run(static fn () => $session->goTo($points[2]['id']));

        // The whole point of going back to a question: it leaves the conversation and comes back
        // in the prompt to be asked differently. pig used to land the leaf *on* the message, so
        // the old wording stayed and re-asking meant retyping it.
        $this->assertTrue($jump->moved);
        $this->assertSame('the second question', $jump->editorText);
        $this->assertCount(2, $session->messages(), 'back to the first exchange, question included');
        $this->assertCount(2, $store->branch());
    }

    public function testGoingBackToAnAnswerKeepsIt(): void
    {
        [$session, , $points] = $this->twoExchanges();

        $jump = Async::run(static fn () => $session->goTo($points[1]['id']));

        // The other half, so the case above cannot pass by every jump moving to a parent: an
        // answer is a place to carry on from, not something to take back.
        $this->assertTrue($jump->moved);
        $this->assertNull($jump->editorText);
        $this->assertCount(2, $session->messages());
    }

    public function testGoingBackToTheFirstThingSaidLeavesAnEmptyConversation(): void
    {
        [$session, , $points] = $this->twoExchanges();

        $jump = Async::run(static fn () => $session->goTo($points[0]['id']));

        // A root's parent is the root's own id in the file; the point before a root is nothing.
        $this->assertSame([], $session->messages());
        $this->assertSame('the first question', $jump->editorText);
    }

    public function testGoingToWhereYouAlreadyAreIsNotACancellation(): void
    {
        [$session, $store, ] = $this->twoExchanges();

        $jump = Async::run(static fn () => $session->goTo($store->leaf()));

        // `moved: false, aborted: false` — the fourth answer. Read as a cancellation it would say
        // "branch summary cancelled" to somebody who asked for no summary.
        $this->assertFalse($jump->moved);
        $this->assertFalse($jump->aborted);
        $this->assertCount(4, $session->messages());
    }

    public function testASummaryAskedForWithNoModelIsRefusedRatherThanSkipped(): void
    {
        $store = SessionManager::create(sys_get_temp_dir());
        $store->append(new UserMessage('a question'));
        $store->append(new AssistantMessage(
            [new TextContent('an answer')],
            Api::AnthropicMessages,
            'anthropic',
            'test-model',
            new Usage(),
            StopReason::Stop,
        ));

        $agent = new Agent(new AgentOptions(streamFn: $this->provider([], null), apiKey: 'test-key'));
        // See `testPromptingWithNoModelSaysSo`: a state fills in a default, so "no model" is a
        // model that was lost rather than one never chosen.
        $agent->state->model = null;
        $session = new AgentSession($agent, sys_get_temp_dir(), $store);
        $session->restore($store->messages());

        $error = $this->assertThrows(
            AgentError::class,
            static fn () => $session->goTo($store->branch()[0]['id'], summarise: true),
        );

        // It used to move and quietly write no summary: somebody who asked for the branch to be
        // written down and got the move without it has lost the branch.
        $this->assertStringContainsString('No model', $error->getMessage());
        $this->assertCount(2, $session->messages(), 'and it did not move');
    }

    // ---- leaving this conversation ------------------------------------------------------

    public function testANewSessionIsANewFileAndTheOldOneStopsWhereItStopped(): void
    {
        $store = SessionManager::create(sys_get_temp_dir());
        $session = $this->session(['hello', 'hello again'], store: $store);

        Async::run(static fn () => $session->prompt('the first conversation'));
        $first = $store->path;
        $lines = substr_count((string) file_get_contents($first), "\n");

        $switch = $session->startNew();

        $this->assertTrue($switch->switched);
        $this->assertSame($first, $switch->previous);
        $this->assertNotSame($first, $session->store()?->path);
        $this->assertSame([], $session->messages());

        Async::run(static fn () => $session->prompt('and the second'));

        // The two halves of the bug `writeTo()` was added for, asserted from the one place
        // that now decides it: the old file did not grow, and the new one is not a
        // continuation of it.
        $this->assertSame($lines, substr_count((string) file_get_contents($first), "\n"));

        $written = (string) file_get_contents((string) $session->store()?->path);
        $this->assertStringContainsString('and the second', $written);
        $this->assertStringNotContainsString('the first conversation', $written);
    }

    public function testANewSessionOnOneThatIsNotBeingSavedStartsNoFile(): void
    {
        $session = $this->session(['hello']);

        Async::run(static fn () => $session->prompt('hi'));
        $switch = $session->startNew();

        // `--no-session` means no file, and `/new` is not a reason to start keeping one.
        $this->assertTrue($switch->switched);
        $this->assertNull($switch->previous);
        $this->assertNull($session->store());
        $this->assertSame([], $session->messages());
    }

    public function testLeavingAConversationLeavesWhatWasTypedIntoIt(): void
    {
        $session = $this->session([], store: SessionManager::create(sys_get_temp_dir()));
        $session->followUp('meant for the conversation being thrown away');

        $session->startNew();

        // Sending it into the next conversation is the same crossing as writing to the
        // wrong file, and neither mode remembered to stop it.
        $this->assertSame([], $session->queued());
    }

    public function testSwitchingCarriesOnInTheFileThatWasOpened(): void
    {
        $mine = SessionManager::create(sys_get_temp_dir());
        $session = $this->session(['hello', 'hello again'], store: $mine);
        Async::run(static fn () => $session->prompt('the conversation I am in'));

        $other = $this->session(['hi there'], store: SessionManager::create(sys_get_temp_dir()));
        Async::run(static fn () => $other->prompt('the conversation I am switching to'));
        $elsewhere = (string) $other->store()?->path;

        $switch = $session->switchTo($elsewhere);

        $this->assertTrue($switch->switched);
        $this->assertSame($mine->path, $switch->previous);
        $this->assertSame(2, $switch->messages);
        $this->assertSame($elsewhere, $session->store()?->path);
        $this->assertCount(2, $session->messages());

        Async::run(static fn () => $session->prompt('carrying on'));

        // What is on screen and what is being written are the same conversation — before
        // `writeTo()` they were two files, neither of them what happened.
        $this->assertStringContainsString('carrying on', (string) file_get_contents($elsewhere));
        $this->assertStringNotContainsString('carrying on', (string) file_get_contents($mine->path));
    }

    public function testWhatWasTypedWithAnExclamationMarkIsInTheFileToo(): void
    {
        $store = SessionManager::create(sys_get_temp_dir());
        $session = $this->session(['hello'], store: $store);

        // The file has to exist before a `!command` can be written to it, which is what the
        // first turn is for: nothing is written until something has been answered.
        Async::run(static fn () => $session->prompt('hi'));
        Async::run(static fn () => $session->executeBash('echo from-the-shell'));

        // Appended directly rather than through a turn, so there is no `message_end` to carry
        // it to the file — and a conversation that reopens without what was run in it is a
        // conversation missing the half that explains the rest.
        $this->assertStringContainsString('from-the-shell', (string) file_get_contents($store->path));
    }

    public function testACommandRunDuringATurnReachesTheFileWhenTheTurnEnds(): void
    {
        $store = SessionManager::create(sys_get_temp_dir());
        $session = $this->session(['hello', 'hello again'], store: $store);
        Async::run(static fn () => $session->prompt('hi'));

        $ran = null;
        $session->subscribe(static function (AgentEvent $event) use ($session, &$ran): void {
            if ($event instanceof MessageStartEvent && $ran === null) {
                // Held back, because a message between a tool call and its result is a request
                // every provider rejects. Held back and then dropped is the failure.
                $ran = Async::run(static fn () => $session->executeBash('echo held-back'));
            }
        });

        Async::run(static fn () => $session->prompt('and again'));

        $this->assertStringContainsString('held-back', (string) file_get_contents($store->path));
    }

    // ---- leaving a conversation, which is a recipe and not a line ---------------------------

    public function testAHookCanRefuseToLeaveAConversationEitherWay(): void
    {
        // The cancellable hook is the whole reason `startNew()` and `switchTo()` are one method
        // each rather than a few lines in every mode: a hook that refuses worked in the terminal
        // and was ignored over RPC until the recipe moved in here. Both doors, because a guard
        // on one of two is the shape that got it wrong the first time.
        $asked = [];
        $extensionRunner = $this->extensionRunner([
            'session_before_switch' => function (mixed $event) use (&$asked): SessionBeforeSwitchResult {
                $asked[] = $event->reason;

                return new SessionBeforeSwitchResult(cancel: true);
            },
        ]);

        $store = SessionManager::create(sys_get_temp_dir());
        $session = $this->session(['hello'], store: $store, extensionRunner: $extensionRunner);
        Async::run(static fn () => $session->prompt('the conversation I am in'));

        $new = $session->startNew();

        $this->assertFalse($new->switched);
        $this->assertSame($store->path, $session->store()?->path, 'still writing where it was');
        $this->assertCount(2, $session->messages(), 'and still holding what was said');

        $other = $this->session(['hi'], store: SessionManager::create(sys_get_temp_dir()));
        Async::run(static fn () => $other->prompt('somewhere else'));

        $switch = $session->switchTo((string) $other->store()?->path);

        $this->assertFalse($switch->switched);
        $this->assertSame($store->path, $session->store()?->path);
        $this->assertSame(['new', 'resume'], $asked, 'and each was told which it was');
    }

    public function testWhatWasQueuedForTheOldConversationDoesNotCrossOver(): void
    {
        $session = $this->session(['hello'], store: SessionManager::create(sys_get_temp_dir()));
        Async::run(static fn () => $session->prompt('the conversation I am in'));
        $session->followUp('and one more thing');

        $this->assertSame(['and one more thing'], $session->queued());

        $session->startNew();

        // It was typed into the conversation being thrown away. Sending it into its replacement
        // is the same crossing as appending to the wrong file.
        $this->assertSame([], $session->queued());

        // And the other door, which had its own copy of the recipe until these became one
        // method each — a guard on one of two is how the first version of this went wrong.
        $other = $this->session(['hi'], store: SessionManager::create(sys_get_temp_dir()));
        Async::run(static fn () => $other->prompt('somewhere else'));

        Async::run(static fn () => $session->prompt('a fresh start'));
        $session->followUp('queued here');

        $session->switchTo((string) $other->store()?->path);

        $this->assertSame([], $session->queued());
    }

    public function testAHookThatLooksAndSaysNothingDoesNotStopTheSwitch(): void
    {
        // A hook that only wants to *watch* must not stop the thing it is watching. Worth knowing
        // that no mutation of the `&& $refusal->cancel` here can fail this: `emitBeforeSwitch()`
        // goes through `ask()`, whose decisiveness predicate is `$r->cancel`, so a result that
        // does not cancel never comes back at all. The two checks are one rule in two places —
        // harmless, and the reason this case passes either way is measured rather than assumed.
        $extensionRunner = $this->extensionRunner([
            'session_before_switch' => static fn (): SessionBeforeSwitchResult
                => new SessionBeforeSwitchResult(cancel: false),
        ]);

        $session = $this->session(['hello'], store: SessionManager::create(sys_get_temp_dir()), extensionRunner: $extensionRunner);
        Async::run(static fn () => $session->prompt('hi'));

        $this->assertTrue($session->startNew()->switched);

        $other = $this->session(['hi'], store: SessionManager::create(sys_get_temp_dir()));
        Async::run(static fn () => $other->prompt('somewhere else'));

        $this->assertTrue($session->switchTo((string) $other->store()?->path)->switched);
    }

    public function testTheHooksHearAboutASwitchOnceItHasHappened(): void
    {
        $seen = [];
        $shutdowns = [];
        $extensionRunner = $this->extensionRunner([
            'session_start' => function (mixed $event) use (&$seen): null {
                $seen[] = [$event->reason, $event->previousSessionFile];

                return null;
            },
            'session_shutdown' => function (mixed $event) use (&$shutdowns): null {
                $shutdowns[] = [$event->reason, $event->targetSessionFile];

                return null;
            },
        ]);

        $store = SessionManager::create(sys_get_temp_dir());
        $session = $this->session(['hello'], store: $store, extensionRunner: $extensionRunner);
        Async::run(static fn () => $session->prompt('hi'));

        $session->startNew();

        // A custom tool watching for this is how it knows the conversation under it changed —
        // and the file it names is the one being *left*, which is the only moment anything can
        // still say what it was.
        $this->assertSame([['new', $store->path]], $seen);

        $fresh = (string) $session->store()?->path;
        // Upstream's shutdown names the file being switched *to*, before the start names the one left.
        $this->assertSame([['new', $fresh]], $shutdowns);
        $other = $this->session(['hi'], store: SessionManager::create(sys_get_temp_dir()));
        Async::run(static fn () => $other->prompt('somewhere else'));

        $session->switchTo((string) $other->store()?->path);

        $this->assertSame(['resume', $fresh], $seen[1] ?? null, 'and the other door says which it was');
        $this->assertSame(['resume', (string) $other->store()?->path], $shutdowns[1] ?? null);
    }

    // ---- forking a branch into a file of its own --------------------------------------------

    public function testForkingBeforeAQuestionMovesToANewFileAndHandsTheQuestionBack(): void
    {
        $store = SessionManager::create(sys_get_temp_dir());
        $session = $this->session(['one', 'two'], store: $store);
        Async::run(static fn () => $session->prompt('first question'));
        Async::run(static fn () => $session->prompt('second question'));
        $second = $session->userMessagesForForking()[1]['entryId'];

        $fork = Async::run(static fn (): SessionSwitch => $session->fork($second));

        $this->assertTrue($fork->switched);
        $this->assertSame($store->path, $fork->previous);
        $this->assertSame('second question', $fork->editorText);

        // Writing somewhere else now, to a file naming the old one as its parent …
        $this->assertNotSame($store->path, $session->store()?->path);
        $this->assertSame($store->path, $session->store()?->parentSession);
        // … holding the conversation up to before the question that was taken back.
        $this->assertCount(2, $session->messages());
        $this->assertCount(2, SessionManager::open((string) $session->store()?->path)->messages());
        // And the old file still has all four.
        $this->assertCount(4, SessionManager::open($store->path)->messages());
    }

    public function testCloningForksAtThePointItselfAndHandsNothingBack(): void
    {
        $store = SessionManager::create(sys_get_temp_dir());
        $session = $this->session(['one'], store: $store);
        Async::run(static fn () => $session->prompt('a question'));

        $fork = Async::run(static fn (): SessionSwitch => $session->fork((string) $store->leaf(), 'at'));

        $this->assertTrue($fork->switched);
        $this->assertNull($fork->editorText);
        $this->assertSame(2, $fork->messages);
        $this->assertCount(2, SessionManager::open((string) $session->store()?->path)->messages());
    }

    public function testForkingBeforeTheFirstQuestionIsAnEmptySessionWithAParent(): void
    {
        $store = SessionManager::create(sys_get_temp_dir());
        $session = $this->session(['one'], store: $store);
        Async::run(static fn () => $session->prompt('the opening'));
        $first = $session->userMessagesForForking()[0]['entryId'];

        $fork = Async::run(static fn (): SessionSwitch => $session->fork($first));

        $this->assertTrue($fork->switched);
        $this->assertSame('the opening', $fork->editorText);
        $this->assertSame([], $session->messages());
        $this->assertSame($store->path, $session->store()?->parentSession);
        // Nothing answered in it yet, so nothing on disk yet — `append()`'s rule.
        $this->assertFileDoesNotExist((string) $session->store()?->path);
    }

    public function testAHookCanRefuseAForkAndIsToldWhichKindItWas(): void
    {
        $asked = [];
        $extensionRunner = $this->extensionRunner([
            'session_before_fork' => function (mixed $event) use (&$asked): SessionBeforeForkResult {
                $asked[] = $event->position;

                return new SessionBeforeForkResult(cancel: true);
            },
        ]);
        $store = SessionManager::create(sys_get_temp_dir());
        $session = $this->session(['one'], store: $store, extensionRunner: $extensionRunner);
        Async::run(static fn () => $session->prompt('a question'));
        $leaf = (string) $store->leaf();

        $this->assertFalse(Async::run(static fn (): SessionSwitch => $session->fork($leaf, 'at'))->switched);
        $this->assertSame($store->path, $session->store()?->path, 'still writing where it was');
        $this->assertSame(['at'], $asked);
    }

    public function testTheHooksHearAForkAsAForkOnceItHasHappened(): void
    {
        $seen = [];
        $extensionRunner = $this->extensionRunner([
            'session_shutdown' => function (mixed $event) use (&$seen): null {
                $seen[] = ['shutdown', $event->reason, $event->targetSessionFile];

                return null;
            },
            'session_start' => function (mixed $event) use (&$seen): null {
                $seen[] = ['start', $event->reason, $event->previousSessionFile];

                return null;
            },
        ]);
        $store = SessionManager::create(sys_get_temp_dir());
        $session = $this->session(['one'], store: $store, extensionRunner: $extensionRunner);
        Async::run(static fn () => $session->prompt('a question'));

        Async::run(static fn (): SessionSwitch => $session->fork((string) $store->leaf(), 'at'));

        $this->assertSame([
            ['shutdown', 'fork', (string) $session->store()?->path],
            ['start', 'fork', $store->path],
        ], $seen);
    }

    public function testAForkIsRefusedWhereThereIsNothingOnDiskToForkFrom(): void
    {
        $unsaved = $this->session(['one']);
        Async::run(static fn () => $unsaved->prompt('hi'));
        $this->assertThrows(AgentError::class, static fn () => $unsaved->fork('whatever'));

        $store = SessionManager::create(sys_get_temp_dir());
        $session = $this->session([], store: $store);
        // A question with no answer yet is a session not written anywhere.
        $session->agent->appendMessage(new UserMessage('not answered'));
        $this->assertThrows(AgentError::class, static fn () => $session->fork('whatever'));
    }

    public function testForkingBeforeSomethingNobodySaidIsRefusedByName(): void
    {
        $store = SessionManager::create(sys_get_temp_dir());
        $session = $this->session(['one'], store: $store);
        Async::run(static fn () => $session->prompt('a question'));

        // The leaf is the answer, and `before` an answer is not a thing to ask differently.
        $error = $this->assertThrows(AgentError::class, static fn () => $session->fork((string) $store->leaf()));
        $this->assertStringContainsString('something you said', $error->getMessage());
        $this->assertThrows(AgentError::class, static fn () => $session->fork('nope0000', 'at'));
    }

    public function testResumingComesBackOnWhatThatConversationWasHadWith(): void
    {
        // A real registry model, for the reason the `--continue` case below gives: restoring
        // means looking the recorded provider and id back up, and this one can reason, so the
        // level is not clamped away before it is ever written down.
        $reasoning = Models::find('anthropic', 'claude-haiku-4-5');
        self::assertNotNull($reasoning);

        $other = SessionManager::create(sys_get_temp_dir());
        $elsewhere = $this->session(['hi there'], store: $other);
        Async::run(static fn () => $elsewhere->prompt('a conversation on another model'));
        $elsewhere->setModel($reasoning);
        $elsewhere->setThinkingLevel(ThinkingLevel::High);

        $session = $this->session(['hello'], store: SessionManager::create(sys_get_temp_dir()));
        Async::run(static fn () => $session->prompt('here'));

        $this->assertSame(ThinkingLevel::Off, $session->thinkingLevel());

        $session->switchTo((string) $other->path);

        // The `--continue` case calls `restoreSettings()` itself; this is the other door, and
        // resuming takes no model and no level, so the file wins outright — which is what the
        // word means. Without it the conversation comes back on whatever the last one used.
        $this->assertSame('claude-haiku-4-5', $session->model()?->id);
        $this->assertSame(ThinkingLevel::High, $session->thinkingLevel());
    }

    public function testAPathThatIsNotASessionCostsTheConversationNothing(): void
    {
        $store = SessionManager::create(sys_get_temp_dir());
        $session = $this->session(['hello'], store: $store);

        Async::run(static fn () => $session->prompt('hi'));
        $session->followUp('still waiting to be sent');

        $this->assertThrows(
            AgentError::class,
            static fn () => $session->switchTo(sys_get_temp_dir() . '/not-a-session-' . bin2hex(random_bytes(4)) . '.jsonl'),
            'Could not read the session',
        );

        // The file is opened before anything is thrown away, so a bad path is a message
        // rather than a session left aborted, emptied, and writing to the file it was
        // about to leave.
        $this->assertSame($store->path, $session->store()?->path);
        $this->assertCount(2, $session->messages());
        $this->assertSame(['still waiting to be sent'], $session->queued());
    }

    // ---- carrying an interrupted run on ---------------------------------------------------------

    public function testARunThatStoppedAfterTheQuestionIsCarriedOnFromIt(): void
    {
        $session = $this->session(['the answer']);
        $session->agent->replaceMessages([new UserMessage('the question')]);
        $told = [];

        // Not an arrow function: one captures `$told` by value, and the closure inside would
        // write to its copy.
        $outcome = Async::run(static function () use ($session, &$told): string {
            return $session->continueRun(static function (string $o) use (&$told): void {
                $told[] = $o;
            });
        });
        self::settle();

        $this->assertSame('continued', $outcome);
        $this->assertSame(['continued'], $told, 'the caller is told before the turn runs');
        $this->assertCount(2, $session->messages());
        $this->assertSame('the answer', self::textOf($session->messages()[1]));
    }

    public function testAFailedLastTurnIsTakenOffAndTheRunGoesAgainFromTheQuestion(): void
    {
        $store = SessionManager::create(sys_get_temp_dir());
        $session = $this->session(
            [],
            streamFn: $this->flaky([['error' => 'Anthropic returned 503: overloaded'], 'here you go']),
            store: $store,
            settings: self::quickRetries(['enabled' => false]),
        );

        Async::run(static function () use ($session): void {
            $session->prompt('hi');
        });
        self::settle();
        $this->assertSame(StopReason::Error, $session->messages()[1]->stopReason, 'the turn failed and nothing retried it');

        $outcome = Async::run(static fn (): string => $session->continueRun());
        self::settle();

        $this->assertSame('continued', $outcome);
        $this->assertCount(2, $session->messages());
        $this->assertSame('here you go', self::textOf($session->messages()[1]));

        $reopened = SessionManager::open($store->path)->messages();
        $this->assertCount(2, $reopened, 'the failed turn is not shown to the model on a later resume either');
        $this->assertSame('here you go', self::textOf($reopened[1]));
    }

    public function testAnAbortedLastTurnIsTakenOffToo(): void
    {
        $session = $this->session(['again']);
        $session->agent->replaceMessages([
            new UserMessage('the question'),
            new AssistantMessage([new TextContent('half an ans')], Api::AnthropicMessages, 'anthropic', 'test-model', new Usage(), StopReason::Aborted),
        ]);

        $this->assertSame('continued', Async::run(static fn (): string => $session->continueRun()));
        self::settle();

        $this->assertCount(2, $session->messages());
        $this->assertSame('again', self::textOf($session->messages()[1]));
    }

    public function testAConversationThatEndsOnAnAnswerHadAlreadyFinished(): void
    {
        $session = $this->session([]);
        $session->agent->replaceMessages([
            new UserMessage('the question'),
            new AssistantMessage([new TextContent('done')], Api::AnthropicMessages, 'anthropic', 'test-model', new Usage(), StopReason::Stop),
        ]);
        $told = [];

        $outcome = $session->continueRun(static function (string $o) use (&$told): void {
            $told[] = $o;
        });

        $this->assertSame('finished', $outcome);
        $this->assertSame(['finished'], $told);
        $this->assertCount(2, $session->messages(), 'nothing is asked of the model');
    }

    public function testACallThatMayHaveHalfRunIsAnsweredInterruptedAndTheRunGoesOn(): void
    {
        $store = SessionManager::create(sys_get_temp_dir());
        $session = $this->session(['it may not have finished; checking'], store: $store);
        $asked = new AssistantMessage([new ToolCall('c1', 'bash', ['command' => 'rm -rf build'])], Api::AnthropicMessages, 'anthropic', 'test-model', new Usage(), StopReason::ToolUse);
        $session->agent->replaceMessages([new UserMessage('delete the build'), $asked]);
        $store->append(new UserMessage('delete the build'));
        $store->append($asked);
        $told = [];

        $outcome = Async::run(static function () use ($session, &$told): string {
            return $session->continueRun(static function (string $o) use (&$told): void {
                $told[] = $o;
            });
        });
        self::settle();

        $this->assertSame('continued', $outcome);
        $this->assertSame(['continued'], $told);
        $result = $session->messages()[2];
        $this->assertInstanceOf(ToolResultMessage::class, $result);
        $this->assertTrue($result->isError);
        $this->assertSame('Tool bash was interrupted and may have partially run', self::textOf($result));
        $this->assertSame('it may not have finished; checking', self::textOf($session->messages()[3]));

        $reopened = SessionManager::open($store->path)->messages();
        $this->assertCount(4, $reopened, 'the interrupted result is written down like any other');
    }

    public function testWhatAnInterruptedCallHadPrintedGoesInItsResult(): void
    {
        $store = SessionManager::create(sys_get_temp_dir());
        $session = $this->session(['the build got halfway'], store: $store);
        $asked = new AssistantMessage([new ToolCall('c1', 'bash', ['command' => 'make'])], Api::AnthropicMessages, 'anthropic', 'test-model', new Usage(), StopReason::ToolUse);
        $session->agent->replaceMessages([new UserMessage('build it'), $asked]);
        $store->append(new UserMessage('build it'));
        $store->append($asked);
        file_put_contents(ToolProgress::pathOf($store->path), json_encode(['toolCallId' => 'c1', 'output' => "compiling a.c\ncompiling b.c\n"]));

        Async::run(static fn (): string => $session->continueRun());
        self::settle();

        $result = $session->messages()[2];
        $this->assertTrue($result->isError);
        $this->assertSame("compiling a.c\ncompiling b.c\n", $result->content[0]->text);
        $this->assertSame('Tool bash was interrupted and may have partially run', $result->content[1]->text);
        $this->assertFileDoesNotExist(ToolProgress::pathOf($store->path), 'gone once the result is written');
    }

    public function testOutputKeptForAnotherCallIsNotPutInThisOnesResult(): void
    {
        $store = SessionManager::create(sys_get_temp_dir());
        $session = $this->session(['ok'], store: $store);
        $asked = new AssistantMessage([new ToolCall('c2', 'bash', ['command' => 'make'])], Api::AnthropicMessages, 'anthropic', 'test-model', new Usage(), StopReason::ToolUse);
        $session->agent->replaceMessages([new UserMessage('build it'), $asked]);
        $store->append(new UserMessage('build it'));
        $store->append($asked);
        file_put_contents(ToolProgress::pathOf($store->path), json_encode(['toolCallId' => 'c1', 'output' => 'an older call']));

        Async::run(static fn (): string => $session->continueRun());
        self::settle();

        $this->assertCount(1, $session->messages()[2]->content);
    }

    public function testARunningToolsOutputIsKeptBesideTheSessionUntilItsResultIsWritten(): void
    {
        $store = SessionManager::create(sys_get_temp_dir());
        $session = $this->session(['read it'], store: $store);
        $sidecar = ToolProgress::pathOf($store->path);
        $tool = new class ($sidecar) implements AgentTool, ReplayableTool {
            public ?string $seen = null;

            public function __construct(private readonly string $sidecar)
            {
            }

            public function definition(): Tool
            {
                return new Tool('read', 'read a file', ['type' => 'object', 'properties' => []]);
            }

            public function label(): string
            {
                return 'Read';
            }

            public function replay(): ToolReplay
            {
                return ToolReplay::Safe;
            }

            public function execute(string $toolCallId, array $arguments, ?AbortSignal $signal = null, ?Closure $onUpdate = null): AgentToolResult
            {
                $onUpdate?->__invoke(new AgentToolResult([new TextContent('first half')]));
                $this->seen = is_file($this->sidecar) ? (string) file_get_contents($this->sidecar) : null;

                return new AgentToolResult([new TextContent('first half, second half')]);
            }
        };
        $session->agent->setTools([$tool]);
        $asked = new AssistantMessage([new ToolCall('c1', 'read', [])], Api::AnthropicMessages, 'anthropic', 'test-model', new Usage(), StopReason::ToolUse);
        $session->agent->replaceMessages([new UserMessage('read it'), $asked]);
        $store->append(new UserMessage('read it'));
        $store->append($asked);

        Async::run(static fn (): string => $session->continueRun());
        self::settle();

        $this->assertSame(['toolCallId' => 'c1', 'output' => 'first half'], json_decode((string) $tool->seen, true), 'written as the tool reported');
        $this->assertSame('first half, second half', self::textOf($session->messages()[2]), 'a safe call is run again');
        $this->assertFileDoesNotExist($sidecar);
    }

    public function testAConversationStoppedMidRunIsOneAProcessLostNotOneSomebodyStopped(): void
    {
        $session = $this->session([]);
        $answer = static fn (StopReason $reason, array $content = [new TextContent('x')]): AssistantMessage => new AssistantMessage($content, Api::AnthropicMessages, 'anthropic', 'test-model', new Usage(), $reason);
        $asked = $answer(StopReason::ToolUse, [new ToolCall('c1', 'bash', ['command' => 'make'])]);

        foreach ([
            'empty' => [[], false],
            'after the question' => [[new UserMessage('q')], true],
            'inside a tool call' => [[new UserMessage('q'), $asked], true],
            'after a tool result' => [[new UserMessage('q'), $asked, new ToolResultMessage('c1', 'bash', [new TextContent('ok')], false)], true],
            'answered' => [[new UserMessage('q'), $answer(StopReason::Stop)], false],
            'stopped with escape' => [[new UserMessage('q'), $answer(StopReason::Aborted)], false],
            'failed' => [[new UserMessage('q'), $answer(StopReason::Error)], false],
        ] as $case => [$messages, $expected]) {
            $session->agent->replaceMessages($messages);
            $this->assertSame($expected, $session->isStoppedMidRun(), $case);
        }
    }

    public function testAPromptsRequestIdIsTakenOnceEvenAfterTheConversationIsReopened(): void
    {
        $store = SessionManager::create(sys_get_temp_dir());
        $session = $this->session(['hello'], store: $store);
        $told = [];
        $tell = static function (string $d) use (&$told): void {
            $told[] = $d;
        };

        Async::run(static fn () => $session->prompt('hi', preflightResult: $tell, requestId: 'r-1'));
        self::settle();
        Async::run(static fn () => $session->prompt('hi', preflightResult: $tell, requestId: 'r-1'));

        $this->assertSame(['started', 'duplicate'], $told);
        $this->assertCount(2, $session->messages());

        // A new process on the same file: the id is in the file, not only in memory.
        $reopened = $this->session([], store: SessionManager::open($store->path));
        Async::run(static fn () => $reopened->prompt('hi', preflightResult: $tell, requestId: 'r-1'));
        $this->assertSame('duplicate', $told[2]);
    }

    public function testARefusedPromptsRequestIdCanBeSentAgain(): void
    {
        $session = $this->session([], streamFn: self::parksUntilAborted());
        $told = [];

        Async::run(static function () use ($session, &$told): void {
            Async::spawn(static fn () => $session->prompt('the first'));
            Async::delay(0.01);

            // Busy and no `streamingBehavior`: refused, so nothing was taken.
            try {
                $session->prompt('hi', requestId: 'r-1');
                self::fail('a prompt mid-run with no streamingBehavior is refused');
            } catch (AgentError) {
            }

            $session->prompt('hi', streamingBehavior: 'followUp', preflightResult: static function (string $d) use (&$told): void {
                $told[] = $d;
            }, requestId: 'r-1');
            $session->abort()->await();
        });
        self::settle();

        $this->assertSame(['queued'], $told, 'taken the second time');
    }

    public function testAnEmptyConversationHasNothingToCarryOn(): void
    {
        $session = $this->session([]);

        $e = $this->assertThrows(RuntimeException::class, static fn () => $session->continueRun());

        $this->assertStringContainsString('nothing in this session', $e->getMessage());
    }

    /** @param array<string, callable> $handlers */
    private function extensionRunner(array $handlers): ExtensionRunner
    {
        $api = new ExtensionApi('.', 'test.php');

        foreach ($handlers as $event => $handler) {
            $api->on($event, $handler);
        }

        return new ExtensionRunner([new LoadedExtension('test.php', 'test.php', $api->name, $api)], sys_get_temp_dir());
    }

    private function session(
        array $answers,
        ?Closure $hook = null,
        ?Model $model = null,
        ?Closure $streamFn = null,
        ?SessionManager $store = null,
        ?Settings $settings = null,
        ?Closure $getApiKey = null,
        ?ExtensionRunner $extensionRunner = null,
        ?Auth $auth = null,
    ): AgentSession {
        $agent = new Agent(new AgentOptions(
            streamFn: $streamFn ?? $this->provider($answers, $hook),
            // One key for every provider unless a test says otherwise, which is what the cases
            // about a model there is no key for hand in instead.
            apiKey: $getApiKey === null ? 'test-key' : null,
            getApiKey: $getApiKey,
        ));

        $agent->setModel($model ?? $this->model());
        $this->current = $agent;

        return new AgentSession($agent, sys_get_temp_dir(), $store, $settings, $extensionRunner, auth: $auth);
    }

    /**
     * A provider that fails for a while, then answers.
     *
     * Each turn takes the next entry: a string is an answer, anything else is the error a
     * failed turn reports. Written as a list rather than a counter so a test reads as the
     * sequence the provider actually produces.
     *
     * @param list<string|array{error: string}> $turns
     */
    private function flaky(array $turns): Closure
    {
        $at = 0;

        return function () use ($turns, &$at): AssistantMessageEventStream {
            $turn = $turns[$at++] ?? throw new RuntimeException('out of scripted turns');

            return is_string($turn) ? $this->replay($turn) : $this->fails($turn['error']);
        };
    }

    /** A turn that comes back as an error, the way a provider's 503 does. */
    private function fails(string $error): AssistantMessageEventStream
    {
        $stream = new AssistantMessageEventStream();
        $message = new AssistantMessage(
            [new TextContent('')],
            Api::AnthropicMessages,
            'anthropic',
            'test-model',
            new Usage(),
            StopReason::Error,
            $error,
        );

        Async::spawn(static function () use ($stream, $message): void {
            $stream->push(new StartEvent($message));
            $stream->push(new ErrorEvent(StopReason::Error, $message));
            $stream->end();
        });

        return $stream;
    }

    /** Settings with the waits short enough that a test is not mostly sleeping. */
    private static function quickRetries(array $extra = []): Settings
    {
        $compaction = [];

        foreach (['keepRecentTokens', 'reserveTokens'] as $key) {
            if (isset($extra[$key])) {
                $compaction[$key] = $extra[$key];
                unset($extra[$key]);
            }
        }

        return Settings::inMemory([
            'retry' => ['baseDelayMs' => 1, ...$extra],
            'compaction' => $compaction,
        ]);
    }

    /**
     * Send something that will fail, and come back with the retry parked on its timer.
     *
     * `Async::run()` will not do: `prompt()` does not return until the retries behind its turn
     * are finished too — which is the whole point of it, and which leaves a test that ran it
     * that way looking at a retry that is already over, or sitting through the delay it was
     * written to measure. So the turn is spawned and the loop is turned until the retry
     * exists, each tick with an expired timer of its own so the retry's own timer is never
     * waited out.
     */
    private static function startTurnAndParkOnTheRetry(AgentSession $session, string $text = 'hi'): void
    {
        $parked = false;
        $stop = $session->subscribe(static function (AgentEvent $event) use (&$parked): void {
            if ($event instanceof RetryStartEvent) {
                $parked = true;
            }
        });

        Async::run(static function () use ($session, $text): void {
            Async::spawn(static fn () => $session->prompt($text));
        });

        // The `RetryStartEvent` and not `isRetrying()`: the retry is decided synchronously, one
        // tick before the fiber that announces it and parks on the timer exists, so waiting for
        // the flag would come back too early to see either.
        for ($tick = 0; $tick < 200 && !$parked; $tick++) {
            self::tickWithoutWaiting();
        }

        $stop();
    }

    /** Turn the loop until nothing is left, so a spawned retry gets to happen. */
    private static function settle(int $ticks = 200): void
    {
        for ($tick = 0; $tick < $ticks && !Loop::get()->isIdle(); $tick++) {
            Loop::get()->tick();
        }
    }

    /**
     * One tick that does not wait out whatever timer is pending.
     *
     * A plain `tick()` with a retry's timer armed and no streams to watch calls `usleep()`
     * for the whole delay — so two ticks really are two seconds, the sleep is over before
     * the test gets control back, and there is nothing left to abort. An expired timer of
     * our own makes `pollTimeout()` ~0, so the tick returns with the retry still parked.
     */
    private static function tickWithoutWaiting(): void
    {
        Loop::get()->delay(0.0, static fn () => null);
        Loop::get()->tick();
    }

    /**
     * @param list<string>              $answers
     * @param Closure(Agent): void|null $hook
     */
    private function provider(array $answers, ?Closure $hook): Closure
    {
        $index = 0;

        return function (Model $model, TranscriptContext $context, SimpleStreamOptions $options) use (
            $answers,
            $hook,
            &$index,
        ): AssistantMessageEventStream {
            if ($hook !== null && $this->current !== null) {
                $hook($this->current);
            }

            return $this->replay($answers[$index++] ?? throw new RuntimeException('out of scripted answers'));
        };
    }

    /**
     * A turn that goes on until escape reaches it, which is what a provider's socket does.
     *
     * The seam for anything that has to happen *while* the agent is working: the scripted
     * providers above finish within the tick they are asked in, so there is no window.
     */
    private static function parksUntilAborted(): Closure
    {
        return static function (Model $model, TranscriptContext $context, SimpleStreamOptions $options): AssistantMessageEventStream {
            $stream = new AssistantMessageEventStream();
            $partial = new AssistantMessage(
                [new TextContent('half of an ans')],
                Api::AnthropicMessages,
                'anthropic',
                'test-model',
                new Usage(),
                StopReason::Aborted,
            );

            Async::spawn(static function () use ($stream, $partial, $options): void {
                $stream->push(new StartEvent($partial));

                // Parked on the signal rather than polling it: a poll only notices between ticks,
                // and a test that drives the loop by hand can get through fifty of them inside the
                // millisecond the poll was waiting for — which reads as an abort that did not
                // arrive.
                $stopped = new Deferred();
                $options->signal?->onAbort(static function () use ($stopped): void {
                    if (!$stopped->isComplete()) {
                        $stopped->complete(null);
                    }
                });

                if ($options->signal?->aborted() === true && !$stopped->isComplete()) {
                    $stopped->complete(null);
                }

                $stopped->future->await();

                $stream->push(new DoneEvent(StopReason::Aborted, $partial));
                $stream->end();
            });

            return $stream;
        };
    }

    private function replay(string $text): AssistantMessageEventStream
    {
        $stream = new AssistantMessageEventStream();
        $message = new AssistantMessage(
            [new TextContent($text)],
            Api::AnthropicMessages,
            'anthropic',
            'test-model',
            new Usage(),
            StopReason::Stop,
        );

        Async::spawn(static function () use ($stream, $message): void {
            $stream->push(new StartEvent($message));
            $stream->push(new DoneEvent(StopReason::Stop, $message));
            $stream->end();
        });

        return $stream;
    }

    private function model(): Model
    {
        return new Model('test-model', 'Test', Api::AnthropicMessages, 'anthropic', 'http://127.0.0.1:1', 200_000, 64_000);
    }

    private static function textOf(mixed $message): string
    {
        $text = '';

        foreach ($message->content as $block) {
            if ($block instanceof TextContent) {
                $text .= $block->text;
            }
        }

        return $text;
    }

    /** @param array<string, string|null> $levels */
    private function thinkingModel(string $id = 'test-thinker', array $levels = []): Model
    {
        return new Model($id, 'Test', Api::AnthropicMessages, 'anthropic', 'http://127.0.0.1:1', 200_000, 64_000, true, thinkingLevelMap: $levels);
    }

    /**
     * One that cannot reason, built here rather than looked up.
     *
     * It used to be `Models::get('claude-3-haiku-20240307')`, and the first regeneration of the
     * registry from models.dev retired that model — along with every other Anthropic model that
     * cannot reason, so there was nothing in that table left to look up. What the clamping rules
     * need is a model without reasoning, which is one line to build and no longer anybody else's
     * to discontinue.
     */
    private function plainModel(string $id = 'test-plain'): Model
    {
        return new Model($id, 'Test Plain', Api::AnthropicMessages, 'anthropic', 'http://127.0.0.1:1', 200_000, 8_192, false);
    }
}
