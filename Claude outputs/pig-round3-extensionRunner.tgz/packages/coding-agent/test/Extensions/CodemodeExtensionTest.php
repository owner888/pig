<?php

declare(strict_types=1);

namespace Pig\CodingAgent\Test\Extensions;

use PHPUnit\Framework\TestCase;
use Pig\Agent\AgentTool;
use Pig\Agent\AgentToolResult;
use Pig\Agent\ToolExecutionEndEvent;
use Pig\Agent\ToolExecutionStartEvent;
use Pig\Ai\TextContent;
use Pig\Ai\Tool;
use Pig\Async\Async;
use Pig\Async\Loop;
use Pig\Codemode\Registry;
use PigCodemode\CodemodeDescription;
use Pig\CodingAgent\Auth;
use Pig\CodingAgent\CodingAgent;
use Pig\CodingAgent\Extensions\Events\SessionShutdownEvent;
use Pig\CodingAgent\Extensions\Events\SessionStartEvent;
use Pig\CodingAgent\Extensions\ExtensionContext;
use Pig\CodingAgent\Extensions\Results\ToolCallEventResult;
use Pig\CodingAgent\Settings;
use Pig\CodingAgent\StartedSession;
use Pig\Test\WithoutProviderKeys;

/**
 * The codemode extension with the MCP extension beside it, through `CodingAgent::session()` —
 * which is how `bin/pig` loads them and the only place the system prompt, the hooks and the
 * agent's tools all meet.
 */
final class CodemodeExtensionTest extends TestCase
{
    use WithoutProviderKeys;

    private string $root;

    private string $home;

    private string $cwd;

    private string|false $realHome = false;

    #[\Override]
    protected function setUp(): void
    {
        Loop::reset();
        Registry::reset();
        $this->realHome = getenv('HOME');
        $this->root = sys_get_temp_dir() . '/pig-codemode-' . bin2hex(random_bytes(4));
        $this->home = $this->root . '/home';
        $this->cwd = $this->root . '/project';
        mkdir($this->home, 0o700, true);
        mkdir($this->cwd . '/.pig', 0o755, true);
        putenv('PIG_CODING_AGENT_DIR=' . $this->home);
        putenv('PI_HOME=' . $this->root . '/pi');
        putenv('HOME=' . $this->root . '/nobody');
        $this->forgetProviderKeys();
        putenv('ANTHROPIC_API_KEY=test-key');
    }

    #[\Override]
    protected function tearDown(): void
    {
        $this->restoreProviderKeys();
        putenv('PIG_CODING_AGENT_DIR');
        putenv('PI_HOME');
        // Unsetting `HOME` rather than restoring it blinded every later test that looks under
        // `~` — `fd is not installed` in `SearchToolsTest`, fourteen skips elsewhere.
        putenv($this->realHome === false ? 'HOME' : 'HOME=' . $this->realHome);
    }

    private static function fixtureServer(): string
    {
        return dirname(__DIR__, 4) . '/packages/mcp/test/fixtures/stdio-server.php';
    }

    /** Start a session with both extensions and let `session_start` connect the servers. */
    private function start(array $mcp = [], array $extra = [], ?Auth $auth = null, array $extensions = []): StartedSession
    {
        if ($mcp !== []) {
            file_put_contents($this->home . '/mcp.json', json_encode(['mcpServers' => $mcp]));
        }

        $settings = Settings::load($this->cwd, $this->home);
        $repo = dirname(__DIR__, 4);
        $arguments = [
            $this->cwd,
            $settings,
            $auth ?? Auth::inMemory($settings),
            'extensionPaths' => [$repo . '/extensions/pig-codemode/index.php', $repo . '/extensions/pig-mcp/index.php', ...array_map(static fn (string $name): string => "{$repo}/extensions/{$name}/index.php", $extensions)],
            ...$extra,
        ];
        $started = Async::run(static fn (): StartedSession => CodingAgent::session(...$arguments));

        $session = $started->session;
        $started->extensionRunner->initialize(
            static fn () => $started->model,
            note: static fn (string $customType, mixed $data) => $session->appendHookEntry($customType, $data),
        );

        Async::run(static function () use ($started): void {
            $started->extensionRunner->emit(new SessionStartEvent());
            $started->extensionRunner->emitBeforeAgentStart(['messageType' => 'user', 'prompt' => 'hi']);
        });

        return $started;
    }

    /** @return list<string> */
    private static function toolNames(StartedSession $started): array
    {
        $names = array_map(static fn ($t) => $t->definition()->name, $started->session->agent->tools());
        sort($names);

        return $names;
    }

    /** The description the model is offered for $name — after `prepareLoadout`. */
    private static function declared(StartedSession $started, string $name): ?string
    {
        foreach ($started->session->agent->tools() as $tool) {
            if ($tool->definition()->name === $name) {
                return $tool->definition()->description;
            }
        }

        return null;
    }

    private function stop(StartedSession $started): void
    {
        Async::run(static fn () => $started->extensionRunner->emit(new SessionShutdownEvent()));
    }

    public function testWithNoCodemodeServerAndNothingNamingItTheToolIsRegisteredButInactive(): void
    {
        $started = $this->start(['fixture' => ['command' => PHP_BINARY, 'args' => [self::fixtureServer()], 'exposure' => 'direct']]);

        $this->assertSame(['bash', 'edit', 'mcp__fixture__echo', 'read', 'write'], self::toolNames($started));
        $this->assertStringNotContainsString('- codemode:', $started->session->systemPrompt());
        // Upstream's `defaultActive: false`: registered, so it can be named, but not active.
        $this->assertNotNull($started->customTools->find('codemode'));
        $this->assertFalse($started->customTools->find('codemode')->defaultActive);
        $this->assertNotContains('codemode', $started->session->activeTools());
        $this->assertContains('codemode', array_column($started->session->allTools(), 'name'));
        $this->stop($started);
    }

    public function testNamingItInToolsActivatesIt(): void
    {
        $started = $this->start(extra: ['tools' => ['read', 'bash', 'codemode']]);

        $this->assertSame(['bash', 'codemode', 'read'], self::toolNames($started));
        $this->assertStringContainsString('- codemode: Run PHP that calls other tools', $started->session->systemPrompt());
        $this->stop($started);
    }

    public function testAPlusModifierInToolsActivatesIt(): void
    {
        $started = $this->start(extra: ['tools' => ['+codemode']]);

        $this->assertSame(['bash', 'codemode', 'edit', 'read', 'write'], self::toolNames($started));
        $this->stop($started);
    }

    public function testNamingItInDefaultToolsActivatesIt(): void
    {
        file_put_contents($this->home . '/settings.json', json_encode(['defaultTools' => ['read', 'codemode']]));
        $started = $this->start();

        $this->assertSame(['codemode', 'read'], self::toolNames($started));
        $this->stop($started);
    }

    public function testSetActiveToolsActivatesIt(): void
    {
        $started = $this->start();
        $this->assertNotContains('codemode', self::toolNames($started));

        $started->session->setActiveTools([...$started->session->activeTools(), 'codemode']);

        $this->assertContains('codemode', self::toolNames($started));
        $this->stop($started);
    }

    public function testTheRemovedEnabledSettingDoesNothing(): void
    {
        file_put_contents($this->home . '/settings.json', json_encode(['codemode' => ['enabled' => true]]));
        $started = $this->start();

        $this->assertSame(['bash', 'edit', 'read', 'write'], self::toolNames($started));
        $this->stop($started);
    }

    public function testToolsThatLeaveItOutKeepItOffEvenForACodemodeServer(): void
    {
        $started = $this->start(['fixture' => ['command' => PHP_BINARY, 'args' => [self::fixtureServer()]]], ['tools' => ['read']]);

        // Upstream's `_isAllowedTool()`: not named, so not registered, and the MCP extension's
        // activation has nothing to activate.
        $this->assertSame(['read'], self::toolNames($started));
        $this->assertNull($started->customTools->find('codemode'));
        $this->stop($started);
    }

    public function testACodemodeServerActivatesTheToolAndTheSystemPromptSaysSo(): void
    {
        $started = $this->start(['fixture' => ['command' => PHP_BINARY, 'args' => [self::fixtureServer()]]]);   // default exposure

        // The MCP tool is not on the model; codemode is, and it is the way to the MCP tool.
        $this->assertSame(['bash', 'codemode', 'edit', 'read', 'write'], self::toolNames($started));

        $prompt = $started->session->systemPrompt();
        $this->assertStringContainsString('- codemode: Run PHP that calls other tools', $prompt, "upstream's promptSnippet, in the Available tools list");
        $this->assertStringContainsString('- Use codemode to batch independent tool calls (parallel_settled), chain them, or filter large output', $prompt, "and its guideline");

        // Upstream's `tool_call` wait: a script naming the server's namespace waits for it to connect,
        // so its tools are there when the script runs. The first prompt did not wait for it.
        Async::run(static fn () => $started->extensionRunner->emitToolCall(new \Pig\CodingAgent\Extensions\Events\ToolCallEvent('codemode', 'call-1', ['code' => 'return $tools->mcp__fixture__echo(["text" => "hi"]);'])));

        // Upstream's tool keeps one description; `prepareLoadout` is what lists the callable tools.
        $codemode = $started->customTools->find('codemode');
        $this->assertStringContainsString('## fixture', (string) self::declared($started, 'codemode'), 'the server is a namespace in the catalog');
        $this->assertStringContainsString('$tools->mcp__fixture__echo(array{text?: string} $input): array{', (string) self::declared($started, 'codemode'));

        // A script calls it and the result is the whole CallToolResult, which the script filters.
        $result = Async::run(static fn () => ($codemode->execute)('1', ['code' => '$r = $tools->mcp__fixture__echo(["text" => "hi"]); return strtoupper($r["content"][0]["text"]);'], null, $started->extensionRunner->context(), null));
        $this->assertMatchesRegularExpression("/^Script completed\nWall time [\d.]+ seconds\nOutput:\n$/", $result->content[0]->text);
        $this->assertSame('ECHO: HI', $result->content[1]->text);
        $this->assertSame('mcp__fixture__echo', $result->details['calls'][0]['name']);
        $this->assertSame('ok', $result->details['calls'][0]['status']);

        // Like upstream's `ensureDiscoveryActive()`, it only ever activates: the session ending
        // does not take it off the loadout.
        $this->stop($started);
        $this->assertContains('codemode', self::toolNames($started));
    }

    public function testDefaultToolsTurnsItOnWithoutAnyServer(): void
    {
        file_put_contents($this->home . '/settings.json', json_encode(['defaultTools' => ['+codemode']]));
        $started = $this->start();

        $this->assertContains('codemode', self::toolNames($started));
        $codemode = $started->customTools->find('codemode');
        $this->assertStringNotContainsString('Nested tools:', $codemode->description, 'nothing codemode-only to list; the agent\'s tools the model has already');

        // Upstream 1.0's lean description: the intro, one line per global, and the path of the
        // reference the model reads when it needs a detail — not the whole reference, every turn.
        // Measured without that path, whose length is wherever pig is installed: a checkout under
        // a deep temporary directory went over by the path alone.
        $this->assertLessThan(1500, strlen(str_replace(CodemodeDescription::DOCS_PATH, '', $codemode->description)), 'the description is read on every request');
        $this->assertStringContainsString(CodemodeDescription::DOCS_PATH, $codemode->description);
        $this->assertFileExists(CodemodeDescription::DOCS_PATH);
        $this->assertStringContainsString('## Store values', (string) file_get_contents(CodemodeDescription::DOCS_PATH));

        // The agent's own tools are callable from a script even though they are not listed.
        file_put_contents($this->cwd . '/note.txt', "hello from a file\n");
        $result = Async::run(static fn () => ($codemode->execute)('1', ['code' => 'return trim($tools->read(["path" => "note.txt"]));'], null, $started->extensionRunner->context(), null));
        $this->assertSame('hello from a file', $result->content[count($result->content) - 1]->text);
        $this->stop($started);
    }

    public function testANestedCallGoesThroughTheToolCallHookLikeAnyOther(): void
    {
        file_put_contents($this->home . '/settings.json', json_encode(['defaultTools' => ['+codemode']]));
        mkdir($this->home . '/extensions', 0o755, true);
        file_put_contents($this->home . '/extensions/guard.php', <<<'PHP'
<?php
use Pig\CodingAgent\Extensions\Results\ToolCallEventResult;
return function ($pig): void {
    $pig->on('tool_call', function ($event) {
        file_put_contents(getenv('PIG_CODING_AGENT_DIR') . '/seen-call-id', $event->toolCallId);

        return $event->toolName === 'bash' ? new ToolCallEventResult(block: true, reason: 'No shells from scripts.') : null;
    });
};
PHP);
        $started = $this->start();
        $codemode = $started->customTools->find('codemode');

        $result = Async::run(static fn () => ($codemode->execute)('call-7', ['code' => 'return parallel_settled([fn () => $tools->bash(["command" => "id"]), fn () => "fine"]);'], null, $started->extensionRunner->context(), null));

        $value = json_decode($result->content[count($result->content) - 1]->text, true);
        $this->assertFalse($value[0]['ok']);
        $this->assertStringContainsString('No shells from scripts.', $value[0]['error'], 'the guard that stops bash stops bash from a script');
        $this->assertSame('fine', $value[1]['value']);
        $this->assertSame('error', $result->details['calls'][0]['status']);
        // The nested call's id is `<codemode call id>/<n>`, upstream's shape, and it is the id the
        // hook was handed — not a synthetic one the row alone knew.
        $this->assertSame('call-7/1', $result->details['calls'][0]['id']);
        $this->assertSame('call-7/1', file_get_contents($this->home . '/seen-call-id'));
        $this->stop($started);
    }

    public function testANestedCallIsCheckedAgainstTheSchemaReportedUnderItsParentAndBilledToTheScript(): void
    {
        file_put_contents($this->home . '/settings.json', json_encode(['defaultTools' => ['+codemode']]));
        mkdir($this->home . '/extensions', 0o755, true);
        file_put_contents($this->home . '/extensions/spend.php', <<<'PHP'
<?php
use Pig\Agent\AgentTool;
use Pig\Agent\AgentToolResult;
use Pig\Ai\Cost;
use Pig\Ai\TextContent;
use Pig\Ai\Usage;
use Pig\CodingAgent\CustomTools\CustomTool;
use Pig\CodingAgent\Extensions\ExtensionApi;
return function (ExtensionApi $pig): void {
    $pig->registerTool(new CustomTool(
        name: 'spend',
        label: 'Spend',
        description: 'Spends a little on a model.',
        parameters: ['type' => 'object', 'properties' => ['amount' => ['type' => 'integer']], 'required' => ['amount']],
        execute: fn () => new AgentToolResult([new TextContent('spent')], null, new Usage(10, 2, 0, 0, 12, new Cost(0.001, 0.002, 0.0, 0.0, 0.003))),
    ));
};
PHP);
        $started = $this->start();
        $codemode = $started->customTools->find('codemode');
        $events = [];
        $started->session->subscribe(static function ($event) use (&$events): void {
            if ($event instanceof ToolExecutionStartEvent || $event instanceof ToolExecutionEndEvent) {
                $events[] = $event;
            }
        });

        $result = Async::run(static fn () => ($codemode->execute)('call-9', ['code' => 'return parallel_settled([fn () => $tools->spend(["amount" => "lots"]), fn () => $tools->spend(["amount" => 3])]);'], null, $started->extensionRunner->context(), null));

        $value = json_decode($result->content[count($result->content) - 1]->text, true);
        $this->assertFalse($value[0]['ok']);
        $this->assertStringContainsString('Validation failed for tool "spend"', $value[0]['error'], 'the arguments are checked against the schema, with the message the model would read');
        $this->assertStringContainsString('amount', $value[0]['error']);
        $this->assertSame('spent', $value[1]['value']);
        $this->assertSame(['error', 'ok'], array_column($result->details['calls'], 'status'));

        // Upstream's `usage` on the result: what the script's calls spent is the script's to bill.
        $this->assertNotNull($result->usage);
        $this->assertSame(12, $result->usage->totalTokens, 'only the call that ran reported usage');
        $this->assertEqualsWithDelta(0.003, $result->usage->cost->total, 1e-9);

        // `tool_execution_*` events with `parentToolCallId`, so a listener sees the sub-calls.
        $this->assertSame(
            [['tool_execution_start', 'call-9/1', 'call-9'], ['tool_execution_end', 'call-9/1', 'call-9'], ['tool_execution_start', 'call-9/2', 'call-9'], ['tool_execution_end', 'call-9/2', 'call-9']],
            array_map(static fn ($e): array => [$e instanceof ToolExecutionStartEvent ? 'tool_execution_start' : 'tool_execution_end', $e->toolCallId, $e->parentToolCallId], $events),
        );
        $this->assertTrue($events[1]->isError);
        $this->assertFalse($events[3]->isError);
        $this->stop($started);
    }

    public function testTextItemsAreNumberedAndWhatEchoWroteFollowsInAConsoleBlock(): void
    {
        file_put_contents($this->home . '/settings.json', json_encode(['defaultTools' => ['+codemode']]));
        $started = $this->start();
        $codemode = $started->customTools->find('codemode');

        $result = Async::run(static fn () => ($codemode->execute)('1', ['code' => 'text("first"); echo "printed one\n"; text("second"); echo "printed two"; return "returned";'], null, $started->extensionRunner->context(), null));

        // Upstream's `formatOutput()` then `joinAdjacentText()`: one text block, each item headed.
        $this->assertCount(2, $result->content, 'the header and one joined text block');
        $this->assertSame(
            "==> text 1/3 <==\nfirst\n==> text 2/3 <==\nsecond\n==> text 3/3 <==\nreturned\n<console_output>\nprinted one\nprinted two\n</console_output>",
            $result->content[1]->text,
        );

        // One item gets no header, and a script that only returns reads as it did before.
        $alone = Async::run(static fn () => ($codemode->execute)('2', ['code' => 'return "just this";'], null, $started->extensionRunner->context(), null));
        $this->assertSame('just this', $alone->content[1]->text);
        $this->stop($started);
    }

    public function testOnModeTellsEachToolHowAScriptCallsItAndOnlyModeHidesThemFromTheModel(): void
    {
        file_put_contents($this->home . '/settings.json', json_encode(['defaultTools' => ['+codemode']]));
        $started = $this->start();
        $read = null;

        foreach ($started->session->agent->tools() as $tool) {
            if ($tool->definition()->name === 'read') {
                $read = $tool->definition();
            }
        }

        $this->assertNotNull($read);
        $this->assertStringEndsWith("\n\nCodemode: `\$tools->read([...])` resolves to a string.", $read->description, 'upstream\'s `on` mode: the declared tool says how a script calls it');
        $codemode = $started->customTools->find('codemode');
        $this->assertStringNotContainsString('### `read`', $codemode->description, 'in `on` mode the agent\'s own tools are not listed again');
        $this->stop($started);

        file_put_contents($this->home . '/settings.json', json_encode(['defaultTools' => ['+codemode'], 'codemode' => ['mode' => 'only']]));
        $started = $this->start();
        $this->assertSame(['codemode'], self::toolNames($started), 'upstream\'s `only` mode: the model is offered scripts alone');
        $declared = null;

        foreach ($started->session->agent->tools() as $tool) {
            $declared = $tool->definition()->description;
        }

        $this->assertStringContainsString('### `read`', (string) $declared, 'and codemode lists what it hid');
        $this->assertStringContainsString('### `bash`', (string) $declared);

        // The hidden tools are still callable: the extension kept the list the loadout handed it.
        file_put_contents($this->cwd . '/note.txt', "hidden but reachable\n");
        $codemode = $started->customTools->find('codemode');
        $result = Async::run(static fn () => ($codemode->execute)('1', ['code' => 'return trim($tools->read(["path" => "note.txt"]));'], null, $started->extensionRunner->context(), null));
        $this->assertSame('hidden but reachable', $result->content[count($result->content) - 1]->text);
        $this->stop($started);
    }

    public function testTheCodemodeToolAsksForGrammarSamplingSoAModelCanWriteRawSource(): void
    {
        file_put_contents($this->home . '/settings.json', json_encode(['defaultTools' => ['+codemode']]));
        $started = $this->start();
        $codemode = $started->customTools->find('codemode');

        $this->assertSame('grammar', $codemode->constrainedSampling['type']);
        $this->assertStringContainsString('@options', $codemode->constrainedSampling['variants']['openai_lark']);
        $this->assertSame(\Pig\Codemode\Source::GRAMMAR, $codemode->constrainedSampling['variants']['openai_lark']);
        $this->stop($started);
    }

    public function testDescribeNamespaceFindsAServerByAnyOfItsNamesAndSearchToolsFiltersByThem(): void
    {
        file_put_contents($this->home . '/settings.json', json_encode(['defaultTools' => ['+codemode']]));
        $started = $this->start();
        // Upstream 24382bedd: a namespace names its other names (`aliases`), in place of the rule that
        // took the part after its last `__`.
        $space = ['name' => 'mcp__dev-radius', 'aliases' => ['dev-radius'], 'description' => 'the radius server', 'instructions' => 'be gentle'];
        Registry::register('mcp__dev-radius__search', 'search radius', ['type' => 'object', 'properties' => []], static fn (): string => 'found', $space, 'codemode');
        Registry::register('mcp__dev-radius__fetch', 'fetch a radius page', ['type' => 'object', 'properties' => []], static fn (): string => 'page', $space, 'codemode');
        Registry::register('mcp__other__search', 'search elsewhere', ['type' => 'object', 'properties' => []], static fn (): string => 'x', ['name' => 'mcp__other', 'description' => null], 'codemode');
        $codemode = $started->customTools->find('codemode');

        $result = Async::run(static fn () => ($codemode->execute)('1', ['code' => <<<'PHP'
            return [
                describe_namespace('dev-radius'),
                describe_namespace('mcp__dev_radius')['tools'],
                describe_namespace('dev_radius')['name'],
                describe_namespace('nowhere'),
                array_column(search_tools('search', ['namespace' => 'dev_radius']), 'name'),
                array_column(search_tools('search', ['namespace' => 'mcp__other']), 'name'),
            ];
            PHP], null, $started->extensionRunner->context(), null));

        $value = json_decode($result->content[count($result->content) - 1]->text, true);
        $this->assertSame(['name' => 'mcp__dev-radius', 'description' => 'the radius server', 'instructions' => 'be gentle', 'tools' => ['mcp__dev_radius__search', 'mcp__dev_radius__fetch']], $value[0]);
        $this->assertSame(['mcp__dev_radius__search', 'mcp__dev_radius__fetch'], $value[1]);
        $this->assertSame('mcp__dev-radius', $value[2]);
        $this->assertNull($value[3]);
        $this->assertSame(['mcp__dev_radius__search'], $value[4], 'the namespace filter takes an alias in identifier form');
        $this->assertSame(['mcp__other__search'], $value[5]);
        $this->stop($started);
    }

    public function testTheModelsNamespaceAnswersTheCatalogueAndRefusesABadCallBeforeAnyProviderIsReached(): void
    {
        file_put_contents($this->home . '/settings.json', json_encode(['defaultTools' => ['+codemode']]));
        $started = $this->start();
        $codemode = $started->customTools->find('codemode');

        $result = Async::run(static fn () => ($codemode->execute)('1', ['code' => <<<'PHP'
            $chat = $models->getModelOfType('chat', 'anthropic', 'claude-sonnet-4-5');
            $classifiers = $models->getModelsOfType('classifier');
            $tries = [];
            foreach ([
                fn () => $models->getModelOfType('oops', 'a', 'b'),
                fn () => $models->getModelOfType('chat', 'anthropic/claude-sonnet-4-5'),
                fn () => $models->classify(null, []),
                fn () => $models->classify($chat, ['state' => [], 'questions' => []]),
                fn () => $models->classify($classifiers[0], ['state' => ['a' => 1], 'questions' => ['q' => ['type' => 'score', 'instructions' => 'rate', 'criteria' => 'bad']]]),
                fn () => $models->generateImages($models->getModelsOfType('image')[0], ['prompt' => 'a cat']),
                fn () => $models->Classify(),
                fn () => $models->classify($classifiers[0], ['state' => ['a' => 1], 'questions' => ['q' => ['type' => 'bool', 'instructions' => 'ok?', 'criteria' => ['true' => 'yes', 'false' => 'no']]], 'images' => ['not a block']]),
            ] as $try) {
                try { $try(); $tries[] = 'no error'; } catch (Throwable $e) { $tries[] = $e->getMessage(); }
            }
            $blind = $models->classify($models->getModelOfType('classifier', 'opencode', 'jev-1.13'), [
                'state' => ['a' => 1],
                'questions' => ['q' => ['type' => 'bool', 'instructions' => 'ok?', 'criteria' => ['true' => 'yes', 'false' => 'no']]],
                'images' => [['type' => 'image', 'data' => base64_encode('png'), 'mimeType' => 'image/png']],
            ]);
            return ['id' => $chat['id'], 'keys' => array_key_exists('headers', $chat), 'cost' => isset($chat['cost']['input']), 'classifiers' => count($classifiers) > 0, 'available' => $models->getAvailableOfType('chat', 'anthropic') !== [], 'tries' => $tries, 'blind' => [$blind['stopReason'], $blind['errorMessage']]];
            PHP], null, $started->extensionRunner->context(), null));

        $value = json_decode($result->content[count($result->content) - 1]->text, true);
        $this->assertSame('claude-sonnet-4-5', $value['id']);
        $this->assertFalse($value['keys'], 'headers can carry credentials and never reach a script');
        $this->assertTrue($value['cost'], 'the price list goes out under upstream\'s name');
        $this->assertTrue($value['classifiers']);
        $this->assertTrue($value['available'], 'the test key for anthropic counts as available');
        $this->assertStringContainsString('Unknown model type "oops". Use "chat", "image", or "classifier".', $value['tries'][0]);
        $this->assertStringContainsString('expects three strings', $value['tries'][1]);
        $this->assertStringContainsString('expects a classifier model as its first argument, got null. $models->getModelOfType() returns null', $value['tries'][2]);
        $this->assertStringContainsString('"anthropic/claude-sonnet-4-5" is a chat model, not a classifier model.', $value['tries'][3]);
        $this->assertStringContainsString('context.questions.q is a "score" question, so criteria must list the levels', $value['tries'][4]);
        $this->assertStringContainsString('context.input must be a non-empty list of blocks, got null', $value['tries'][5]);
        $this->assertStringContainsString('$models->Classify() does not exist. Did you mean $models->classify()?', $value['tries'][6]);
        $this->assertStringContainsString('context.images[0] must be an image block with base64 data and a mimeType, got a string', $value['tries'][7]);
        $this->assertSame('error', $value['blind'][0], 'a picture for a text-only classifier is an error result, not an exception');
        $this->assertStringContainsString('Model opencode/jev-1.13 does not accept image input', $value['blind'][1]);
        $this->assertCount(1, $result->details['calls'], 'only the image call for the text-only model reached Models::classify()');
        $this->assertSame('error', $result->details['calls'][0]['status']);
        $this->stop($started);
    }

    public function testGenerateImagesReachesAnExtensionsImageModelAndItsUsageIsBilledToTheScript(): void
    {
        // An extension's own image generation (upstream's provider `images`), reached the way every
        // image model is: listed by `getAvailableOfType('image')`, generated by `generateImages()`, its
        // usage on the codemode result where the session bills it.
        file_put_contents($this->home . '/settings.json', json_encode(['defaultTools' => ['+codemode']]));
        mkdir($this->home . '/extensions', 0o755, true);
        $seenKey = $this->home . '/seen-key';
        file_put_contents($this->home . '/extensions/pics.php', str_replace('SEEN_KEY', var_export($seenKey, true), <<<'PHP'
<?php
use Pig\Ai\AssistantImages;
use Pig\Ai\Cost;
use Pig\Ai\ImageContent;
use Pig\Ai\ImageModel;
use Pig\Ai\ImagesContext;
use Pig\Ai\ImagesOptions;
use Pig\Ai\StopReason;
use Pig\Ai\TextContent;
use Pig\Ai\Timestamp;
use Pig\Ai\Usage;
use Pig\CodingAgent\Extensions\ExtensionApi;
return function (ExtensionApi $pig): void {
    $pig->registerProvider('zzpics', [
        'baseUrl' => 'https://pics.example',
        'apiKey' => 'sk-pics',
        'models' => [['type' => 'image', 'id' => 'painter', 'name' => 'Painter', 'api' => 'zz-images', 'input' => ['text'], 'output' => ['image', 'text']]],
        'images' => ['zz-images' => static function (ImageModel $model, ImagesContext $context, ImagesOptions $options): AssistantImages {
            file_put_contents(SEEN_KEY, $options->apiKey . '|' . $context->input[0]->text);

            return new AssistantImages($model->api, $model->provider, $model->id, [new TextContent('painted'), new ImageContent('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg==', 'image/png')], StopReason::Stop, Timestamp::nowMs(), usage: new Usage(7, 1290, 0, 0, 1297, new Cost(0.0, 0.039, 0.0, 0.0, 0.039)));
        }],
    ]);
};
PHP));
        $started = $this->start();
        $codemode = $started->customTools->find('codemode');

        $result = Async::run(static fn () => ($codemode->execute)('1', ['code' => <<<'PHP'
            $available = $models->getAvailableOfType('image', 'zzpics');
            $r = $models->generateImages($available[0], ['input' => [['type' => 'text', 'text' => 'a cat']]]);
            foreach ($r['output'] as $block) { if ($block['type'] === 'image') { image($block); } }
            return ['ids' => array_column($available, 'id'), 'stop' => $r['stopReason'], 'types' => array_column($r['output'], 'type')];
            PHP], null, $started->extensionRunner->context(), null));

        $value = json_decode($result->content[count($result->content) - 1]->text, true);
        $this->assertSame(['painter'], $value['ids']);
        $this->assertSame('stop', $value['stop']);
        $this->assertSame(['text', 'image'], $value['types']);
        $this->assertSame('sk-pics|a cat', file_get_contents($seenKey), 'the provider\'s key reached the implementation');
        $images = array_values(array_filter($result->content, static fn ($b): bool => $b instanceof \Pig\Ai\ImageContent));
        $this->assertCount(1, $images);
        $this->assertSame('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg==', $images[0]->data);

        $this->assertNotNull($result->usage, 'billed to the codemode call');
        $this->assertSame(1297, $result->usage->totalTokens);
        $this->assertEqualsWithDelta(0.039, $result->usage->cost->total, 1e-9);
        $this->assertSame('ok', $result->details['calls'][0]['status']);
        $this->assertEqualsWithDelta(0.039, $result->details['calls'][0]['cost'], 1e-9);

        // `saveImages()` wrote the picture for the model; the label in front of it says where.
        $label = $result->content[array_search($images[0], $result->content, true) - 1];
        $this->assertInstanceOf(TextContent::class, $label);
        $this->assertSame(1, preg_match('#saved to (\S+\.png)#', $label->text, $m));
        unlink($m[1]);

        $this->stop($started);
    }

    public function testAntigravitysImageModelIsAvailableToAScriptOnceSignedIn(): void
    {
        file_put_contents($this->home . '/settings.json', json_encode(['defaultTools' => ['+codemode']]));
        $code = ['code' => <<<'PHP'
            return array_column($models->getAvailableOfType('image', 'antigravity'), 'id');
            PHP];

        $signedOut = $this->start(extensions: ['pig-antigravity']);
        $codemode = $signedOut->customTools->find('codemode');
        $content = Async::run(static fn () => ($codemode->execute)('1', $code, null, $signedOut->extensionRunner->context(), null))->content;
        $this->assertSame([], json_decode($content[count($content) - 1]->text, true), 'not before signing in: ' . $content[count($content) - 1]->text);
        $this->stop($signedOut);
        \Pig\Ai\Extension\ProviderRegistry::forget();

        $auth = Auth::inMemory(Settings::load($this->cwd, $this->home));
        $auth->setCredentials('antigravity', new \Pig\Ai\Utils\Oauth\Credentials('refresh', 'ya29.test', (int) (microtime(true) * 1000) + 3_600_000, projectId: 'proj-1'));
        $signedIn = $this->start(auth: $auth, extensions: ['pig-antigravity']);
        $codemode = $signedIn->customTools->find('codemode');
        $content = Async::run(static fn () => ($codemode->execute)('1', $code, null, $signedIn->extensionRunner->context(), null))->content;
        $value = json_decode($content[count($content) - 1]->text, true);
        $this->assertSame(['gemini-3.1-flash-image', 'gemini-3-pro-image', 'gemini-3-pro-image-preview'], $value);
        $this->stop($signedIn);
        \Pig\Ai\Extension\ProviderRegistry::forget();
    }

    public function testAToolResultWithAPictureInItReachesTheScriptAsABlockImageCanShow(): void
    {
        // Upstream's `models.generateImages()` answers image blocks that `image()` shows as they
        // are. pig's pictures come back from tools — `read` on a PNG, `generate_image` — and a
        // script used to get the text half only: "Saved image to …", and then a second `read`
        // to show what it had just made. The pictures ride beside the text now, MCP-shaped.
        file_put_contents($this->home . '/settings.json', json_encode(['defaultTools' => ['+codemode']]));
        // A 1×1 PNG is a valid PNG and is all `read` needs; nothing here reaches a provider.
        $png = base64_decode('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg==');
        file_put_contents($this->cwd . '/dot.png', $png);
        $started = $this->start();
        $codemode = $started->customTools->find('codemode');

        $result = Async::run(static fn () => ($codemode->execute)('1', ['code' => <<<'PHP'
            $r = $tools->read(['path' => 'dot.png']);
            image($r['images'][0]);
            return ['keys' => array_keys($r), 'mime' => $r['images'][0]['mimeType'], 'type' => $r['images'][0]['type']];
            PHP], null, $started->extensionRunner->context(), null));

        $images = array_values(array_filter($result->content, static fn ($b): bool => $b instanceof \Pig\Ai\ImageContent));
        $this->assertCount(1, $images, 'the picture the script showed is on the result');
        $this->assertSame(base64_encode($png), $images[0]->data, 'byte for byte: no re-encoding on the way through the sandbox');

        // Upstream's `saveImages()`: the model has no other way to reach the bytes it is shown.
        $at = array_search($images[0], $result->content, true);
        $label = $result->content[$at - 1];
        $this->assertInstanceOf(\Pig\Ai\TextContent::class, $label);
        $this->assertMatchesRegularExpression('#^\[Image saved to (\S+\.png) \(image/png, \d+B\)\]$#', $label->text, 'the path line sits right in front of the picture');
        preg_match('#saved to (\S+\.png)#', $label->text, $m);
        $this->assertSame($png, file_get_contents($m[1]), 'the file holds the bytes the model was shown');
        unlink($m[1]);
        $value = json_decode($result->content[count($result->content) - 1]->text, true);
        $this->assertSame(['text', 'images'], $value['keys']);
        $this->assertSame('image/png', $value['mime']);
        $this->assertSame('image', $value['type']);
        $this->stop($started);
    }

    public function testAPictureInAReturnedOrPrintedValueIsShownNotSentAsBase64(): void
    {
        // A script that returned a tool result whole — `return ['shot' => $tools->android_observe(...)]`
        // — sent the picture as base64 text: 30,000 tokens of a screenshot, cut off by the output
        // limit, that the model could not see. Upstream never hands a script a picture, so it
        // never had this; pig does, so a block inside a returned or printed value is shown.
        file_put_contents($this->home . '/settings.json', json_encode(['defaultTools' => ['+codemode']]));
        $png = base64_decode('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg==');
        file_put_contents($this->cwd . '/dot.png', $png);
        $started = $this->start();
        $codemode = $started->customTools->find('codemode');

        $result = Async::run(static fn () => ($codemode->execute)('1', ['code' => <<<'PHP'
            $r = $tools->read(['path' => 'dot.png']);
            text(['printed' => $r]);
            return ['returned' => $r];
            PHP], null, $started->extensionRunner->context(), null));

        $images = array_values(array_filter($result->content, static fn ($b): bool => $b instanceof \Pig\Ai\ImageContent));
        $this->assertCount(1, $images, 'the same picture twice is one image');
        $this->assertSame(base64_encode($png), $images[0]->data);

        $text = implode("\n", array_map(static fn ($b): string => $b->text, array_filter($result->content, static fn ($b): bool => $b instanceof \Pig\Ai\TextContent)));
        $this->assertStringNotContainsString(base64_encode($png), $text, 'no base64 in the text');
        $this->assertSame(2, substr_count($text, '"[image: image/png, shown as an image]"'), 'each place the block was says what became of it');
        foreach (glob(sys_get_temp_dir() . '/pig-codemode-*.png') ?: [] as $saved) {
            if (file_get_contents($saved) === $png) {
                unlink($saved);
            }
        }
        $this->stop($started);
    }

    /** Upstream #11501: a union or multi-line output type is summarised, not sent whole every request. */
    public function testUnionAndMultiLineOutputTypesAreSummarised(): void
    {
        file_put_contents($this->home . '/settings.json', json_encode(['defaultTools' => ['+codemode']]));
        $started = $this->start();
        $codemode = $started->customTools->find('codemode');
        $tool = static fn (string $name, array $outputSchema): AgentTool => new class ($name, $outputSchema) implements AgentTool {
            public function __construct(private string $name, private array $outputSchema)
            {
            }

            #[\Override]
            public function definition(): Tool
            {
                return new Tool($this->name, "{$this->name} tool", ['type' => 'object', 'properties' => []], outputSchema: $this->outputSchema);
            }

            #[\Override]
            public function label(): string
            {
                return $this->name;
            }

            #[\Override]
            public function execute(string $toolCallId, array $arguments, ?\Pig\Async\AbortSignal $signal = null, ?\Closure $onUpdate = null): AgentToolResult
            {
                return new AgentToolResult([]);
            }
        };
        $process = $tool('process', ['anyOf' => [
            ['type' => 'object', 'properties' => [
                'action' => ['const' => 'start', 'type' => 'string'],
                'process' => ['type' => 'object', 'properties' => ['id' => ['type' => 'string', 'description' => 'Process id'], 'pid' => ['type' => 'integer']], 'required' => ['id', 'pid']],
            ], 'required' => ['action', 'process']],
            ['type' => 'object', 'properties' => [
                'action' => ['const' => 'list', 'type' => 'string'],
                'processes' => ['type' => 'array', 'items' => ['type' => 'object', 'properties' => ['id' => ['type' => 'string']], 'required' => ['id']]],
                'truncated' => ['type' => 'boolean'],
            ], 'required' => ['action', 'processes']],
        ]]);
        $entries = $tool('entries', ['type' => 'array', 'items' => ['type' => 'object', 'properties' => ['id' => ['type' => 'string'], 'size' => ['type' => 'integer']], 'required' => ['id', 'size']]]);
        $count = $tool('count', ['type' => 'number']);

        $descriptions = ($codemode->prepareLoadout)([$process, $entries, $count])['descriptions'];

        $this->assertSame('process tool' . "\n\nCodemode: `\$tools->process([...])` resolves to `{ action: \"start\", process } | { action: \"list\", processes, truncated? }`.", $descriptions['process']);
        $this->assertSame('entries tool' . "\n\nCodemode: `\$tools->entries([...])` resolves to a value; `describe_tool(\"entries\")` shows its type.", $descriptions['entries']);
        $this->assertSame('count tool' . "\n\nCodemode: `\$tools->count([...])` resolves to `float`.", $descriptions['count']);
        $this->stop($started);
    }

    public function testBashResolvesToItsStructuredOutputEvenWhenTheCommandFails(): void
    {
        // Upstream's `bashOutputSchema` and `toScriptValue()`: `{ output, truncated,
        // full_output_path?, exit_code, wall_time_seconds }`, also for a non-zero exit — and the
        // session variables, which the session describes to every command.
        file_put_contents($this->home . '/settings.json', json_encode(['defaultTools' => ['+codemode']]));
        $started = $this->start();
        $bash = null;

        foreach ($started->session->agent->tools() as $tool) {
            if ($tool->definition()->name === 'bash') {
                $bash = $tool->definition();
            }
        }

        $this->assertNotNull($bash);
        $this->assertStringEndsWith(
            "\n\nCodemode: `\$tools->bash([...])` resolves to `{ output, truncated, full_output_path?, exit_code, wall_time_seconds }`.",
            $bash->description,
        );

        $codemode = $started->customTools->find('codemode');
        $result = Async::run(static fn () => ($codemode->execute)('1', ['code' => <<<'PHP'
            $ok = $tools->bash(['command' => 'printf "%s" "$PIG_SESSION_ID"']);
            $bad = $tools->bash(['command' => 'echo nope; exit 2']);
            return ['ok' => $ok['output'], 'okExit' => $ok['exit_code'], 'bad' => $bad['output'], 'badExit' => $bad['exit_code'], 'keys' => array_keys($bad)];
            PHP], null, $started->extensionRunner->context(), null));

        $value = json_decode($result->content[count($result->content) - 1]->text, true);
        $this->assertSame($started->session->store()?->id, $value['ok']);
        $this->assertSame(0, $value['okExit']);
        $this->assertSame("nope\n", $value['bad']);
        $this->assertSame(2, $value['badExit']);
        $this->assertSame(['output', 'truncated', 'exit_code', 'wall_time_seconds'], $value['keys']);
        $this->stop($started);
    }

    public function testAFailedScriptIsAnErrorThatStillShowsItsCalls(): void
    {
        file_put_contents($this->home . '/settings.json', json_encode(['defaultTools' => ['+codemode']]));
        $started = $this->start();
        $codemode = $started->customTools->find('codemode');

        try {
            Async::run(static fn () => ($codemode->execute)('1', ['code' => '$x = $tools->read(["path" => "nope.txt"]); return $x;'], null, $started->extensionRunner->context(), null));
            $this->fail('the script failed');
        } catch (\Pig\Agent\AgentError $error) {
            $this->assertStringContainsString("Script failed", $error->getMessage());
            $this->assertStringContainsString('Script error:', $error->getMessage());
            $this->assertStringContainsString('Tool calls made before the failure (they are not undone): read (error)', $error->getMessage());
            $this->assertSame('read', $error->details['calls'][0]['name']);
        }

        try {
            Async::run(static fn () => ($codemode->execute)('1', ['code' => '   '], null, $started->extensionRunner->context(), null));
            $this->fail('refused');
        } catch (\Pig\Agent\AgentError $error) {
            $this->assertStringContainsString('Expected PHP source text', $error->getMessage());
        }

        $this->stop($started);
    }

    public function testTheStoreSurvivesBetweenScriptsThroughTheSessionFile(): void
    {
        file_put_contents($this->home . '/settings.json', json_encode(['defaultTools' => ['+codemode']]));
        $started = $this->start();
        $codemode = $started->customTools->find('codemode');
        $ctx = $started->extensionRunner->context();

        Async::run(static fn () => ($codemode->execute)('1', ['code' => 'store("count", 41); return null;'], null, $ctx, null));
        $result = Async::run(static fn () => ($codemode->execute)('2', ['code' => 'return load("count") + 1;'], null, $ctx, null));

        $this->assertSame('42', $result->content[count($result->content) - 1]->text);
        $entries = $started->store->customEntries('codemode-store');
        $this->assertCount(1, $entries, "upstream's entry type, so a conversation moved to pi keeps its store");
        $this->assertSame(['set' => ['count' => 41], 'delete' => []], $entries[0]->data);
        $this->stop($started);
    }

    public function testOutputPastTheBudgetIsCutInTheMiddleAndSaved(): void
    {
        file_put_contents($this->home . '/settings.json', json_encode(['defaultTools' => ['+codemode']]));
        $started = $this->start();
        $codemode = $started->customTools->find('codemode');

        $result = Async::run(static fn () => ($codemode->execute)('1', ['code' => "// @options: {\"max_output_tokens\": 100}\nforeach (range(1, 300) as \$i) { text(\"line {\$i}\"); } return null;"], null, $started->extensionRunner->context(), null));

        $text = $result->content[1]->text;
        $this->assertStringStartsWith('Warning: truncated output (original token count:', $text);
        $this->assertStringContainsString('line 1', $text);
        $this->assertStringContainsString('line 300', $text);
        $this->assertStringContainsString('chars truncated', $text);
        $this->assertFileExists($result->details['fullOutputPath']);
        $this->assertStringContainsString("line 150\n", (string) file_get_contents($result->details['fullOutputPath']));
        unlink($result->details['fullOutputPath']);
        $this->stop($started);
    }
}
