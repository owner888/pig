<?php

declare(strict_types=1);

namespace Pig\CodingAgent\Test;

use Closure;
use PHPUnit\Framework\Attributes\DataProvider;
use PHPUnit\Framework\TestCase;
use Pig\CodingAgent\Theme\Themes;
use Pig\Agent\Agent;
use Pig\Agent\AgentOptions;
use Pig\Agent\QueueMode;
use Pig\Agent\ThinkingLevel;
use Pig\Ai\Api;
use Pig\Ai\AssistantMessage;
use Pig\Ai\Context;
use Pig\Ai\DoneEvent;
use Pig\Ai\ErrorEvent;
use Pig\Ai\ImageContent;
use Pig\Ai\Model;
use Pig\Ai\Models;
use Pig\Ai\SimpleStreamOptions;
use Pig\Ai\StartEvent;
use Pig\Ai\StopReason;
use Pig\Ai\TextContent;
use Pig\Ai\ToolCall;
use Pig\Ai\ToolCallEndEvent;
use Pig\Ai\Cost;
use Pig\Ai\Usage;
use Pig\Ai\UserMessage;
use Pig\Ai\Utils\AssistantMessageEventStream;
use Pig\Async\Async;
use Pig\Async\Loop;
use Pig\CodingAgent\Changelog;
use Pig\CodingAgent\Cli\UpdateCheck;
use Pig\CodingAgent\CustomTools\CustomTool;
use Pig\CodingAgent\CustomTools\CustomToolSet;
use Pig\CodingAgent\CustomTools\LoadedCustomTool;
use Pig\CodingAgent\Extensions\ExtensionApi;
use Pig\CodingAgent\Extensions\ExtensionGuardedTool;
use Pig\CodingAgent\Extensions\ExtensionRunner;
use Pig\CodingAgent\Extensions\LoadedExtension;
use Pig\CodingAgent\Interactive\FooterComponent;
use Pig\CodingAgent\Interactive\InteractiveMode;
use Pig\CodingAgent\ModelResolver;
use Pig\CodingAgent\Prompt\ContextFile;
use Pig\CodingAgent\Prompt\FileCommand;
use Pig\CodingAgent\Prompt\Skill;
use Pig\CodingAgent\Session\BashExecution;
use Pig\CodingAgent\Session\CompactionSummary;
use Pig\CodingAgent\Session\AgentSession;
use Pig\CodingAgent\Session\CustomMessage;
use Pig\CodingAgent\Session\SessionManager;
use Pig\Ai\Extension\OauthFlow;
use Pig\Ai\Extension\ProviderRegistry;
use Pig\Ai\Utils\Oauth\OauthError;
use Pig\Ai\Utils\Oauth\Credentials;
use Throwable;
use Pig\Ai\Utils\Oauth\Provider;
use Pig\Ai\TranscriptContext;
use Pig\CodingAgent\Auth;
use Pig\CodingAgent\Settings;
use Pig\CodingAgent\Tools\ToolSet;
use Pig\Test\ProbeModels;
use Pig\Test\WithoutProviderKeys;
use Pig\Tui\Ansi;
use Pig\Tui\Autocomplete\AutocompleteItem;
use Pig\Tui\Autocomplete\AutocompleteProvider;
use Pig\Tui\Autocomplete\Completion;
use Pig\Tui\Autocomplete\Suggestions;
use Pig\Tui\Components\Editor;
use Pig\CodingAgent\Interactive\CustomEditor;
use Pig\Tui\TuiAltScreen;
use Pig\Tui\Width;
use Pig\Tui\Components\Text;
use Pig\Tui\Test\FakeClipboard;
use Pig\Tui\Test\FakeTerminal;
use RuntimeException;

/**
 * The terminal around the agent, driven by typing into a fake one.
 *
 * Nothing here runs the event loop to completion: the loop is what `run()` blocks on,
 * and a test that entered it would never come back. `start()` draws the first frame and
 * the keystrokes go in by hand, which is the same path a real key takes.
 */
final class InteractiveModeTest extends TestCase
{
    use GlobalThemeFixture;
    use ProbeModels;
    use WithoutProviderKeys;

    private const string ESC = "\e";

    private const string ENTER = "\r";
    /** The kitty form: `\e\r` is Apple Terminal's Shift+Enter and is a new line. */
    private const string ALT_ENTER = "\e[13;3u";
    private const string CTRL_ENTER = "\e[13;5u";
    private const string CMD_ENTER = "\x1b[13;9u";
    private const string SHIFT_ENTER = "\x1b[13;2u";
    private const string ALT_UP = "\e[1;3A";

    private FakeTerminal $terminal;

    private AgentSession $session;

    private InteractiveMode $mode;

    /** @var list<string|AssistantMessage> a bare string is an answer of that text */
    private array $answers = [];

    /** Set while a test is holding the agent mid-run; the stream it is waiting on. */
    private ?AssistantMessageEventStream $held = null;

    private bool $holding = false;

    /** Model calls to let through before the next one is held. */
    private int $letThrough = 0;

    private string $cwd;

    private string $home;

    private FakeClipboard $clipboard;

    private Settings $settings;

    #[\Override]
    protected function setUp(): void
    {
        $this->setUpGlobalTheme();
        Loop::reset();
        // `/login` says the URL and then opens it; with this unset, every run of this file opened
        // the developer's real browser on Anthropic's authorize page. The tests read the screen.
        putenv('PIG_OFFLINE=1');
        $this->held = null;
        $this->holding = false;
        $this->letThrough = 0;
        $this->terminal = new FakeTerminal(80, 24);
        $this->cwd = sys_get_temp_dir() . '/pig-interactive-' . bin2hex(random_bytes(4));
        $this->home = $this->cwd . '-home';
        mkdir($this->cwd, 0o755, true);
        putenv('PIG_CODING_AGENT_DIR=' . $this->home);

        // `/model` lists the models there is a key for when this mode is given an `Auth`, and what
        // the shell running the suite exports is not something an assertion should turn on.
        $this->forgetProviderKeys();

        // The scope cases need two models with known ids; which ones providers sell is not
        // what they are about — see `ProbeModels`.
        self::registerProbeModels();
    }

    #[\Override]
    protected function tearDown(): void
    {
        $this->tearDownGlobalTheme();
        $this->mode->stop();
        putenv('PIG_CODING_AGENT_DIR');
        putenv('PIG_OFFLINE');
        $this->restoreProviderKeys();
        Models::forgetRegistered();
        // The mode points the TUI's process-wide keybinding registry at its own manager.
        \Pig\Tui\Keybindings::reset();
        self::remove($this->home);
        self::remove($this->cwd);
    }

    private static function remove(string $path): void
    {
        if (is_dir($path) && !is_link($path)) {
            foreach (scandir($path) ?: [] as $entry) {
                if ($entry !== '.' && $entry !== '..') {
                    self::remove($path . '/' . $entry);
                }
            }

            rmdir($path);

            return;
        }

        if (file_exists($path)) {
            unlink($path);
        }
    }

    private function startWithContext(): void
    {
        $this->start(context: [new ContextFile('/somewhere/AGENTS.md', 'be careful')]);
    }

    /**
     * @param list<string|AssistantMessage> $answers one per model call
     * @param list<ContextFile>             $context
     * @param list<string>                  $tools which built-ins the agent is given
     */
    private function start(
        array $answers = [],
        bool $reasoning = false,
        array $context = [],
        bool $store = false,
        ?string $resume = null,
        array $skills = [],
        array $fileCommands = [],
        ?Settings $settings = null,
        ?ExtensionRunner $extensionRunner = null,
        ?CustomToolSet $customTools = null,
        array $initialMessages = [],
        array $initialImages = [],
        ?Auth $auth = null,
        ?string $changelog = null,
        array $tools = ['read'],
        array $modelScope = [],
        bool $projectTrusted = true,
        ?\Pig\CodingAgent\Keybindings $keybindings = null,
        ?string $tuiMode = null,
        ?Closure $createRuntime = null,
        bool $incognito = false,
        array $extensions = [],
    ): void {
        $this->clipboard = new FakeClipboard();
        $this->settings = $settings ?? Settings::inMemory();
        // The session would ask the scripted model for its name after the first prompt, and take an
        // answer meant for the next one: off here, its own tests are in AgentSettledTest.
        $this->settings->setAutoSessionNameEnabled(false);
        $this->answers = $answers;
        $agent = new Agent(new AgentOptions(streamFn: $this->provider(...), apiKey: 'k'));
        $agent->setModel(new Model(
            'claude-test',
            'Test',
            Api::AnthropicMessages,
            'anthropic',
            'http://127.0.0.1:1',
            200_000,
            64_000,
            $reasoning,
        ));

        // The same shape `CodingAgent::create()` builds: one built-in plus whatever was
        // loaded, wrapped. Without the tools `/tools` would be answering about an agent that
        // has none; without the wrapping no `tool_call` hook fires at all, so a guard that
        // works in production could not be reached from here.
        $agent->setTools(ExtensionGuardedTool::wrap(
            [...ToolSet::create($this->cwd, $tools), ...($customTools?->agentTools() ?? [])],
            $extensionRunner ?? new ExtensionRunner(),
        ));

        $saved = match (true) {
            $resume !== null => SessionManager::open($resume),
            $store => SessionManager::create($this->cwd),
            default => null,
        };

        // The settings go to the session as well as to the mode, because that is what `bin/pig`
        // does — and the session reads them for the queue mode, auto-compaction and auto-retry.
        // Passing null here meant three settings that were live in production and inert in
        // every test. The file commands are the same shape and arrived the same way: the session
        // is what expands one now, so a list given only to the mode would leave the expansion
        // inert here too.
        $this->session = new AgentSession(
            $agent,
            $this->cwd,
            $saved,
            $this->settings,
            $extensionRunner,
            $fileCommands,
            $modelScope,
            incognito: $incognito,
        );

        if ($resume !== null && $saved !== null) {
            $this->session->restore($saved->messages());
        }
        $this->mode = new InteractiveMode(
            $this->session,
            $this->cwd,
            '0.0.0',
            'dark',
            $this->terminal,
            $context,
            $skills,
            $this->clipboard,
            $fileCommands,
            $this->settings,
            $extensionRunner,
            $customTools,
            $initialMessages,
            $initialImages,
            $auth,
            $changelog,
            extensions: $extensions,
            projectTrusted: $projectTrusted,
            keybindings: $keybindings ?? new \Pig\CodingAgent\Keybindings(),
            tuiMode: $tuiMode,
            createRuntime: $createRuntime,
        );

        $this->mode->start();
    }

    // ---- crashes --------------------------------------------------------------------------------

    public function testSlashBugAsksBeforeItWritesAnything(): void
    {
        // `/bug` read `$this->terminalUi`, a property this class has never had — the field is
        // `$ui` — so the one command that exists for reporting a fault failed with
        // `Undefined property` the moment it was typed, inside the spawned fiber where the only
        // thing on screen was PHP's warning. Nothing drove the command through the screen.
        $this->start();
        $this->type('/bug something odd');
        $this->type(self::ENTER);
        $this->settle();

        // Upstream's order: what went wrong first, with the hint typed after `/bug` in the field.
        $this->assertStringContainsString('What went wrong? (optional)', $this->screenText());
        $this->assertStringContainsString('something odd', $this->screenText());
        $this->type(self::ENTER);
        $this->settle();

        $this->assertStringContainsString('Include the session transcript?', $this->screenText(), 'the question is asked');
        $this->assertStringNotContainsString('Undefined property', $this->screenText());

        // Escape is the no, and here it is also "not now": nothing is written and nothing opens.
        $this->type(self::ESC);
        $this->settle();

        $this->assertStringNotContainsString('Include the session transcript?', $this->screenText());
        $this->assertStringContainsString('Bug report cancelled', $this->screenText());
    }

    public function testSlashBugExportsAZipWithoutTheTranscriptAndRecordsIt(): void
    {
        $this->start(['the answer'], store: true);
        $this->type('hello');
        $this->type(self::ENTER);
        $this->settle();

        $this->type('/bug the footer');
        $this->type(self::ENTER);
        $this->settle();
        $this->type(self::ENTER); // the description, as typed
        $this->settle();
        $this->type("\e[B");      // transcript: No
        $this->type(self::ENTER);
        $this->settle();
        $this->assertStringContainsString('Attach a summary written by', $this->screenText());
        $this->type("\e[B");      // summary: No
        $this->type(self::ENTER);
        $this->settle();
        $this->assertStringContainsString('Transcript: not included', $this->screenText());
        $this->type("\e[B");      // Export as Zip
        $this->type(self::ENTER);
        $this->settle();

        $zips = glob($this->cwd . '/pig-bug-report-*.zip') ?: [];
        $this->assertCount(1, $zips);
        $this->assertStringContainsString('Bug report exported to: ' . $zips[0], $this->screenText());
        $this->assertStringContainsString('report.md', (string) file_get_contents($zips[0]));
        $this->assertStringNotContainsString('session.jsonl', (string) file_get_contents($zips[0]));

        $recorded = $this->session->store()?->customEntries(\Pig\CodingAgent\BugReport::CUSTOM_ENTRY_TYPE) ?? [];
        $this->assertCount(1, $recorded);
        $this->assertSame('zip', $recorded[0]->data['delivery']);
        $this->assertSame('the footer', $recorded[0]->data['hint']);
        $this->assertFalse($recorded[0]->data['sessionIncluded']);
    }

    public function testTheLastCrashIsAnnouncedOnceAtStartup(): void
    {
        \Pig\CodingAgent\CrashLog::record('fatal_error', new RuntimeException('it fell over'), null, $this->cwd);

        $this->start();
        $this->assertStringContainsString('pig crashed on', $this->screenText());
        $this->assertStringContainsString('(it fell over). Run /bug', $this->screenText());

        $this->mode->stop();
        Loop::reset();
        $this->start();
        $this->assertStringNotContainsString('pig crashed on', $this->screenText());
    }

    public function testAThrowTheLoopCaughtIsWrittenDownForBug(): void
    {
        $this->start();
        $this->assertSame([], \Pig\CodingAgent\CrashLog::read());

        Loop::get()->defer(static function (): void {
            throw new RuntimeException('render died');
        });
        $this->settle();

        $records = \Pig\CodingAgent\CrashLog::read();
        $this->assertCount(1, $records);
        $this->assertSame('loop_error', $records[0]['kind']);
        $this->assertSame('render died', $records[0]['message']);
        $this->assertStringContainsString('render died', $this->screenText(), 'and it is still drawn');
    }

    // ---- /trust ---------------------------------------------------------------------------------

    public function testAnUntrustedProjectSaysSoOnScreenAndSlashTrustSavesADecision(): void
    {
        mkdir($this->cwd . '/.pig/extensions', 0o755, true);
        $this->start(projectTrusted: false);

        $this->assertStringContainsString('This project is not trusted', $this->screenText());

        $this->type('/trust');
        $this->type("\r");
        $this->assertStringContainsString('this session: not trusted, no saved decision', $this->screenText());

        // The first row is "Trust".
        $this->type("\r");

        $this->assertStringContainsString('Saved trust decision: trusted. Restart pig', $this->screenText());
        $this->assertTrue(\Pig\CodingAgent\ProjectTrust::decision($this->cwd, $this->home));
    }

    public function testATrustedProjectIsNotWarnedAboutAndEscapeLeavesTheFileAlone(): void
    {
        mkdir($this->cwd . '/.pig/extensions', 0o755, true);
        $this->start();

        $this->assertStringNotContainsString('This project is not trusted', $this->screenText());

        $this->type('/trust');
        $this->type("\r");
        $this->type("\e");

        $this->assertFileDoesNotExist($this->home . '/trust.json');
    }

    private function provider(Model $model, TranscriptContext $context, SimpleStreamOptions $options): AssistantMessageEventStream
    {
        $answer = array_shift($this->answers) ?? throw new RuntimeException('out of scripted answers');
        $message = $answer instanceof AssistantMessage ? $answer : self::message($answer);
        $stream = new AssistantMessageEventStream();

        // Held open: the two tests about typing mid-run need the agent to still be
        // working when the next key arrives, which an instant answer never is.
        if ($this->held === null && $this->holding) {
            if ($this->letThrough > 0) {
                $this->letThrough--;
            } else {
                $this->held = $stream;
                $this->answers[] = $answer;

                $options->signal?->onAbort(function () use ($stream, $message): void {
                    $aborted = new AssistantMessage(
                        $message->content,
                        $message->api,
                        $message->provider,
                        $message->model,
                        $message->usage,
                        StopReason::Aborted,
                        'Aborted',
                    );
                    $stream->push(new StartEvent($aborted));
                    $stream->push(new ErrorEvent(StopReason::Aborted, $aborted));
                    $stream->end($aborted);
                });

                return $stream;
            }
        }

        Async::spawn(static function () use ($stream, $message): void {
            $stream->push(new StartEvent($message));

            // Each call announced as it closes, which is what every real provider does and
            // what gives the terminal a component to draw before the message ends. Without
            // it the first thing the UI hears about a call is that it has started running.
            foreach ($message->content as $index => $block) {
                if ($block instanceof ToolCall) {
                    $stream->push(new ToolCallEndEvent($index, $block, $message));
                }
            }

            $stream->push(new DoneEvent($message->stopReason, $message));
            $stream->end();
        });

        return $stream;
    }

    private static function costing(Usage $usage, string $text = 'ok'): AssistantMessage
    {
        return new AssistantMessage([new TextContent($text)], Api::AnthropicMessages, 'anthropic', 'claude-test', $usage, StopReason::Stop);
    }

    private static function message(string $text): AssistantMessage
    {
        return new AssistantMessage(
            [new TextContent($text)],
            Api::AnthropicMessages,
            'anthropic',
            'claude-test',
            new Usage(),
            StopReason::Stop,
        );
    }

    private function type(string $text): void
    {
        $this->terminal->type($text);
    }

    /** What is in the prompt right now. */
    private function editorText(): string
    {
        $editor = (new \ReflectionProperty($this->mode, 'editor'))->getValue($this->mode);

        return $editor->text();
    }

    /** Everything on screen right now, without the escape codes. */
    private function screen(): string
    {
        return implode("\n", array_map(Ansi::strip(...), $this->mode->screen()->render(80)));
    }

    /** How many rows a picker says it has, from the `(3/57)` it draws under a long list. */
    private function pickerTotal(): int
    {
        return preg_match('/\(\d+\/(\d+)\)/', $this->screen(), $found) === 1 ? (int) $found[1] : 0;
    }

    /**
     * The row a picker has the selection on, which is the arrow's line.
     *
     * For a fuzzy-filtered list this is the assertion worth making: everything matches a little,
     * and what the filter is *for* is putting the right row under the cursor.
     */
    private function selectedRow(): string
    {
        foreach (explode("\n", $this->screen()) as $line) {
            if (str_contains($line, '→ ')) {
                return $line;
            }
        }

        return '';
    }

    /**
     * The screen as one run of words, for asserting on a sentence the renderer may have wrapped.
     *
     * **A line break inside the text is the renderer working, not a difference in the text.** The
     * export test asserted `Exported to <path>` against `screen()` and passed only where the
     * temporary directory was short: on macOS the path is
     * `/var/folders/mk/6fds…/T/pig-interactive-…` and the sentence wraps across three rows, so the
     * assertion failed on a machine where the feature was working perfectly. Reproduced in the
     * container by pointing `TMPDIR` at a path of that shape. Use this whenever the thing being
     * asserted is the *words*; use `screen()` when the layout is the point.
     *
     * **Rendered wide rather than de-wrapped**, because collapsing whitespace does not undo a wrap:
     * 80 columns split the path at `out.` / `html`, and joining those with a space gives
     * `out. html`, which is not the filename either. A width nothing wraps at is the only way to
     * read the text back as it was written.
     */
    private function screenText(int $width = 400): string
    {
        $lines = array_map(Ansi::strip(...), $this->mode->screen()->render($width));

        return trim((string) preg_replace('/ +/', ' ', implode(' ', $lines)));
    }

    /**
     * Turn the loop without waiting out whatever timer is pending.
     *
     * `settle()` polls with no timeout of its own, so with a retry's half-minute timer armed and
     * nothing to read it `usleep()`s for the whole of it. An expired timer of our own makes the
     * poll return at once, which is what lets a test look at a countdown rather than sit through it.
     */
    private static function turnTheLoop(int $ticks = 100): void
    {
        for ($tick = 0; $tick < $ticks; $tick++) {
            Loop::get()->delay(0.0, static fn () => null);
            Loop::get()->tick();
        }
    }

    /** A turn that comes back as a provider failure, which is what auto-retry is for. */
    private static function failed(string $error): AssistantMessage
    {
        return new AssistantMessage(
            [],
            Api::AnthropicMessages,
            'anthropic',
            'claude-test',
            new Usage(),
            StopReason::Error,
            $error,
        );
    }

    /** Run the loop until it has nothing left to do, so a spawned prompt can finish. */
    /**
     * Run what the loop has to do now and soon — callbacks, I/O, a render a few milliseconds off —
     * and stop at what is far off. A working loader's next frame is always 80ms away, so waiting
     * for the loop to go idle while the agent works meant fifty ticks of waiting for frames: 1.9s
     * a call, most of this file's minute and a half.
     */
    private function settle(): void
    {
        $loop = Loop::get();

        for ($tick = 0; $tick < 50 && !$loop->isIdle(); $tick++) {
            $next = $loop->nextTimerIn();
            if (!$loop->isWatchingStreams() && ($next === null || $next > 0.05)) {
                return;
            }
            $loop->tick();
        }
    }

    // ---- the first frame ------------------------------------------------------------

    public function testTheDebugKeyWritesTheFrameAndTheConversation(): void
    {
        // The renderer has intercepted shift+ctrl+d and offered `onDebug` since it was ported,
        // and nothing ever called the setter — so the key that works whatever holds the focus did
        // nothing, and the frame dump `checkWidth()` writes on a fault could only be got by
        // causing one. Both ends are here now.
        $this->start(answers: ['an answer of some length']);
        $this->type('say something');
        $this->type(self::ENTER);
        $this->settle();

        // Shift+ctrl has no control character; only a kitty terminal can report it.
        $this->type("\e[100;6u");
        $this->settle();

        $path = getenv('PIG_CODING_AGENT_DIR') . '/pig-debug.log';
        $this->assertFileExists($path);

        $written = (string) file_get_contents($path);

        // The frame, with a width per line, which is the pair that makes a padding bug obvious.
        $this->assertStringContainsString('=== the frame ===', $written);
        $this->assertMatchesRegularExpression('/\[0\] \(w=\d+\)/', $written);

        // And what was said, as the session file's own shape rather than a second one.
        $this->assertStringContainsString('=== the conversation ===', $written);
        $this->assertStringContainsString('say something', $written);
        $this->assertStringContainsString('an answer of some length', $written);

        // A conversation holds whatever the model read.
        $this->assertSame('0600', substr(sprintf('%o', fileperms($path)), -4));
    }

    public function testTheDebugCommandWritesTheSameThingWithoutBeingListed(): void
    {
        $this->start();
        $this->type('/debug');
        $this->type(self::ENTER);
        $this->settle();

        $this->assertFileExists(getenv('PIG_CODING_AGENT_DIR') . '/pig-debug.log');

        // Known and not offered, like `quit`: `COMMANDS` is what `/help` prints and what the
        // autocomplete lists, and this is for reporting a fault rather than for using pig.
        $this->type('/help');
        $this->type(self::ENTER);
        $this->settle();

        $this->assertStringNotContainsString('/debug', $this->screen());
    }

    public function testTypingAfterSlashModelOffersModelsRatherThanFileNames(): void
    {
        // `SlashCommand::$argumentCompletions` is read by the provider and was supplied by nobody,
        // so the docblock's own example — "`/model <tab>` lists models rather than files" — was a
        // claim about the repository that the repository did not keep: past the first space Tab
        // means a path, so `/model s` offered whatever files happen to sit in the project.
        file_put_contents($this->cwd . '/sonnet-notes-for-the-picker.txt', 'x');

        $this->start();
        // No Tab: a command's own completions are the *automatic* list, offered as you type, and
        // Tab is then how you take one. Tab before the list exists means a path, and past a
        // command that answers for its argument it means neither — which is the fix.
        // The last keystroke on its own, because one chunk is one key: a `type()` of the whole
        // string arrives as a single seventeen-character key, and what opens the list is a typed
        // *letter or digit* inside a line that starts with a slash.
        $this->type('/model sonnet-4-');
        $this->type('5');
        $this->settle();

        $screen = $this->screen();

        // A real model id, which can only be on screen because a list of models was offered — the
        // footer says `claude-test`, so asserting on that would be an assertion that cannot fail.
        $this->assertStringContainsString('claude-sonnet-4-5', $screen);
        $this->assertStringNotContainsString('sonnet-notes-for-the-picker.txt', $screen);
    }

    public function testTabAfterACommandThatAnswersForItsArgumentIsNotAPath(): void
    {
        // The other door, and the one that made `shouldCompleteFiles()` a public method with no
        // caller: a space closes the automatic list, so the next Tab had nothing open and went
        // straight to the filesystem. `Editor::completeOnTab()` spelled the rule itself instead of
        // asking the provider, which is the only thing that knows `/model` answers for its own
        // argument.
        file_put_contents($this->cwd . '/notes-after-a-space.txt', 'x');

        $this->start();
        $this->type('/model');
        $this->type(' ');
        $this->type("\t");
        $this->settle();

        $screen = $this->screen();

        $this->assertStringNotContainsString('notes-after-a-space.txt', $screen);
        // A provider name, which is the description on each offered model and appears nowhere else
        // on this screen — the footer carries the model id alone.
        $this->assertStringContainsString('anthropic', $screen, 'the whole list, since nothing narrows it');

        // And once something *has* been typed after the space. Escape first, because a list that is
        // already open takes Tab as "accept this one" and never reaches the question — dismissing it
        // and pressing Tab is the one way back to asking, and the way a file name got in.
        $this->type('sonnet-4-');
        $this->type('5');
        $this->type(self::ESC);
        $this->type("\t");
        $this->settle();

        $narrowed = $this->screen();

        $this->assertStringNotContainsString('notes-after-a-space.txt', $narrowed);
        $this->assertStringContainsString('claude-sonnet-4-5', $narrowed);
    }

    public function testTypingAfterSlashThemeOffersAvailableThemes(): void
    {
        $this->start();
        $this->type('/theme');
        $this->type(' ');
        $this->type('d');
        $this->settle();

        $screen = $this->screen();
        $this->assertStringContainsString('dark', $screen);
    }

    public function testSwitchingThemeDoesNotWriteTheWholeFrameUnderItself(): void
    {
        // `requestRender(true)` empties what the screen is believed to hold, and the renderer
        // reads an empty `previousLines` as "first frame ever" — so it writes every line with no
        // clear, starting from wherever the cursor is, which is the bottom of the frame already
        // there. That is the trap in docs/dev/traps/tui.md about the forced render, and `/theme` is the third
        // caller to make it: nothing overwrote this screen, so there is a previous frame to diff
        // against and a plain render rewrites only the lines whose colours changed.
        $this->start();
        $this->settle();

        // `/theme` opens the picker: system, dark (on), labra, light.
        $this->type('/theme');
        $this->type(self::ENTER);
        $this->type(self::DOWN);
        $this->type(self::DOWN);
        $this->settle();

        $this->terminal->clearWrites();
        $this->type(self::ENTER);
        $this->settle();

        $written = $this->terminal->output();

        $this->assertStringContainsString('Theme: light', Ansi::strip($written), 'it did switch');

        // The bytes, because `FakeTerminal` records writes and not a screen: a differential update
        // clears each line it rewrites (`\e[2K`), and the first-frame path — which is what an
        // emptied `previousLines` selects — emits none of those and no cursor move either. Counting
        // how often the banner is written cannot tell them apart, because `requestRender()`
        // coalesces: the plain render `say()` asked for and the forced one become a single draw.
        $this->assertStringContainsString("\x1b[2K", $written, 'a differential update, not a fresh frame');
    }

    public function testSwitchingToSpecificThemeLikeLabraWorksAndIsRemembered(): void
    {
        $this->start();
        $this->settle();

        $this->terminal->clearWrites();
        $this->type('/theme labra');
        $this->type(self::ENTER);
        $this->settle();

        $written = $this->terminal->output();
        $this->assertStringContainsString('Theme: labra', Ansi::strip($written));
        $this->assertSame('labra', $this->settings->theme());
    }

    public function testSwitchingToUnknownThemeReportsAvailableThemes(): void
    {
        $this->start();
        $this->settle();

        $this->terminal->clearWrites();
        $this->type('/theme unknown-theme');
        $this->type(self::ENTER);
        $this->settle();

        $written = $this->terminal->output();
        $this->assertStringContainsString("No theme called 'unknown-theme'", Ansi::strip($written));
        $this->assertStringContainsString('Available themes: system, dark, labra', Ansi::strip($written));
    }

    public function testThePickerPreviewsEachThemeAndEscapePutsTheOldOneBack(): void
    {
        $this->start();
        $this->settle();

        $this->type('/theme');
        $this->type(self::ENTER);
        $this->type(self::DOWN);
        $this->settle();

        $this->assertSame('labra', Themes::theme()->name, 'moving onto a theme previews it');
        $this->assertNull($this->settings->theme(), 'a preview is not saved');

        $this->type(self::ESCAPE);
        $this->settle();

        $this->assertSame('dark', Themes::theme()->name);
        $this->assertNull($this->settings->theme());
    }

    public function testASwitchedThemeRecoloursTheBannerAndTheChatsLinesWithoutReplayingThem(): void
    {
        // Upstream's `ThemedText`: the banner and a `say()` line are built when drawn, so the
        // controller's invalidation recolours them in place — nothing rebuilds the chat.
        $this->start();
        $this->type('/name before the switch');
        $this->type(self::ENTER);
        $this->settle();

        $chat = (new \ReflectionProperty($this->mode, 'chat'))->getValue($this->mode);
        $before = $chat->children();
        $line = fn (string $needle): string => array_values(array_filter(
            $this->mode->screen()->render(80),
            static fn (string $row): bool => str_contains(Ansi::strip($row), $needle),
        ))[0] ?? '';

        $dark = Themes::theme();
        $this->assertStringContainsString($dark->getFgAnsi('dim'), $line('Session name set: before the switch'));
        $this->assertStringContainsString($dark->getFgAnsi('dim'), $line('Pig v'));

        $this->type('/theme light');
        $this->type(self::ENTER);
        $this->settle();

        $light = Themes::theme();
        $this->assertSame('light', $light->name);
        $said = $line('Session name set: before the switch');
        $this->assertStringContainsString($light->getFgAnsi('dim'), $said);
        $this->assertStringNotContainsString($dark->getFgAnsi('dim'), $said);
        $banner = $line('Pig v');
        $this->assertStringContainsString($light->getFgAnsi('dim'), $banner);
        $this->assertStringNotContainsString($dark->getFgAnsi('dim'), $banner);
        $this->assertSame($before, array_slice($chat->children(), 0, count($before)), 'the same components, recoloured');
    }

    public function testEveryKeyTheEditorAnswersToIsNamedSomewhere(): void
    {
        // `Editor` answers to all of these and pig named none of them: the application keys were
        // in `KEYS` and the *editing* keys — upstream's own `/hotkeys` table — were listed
        // nowhere, so ctrl+w, ctrl+u, ctrl+k, word movement and the prompt history all worked and
        // could only be found by guessing. `/help` says "the keys and commands", which is a claim.
        $this->start();
        $this->type('/help');
        $this->type(self::ENTER);
        $this->settle();

        $screen = $this->screen();

        foreach ([
            'ctrl+w',
            'ctrl+u',
            'ctrl+k',
            'ctrl+a',
            'ctrl+e',
            'alt+left',
            'shift+enter',
            'tab',
            'up',
        ] as $key) {
            $this->assertStringContainsString($key, $screen, "{$key} is not named anywhere");
        }
    }

    public function testTheBannerIsThreeLinesUntilAskedForMore(): void
    {
        $this->start();
        $screen = $this->screen();

        // A column of thirteen keys was taller than most of the conversations it sat
        // above, so the list moved behind ctrl+o.
        $this->assertStringContainsString('Pig v0.0.0', $screen);
        $this->assertStringContainsString('escape interrupt · ctrl+c/ctrl+d clear/exit', $screen);
        $this->assertStringContainsString('Press ctrl+o to show full startup help and loaded resources.', $screen);
        $this->assertStringContainsString('Pig can explain its own features', $screen);
        $this->assertStringNotContainsString('suspend', $screen);
    }

    public function testQuietStartupDropsTheHeaderAndTheResources(): void
    {
        $this->start(context: [new ContextFile('/somewhere/AGENTS.md', 'be careful')], settings: Settings::inMemory(['quietStartup' => true]));

        $this->assertStringNotContainsString('Pig v0.0.0', $this->screen());
        $this->assertStringNotContainsString('[Context]', $this->screen());
    }

    public function testQuietStartupHeaderKeepsTheHeaderAndDropsTheResources(): void
    {
        $this->start(context: [new ContextFile('/somewhere/AGENTS.md', 'be careful')], settings: Settings::inMemory(['quietStartup' => 'header']));

        $this->assertStringContainsString('Pig v0.0.0', $this->screen());
        $this->assertStringContainsString('Press ctrl+o to show full startup help.', $this->screen());
        $this->assertStringNotContainsString('[Context]', $this->screen());
    }

    public function testEscapeTwiceOnAnEmptyPromptOpensTheTree(): void
    {
        $this->start(['an answer'], store: true);
        $this->type('a question');
        $this->type(self::ENTER);
        $this->settle();

        $this->type(self::ESC);
        $this->assertStringNotContainsString('Go back to', $this->screen(), 'one escape is not two');
        $this->type(self::ESC);
        $this->assertStringContainsString('Go back to', $this->screen());
    }

    public function testEscapeTwiceDoesNothingWhenTheSettingSaysNone(): void
    {
        $this->start(['an answer'], store: true, settings: Settings::inMemory(['doubleEscapeAction' => 'none']));
        $this->type('a question');
        $this->type(self::ENTER);
        $this->settle();

        $this->type(self::ESC);
        $this->type(self::ESC);
        $this->assertStringNotContainsString('Go back to', $this->screen());
    }

    public function testTheTreeOpensOnTheFilterTheSettingNames(): void
    {
        $this->start(['an answer'], store: true, settings: Settings::inMemory(['treeFilterMode' => 'user-only']));
        $this->type('a question');
        $this->type(self::ENTER);
        $this->settle();

        $this->type('/tree');
        $this->type(self::ENTER);

        $this->assertStringContainsString('[user-only]', $this->screen());
    }

    public function testTheTabShowsProgressWhileATurnRunsWhenAskedTo(): void
    {
        $this->start(['an answer'], settings: Settings::inMemory(['terminal' => ['showTerminalProgress' => true]]));
        $this->type('a question');
        $this->type(self::ENTER);
        $this->settle();

        $this->assertNotSame([], $this->terminal->progress);
        $this->assertTrue($this->terminal->progress[0]);
        $this->assertFalse($this->terminal->progress[array_key_last($this->terminal->progress)], 'cleared when the turn ends');
    }

    public function testTheTabShowsNoProgressByDefault(): void
    {
        $this->start(['an answer']);
        $this->type('a question');
        $this->type(self::ENTER);
        $this->settle();

        $this->assertSame([], $this->terminal->progress);
    }

    #[DataProvider('shownOrNot')]
    public function testTheFooterSaysHowFastTheAnswerCameUnlessTurnedOff(bool $shown): void
    {
        // An answer delivered at once is past any plausible rate, so the reading is its token count.
        $this->start([self::costing(new Usage(output: 500), 'an answer')], settings: Settings::inMemory(['tokenSpeed' => ['enabled' => $shown]]));

        $this->type('hello');
        $this->type(self::ENTER);
        $this->settle();

        $shown
            ? $this->assertStringContainsString('• ⚡ 500 tok', $this->screenText())
            : $this->assertStringNotContainsString('⚡', $this->screenText());
    }

    public function testAnotherSessionDoesNotShowThisOnesSpeed(): void
    {
        $this->start([self::costing(new Usage(output: 500), 'an answer')], store: true);

        $this->type('hello');
        $this->type(self::ENTER);
        $this->settle();
        $this->assertStringContainsString('⚡ 500 tok', $this->screenText());

        $this->type('/new');
        $this->type(self::ENTER);
        $this->settle();

        $this->assertStringNotContainsString('⚡', $this->screenText());
    }

    #[DataProvider('shownOrNot')]
    public function testACacheMissIsSaidWhenTheSettingAsksForIt(bool $shown): void
    {
        $this->start([
            self::costing(new Usage(cacheWrite: 50_000, output: 10, cost: new Cost(cacheWrite: 0.19))),
            self::costing(new Usage(input: 52_000, output: 10, cost: new Cost(input: 0.156))),
        ], settings: Settings::inMemory(['showCacheMissNotices' => $shown]));

        foreach (['one', 'two'] as $said) {
            $this->type($said);
            $this->type(self::ENTER);
            $this->settle();
        }

        $shown
            ? $this->assertMatchesRegularExpression('/Cache miss: 50k tokens re-billed \(~\$0\.\d\d\)/', $this->screenText())
            : $this->assertStringNotContainsString('Cache miss', $this->screenText());
    }

    /** @return iterable<string, array{bool}> */
    public static function shownOrNot(): iterable
    {
        yield 'on' => [true];
        yield 'off' => [false];
    }

    public function testACompactionSaysWhatItCostWhenTheSettingAsksForIt(): void
    {
        $this->start(
            [self::costing(new Usage(input: 40_000, output: 500, cost: new Cost(input: 0.12, output: 0.0075, total: 0.1275)), 'a summary of it all')],
            settings: Settings::inMemory(['showCacheMissNotices' => true]),
        );

        foreach (range(1, 6) as $ignored) {
            $this->session->agent->appendMessage(new UserMessage(str_repeat('x', 40_000)));
        }

        $this->type('/compact');
        $this->type(self::ENTER);
        $this->settle();

        $this->assertMatchesRegularExpression('/Compaction: 41k tokens billed \(~\$0\.13\)/', $this->screenText());
        $this->assertEqualsWithDelta(0.1275, $this->session->stats()->cost, 1e-9, 'and on the bill');
    }

    public function testCtrlOOpensTheFullListAndClosesItAgain(): void
    {
        $this->start();

        $this->type("\x0f");
        $this->assertStringContainsString('suspend', $this->screen());
        $this->assertStringNotContainsString('Press ctrl+o', $this->screen());

        $this->type("\x0f");
        $this->assertStringNotContainsString('suspend', $this->screen());
    }

    public function testWhatWasLoadedIsListedInTheBanner(): void
    {
        $this->startWithContext();

        $screen = $this->screen();
        $this->assertStringContainsString('[Context]', $screen);
        $this->assertStringContainsString('AGENTS.md', $screen);
    }

    public function testNoContextFilesMeansNoEmptyHeading(): void
    {
        $this->start();
        $this->type("\x0f");

        // A heading with nothing under it is worse than no heading.
        $this->assertStringNotContainsString('[Context]', $this->screen());
    }

    public function testTheFooterIsDrawnUnderEverything(): void
    {
        $this->start();

        // The model name is the last thing on the last line.
        $this->assertStringContainsString('claude-test', $this->screen());
    }

    // ---- saying something -------------------------------------------------------------

    public function testTypingAndPressingEnterSendsIt(): void
    {
        $this->start(['Here you go.']);

        $this->type('hello there');
        $this->type(self::ENTER);
        $this->settle();

        $screen = $this->screen();

        $this->assertStringContainsString('hello there', $screen);
        $this->assertStringContainsString('Here you go.', $screen);
    }

    public function testTheEditorIsEmptiedOnceTheMessageIsSent(): void
    {
        $this->start(['ok']);

        $this->type('a question');
        $this->type(self::ENTER);
        $this->settle();

        // The text appears once, in the transcript — not still sitting in the editor.
        $this->assertSame(1, substr_count($this->screen(), 'a question'));
    }

    public function testAnEmptyLineSendsNothing(): void
    {
        $this->start();

        $this->type(self::ENTER);
        $this->settle();

        $this->assertFalse($this->session->isStreaming());
    }

    // ---- commands ------------------------------------------------------------------------

    public function testALineThatNamesNoCommandIsSentAsTheTextItIs(): void
    {
        $this->start(['ok']);

        $this->type('/nonsense');
        $this->type(self::ENTER);
        $this->settle();

        // Upstream's rule, and the one pig follows: a command is a name something answers
        // to, matched exactly. Everything else is a message — including a typo, because
        // deciding that `/setings` *meant* `/settings` is a guess, and guessing is what read
        // a pasted picture's path as a command in the first place.
        $this->assertStringNotContainsString('No command called', $this->screen());
        $this->assertSame(2, count(self::said($this->session->messages())), 'sent, and answered');
    }

    public function testAPastedPathIsAMessageAndNotABadCommand(): void
    {
        $this->start(['ok']);

        // What pasting a picture leaves in the editor: `ClipboardFile` writes it to a temp
        // file and puts the path in, so the line begins with a slash.
        $this->type('/var/folders/mk/T/pig-clipboard-bf66.png what changed here?');
        $this->type(self::ENTER);
        $this->settle();

        $screen = $this->screen();

        // It used to be read as a command — "No command called /var/folders/…" — and the
        // question after it was swallowed along with the path.
        $this->assertStringNotContainsString('No command called', $screen);
        $this->assertStringContainsString('what changed here?', $screen, 'the whole line, not just the path');
        $this->assertStringContainsString('ok', $screen, 'and the model answered it');
    }

    public function testANearMissIsNotTreatedAsTheCommandItResembles(): void
    {
        $this->start(['ok']);

        $this->type('/setings');
        $this->type(self::ENTER);
        $this->settle();

        // The thing that must not happen is `/settings` opening. Matching is exact, so a
        // near miss is text, and it reaches the model as text.
        $this->assertStringNotContainsString('esc when done', $this->screen(), 'no settings screen');
        $this->assertStringContainsString('/setings', $this->screen());
    }

    public function testHelpListsTheKeysAndTheCommands(): void
    {
        $this->start();

        $this->type('/help');
        $this->type(self::ENTER);

        $screen = $this->screen();

        $this->assertStringContainsString('shift+tab', $screen);
        $this->assertStringContainsString('/session', $screen);
    }

    public function testHotkeysAliasListsTheKeysAndTheCommands(): void
    {
        $this->start();

        $this->type('/hotkeys');
        $this->type(self::ENTER);

        $screen = $this->screen();

        $this->assertStringContainsString('shift+tab', $screen);
        $this->assertStringContainsString('/session', $screen);
    }

    public function testThinkingCommandSetsLevelDirectlyOrOpensSubmenu(): void
    {
        $this->start(reasoning: true);

        // 1. Set level directly via argument
        $this->type('/thinking high');
        $this->type(self::ENTER);

        $this->assertSame(ThinkingLevel::High, $this->session->thinkingLevel());
        $this->assertStringContainsString('Thinking level: high', $this->screen());

        // 2. Open submenu via /thinking without arguments
        $this->type('/thinking');
        $this->type(self::ENTER);

        // Overlay is open showing Thinking submenu
        $screen = $this->screen();
        $this->assertStringContainsString('Thinking', $screen);
        $this->assertStringContainsString('Enter to select', $screen);

        // Escape closes submenu
        $this->type("\e");
        $this->assertStringNotContainsString('Enter to select', $this->screen());
    }

    public function testThinkingCommandReportsUnknownLevel(): void
    {
        $this->start(reasoning: true);

        $this->type('/thinking ultra');
        $this->type(self::ENTER);

        $this->assertStringContainsString('Unknown thinking level "ultra"', $this->screen());
    }

    public function testThinkingCommandOnNonReasoningModelSaysNotSupported(): void
    {
        $this->start(reasoning: false);

        $this->type('/thinking');
        $this->type(self::ENTER);

        $this->assertStringContainsString('This model does not support thinking', $this->screen());
    }

    public function testReloadCommandRefreshesResourcesWhenIdle(): void
    {
        $this->start();

        $this->type('/reload');
        $this->type(self::ENTER);

        $this->assertStringContainsString('Reloaded keybindings, extensions, skills, commands, tools, themes, and context files', $this->screenText());
    }

    public function testReloadLoadsTheExtensionsThatAreThereAndComplainsAboutNoneOfThem(): void
    {
        // A global extension, as `~/.pig/agent/extensions/copy.php` is on a real machine.
        mkdir($this->home . '/extensions', 0o755, true);
        file_put_contents($this->home . '/extensions/greeter.php', <<<'PHP'
            <?php
            return function ($pig): void { $pig->registerCommand('greet', fn () => null, 'Say hello'); };
            PHP);

        $this->start();
        $this->type('/reload');
        $this->type(self::ENTER);

        $screen = $this->screenText();

        // The reload used to hand the loader the *banner labels* of the discovered extensions as if
        // they were command-line paths, so every one of them came back as
        // `<cwd>/greeter.php (load): not a readable file`.
        $this->assertStringNotContainsString('not a readable file', $screen);
        $this->assertStringContainsString('Reloaded keybindings, extensions', $screen);

        // And the extension is live afterwards: its command is known.
        $this->type('/greet');
        $this->type(self::ENTER);
        $this->assertStringNotContainsString('No command called', $this->screenText());
    }

    public function testReloadDrawsAnExtensionThatWouldNotLoadAsUpstreamsExtensionIssuesBlock(): void
    {
        mkdir($this->home . '/extensions', 0o755, true);
        file_put_contents($this->home . '/extensions/broken.php', "<?php\nreturn 42;\n");

        $this->start();
        $this->type('/reload');
        $this->type(self::ENTER);

        // Upstream's `showLoadedResources()` after a reload: the problem is a block under the
        // loaded sections, headed `[Extension issues]`, with the file on its own line.
        $screen = $this->screenText();
        $this->assertStringContainsString('[Extension issues]', $screen);
        $this->assertStringContainsString('broken.php', $screen);
    }

    public function testReloadCommandWarnsWhenStreaming(): void
    {
        $this->start(['done']);
        $this->holdTheAgent();

        $this->type('hello');
        $this->type(self::ENTER);
        $this->settle();

        $this->assertTrue($this->session->isStreaming());

        $this->type('/reload');
        $this->type(self::ENTER);

        $this->assertStringContainsString('Wait for the current response to finish before reloading', $this->screen());

        // Exit cleanly
        $this->type('/quit');
        $this->type(self::ENTER);
        $this->settle();
    }

    public function testNewForgetsTheConversation(): void
    {
        $this->start(['answered']);

        $this->type('question');
        $this->type(self::ENTER);
        $this->settle();
        $this->assertNotSame([], $this->session->messages());

        $this->type('/new');
        $this->type(self::ENTER);

        $this->assertSame([], $this->session->messages());
        $this->assertStringNotContainsString('answered', $this->screen());
    }

    public function testSessionReportsWhatItHasCost(): void
    {
        $this->start();

        $this->type('/session');
        $this->type(self::ENTER);

        $this->assertStringContainsString('0 messages', $this->screen());
        // The terminal turns the warmer on, so `/session` has something to say about it.
        $this->assertStringContainsString('Cache warming: streaming · Inactive (waiting for first request)', $this->screenText());
    }

    public function testExitStopsTheWholeThing(): void
    {
        $this->start();

        $this->type('/exit');
        $this->type(self::ENTER);

        $this->assertFalse($this->terminal->started);
    }

    // ---- the keys ---------------------------------------------------------------------------

    public function testCtrlCClearsTheEditorAndTwiceQuits(): void
    {
        $this->start();

        $this->type('half a thought');
        $this->type("\x03");

        $this->assertStringNotContainsString('half a thought', $this->screen());
        $this->assertTrue($this->terminal->started);

        $this->type("\x03");
        $this->assertFalse($this->terminal->started);
    }

    public function testCtrlDQuitsOnlyFromAnEmptyPrompt(): void
    {
        $this->start();

        $this->type('something');
        $this->type("\x04");
        $this->assertTrue($this->terminal->started);

        $this->type("\x03");
        $this->type("\x04");
        $this->assertFalse($this->terminal->started);
    }

    public function testShiftTabCyclesThinkingAndSaysSo(): void
    {
        $this->start(reasoning: true);

        $this->type("\e[Z");

        $this->assertSame(ThinkingLevel::Minimal, $this->session->thinkingLevel());
        $this->assertStringContainsString('Thinking: minimal', $this->screen());
    }

    public function testShiftTabOnAModelThatCannotThinkSaysThatInstead(): void
    {
        $this->start();

        $this->type("\e[Z");

        $this->assertStringContainsString('does not support thinking', $this->screen());
    }

    public function testCtrlTTogglesThinkingBlocksAndSaysWhich(): void
    {
        $this->start();

        $this->type("\x14");
        $this->assertStringContainsString('Thinking hidden', $this->screen());

        $this->type("\x14");
        $this->assertStringContainsString('Thinking shown', $this->screen());
    }



    public function testEscapeAtAnIdlePromptDoesNothing(): void
    {
        $this->start();

        $this->type('a draft');
        $this->type(self::ESC);

        // Nothing to interrupt, so the draft stays where it was typed.
        $this->assertStringContainsString('a draft', $this->screen());
    }

    // ---- sessions on disk ----------------------------------------------------------------

    public function testAConversationIsWrittenAsItHappens(): void
    {
        $this->start(['an answer'], store: true);

        $this->type('a question');
        $this->type(self::ENTER);
        $this->settle();

        // What was said: the system message in front of it declares the agent's tools.
        $saved = self::said(SessionManager::open($this->session->store()->path)->messages());

        $this->assertCount(2, $saved);
        $this->assertInstanceOf(UserMessage::class, $saved[0]);
        $this->assertSame('an answer', $saved[1]->content[0]->text);
    }

    public function testASavedConversationIsDrawnAgainWhenItIsResumed(): void
    {
        $this->start(['the first answer'], store: true);
        $this->type('the first question');
        $this->type(self::ENTER);
        $this->settle();

        $path = $this->session->store()->path;
        $this->mode->stop();

        // A fresh pig in the same directory, resuming.
        $this->start(store: true, resume: $path);

        $screen = $this->screen();

        $this->assertStringContainsString('the first question', $screen);
        $this->assertStringContainsString('the first answer', $screen);
        $this->assertStringNotContainsString('stopped in the middle of a run', $screen, 'a run that finished is not offered again');
        $this->assertCount(2, self::said($this->session->messages()));
    }

    public function testUpAfterResumingBringsBackWhatWasAsked(): void
    {
        // Upstream's `renderInitialMessages()` fills the editor's history from the session; pig's
        // history started empty on every resume, so Up had nothing to bring back.
        $this->start(['the first answer'], store: true);
        $this->type('the first question');
        $this->type(self::ENTER);
        $this->settle();

        $path = $this->session->store()->path;
        $this->mode->stop();
        $this->start(store: true, resume: $path);

        $this->type("\e[A");

        $this->assertSame('the first question', $this->editorText());
    }

    public function testAConversationThatStoppedMidRunSaysSoAndContinueCarriesItOn(): void
    {
        $store = SessionManager::create($this->cwd);
        $store->append(new UserMessage('build it'));
        $store->append(self::wants('bash', ['command' => 'make']));

        $this->start(['it may have half run; checking'], store: true, resume: $store->path);

        $this->assertStringContainsString('This conversation stopped in the middle of a run. /continue carries it on.', $this->screenText());
        $this->assertCount(2, $this->session->messages(), 'nothing runs on its own');

        $this->type('/continue');
        $this->type(self::ENTER);
        $this->settle();

        $this->assertStringContainsString('it may have half run; checking', $this->screen());
        $this->assertSame('Tool bash was interrupted and may have partially run', $this->session->messages()[2]->content[0]->text);
        $this->assertSame(1, substr_count($this->screenText(), '$ make'), 'answered in the row the conversation drew, not a second one');

        $this->type('/continue');
        $this->type(self::ENTER);
        $this->settle();

        $this->assertStringContainsString('The last run had finished; there is nothing to carry on.', $this->screenText());
    }

    /**
     * What is said after resuming goes into the file that was resumed.
     *
     * It used to go into the file pig created at startup, which ended up holding its own
     * opening plus the continuation of a different conversation — while the resumed file
     * stopped growing at the moment it was resumed. Two files, neither of them what
     * happened.
     */
    public function testWhatIsSaidAfterResumingIsWrittenToTheFileThatWasResumed(): void
    {
        $this->start(['answer in the old one'], store: true);
        $this->type('the old question');
        $this->type(self::ENTER);
        $this->settle();

        $old = $this->session->store()->path;
        $this->mode->stop();

        // A second pig in the same directory, with its own file, which then resumes the
        // first one from the picker.
        $this->start(['answer after resuming'], store: true);
        $fresh = $this->session->store()->path;

        $this->assertNotSame($old, $fresh);

        $this->type('/resume');
        $this->type(self::ENTER);
        $this->type(self::ENTER);
        $this->settle();

        $this->type('said after resuming');
        $this->type(self::ENTER);
        $this->settle();

        $resumed = array_map(
            static fn (mixed $m): string => $m->content[0]->text ?? '',
            self::said(SessionManager::open($old)->messages()),
        );

        // The resumed file carries the whole thing: what was there, and what came after.
        $this->assertSame(
            ['the old question', 'answer in the old one', 'said after resuming', 'answer after resuming'],
            $resumed,
        );

        // And the file pig started with was never written at all — a session file appears
        // when something has been answered in it, and nothing ever was.
        $this->assertFileDoesNotExist($fresh);
    }

    /**
     * `/new` starts a new file, not just an empty screen.
     *
     * Keeping the old one appended the new conversation onto the last one as though they
     * were the same, and the new session never appeared in `/resume` at all.
     */
    public function testANewSessionGetsAFileOfItsOwn(): void
    {
        $this->start(['first answer', 'second answer'], store: true);

        $this->type('the first conversation');
        $this->type(self::ENTER);
        $this->settle();

        $first = $this->session->store()->path;

        $this->type('/new');
        $this->type(self::ENTER);
        $this->settle();

        $second = $this->session->store()->path;

        $this->assertNotSame($first, $second);

        $this->type('the second conversation');
        $this->type(self::ENTER);
        $this->settle();

        $this->assertSame(
            ['the first conversation', 'first answer'],
            array_map(static fn (mixed $m): string => $m->content[0]->text ?? '', self::said(SessionManager::open($first)->messages())),
        );
        $this->assertSame(
            ['the second conversation', 'second answer'],
            array_map(static fn (mixed $m): string => $m->content[0]->text ?? '', self::said(SessionManager::open($second)->messages())),
        );

        // Two conversations, two sessions to pick from.
        $this->assertCount(2, SessionManager::listFor($this->cwd));
    }

    /** `--no-session` means no file, and `/new` does not quietly start one. */
    public function testANewSessionWritesNothingWhenNothingWasBeingWritten(): void
    {
        $this->start(['answered']);

        $this->type('/new');
        $this->type(self::ENTER);
        $this->settle();

        $this->assertNull($this->session->store());
        $this->assertSame([], SessionManager::listFor($this->cwd));
    }

    public function testResumeOffersTheSessionsInThisDirectory(): void
    {
        $this->start(['answered'], store: true);
        $this->type('something memorable');
        $this->type(self::ENTER);
        $this->settle();
        $this->mode->stop();

        $this->start(store: true);
        $this->type('/resume');
        $this->type(self::ENTER);

        // Labelled by what was asked, which is how anyone remembers a conversation.
        $this->assertStringContainsString('something memorable', $this->screen());
        $this->assertStringContainsString('Resume Session (Current Fold', $this->screen());
    }

    public function testPickingOneReplacesTheConversation(): void
    {
        $this->start(['answered'], store: true);
        $this->type('something memorable');
        $this->type(self::ENTER);
        $this->settle();
        $this->mode->stop();

        $this->start(store: true);
        $this->type('/resume');
        $this->type(self::ENTER);
        $this->type(self::ENTER);
        // The resume runs in a fiber of its own, as it may have to ask something.
        $this->settle();

        $screen = $this->screen();

        $this->assertStringContainsString('something memorable', $screen);
        $this->assertStringContainsString('Resumed 2 messages', $screen);
        $this->assertStringNotContainsString('Pick a session', $screen);
        $this->assertCount(2, self::said($this->session->messages()));
    }

    public function testTypingSearchesTheSessionsFromInsideASession(): void
    {
        // The same search the startup picker has. Without it the in-session list is eight rows
        // of openings and the arrow keys, which is the thing `SessionList` was written to fix —
        // and upstream shows the searchable list in both places, not one.
        $this->start(['first answer', 'second answer'], store: true);

        $this->type('the markdown lexer');
        $this->type(self::ENTER);
        $this->settle();

        $this->type('/new');
        $this->type(self::ENTER);
        $this->settle();

        $this->type('the tls handshake');
        $this->type(self::ENTER);
        $this->settle();

        $this->type('/resume');
        $this->type(self::ENTER);

        // Newest first, so the highlighted row is the tls one; the query has to be what
        // decides, or this passes with no search at all.
        foreach (['l', 'e', 'x'] as $key) {
            $this->type($key);
        }

        $this->type(self::ENTER);
        $this->settle();

        $screen = $this->screen();

        $this->assertStringContainsString('the markdown lexer', $screen);
        $this->assertStringNotContainsString('the tls handshake', $screen);
    }

    public function testASearchThatMatchesNothingSaysSoRatherThanLookingEmpty(): void
    {
        $this->start(['answered'], store: true);
        $this->type('something memorable');
        $this->type(self::ENTER);
        $this->settle();
        $this->mode->stop();

        $this->start(store: true);
        $this->type('/resume');
        $this->type(self::ENTER);

        foreach (['z', 'z', 'z'] as $key) {
            $this->type($key);
        }

        // Upstream's wording for the current folder, which points at Tab for every project's.
        $this->assertStringContainsString('No sessions in current folder. Press Tab to view all.', $this->screen());
    }

    public function testEscapeClosesThePickerAndChangesNothing(): void
    {
        $this->start(['answered'], store: true);
        $this->type('something memorable');
        $this->type(self::ENTER);
        $this->settle();
        $this->mode->stop();

        $this->start(store: true);
        $this->type('/resume');
        $this->type(self::ENTER);
        $this->type(self::ESC);

        $this->assertStringNotContainsString('Pick a session', $this->screen());
        $this->assertSame([], $this->session->messages());
    }

    public function testWithNothingSavedHereResumeStillOpensAndOffersEveryProject(): void
    {
        $this->start(store: true);

        $this->type('/resume');
        $this->type(self::ENTER);

        // Upstream's: the list opens, says so, and Tab is how another project's session is reached.
        $this->assertStringContainsString('No sessions in current folder. Press Tab to view all.', $this->screen());
    }

    // ---- running a command yourself -----------------------------------------------------

    public function testABangCommandRunsAndJoinsTheConversation(): void
    {
        $this->start();

        $this->type('!echo hello-from-bash');
        $this->type(self::ENTER);
        $this->settle();

        $screen = $this->screen();

        $this->assertStringContainsString('$ echo hello-from-bash', $screen);
        $this->assertStringContainsString('hello-from-bash', $screen);
        $this->assertCount(1, $this->session->messages());
        $this->assertInstanceOf(BashExecution::class, $this->session->messages()[0]);
    }

    public function testTwoBangsRunItAndKeepItOut(): void
    {
        $this->start();

        $this->type('!!echo quiet');
        $this->type(self::ENTER);
        $this->settle();

        $screen = $this->screen();

        // Shown the same way, in `dim` rather than the bash-mode colour — upstream's one signal
        // that the model will not see it afterwards.
        $this->assertStringContainsString('$ echo quiet', $screen);
        $this->assertStringContainsString('quiet', $screen);
        $this->assertStringNotContainsString('Not added', $screen);
        // Kept in the session, flagged, as upstream records it — and out of what the model is sent.
        $kept = array_values(array_filter($this->session->messages(), static fn ($m) => $m instanceof \Pig\CodingAgent\Session\BashExecution));
        $this->assertCount(1, $kept);
        $this->assertTrue($kept[0]->excludeFromContext);
        $this->assertSame([], \Pig\CodingAgent\CodingAgent::toLlm($kept));
    }

    public function testATypedCommandKeepsTwentyLinesAndCountsTheRest(): void
    {
        $this->start();

        // Upstream's `bash-execution.ts`: the last `PREVIEW_LINES` (20) are shown, and the count
        // of what is hidden goes under them with the expand key — not above, as the model's
        // `bash` tool draws its own cut.
        $this->type('!seq 1 30');
        $this->type(self::ENTER);
        $this->settle();

        $screen = $this->screen();

        $this->assertStringContainsString('$ seq 1 30', $screen);
        $this->assertStringContainsString('30', $screen);
        $this->assertStringContainsString('... 10 more lines (ctrl+o to expand)', $screen);
    }

    public function testABareBangDoesNothing(): void
    {
        $this->start();

        $this->type('!');
        $this->type(self::ENTER);
        $this->settle();

        $this->assertSame([], $this->session->messages());
        $this->assertStringNotContainsString('$', $this->screen());
    }

    public function testAFailingCommandIsMarkedAsOne(): void
    {
        $this->start();

        $this->type('!exit 3');
        $this->type(self::ENTER);
        $this->settle();

        // The exit code is marked with the error color.
        $this->assertStringContainsString(Themes::theme()->fg('error', '(exit 3)'), implode('', $this->mode->screen()->render(80)));
        $this->assertSame(3, $this->session->messages()[0]->exitCode);
    }

    public function testTheExitCodeIsOnScreenAndNotOnlyInTheConversation(): void
    {
        $this->start();

        $this->type('!exit 3');
        $this->type(self::ENTER);
        $this->settle();

        // The colour says something went wrong and the number says what. 137 against 1 is the whole
        // point of the entry about signal numbers, and it is worth as much to a person as to a
        // model. The test above this one asserted the colour and then read the code off the
        // *message*, which is exactly where it was present.
        $this->assertStringContainsString('(exit 3)', $this->screen());
    }

    public function testACancelledCommandSaysItWasCancelledRatherThanJustFailing(): void
    {
        $this->start();

        $this->type('!sleep 5');
        $this->type(self::ENTER);

        // Turned rather than settled, and this is why the first version of this test could not
        // fail: `settle()` polls with no timeout, so with the command's pipes the only thing to
        // wait on it sat through the whole five seconds and escape arrived after the command had
        // already finished cleanly. `turnTheLoop()` arms a timer of its own, so the poll comes
        // back at once and the command is still running when the key goes in.
        self::turnTheLoop(5);
        $this->assertTrue($this->session->isBashRunning(), 'the command is still going');

        $this->type(self::ESC);

        for ($tick = 0; $tick < 400 && $this->session->isBashRunning(); $tick++) {
            Loop::get()->delay(0.005, static fn () => null);
            Loop::get()->tick();
        }

        self::turnTheLoop(5);

        // Escape stopping a command and a command failing are different things, and the block is
        // coloured the same for both.
        $this->assertStringContainsString('(cancelled)', $this->screen());
    }

    public function testTruncatedOutputSaysSoAndWhereTheRestIs(): void
    {
        $this->start();

        // Over `Truncate::MAX_LINES`, so `Run` spills the whole of it to a file and the tail is what
        // is kept. The model is told — `BashExecution::toText()` appends the sentence — and the
        // person watching it happen was told nothing, which is the notice's two readers with only
        // one of them served.
        $this->type('!seq 2500');
        $this->type(self::ENTER);
        $this->settle();

        $screen = $this->screen();

        $this->assertStringContainsString('Output truncated', $screen);
        $this->assertStringContainsString('/pig-bash-', $screen, 'and the file to read the rest in');
    }

    public function testACommandIsNotSentToTheModel(): void
    {
        // No scripted answers: if this reached the provider the test would blow up on
        // "out of scripted answers" rather than pass.
        $this->start();

        $this->type('!echo x');
        $this->type(self::ENTER);
        $this->settle();

        $this->assertFalse($this->session->isStreaming());
    }

    // ---- going back ---------------------------------------------------------------------------

    public function testATranscriptDrawsAMessageWhoseBytesAreNotUtf8(): void
    {
        // The fifth transcript path. `pig @notes.txt` on a latin-1 file, or `pig $'ask \x80 this'`,
        // put bytes in here that no keystroke could — and `Graphemes::split()` throws on them from
        // inside `render()`, in the loop's own callback, which takes the session with it. The other
        // four paths had a guard; what the person said looked obviously safe.
        $this->start(['the answer'], initialMessages: ['why does ' . chr(0x80) . ' this fail']);
        $this->settle();

        $screen = $this->screen();

        $this->assertStringContainsString('why does', $screen);
        $this->assertStringContainsString('this fail', $screen);
    }

    public function testATreeRowSaysWhatWasSaidEvenWhenItsBytesAreNotUtf8(): void
    {
        // `bin/pig @notes.txt` on a latin-1 file is exactly this: the bytes reach the first
        // message without passing an editor, and `/tree` reads the conversation in memory rather
        // than the file, so the `JSON_INVALID_UTF8_SUBSTITUTE` that protects the file is not here.
        $this->start(['the answer'], store: true, initialMessages: ['why does ' . chr(0x80) . ' this fail']);
        $this->settle();

        $this->type('/tree');
        $this->type(self::ENTER);

        $screen = $this->screen();

        // `preg_replace('/\s+/u', …)` answers null on malformed UTF-8 and `(string) null` is '',
        // so the row fell through to `(nothing said)` — which is the line for a message that is a
        // pasted picture and nothing else, and the one row nobody would go back to.
        $this->assertStringNotContainsString('(nothing said)', $screen);
        $this->assertStringContainsString('why does', $screen);
    }

    public function testForkMovesToANewFileWithTheChosenQuestionBackInThePrompt(): void
    {
        $this->start(['first answer', 'second answer'], store: true);

        $this->type('the first question');
        $this->type(self::ENTER);
        $this->settle();
        $this->type('the second question');
        $this->type(self::ENTER);
        $this->settle();

        $first = $this->session->store()->path;

        $this->type('/fork');
        $this->type(self::ENTER);

        $screen = $this->screen();
        $this->assertStringContainsString('Fork from', $screen);
        $this->assertStringContainsString('the second question', $screen);

        // The cursor starts on the newest message, which is the one a fork is nearly always made from.
        $this->type(self::ENTER);
        $this->settle();

        $this->assertNotSame($first, $this->session->store()->path);
        $this->assertSame($first, $this->session->store()->parentSession);
        $this->assertSame('the second question', $this->editorText());
        $this->assertStringContainsString('Forked to new session', $this->screenText());
        // Up to before the second question: the first and its answer.
        $this->assertSame(
            ['the first question', 'first answer'],
            array_map(static fn (mixed $m): string => $m->content[0]->text ?? '', self::said($this->session->messages())),
        );
        $this->assertCount(2, SessionManager::listFor($this->cwd));
    }

    public function testCloneCopiesTheConversationIntoANewFileAndCarriesOnThere(): void
    {
        $this->start(['the answer', 'and another'], store: true);

        $this->type('hello');
        $this->type(self::ENTER);
        $this->settle();

        $first = $this->session->store()->path;

        $this->type('/clone');
        $this->type(self::ENTER);
        $this->settle();

        $second = $this->session->store()->path;
        $this->assertNotSame($first, $second);
        $this->assertStringContainsString('Cloned to new session', $this->screenText());
        $this->assertSame('', $this->editorText());

        $this->type('carrying on');
        $this->type(self::ENTER);
        $this->settle();

        // Written to the clone and not to the original.
        $this->assertCount(2, self::said(SessionManager::open($first)->messages()));
        $this->assertCount(4, self::said(SessionManager::open($second)->messages()));
    }

    public function testForkAndCloneSayWhyWhenThereIsNothingToForkYet(): void
    {
        $this->start(['the answer'], store: true);

        $this->type('/fork');
        $this->type(self::ENTER);
        $this->assertStringContainsString('No messages to fork from', $this->screenText());

        $this->type('/clone');
        $this->type(self::ENTER);
        $this->assertStringContainsString('Nothing to clone yet', $this->screenText());
    }

    public function testTreeOffersThePointsInThisConversation(): void
    {
        $this->start(['the answer'], store: true);

        $this->type('hello');
        $this->type(self::ENTER);
        $this->settle();

        $this->type('/tree');
        $this->type(self::ENTER);

        $screen = $this->screen();

        $this->assertStringContainsString('Go back to', $screen);
        $this->assertStringContainsString('hello', $screen);
        // Who said it, which is what the tree shows instead of the old list's "N back": a row is
        // read for what is on it, and the position is the `•` down the side.
        $this->assertStringContainsString('user:', $screen);
        $this->assertStringContainsString('assistant:', $screen);
    }

    public function testSkipPromptGoesBackWithoutAskingAboutASummary(): void
    {
        $this->start(['first answer', 'second answer'], store: true, settings: Settings::inMemory(['branchSummary' => ['skipPrompt' => true]]));

        foreach (['hello', 'down the first road'] as $said) {
            $this->type($said);
            $this->type(self::ENTER);
            $this->settle();
        }

        $leaf = $this->session->store()?->leaf();
        $this->type('/tree');
        $this->type(self::ENTER);
        $this->type("\e[A");
        $this->type("\e[A");
        $this->type(self::ENTER);
        $this->settle();

        $this->assertStringNotContainsString('Summarise the branch you are leaving?', $this->screen());
        $this->assertNotSame($leaf, $this->session->store()?->leaf(), 'and it went');
    }

    public function testTreeShowsABranchThatWasAbandonedAndCanGoBackToIt(): void
    {
        // The whole reason `/tree` is a tree. Going back and carrying on leaves the first direction
        // in the file with its parents intact, and listing only the current branch made it
        // unreachable: `goTo()` needs an id and nothing showed one.
        $this->start(['first answer', 'second answer', 'third answer'], store: true);

        $this->type('hello');
        $this->type(self::ENTER);
        $this->settle();

        $this->type('down the first road');
        $this->type(self::ENTER);
        $this->settle();

        // Back to the first exchange, then somewhere else.
        $this->type('/tree');
        $this->type(self::ENTER);
        $this->type("\e[A");
        $this->type("\e[A");
        $this->type(self::ENTER);
        $this->settle();

        // "Summarise the branch you are leaving?" — No is the default, so Enter is no. Without
        // answering it, everything typed next goes to that dialog: this test failed for exactly
        // that reason first, with the message quietly going nowhere.
        $this->type(self::ENTER);
        $this->settle();

        $this->type('down the second road');
        $this->type(self::ENTER);
        $this->settle();

        $this->type('/tree');
        $this->type(self::ENTER);

        $screen = $this->screen();

        $this->assertStringContainsString('down the second road', $screen, 'the branch being talked on');
        $this->assertStringContainsString('down the first road', $screen, 'and the one that was left');
        // The fork is drawn rather than implied.
        $this->assertMatchesRegularExpression('/[├└]/u', $screen);
    }

    public function testGoingBackRedrawsTheConversationWithoutWhatCameAfter(): void
    {
        $this->start(['first answer', 'second answer'], store: true);

        $this->type('hello');
        $this->type(self::ENTER);
        $this->settle();

        $this->type('and again');
        $this->type(self::ENTER);
        $this->settle();

        $this->type('/tree');
        $this->type(self::ENTER);
        // Two rows down from where the cursor starts, which is the point being talked on: the tree
        // opens on the leaf and wraps at the ends, so this lands earlier in the conversation.
        $this->type("\e[B");
        $this->type("\e[B");
        $this->type(self::ENTER);
        $this->settle();

        // "Summarise the branch you are leaving?" — Yes is first, as upstream has it; No is one down.
        $this->type("\e[B");
        $this->type(self::ENTER);
        $this->settle();

        $this->assertStringContainsString('Went back', $this->screen());
        $this->assertStringNotContainsString('second answer', $this->screen());
    }

    public function testGoingBackToSomethingYouSaidPutsItBackInThePrompt(): void
    {
        $this->start(['first answer'], store: true);

        $this->type('hello');
        $this->type(self::ENTER);
        $this->settle();

        // Two rows, and the cursor opens on the leaf — the answer — so one press up is the
        // question. The list wraps, which is what makes one press enough.
        $this->type('/tree');
        $this->type(self::ENTER);
        $this->type("\e[A");
        $this->type(self::ENTER);
        $this->settle();

        // "Summarise the branch you are leaving?" — Yes is first; No is one down.
        $this->type("\e[B");
        $this->type(self::ENTER);
        $this->settle();

        $screen = $this->screen();

        // The conversation is empty now, so "hello" on screen is the prompt and nothing else: the
        // question came back to be asked differently, which is what going back to it is for.
        $this->assertStringNotContainsString('first answer', $screen);
        $this->assertStringContainsString('hello', $screen);
        // Back to before "hello": what is left is the system message that declared the tools.
        $this->assertSame([], self::said($this->session->messages()));
    }

    public function testWithNothingSaidYetThereIsNowhereToGoBackTo(): void
    {
        $this->start(store: true);

        $this->type('/tree');
        $this->type(self::ENTER);

        $this->assertStringContainsString('Nothing to go back to yet', $this->screen());
    }

    public function testASessionThatIsNotSavedHasNowhereToGoBackTo(): void
    {
        $this->start(['the answer']);

        $this->type('/tree');
        $this->type(self::ENTER);

        $this->assertStringContainsString('not being saved', $this->screen());
    }

    // ---- exporting --------------------------------------------------------------------------

    public function testExportWritesTheConversationAsOneHtmlFile(): void
    {
        $this->start(['the answer'], store: true);

        $this->type('hello');
        $this->type(self::ENTER);
        $this->settle();

        $path = $this->cwd . '/out.html';
        $this->type('/export ' . $path);
        $this->type(self::ENTER);
        $this->settle();

        $this->assertFileExists($path);

        $html = (string) file_get_contents($path);

        $this->assertStringContainsString('hello', $html);
        $this->assertStringContainsString('the answer', $html);
        $this->assertStringNotContainsString('<script', $html);
        $this->assertStringContainsString('Session exported to: ' . $path, $this->screenText());
    }

    public function testASessionThatIsNotSavedHasNothingToExport(): void
    {
        $this->start(['the answer']);

        $this->type('/export');
        $this->type(self::ENTER);
        $this->settle();

        // The file is built from what is on disk, so a `--no-session` run has nothing to
        // build from — saying so beats writing an empty page.
        $this->assertStringContainsString('not being saved', $this->screen());
    }

    // ---- what is remembered for next time -------------------------------------------------------

    public function testSwitchingThemeIsRemembered(): void
    {
        $this->start();

        // The picker lists system, dark (on), labra, light.
        $this->type('/theme');
        $this->type(self::ENTER);
        $this->type(self::DOWN);
        $this->type(self::DOWN);
        $this->type(self::ENTER);

        // `/theme` that resets every run is a setting nobody uses twice.
        $this->assertSame('light', $this->settings->theme());
    }

    public function testHidingThinkingIsRemembered(): void
    {
        $this->start();

        $this->type("\x14");

        $this->assertTrue($this->settings->hideThinking());
    }

    public function testThinkingHiddenLastTimeStartsHidden(): void
    {
        $this->start(settings: Settings::inMemory(['hideThinkingBlock' => true]));

        $this->type("\x14");

        // Toggled from what was saved, not from the default: otherwise the first ctrl+t
        // of a session does nothing visible.
        $this->assertFalse($this->settings->hideThinking());
    }

    public function testSwitchingModelChangesSessionAndLeavesSettingsUntouched(): void
    {
        // Anthropic's key only: Bedrock and Vertex serve Claude and Gemini under ids of their own
        // (`us.anthropic.claude-haiku-5-5`), and with every model on offer upstream's resolver ranks
        // those first. Which provider wins is not what this case is about.
        $auth = Auth::inMemory();
        $auth->setRuntimeApiKey('anthropic', 'for-this-run');
        $this->start(auth: $auth);

        $this->type('/model haiku:high');
        $this->type(self::ENTER);

        // Switches for the current session. `haiku` now resolves to Claude Haiku 5.5, the row
        // upstream's generator adds by hand and pig's table now carries; it used to be 4.5.
        $this->assertSame('claude-haiku-5-5', $this->session->model()?->id);
        $this->assertSame(ThinkingLevel::High, $this->session->thinkingLevel());

        // Does NOT overwrite global settings.json (matching upstream pi)
        $this->assertNull($this->settings->defaultModel());
        $this->assertNull($this->settings->defaultThinkingLevel());
    }

    public function testSettingModelAsDefaultWithCtrlSSavesToSettings(): void
    {
        $this->start();

        $this->type('/model');
        $this->type(self::ENTER);
        $this->settle();

        // Ctrl+S is ASCII 19 (\x13): saves the selected model as persistent default
        $this->type("\x13");
        $this->settle();

        // Saved to settings
        $this->assertNotNull($this->settings->defaultModel());
        $this->assertStringContainsString('Default model:', $this->screen());
    }

    public function testCyclingTheThinkingLevelChangesSessionAndLeavesSettingsUntouched(): void
    {
        $this->start(reasoning: true);

        $this->type("\e[Z");

        // Changes level on current session
        $this->assertSame(ThinkingLevel::Minimal, $this->session->thinkingLevel());

        // Does NOT overwrite global settings.json
        $this->assertNull($this->settings->defaultThinkingLevel());
    }

    // ---- commands kept as files ---------------------------------------------------------------

    public function testAFileCommandIsSentAsTheMessageItStandsFor(): void
    {
        $this->start(['done'], fileCommands: [
            new FileCommand('review', 'Review a file', 'Please review $1 closely.', '(user)'),
        ]);

        $this->type('/review src/Foo.php');
        $this->type(self::ENTER);
        $this->settle();

        $screen = $this->screen();

        // A command here is a stored prompt, not a program: it goes as if it were typed.
        $this->assertStringContainsString('Please review src/Foo.php closely.', $screen);
        $this->assertStringContainsString('done', $screen);
    }

    public function testAFileCommandCannotShadowABuiltInOne(): void
    {
        // No scripted answers: if `/help` reached the model this would blow up on
        // "out of scripted answers" rather than pass.
        $this->start(fileCommands: [new FileCommand('help', 'Not this one', 'send me instead', '(user)')]);

        $this->type('/help');
        $this->type(self::ENTER);
        $this->settle();

        $this->assertStringContainsString('ctrl+c', $this->screen());
        $this->assertStringNotContainsString('send me instead', $this->screen());
    }

    public function testAFileCommandsNameIsMatchedExactlyLikeAnyOther(): void
    {
        $this->start(['ok'], fileCommands: [new FileCommand('review', 'd', 'the stored prompt', '(user)')]);

        // One character off the name of a command that does exist, which is the case the
        // exact match is for: it is not `/review`, so it is not expanded into the prompt.
        $this->type('/reviews');
        $this->type(self::ENTER);
        $this->settle();

        $screen = $this->screen();

        $this->assertStringNotContainsString('the stored prompt', $screen);
        $this->assertStringContainsString('/reviews', $screen);
    }

    // ---- copying ----------------------------------------------------------------------------

    public function testCopyPutsTheLastAnswerOnTheClipboard(): void
    {
        $this->start(['the whole answer']);

        $this->type('hello');
        $this->type(self::ENTER);
        $this->settle();

        $this->type('/copy');
        $this->type(self::ENTER);

        $this->assertSame('the whole answer', $this->clipboard->written);
        $this->assertStringContainsString('Copied the last answer', $this->screen());
    }

    public function testCopyWithNothingAnsweredYetSaysSo(): void
    {
        $this->start();

        $this->type('/copy');
        $this->type(self::ENTER);

        $this->assertNull($this->clipboard->written);
        $this->assertStringContainsString('Error: No agent messages to copy yet', $this->screen());
    }

    public function testCopyCodePicksOneBlockOfTheLastAnswer(): void
    {
        $this->start(["Two:\n\n```php\necho 1;\n```\n\n```sh\nls\n```"]);

        $this->type('hello');
        $this->type(self::ENTER);
        $this->settle();

        $this->type('/cc');
        $this->type(self::ENTER);
        $this->settle();

        $this->assertStringContainsString('Copy which code block?', $this->screen());
        $this->assertStringContainsString('[1] php (1 line)  echo 1;', $this->screen());
        $this->assertStringContainsString('The whole answer', $this->screen());

        $this->type("\e[B");
        $this->type(self::ENTER);
        $this->settle();

        $this->assertSame('ls', $this->clipboard->written);
        $this->assertStringContainsString('Copied code block 2 (sh, 1 line)', $this->screen());
    }

    public function testCopyCodeWithNoBlockCopiesTheWholeAnswer(): void
    {
        $this->start(['no code here']);

        $this->type('hello');
        $this->type(self::ENTER);
        $this->settle();

        $this->type('/copycode');
        $this->type(self::ENTER);
        $this->settle();

        $this->assertSame('no code here', $this->clipboard->written);
        $this->assertStringContainsString('No code blocks in the last answer', $this->screen());
    }

    public function testAMachineWithNoClipboardToolIsToldWhatToInstall(): void
    {
        $this->start(['the whole answer']);
        $this->clipboard->writable = false;

        $this->type('hello');
        $this->type(self::ENTER);
        $this->settle();

        $this->type('/copy');
        $this->type(self::ENTER);

        // Not a broken machine, but worth naming the thing to install rather than
        // saying it did not work.
        if (PHP_OS_FAMILY !== 'Linux') {
            $this->assertStringContainsString('Error: Clipboard unavailable', $this->screen());

            return;
        }

        $this->assertStringContainsString('wl-copy, xclip or xsel', $this->screen());
    }

    // ---- skills -----------------------------------------------------------------------------

    public function testLoadedSkillsAreListedInTheBanner(): void
    {
        $this->start(skills: [new Skill('tidy', 'tidy up a file', '/s/tidy/SKILL.md', '/s/tidy', 'user')]);

        $screen = $this->screen();

        $this->assertStringContainsString('[Skills]', $screen);
        $this->assertStringContainsString('tidy', $screen);
    }

    public function testNoSkillsMeansNoEmptyHeading(): void
    {
        $this->start();

        $this->type("\x0f");

        $this->assertStringNotContainsString('[Skills]', $this->screen());
    }

    public function testSkillsSaysWhereEachOneCameFrom(): void
    {
        $this->start(skills: [new Skill('tidy', 'tidy up a file', '/s/tidy/SKILL.md', '/s/tidy', 'claude-user')]);

        $this->type('/skills');
        $this->type(self::ENTER);

        $screen = $this->screen();

        // The same name can live in four places, and a shadowed skill looks exactly like
        // one that simply does not work.
        $this->assertStringContainsString('tidy', $screen);
        $this->assertStringContainsString('claude-user', $screen);
        $this->assertStringContainsString('/s/tidy/SKILL.md', $screen);
    }

    public function testTheDescriptionColumnLinesUpForASkillNamedInAnotherAlphabet(): void
    {
        $this->start(skills: [
            new Skill('tidy', 'tidy up a file', '/s/tidy/SKILL.md', '/s/tidy', 'user'),
            new Skill('代码审查', 'review the diff', '/s/review/SKILL.md', '/s/review', 'user'),
        ]);

        $this->type('/skills');
        $this->type(self::ENTER);

        $columns = [];

        foreach (explode("\n", $this->screen()) as $line) {
            $plain = Ansi::strip($line);

            foreach (['tidy up a file', 'review the diff'] as $description) {
                $at = mb_strpos($plain, $description, 0, 'UTF-8');

                if ($at !== false) {
                    $columns[$description] = Width::visible(mb_substr($plain, 0, $at, 'UTF-8'));
                }
            }
        }

        // `str_pad` counts bytes, so a name in an alphabet that spends more than one per character
        // is padded short and its description starts early — 代码审查 is 12 bytes and 8 columns, so
        // the column was four to the left of every other row's. `SelectList` and `SettingsList`
        // already measure their label columns in columns for this reason.
        $this->assertCount(2, $columns);
        $this->assertSame(
            $columns['tidy up a file'],
            $columns['review the diff'],
            'the two descriptions should start in the same column',
        );
    }

    public function testWithNoSkillsTheCommandSaysWhereToPutOne(): void
    {
        $this->start();

        $this->type('/skills');
        $this->type(self::ENTER);

        $this->assertStringContainsString('~/.pig/agent/skills', $this->screen());
    }

    // ---- models -----------------------------------------------------------------------------

    public function testModelOnItsOwnOffersTheList(): void
    {
        $this->start();

        $this->type('/model');
        $this->type(self::ENTER);

        $screen = $this->screen();

        $this->assertStringContainsString('Pick a model', $screen);
        $this->assertStringContainsString('claude-', $screen);
    }

    public function testTypingInTheModelListNarrowsItAndSwitchesToWhatIsLeft(): void
    {
        // Anthropic's key only: Bedrock and Vertex serve Claude and Gemini under ids of their own
        // (`us.anthropic.claude-haiku-5-5`), and with every model on offer upstream's resolver ranks
        // those first. Which provider wins is not what this case is about.
        $auth = Auth::inMemory();
        $auth->setRuntimeApiKey('anthropic', 'for-this-run');
        $this->start(auth: $auth);

        $this->type('/model');
        $this->type(self::ENTER);
        $this->type('haiku');

        $this->assertStringContainsString('/haiku', $this->screen());

        // A fuzzy match over a line naming the provider, the id and the name is a loose net —
        // upstream's is too. What the assertion is about is the *ranking*: the best match is on
        // the top row, which is where typing puts the selection.
        $this->assertStringContainsString('claude-haiku-4-5', $this->selectedRow());

        $this->type(self::ENTER);

        $this->assertSame('claude-haiku-4-5', $this->session->model()?->id);
    }

    public function testTheModelListIsSearchedByProviderAndNameAsWellAsId(): void
    {
        // The rows are numbered `0`, `1`, `2`, so without a haystack of their own there is
        // nothing here anyone could type. Upstream ranks on provider, `provider/id`, id and name.
        $this->start();

        $this->type('/model');
        $this->type(self::ENTER);
        $this->type('anthropic/haiku');

        // Every token has to match, and `anthropic/…` is two tokens: a github-copilot row named
        // "Claude Haiku 4.5" cannot satisfy the first one.
        $this->assertStringContainsString('claude-haiku-4-5', $this->selectedRow());
        $this->assertStringNotContainsString('No matches', $this->screen());
    }

    public function testAProviderPrefixedQueryRanksThatProvidersOwnAboveAResellersCopy(): void
    {
        // The reason upstream's search line names the provider twice and the bare id last. Rank
        // the rows on how they read instead and `openai/gpt` puts groq's `openai/gpt-oss-120b`
        // first, because that row's *id* contains the provider the query names.
        $this->start();

        $this->type('/model');
        $this->type(self::ENTER);
        $this->type('openai/gpt');

        $row = $this->selectedRow();

        $this->assertStringContainsString('openai ·', $row);
        $this->assertStringNotContainsString('groq', $row);
    }

    public function testBackspaceInTheModelListWidensItAgain(): void
    {
        $this->start();

        $this->type('/model');
        $this->type(self::ENTER);
        $this->type('haiku');

        $this->assertStringContainsString('/haiku', $this->screen());
        $narrowed = $this->pickerTotal();

        foreach (range(1, 5) as $ignored) {
            $this->type("\x7f");
        }

        // The query line goes with the last character of the query, and the list is longer than
        // it was. The *selection* stays where it was rather than jumping back to the top, which
        // is upstream's behaviour and the point of clamping instead of resetting: you do not get
        // thrown to the start of a list you had scrolled into.
        $this->assertStringNotContainsString('/haiku', $this->screen());
        $this->assertGreaterThan($narrowed, $this->pickerTotal());
    }

    public function testEscapeLeavesTheModelListEvenAfterTypingInIt(): void
    {
        $this->start();
        $before = $this->session->model()?->id;

        $this->type('/model');
        $this->type(self::ENTER);
        $this->type('haiku');
        $this->type(self::ESCAPE);

        $this->assertStringNotContainsString('Pick a model', $this->screen());
        $this->assertSame($before, $this->session->model()?->id);
    }

    public function testModelWithAPatternSwitchesWithoutOpeningTheList(): void
    {
        // Anthropic's key only: Bedrock and Vertex serve Claude and Gemini under ids of their own
        // (`us.anthropic.claude-haiku-5-5`), and with every model on offer upstream's resolver ranks
        // those first. Which provider wins is not what this case is about.
        $auth = Auth::inMemory();
        $auth->setRuntimeApiKey('anthropic', 'for-this-run');
        $this->start(auth: $auth);

        $this->type('/model haiku');
        $this->type(self::ENTER);

        // Haiku 5.5 since the table carries upstream's hand-added row (see the test above).
        $this->assertSame('claude-haiku-5-5', $this->session->model()?->id);
        $this->assertStringNotContainsString('Pick a model', $this->screen());
        $this->assertStringContainsString('Model: claude-haiku-5-5', $this->screen());
    }

    public function testAThinkingLevelCanRideAlongWithTheModel(): void
    {
        $this->start();

        $this->type('/model sonnet:high');
        $this->type(self::ENTER);

        $this->assertSame(ThinkingLevel::High, $this->session->thinkingLevel());

        // Said out loud, because switching models can change the level under you and
        // finding that out from a bill is worse than reading it here.
        $this->assertStringContainsString('thinking high', $this->screen());
    }

    public function testAPatternThatMatchesNothingSaysSoInsteadOfPickingOne(): void
    {
        $this->start();
        $before = $this->session->model()?->id;

        $this->type('/model llama-9');
        $this->type(self::ENTER);

        $this->assertStringContainsString('Error: No model matches "llama-9"', $this->screen());
        $this->assertSame($before, $this->session->model()?->id);
    }

    public function testTheListIsTheModelsThereIsAKeyFor(): void
    {
        // A key for openai and nothing else, because the registry starts with twenty-one anthropic
        // models: a picker that was not filtered would show eight of those and this case would
        // pass on a screen that never mentions the provider it is about.
        $auth = Auth::inMemory();
        $auth->setRuntimeApiKey('openai', 'for-this-run');
        $this->start(auth: $auth);

        $this->type('/model');
        $this->type(self::ENTER);

        $screen = $this->screen();

        // Upstream's model selector lists `getAvailable()`. A picker that offers a model whose
        // every turn will fail is a picker that teaches people not to read it.
        $this->assertStringContainsString('openai', $screen);
        $this->assertStringNotContainsString('anthropic ·', $screen);
    }

    public function testAPatternForAProviderWithNoKeyMatchesNothing(): void
    {
        $auth = Auth::inMemory();
        $auth->setRuntimeApiKey('anthropic', 'for-this-run');
        $this->start(auth: $auth);
        $before = $this->session->model()?->id;

        $this->type('/model gpt-5');
        $this->type(self::ENTER);
        // Nothing cached matches, so the catalogs are refreshed first, as upstream's
        // `findExactModelMatch()` does, and the pattern is looked for again after.
        $this->assertStringContainsString('Refreshing model catalogs…', $this->screen());
        $this->settle();

        // Rather than switching to it and failing on the next turn, from inside the turn.
        $this->assertStringContainsString('No model matches "gpt-5"', $this->screen());
        $this->assertSame($before, $this->session->model()?->id);
    }

    public function testCtrlPMovesToTheNextModelAndBackAgain(): void
    {
        $auth = Auth::inMemory();
        $auth->setRuntimeApiKey('anthropic', 'for-this-run');
        $this->start(auth: $auth);

        // `CustomEditor` claimed both keys from the start and nothing was listening: upstream
        // binds them to cycling the model, so pressing them did nothing at all.
        $this->type("\x10");
        $first = $this->session->model()?->id;

        $this->type("\x10");
        $second = $this->session->model()?->id;

        $this->assertNotSame($first, $second);
        $this->assertStringContainsString('Model: ' . $second, $this->screen());

        $this->type("\e[112;6u");

        // Which is the point of having both: overshooting by one keystroke is the normal way to
        // use this, and the way back has to be a keystroke too.
        $this->assertSame($first, $this->session->model()?->id, 'shift+ctrl+p goes back');
    }

    public function testCtrlLOpensTheModelPicker(): void
    {
        $this->start();

        // `CustomEditor` has claimed ctrl+l since it was ported and nothing was listening, so the
        // key was taken off the text field and did nothing at all — the third time that exact
        // shape has turned up, after ctrl+p and `/debug`. Upstream binds it to its model selector.
        $this->type("\x0c");

        $this->assertStringContainsString('Pick a model', $this->screen());
    }

    public function testAMovedBindingMovesTheKeyTheHelpAndFreesTheOldOne(): void
    {
        $this->start(keybindings: new \Pig\CodingAgent\Keybindings(['app.model.select' => ['ctrl+e']]));

        // The old key is the text field's again — ctrl+l does nothing to the picker...
        $this->type("\x0c");
        $this->assertStringNotContainsString('Pick a model', $this->screen());

        // ...and the new one opens it.
        $this->type("\x05");
        $this->assertStringContainsString('Pick a model', $this->screen());
        $this->type("\e");

        // And the help names the key that works, not the one that used to.
        $this->type('/help');
        $this->type("\r");
        $text = $this->screenText();
        $this->assertMatchesRegularExpression('/ctrl\+e\s+choose a model from the list/', $text);
        $this->assertDoesNotMatchRegularExpression('/ctrl\+l\s+choose a model/', $text);
    }

    public function testReloadReadsKeybindingsJsonAgain(): void
    {
        is_dir($this->home) || mkdir($this->home, 0o755, true);
        $this->start(keybindings: \Pig\CodingAgent\Keybindings::load($this->home));

        file_put_contents($this->home . '/keybindings.json', json_encode(['app.model.select' => 'ctrl+e', 'app.nope' => 'x']));
        $this->type('/reload');
        $this->type(self::ENTER);
        $this->settle();

        $this->assertStringContainsString("binds 'app.nope', which pig has no action for", $this->screenText());

        $this->type("\x0c");
        $this->assertStringNotContainsString('Pick a model', $this->screen(), 'ctrl+l is the old key');
        $this->type("\x05");
        $this->assertStringContainsString('Pick a model', $this->screen(), 'the reloaded binding works without a restart');
    }

    public function testASessionActionGivenAKeyRunsItsCommand(): void
    {
        // Upstream's `app.session.tree` has no key until `keybindings.json` gives it one.
        $this->start(keybindings: new \Pig\CodingAgent\Keybindings(['app.session.tree' => ['f5']]));

        $this->type("\x1b[15~");
        $this->settle();

        $this->assertStringContainsString('This session is not being saved', $this->screenText());
        $this->assertSame('', $this->editorText(), 'the key is the action, not typing');
    }

    public function testTheEditingKeysAtThePromptGoThroughTheRegistry(): void
    {
        $this->start(keybindings: new \Pig\CodingAgent\Keybindings(['tui.editor.undo' => ['ctrl+z'], 'app.suspend' => []]));

        $this->type('hello');
        $this->type(' world');
        $this->type("\x1a"); // ctrl+z, moved onto undo
        $this->assertSame('hello', $this->editorText());

        $this->type("\x17"); // ctrl+w kills the word...
        $this->assertSame('', $this->editorText());
        $this->type("\x19"); // ...and ctrl+y yanks it back
        $this->assertSame('hello', $this->editorText());
    }

    public function testCtrlPStaysInsideTheScopeAndCarriesItsThinkingLevel(): void
    {
        $auth = Auth::inMemory();
        $auth->setRuntimeApiKey('anthropic', 'for-this-run');
        [$scope, $warnings] = ModelResolver::scope(
            ['zzp-plain', 'zzp-alpha:high'],
            $auth->availableModels(),
        );
        $this->assertSame([], $warnings);

        $this->start(auth: $auth, reasoning: true, modelScope: $scope);

        $this->type("\x10");

        // Two models in the scope and the current one is in neither — the test model is
        // `claude-test` — so the first press lands on the second entry, which is upstream's
        // `indexOf` quirk. What matters here is the level: `--models opus:high` says how hard
        // *that* model thinks, and a cycle that applied the model and forgot the level would be
        // the wired-at-one-end shape again.
        $this->assertSame('zzp-alpha', $this->session->model()?->id);
        $this->assertSame(ThinkingLevel::High, $this->session->thinkingLevel());
        $this->assertStringContainsString('thinking high', $this->screen());

        $this->type("\x10");

        $this->assertSame('zzp-plain', $this->session->model()?->id, 'and round the end of the scope');
    }

    public function testThePickerOffersTheScopeAndNothingElse(): void
    {
        $auth = Auth::inMemory();
        $auth->setRuntimeApiKey('anthropic', 'for-this-run');
        [$scope] = ModelResolver::scope(['claude-haiku-4-5'], $auth->availableModels());

        $this->start(auth: $auth, modelScope: $scope);

        $this->type('/model');
        $this->type(self::ENTER);

        $screen = $this->screen();

        // A picker offering twenty models ctrl+p cannot reach is the same fault as a picker
        // offering a model whose every turn fails, one step milder — so the scope narrows every
        // list, not only the cycling.
        $this->assertStringContainsString('claude-haiku-4-5', $screen);
        $this->assertStringNotContainsString('claude-opus-4-1', $screen);
    }

    public function testWithOneModelInTheScopeCtrlPSaysSoRatherThanNothing(): void
    {
        $auth = Auth::inMemory();
        $auth->setRuntimeApiKey('anthropic', 'for-this-run');
        [$scope] = ModelResolver::scope(['claude-haiku-4-5'], $auth->availableModels());

        $this->start(auth: $auth, modelScope: $scope);

        $this->type("\x10");

        $this->assertStringContainsString('Only one model in the scope --models set.', $this->screen());
    }

    public function testPickingFromTheListSwitches(): void
    {
        $this->start();

        $this->type('/model');
        $this->type(self::ENTER);
        $this->type(self::ENTER);

        // **The first row of the list, whichever it is** — which is what the assertion says
        // now. It used to name the row, and the first regeneration of the registry from
        // models.dev put a different model at the top, so a case whose own comment said the id
        // did not matter failed because the id had changed. What matters is that choosing one
        // actually changes the model and closes the picker.
        $this->assertNotSame('claude-test', $this->session->model()?->id);
        $this->assertNotNull($this->session->model());
        $this->assertStringNotContainsString('Pick a model', $this->screen());
    }

    // ---- compaction -------------------------------------------------------------------------

    public function testCompactSummarisesTheConversationAndSaysSoInTheTranscript(): void
    {
        $this->start(['a summary of it all']);

        foreach (range(1, 6) as $ignored) {
            $this->session->agent->appendMessage(new UserMessage(str_repeat('x', 40_000)));
        }

        $this->type('/compact');
        $this->type(self::ENTER);
        $this->settle();

        $screen = $this->screen();

        $this->assertStringContainsString('[compaction]', $screen);
        // `tokensBefore` is upstream's estimate of the projected context, so it is known even
        // before any answer reported a usage.
        $this->assertMatchesRegularExpression('/Compacted from [\d,]+ tokens/', $screen);

        // Collapsed by default: the summary is long, and the transcript above it is what
        // the person was reading.
        $this->assertStringNotContainsString('a summary of it all', $screen);
    }

    public function testCompactingSaysEscapeCancelsItAndEscapeDoes(): void
    {
        // Upstream's `CompactionStatusIndicator`: `Compacting context... (escape to cancel)` for
        // `/compact`, and `compaction_end` with `aborted` shows the error `Compaction cancelled`.
        $this->start(['a summary of it all']);

        foreach (range(1, 6) as $ignored) {
            $this->session->agent->appendMessage(new UserMessage(str_repeat('x', 40_000)));
        }

        $this->holdTheAgent();
        $this->type('/compact');
        $this->type(self::ENTER);
        self::turnTheLoop();

        $this->assertMatchesRegularExpression('/Compacting context\\.\\.\\.( · \\d+s)? \\(escape to cancel\\)/u', $this->screen());

        $this->type(self::ESC);
        self::turnTheLoop();

        $this->assertStringContainsString('Error: Compaction cancelled', $this->screen());
        $this->assertStringNotContainsString('Compacting context...', $this->screen());
    }

    public function testSummarisingTheBranchSaysEscapeCancelsItAndEscapeReopensTheTree(): void
    {
        // Upstream's `BranchSummaryStatusIndicator`, and on an aborted summary
        // `showStatus("Branch summarization cancelled")` with the tree shown again.
        $this->start(['first answer', 'second answer', 'the summary'], store: true);

        foreach (['hello', 'and again'] as $said) {
            $this->type($said);
            $this->type(self::ENTER);
            $this->settle();
        }

        $this->holdTheAgent();
        $this->type('/tree');
        $this->type(self::ENTER);
        $this->type("\e[B");
        $this->type("\e[B");
        $this->type(self::ENTER);
        $this->settle();

        // "Summarise the branch you are leaving?" — Yes is first.
        $this->type(self::ENTER);
        self::turnTheLoop();

        $this->assertMatchesRegularExpression('/Summarizing branch\\.\\.\\.( · \\d+s)? \\(escape to cancel\\)/u', $this->screen());

        $this->type(self::ESC);
        self::turnTheLoop();

        $screen = $this->screen();
        $this->assertStringContainsString('Branch summarization cancelled', $screen);
        $this->assertStringContainsString('Go back to', $screen);
        $this->assertStringContainsString('second answer', $screen, 'nothing moved');
    }

    public function testCtrlOOpensTheSummaryTheModelWillBeWorkingFrom(): void
    {
        $this->start(['a summary of it all']);

        foreach (range(1, 6) as $ignored) {
            $this->session->agent->appendMessage(new UserMessage(str_repeat('x', 40_000)));
        }

        $this->type('/compact');
        $this->type(self::ENTER);
        $this->settle();

        $this->type("\x0f");

        // The only way to tell a good summary from a bad one before it costs you
        // something.
        $this->assertStringContainsString('a summary of it all', $this->screen());
    }

    public function testANearlyFullContextIsCompactedBeforeTheTurnRatherThanAfterTheFailure(): void
    {
        $this->start(['a summary of it all', 'and the answer']);

        foreach (range(1, 6) as $ignored) {
            $this->session->agent->appendMessage(new UserMessage(str_repeat('x', 40_000)));
        }

        // What the provider said the last turn carried: 190k of a 200k window, which
        // leaves no room for an answer.
        $this->session->agent->appendMessage(new AssistantMessage(
            [new TextContent('so far so good')],
            Api::AnthropicMessages,
            'anthropic',
            'claude-test',
            new Usage(0, 0, 0, 0, 190_000),
            StopReason::Stop,
        ));

        $this->type('one more thing');
        $this->type(self::ENTER);
        $this->settle();

        $screen = $this->screen();

        // The session's own check before the prompt (`AgentSession::prompt()`, upstream's
        // `_checkCompaction()`), drawn from its `compaction_start` / `compaction_end`.
        $this->assertStringContainsString('Compacted', $screen);
        $this->assertStringContainsString('and the answer', $screen);
    }

    public function testCompactingAShortConversationSaysWhyInUpstreamsWords(): void
    {
        // No scripted answers: a conversation with nothing old enough to drop must not
        // reach the provider at all.
        $this->start();

        $this->type('/compact');
        $this->type(self::ENTER);
        $this->settle();

        // Upstream's wording, because it is the wording someone will search for.
        $this->assertStringContainsString(
            'Error: Compaction failed: Nothing to compact (session too small)',
            $this->screen(),
        );
    }

    public function testCompactingTwiceOverSaysItIsAlreadyDone(): void
    {
        $this->start();
        $this->session->agent->appendMessage(new CompactionSummary('already summarised'));

        $this->type('/compact');
        $this->type(self::ENTER);
        $this->settle();

        $this->assertStringContainsString('Error: Compaction failed: Already compacted', $this->screen());
    }

    public function testCompactingWhileTheAgentWorksSaysToStopItFirst(): void
    {
        $this->start(['done']);

        $held = $this->holdTheAgent();

        $this->type('hello');
        $this->type(self::ENTER);
        $this->settle();

        $this->type('/compact');
        $this->type(self::ENTER);
        $this->settle();

        $this->assertStringContainsString('Warning: Still working', $this->screen());

        $held();
        $this->settle();
    }

    // ---- a prompt from the command line -------------------------------------------------

    public function testAMessageFromTheCommandLineIsSentWithoutAKeystroke(): void
    {
        $this->start(answers: ['the answer'], initialMessages: ['what does this do?']);
        $this->settle();

        // `bin/pig "what does this do?"` asks, and then leaves you in the terminal — which is
        // the difference from `-p`, and the reason it goes through the same path a typed
        // message does rather than a shortcut of its own.
        $screen = $this->screen();
        $this->assertStringContainsString('what does this do?', $screen);
        $this->assertStringContainsString('the answer', $screen);
    }

    public function testSeveralMessagesAreSentInTheOrderTheyWereGiven(): void
    {
        $this->start(answers: ['first answer', 'second answer'], initialMessages: ['one', 'two']);
        $this->settle();

        $messages = self::said($this->session->messages());
        $this->assertCount(4, $messages);
        $this->assertSame('one', $messages[0]->content[0]->text);
        $this->assertSame('first answer', $messages[1]->content[0]->text);
        $this->assertSame('two', $messages[2]->content[0]->text);
    }

    public function testTheTerminalIsStillYoursAfterwards(): void
    {
        $this->start(answers: ['answered', 'and again'], initialMessages: ['from the shell']);
        $this->settle();

        // Two calls, because one chunk is one key: `'text' . ENTER` arrives as a
        // fourteen-character key that is not Enter, and lands in the editor as text.
        $this->type('typed by hand');
        $this->type(self::ENTER);
        $this->settle();

        $this->assertStringContainsString('typed by hand', $this->screen());
        $this->assertCount(4, self::said($this->session->messages()));
    }

    public function testAnImageRidesOnTheFirstMessageOnly(): void
    {
        $image = new ImageContent(TinyImages::PNG_BASE64, 'image/png');
        $this->start(
            answers: ['ok', 'ok again'],
            initialMessages: ['look', 'and again'],
            initialImages: [$image],
        );
        $this->settle();

        $messages = self::said($this->session->messages());
        $this->assertCount(2, $messages[0]->content, 'the text and the image');
        $this->assertCount(1, $messages[2]->content, 'the text only');
    }

    public function testNoMessageFromTheCommandLineLeavesTheBannerAlone(): void
    {
        $this->start();
        $this->settle();

        $this->assertSame([], $this->session->messages());
        $this->assertStringContainsString('Pig v0.0.0', $this->screen());
    }

    // ---- the queue ------------------------------------------------------------------------------

    public function testTypingWhileTheAgentWorksQueuesRatherThanRefuses(): void
    {
        $this->start([...array_fill(0, 2, 'done')]);

        $held = $this->holdTheAgent();

        $this->type('first');
        $this->type(self::ENTER);
        $this->settle();

        $this->type('and another thing');
        $this->type(self::ENTER);

        $this->assertSame(['and another thing'], $this->session->queued());
        // Enter mid-turn steers, and the line says so — upstream's `Steering:` — with the way
        // back out named under it, since a queued line that cannot be taken back is one nobody
        // dares to queue. `Option` on a Mac and `Alt` elsewhere, which is what the key says.
        $this->assertStringContainsString('Steering: and another thing', $this->screen());
        $this->assertMatchesRegularExpression('/↳ (Option|Alt)\+Up to edit all queued messages/', $this->screen());

        $held();
        $this->settle();
    }

    public function testCtrlEnterWhileTheAgentWorksIsAFollowUpAndNotASteer(): void
    {
        // Upstream's `app.message.followUp`: Enter cuts in after the tool that is running,
        // Ctrl+Enter (upstream's Alt+Enter) waits for the turn to end. The two queues are kept
        // apart and the screen labels each by what it will do.
        $this->start([...array_fill(0, 2, 'done')]);

        $held = $this->holdTheAgent();

        $this->type('first');
        $this->type(self::ENTER);
        $this->settle();

        $this->type('do this next');
        $this->type(self::CTRL_ENTER);

        $this->assertSame(['steering' => [], 'followUp' => ['do this next']], $this->session->queuedByKind());
        $this->assertStringContainsString('Follow-up: do this next', $this->screen());
        $this->assertSame('', $this->editorText(), 'the prompt was handed over');

        $held();
        $this->settle();
    }

    public function testCtrlEnterFromAnIdlePromptIsEnter(): void
    {
        // Nothing to wait behind, so upstream sends it as Enter would.
        $this->start(['done']);

        $this->type('hello');
        $this->type(self::CTRL_ENTER);
        $this->settle();

        $this->assertSame([], $this->session->queued());
        $this->assertStringContainsString('done', $this->screen());
        $this->assertSame('', $this->editorText());
    }

    public function testAltEnterWhileTheAgentWorksBreaksTheLineAndNeverQueues(): void
    {
        // pig's Alt+Enter is Shift+Enter: a terminal without the kitty protocol cannot tell the
        // two apart, so neither is a follow-up anywhere.
        $this->start(['done']);

        $held = $this->holdTheAgent();

        $this->type('first');
        $this->type(self::ENTER);
        $this->settle();

        $this->type('line 1');
        $this->type(self::ALT_ENTER);
        $this->type('line 2');

        $this->assertSame(['steering' => [], 'followUp' => []], $this->session->queuedByKind());
        $this->assertSame("line 1\nline 2", $this->editorText());

        $held();
        $this->settle();
    }

    public function testCommandEnterWhileTheAgentWorksIsAFollowUp(): void
    {
        $this->start([...array_fill(0, 2, 'done')]);

        $held = $this->holdTheAgent();

        $this->type('first');
        $this->type(self::ENTER);
        $this->settle();

        $this->type('queued via cmd enter');
        $this->type(self::CMD_ENTER);

        $this->assertSame(['steering' => [], 'followUp' => ['queued via cmd enter']], $this->session->queuedByKind());
        $this->assertStringContainsString('Follow-up: queued via cmd enter', $this->screen());
        $this->assertSame('', $this->editorText());

        $held();
        $this->settle();
    }

    public function testCommandEnterFromAnIdlePromptSends(): void
    {
        $this->start(['done']);

        $this->type('hello via command enter');
        $this->type(self::CMD_ENTER);
        $this->settle();

        $this->assertSame([], $this->session->queued());
        $this->assertStringContainsString('done', $this->screen());
        $this->assertSame('', $this->editorText());
    }

    public function testShiftEnterWhileTheAgentWorksBreaksTheLineAndNeverQueues(): void
    {
        $this->start(['done']);

        $held = $this->holdTheAgent();

        $this->type('first');
        $this->type(self::ENTER);
        $this->settle();

        $this->type('line 1');
        $this->type(self::SHIFT_ENTER);
        $this->type('line 2');

        $this->assertSame(['steering' => [], 'followUp' => []], $this->session->queuedByKind());
        $this->assertSame("line 1\nline 2", $this->editorText());

        $held();
        $this->settle();
    }

    public function testAltUpTakesTheQueueBackWithoutStoppingTheTurn(): void
    {
        // Upstream's `app.message.dequeue`: escape also hands the queue back, but on its way to
        // stopping the turn. This is for changing your mind about what was queued while the
        // agent carries on.
        $this->start([...array_fill(0, 2, 'done')]);

        $held = $this->holdTheAgent();

        $this->type('first');
        $this->type(self::ENTER);
        $this->settle();

        $this->type('steer this');
        $this->type(self::ENTER);
        $this->type('and follow with this');
        $this->type(self::CTRL_ENTER);
        $this->type('half typed');
        $this->type(self::ALT_UP);

        $this->assertSame([], $this->session->queued());
        $this->assertTrue($this->session->isStreaming(), 'the turn carried on');
        $this->assertSame("steer this\n\nand follow with this\n\nhalf typed", $this->editorText());
        $this->assertStringNotContainsString('Steering:', $this->screen());
        $this->assertStringContainsString('Restored 2 queued messages to editor', $this->screen());

        $held();
        $this->settle();
    }

    public function testAltUpWithNothingQueuedSaysSo(): void
    {
        $this->start();
        $this->type(self::ALT_UP);

        $this->assertStringContainsString('No queued messages to restore', $this->screen());
    }

    public function testQuittingWhileTheAgentIsWorkingAbortsTheAgentAndStops(): void
    {
        $this->start(['done']);
        $this->holdTheAgent();

        $this->type('hello');
        $this->type(self::ENTER);
        $this->settle();

        $this->assertTrue($this->session->isStreaming());

        $this->type('/quit');
        $this->type(self::ENTER);
        $this->settle();

        $this->assertFalse($this->session->isStreaming());
    }

    public function testAFileCommandQueuedMidTurnReachesTheModelAsItsPromptAndComesBackAsItsName(): void
    {
        $this->start(['first done', 'reviewed'], fileCommands: [
            new FileCommand('review', 'Review a file', 'Please review $1 closely.', '(user)'),
        ]);

        $held = $this->holdTheAgent();

        $this->type('first');
        $this->type(self::ENTER);
        $this->settle();

        $this->type('/review src/Foo.php');
        $this->type(self::ENTER);

        // Two halves of one decision. What is *waiting* is the line as typed, because that list
        // is what escape hands back to the editor — a forty-line stored prompt in front of
        // somebody who typed `/review foo.php` is not putting their text back.
        $this->assertSame(['/review src/Foo.php'], $this->session->queued());
        $this->assertStringContainsString('Steering: /review src/Foo.php', $this->screen());

        $held();
        $this->settle();

        // And what the *model* is handed is the prompt. Upstream queues the raw line at both
        // ends, so a file command typed during a turn reaches the model there as the eight
        // characters `/review `.
        $this->assertStringContainsString('Please review src/Foo.php closely.', $this->screen());
    }

    public function testInterruptingGivesTheQueuedTextBack(): void
    {
        $this->start(['done']);

        $held = $this->holdTheAgent();

        $this->type('first');
        $this->type(self::ENTER);
        $this->settle();

        $this->type('second');
        $this->type(self::ENTER);
        $this->type(self::ESC);

        // Losing what someone typed because they pressed Escape is how people stop
        // trusting the queue at all, so it goes back into the editor.
        $this->assertSame([], $this->session->queued());
        $this->assertStringContainsString('second', $this->screen());

        $held();
        $this->settle();
    }

    // ---- extension commands --------------------------------------------------------------

    public function testACommandAHookRegisteredRunsWithItsArguments(): void
    {
        $seen = null;
        $api = new ExtensionApi($this->cwd, 'deploy.php');
        $api->registerCommand('deploy', static function (string $arguments) use (&$seen): void {
            $seen = $arguments;
        });

        $this->start(extensionRunner: $this->runner($api));
        $this->type('/deploy staging --now');
        $this->type(self::ENTER);
        // Settled, because the command runs inside `AgentSession::prompt()` in a fiber of its
        // own now — a handler that opens a dialog must not be run inside the input callback.
        $this->settle();

        $this->assertSame('staging --now', $seen);
    }

    public function testACommandThatFailsIsAWarningRatherThanTheEndOfTheSession(): void
    {
        $api = new ExtensionApi($this->cwd, 'deploy.php');
        $api->registerCommand('deploy', static function (): void {
            throw new RuntimeException('no credentials');
        });

        $this->start(extensionRunner: $this->runner($api));
        $this->type('/deploy');
        $this->type(self::ENTER);
        $this->settle();

        $this->assertStringContainsString('Warning: extension deploy.php (/deploy): no credentials', $this->screen());
    }

    public function testAHookCannotShadowABuiltIn(): void
    {
        $called = false;
        $api = new ExtensionApi($this->cwd, 'evil.php');
        $api->registerCommand('help', static function () use (&$called): void {
            $called = true;
        });

        $this->start(extensionRunner: $this->runner($api));
        $this->type('/help');
        $this->type(self::ENTER);

        $this->assertFalse($called);
        $this->assertStringContainsString('ctrl+o', $this->screen());
    }

    public function testAHookCommandIsOfferedInTheBanner(): void
    {
        $api = new ExtensionApi($this->cwd, 'deploy.php');
        $api->registerCommand('deploy', static fn () => null, 'Ship it');

        $this->start(extensionRunner: $this->runner($api));
        $this->type("\x0f");

        $this->assertStringContainsString('deploy.php', $this->screen());
    }

    public function testAHookThatFailsMidRunIsAWarningInTheTranscript(): void
    {
        $api = new ExtensionApi($this->cwd, 'watcher.php');
        $api->on('turn_end', static function (): void {
            throw new RuntimeException('counted wrong');
        });

        $this->start(['the answer'], extensionRunner: $this->runner($api, 'watcher.php'));
        $this->type('hello');
        $this->type(self::ENTER);
        $this->settle();

        $screen = $this->screen();

        $this->assertStringContainsString('the answer', $screen);
        $this->assertStringContainsString('Warning: extension watcher.php (turn_end)', $screen);
    }

    public function testAHookCommandStillRunsWhileTheAgentIsWorking(): void
    {
        $seen = null;
        $api = new ExtensionApi($this->cwd, 'deploy.php');
        $api->registerCommand('deploy', static function (string $arguments) use (&$seen): void {
            $seen = $arguments;
        });

        $this->start(['answered'], extensionRunner: $this->runner($api));
        $release = $this->holdTheAgent();

        $this->type('hi');
        $this->type(self::ENTER);
        $this->settle();

        // A hook's command is code, not a message, so there is nothing for it to wait behind —
        // which is why the dispatch in `prompt()` sits in front of the "already working" throw.
        // Upstream's own comment says the same and its code throws there.
        $this->type('/deploy now');
        $this->type(self::ENTER);
        $this->settle();

        $this->assertSame('now', $seen);

        $release();
        $this->settle();
    }

    public function testAnExtensionCanStackItsOwnCompletionsOnTheBuiltInOnes(): void
    {
        $api = new ExtensionApi($this->cwd, 'completer.php');
        $api->on('session_start', static function ($event, $ctx): void {
            $ctx->ui->addAutocompleteProvider(static fn (AutocompleteProvider $base): AutocompleteProvider => new class($base) implements AutocompleteProvider {
                public function __construct(private readonly AutocompleteProvider $base)
                {
                }

                #[\Override]
                public function suggestions(array $lines, int $cursorLine, int $cursorCol): ?Suggestions
                {
                    $before = substr($lines[$cursorLine] ?? '', 0, $cursorCol);

                    return str_starts_with($before, '/zz')
                        ? new Suggestions([new AutocompleteItem('zz-from-extension')], $before)
                        : $this->base->suggestions($lines, $cursorLine, $cursorCol);
                }

                #[\Override]
                public function apply(array $lines, int $cursorLine, int $cursorCol, AutocompleteItem $item, string $prefix): Completion
                {
                    return $this->base->apply($lines, $cursorLine, $cursorCol, $item, $prefix);
                }
            });
        });

        $this->start(extensionRunner: $this->runner($api, 'completer.php'));
        $this->type('/');
        $this->type('zz');

        $this->assertStringContainsString('zz-from-extension', $this->screen());

        // The built-ins are still underneath: the wrapper hands anything else on.
        $this->type(self::ESC);
        $this->type("\x03");
        $this->type('/');
        $this->type('hel');
        $this->assertStringContainsString('Show the keys and commands', $this->screen());
    }

    public function testAnExtensionCanPutItsOwnPromptInPlaceAndTakeItBack(): void
    {
        $api = new ExtensionApi($this->cwd, 'vim.php');
        $api->registerCommand('vim', static function (string $arguments, $ctx): void {
            if ($ctx->ui->getEditorComponent() !== null) {
                $ctx->ui->setEditorText('kept');
                $ctx->ui->setEditorComponent(null);

                return;
            }

            $ctx->ui->setEditorComponent(static fn ($tui, $theme, $keybindings): CustomEditor => new class(new Editor($theme), $keybindings) extends CustomEditor {
                #[\Override]
                public function handleInput(string $data): void
                {
                    // A prompt of its own: `Z` means something to it and never reaches the text.
                    if ($data !== 'Z') {
                        parent::handleInput($data);
                    }
                }
            });
        });

        $this->start(extensionRunner: $this->runner($api, 'vim.php'));
        $this->type('/vim');
        $this->type(self::ENTER);
        $this->settle();

        $this->type('x');
        $this->type('Z');
        $this->type('y');
        $this->assertStringContainsString('xy', $this->screen());
        $this->assertStringNotContainsString('xZy', $this->screen());

        // The app's own keys still work from inside it: ctrl+c clears, and Enter submits.
        $this->type("\x03");
        $this->type('/help');
        $this->type(self::ENTER);
        $this->settle();
        $this->assertStringContainsString('/compact', $this->screen());

        // Back to the default, with the text the extension left in it.
        $this->type('/vim');
        $this->type(self::ENTER);
        $this->settle();
        $this->type('Z');
        $this->assertStringContainsString('keptZ', $this->screen());
    }

    /** Upstream #11431: replacing the prompt while a dialog is open took the dialog's keys. */
    public function testReplacingThePromptLeavesAnOpenDialogAnswerable(): void
    {
        $answer = null;
        $api = new ExtensionApi($this->cwd, 'swap.php');
        $api->registerCommand('swap', static function (string $arguments, $ctx) use (&$answer): void {
            Async::spawn(static function () use ($ctx, &$answer): void {
                $answer = $ctx->ui->confirm('Keep going?', '');
            });
            // Once the confirm is open.
            Async::spawn(static function () use ($ctx): void {
                $ctx->ui->setEditorComponent(static fn ($tui, $theme, $keybindings): CustomEditor => new class(new Editor($theme), $keybindings) extends CustomEditor {
                    #[\Override]
                    public function handleInput(string $data): void
                    {
                        parent::handleInput($data === 'Z' ? 'new' : $data);
                    }
                });
            });
        });

        $this->start(extensionRunner: $this->runner($api, 'swap.php'));
        $this->type('/swap');
        $this->type(self::ENTER);
        $this->settle();

        $this->assertStringContainsString('Keep going?', $this->screen());
        $this->type(self::ENTER);
        $this->settle();
        $this->assertTrue($answer);

        // The new prompt has the keys once the dialog is gone.
        $this->type('Z');
        $this->assertStringContainsString('new', $this->screen());
    }

    private function runner(ExtensionApi $api, string $path = 'deploy.php'): ExtensionRunner
    {
        return new ExtensionRunner([new LoadedExtension($path, $path, $api->name, $api)], $this->cwd);
    }

    // ---- naming a point ----------------------------------------------------------------

    public function testLabelNamesWhereTheConversationIs(): void
    {
        $this->start(answers: ['answered'], store: true);
        $this->type('hi');
        $this->type(self::ENTER);
        $this->settle();

        $this->type('/label before the refactor');
        $this->type(self::ENTER);
        $this->settle();

        // The last thing *said*, which is not the leaf: writing the label advanced it.
        $store = $this->session->store();
        self::assertNotNull($store);
        $points = $store->branch();
        $named = $points[count($points) - 1]['id'];

        $this->assertSame('before the refactor', $store->labelOf($named));
        $this->assertStringContainsString('before the refactor', $this->screen());
    }

    public function testNameCommandSetsAndShowsSessionName(): void
    {
        $this->start(answers: ['answered'], store: true);
        $this->type('/name');
        $this->type(self::ENTER);
        $this->settle();

        $this->assertStringContainsString('Usage: /name <name>', $this->screen());

        $this->type('/name 仿写更新日志规则模板');
        $this->type(self::ENTER);
        $this->settle();

        $this->assertStringContainsString('Session name set: 仿写更新日志规则模板', $this->screen());
        $this->assertSame('仿写更新日志规则模板', $this->session->getSessionName());

        $this->type('/name');
        $this->type(self::ENTER);
        $this->settle();

        $this->assertStringContainsString('Session name: 仿写更新日志规则模板', $this->screen());
    }

    public function testTreeShowsTheNameBesideWhatWasSaid(): void
    {
        $this->start(answers: ['answered', 'again'], store: true);
        $this->type('the first thing');
        $this->type(self::ENTER);
        $this->settle();

        $this->type('/label before the refactor');
        $this->type(self::ENTER);
        $this->settle();

        $this->type('the second thing');
        $this->type(self::ENTER);
        $this->settle();

        $this->type('/tree');
        $this->type(self::ENTER);
        $this->settle();

        // Both: the name is what you were thinking, the message is what was actually said,
        // and a list of "4 back · 7 back" is a list nobody can choose from.
        $screen = $this->screen();
        $this->assertStringContainsString('before the refactor', $screen);
        $this->assertStringContainsString('the first thing', $screen);
    }

    public function testLabelWithNothingClearsIt(): void
    {
        $this->start(answers: ['answered'], store: true);
        $this->type('hi');
        $this->type(self::ENTER);
        $this->settle();

        $this->type('/label a name');
        $this->type(self::ENTER);
        $this->settle();

        $this->type('/label');
        $this->type(self::ENTER);
        $this->settle();

        // Asserted on the point that was named, not on whatever the leaf is now — which
        // is what made the first version of this test pass without clearing anything.
        $store = $this->session->store();
        self::assertNotNull($store);
        $points = $store->branch();
        $named = $points[count($points) - 1]['id'];

        $this->assertNull($store->labelOf($named));
        $this->assertStringContainsString('Name cleared', $this->screen());
    }

    public function testLabelInAnUnsavedSessionSaysWhyNot(): void
    {
        $this->start(answers: ['answered']);

        $this->type('/label a name');
        $this->type(self::ENTER);
        $this->settle();

        // Not silence: a name that would not survive the session is a name nobody asked for.
        $this->assertStringContainsString('would not survive', $this->screen());
    }

    // ---- an edit shown before it is made ----------------------------------------------

    /** @param array<string, mixed> $arguments */
    private static function wants(string $tool, array $arguments): AssistantMessage
    {
        return new AssistantMessage(
            [new ToolCall('call-1', $tool, $arguments)],
            Api::AnthropicMessages,
            'anthropic',
            'claude-test',
            new Usage(),
            StopReason::ToolUse,
        );
    }

    /**
     * The window the preview exists for, and the wire that has to reach it.
     *
     * The component computing its own preview is one end; this is the other. A `tool_call`
     * hook parks the whole turn on a question, and until this was wired the answer was
     * given with nothing on screen but a path — approving a change to a file without being
     * shown the change.
     */
    public function testAnEditIsOnScreenBeforeAHookIsAskedWhetherToAllowIt(): void
    {
        file_put_contents($this->cwd . '/notes.txt', "one\ntwo\nthree\n");

        $api = new ExtensionApi($this->cwd, 'guard.php');
        $api->on('tool_call', function ($event, $context): mixed {
            $context->ui->confirm('Let edit run?', 'notes.txt');

            return null;
        });

        $this->start(
            answers: [self::wants('edit', ['path' => 'notes.txt', 'edits' => [['oldText' => 'two', 'newText' => 'TWO']]]), 'done'],
            extensionRunner: $this->runner($api, 'guard.php'),
            tools: ['edit'],
        );

        $this->type('fix line two');
        $this->type(self::ENTER);
        $this->settle();

        $screen = $this->screen();
        $this->assertStringContainsString('Let edit run?', $screen);
        $this->assertStringContainsString('-2 two', $screen);
        $this->assertStringContainsString('+2 TWO', $screen);

        // And it really has not happened yet.
        $this->assertSame("one\ntwo\nthree\n", file_get_contents($this->cwd . '/notes.txt'));

        $this->type("\e[B");
        $this->type(self::ENTER);
        $this->settle();

        $this->assertSame("one\nTWO\nthree\n", file_get_contents($this->cwd . '/notes.txt'));
    }

    /**
     * The other end of the wire, and the end that was missing.
     *
     * `ExtensionRunnerTest` drives the runner with a signal handed to it directly; nothing checked
     * that the *terminal* hands it one. Taking `signal:` out of `initialize()` here broke no
     * test at all — the same "wired at one end only" shape as the ctrl+o handler that named
     * three classes, made again inside its own fix.
     */
    public function testEscapeStopsACommandAHooksGuardStarted(): void
    {
        $result = null;
        $api = new ExtensionApi($this->cwd, 'guard.php');
        $api->on('tool_call', function ($event, $context) use (&$result, $api): mixed {
            // Escape arrives while this is parked on the command, which is the real order: the
            // loop can only deliver the key because the command is not blocking it.
            Async::spawn(function (): void {
                Async::delay(0.05);
                $this->type(self::ESC);
            });

            $result = $api->exec(['sh', '-c', 'echo guarding; sleep 5']);

            return null;
        });

        $this->start(
            answers: [self::wants('read', ['path' => 'notes.txt']), 'done'],
            extensionRunner: $this->runner($api, 'guard.php'),
        );

        $started = microtime(true);
        $this->type('read it');
        $this->type(self::ENTER);
        $this->settle();

        $this->assertNotNull($result, 'the guard never ran');
        $this->assertTrue($result->stopped());
        $this->assertStringContainsString('guarding', $result->stdout);
        $this->assertLessThan(3.0, microtime(true) - $started, 'escape did not reach the command');
    }

    public function testEnterDuringAnAutoCompactionKeepsWhatYouTypedRatherThanLosingIt(): void
    {
        // `Editor::$disableSubmit` is honoured, `CustomEditor::disableSubmit()` is public, and
        // nothing in pig ever called either — upstream's one use is exactly this window. Without
        // it the submit handler clears the editor and spawns a turn that parks on the
        // compaction; when the compaction's own carry-on starts a run, that turn wakes up to
        // `Agent is already working` and the message is gone, with a red line where it went.
        $this->start(
            answers: [
                'first',
                'second',
                self::failed('prompt is too long: 213462 tokens > 200000 maximum'),
                'the summary',
                'answered after summarising',
                'and one more',
            ],
            settings: Settings::inMemory(['compaction' => ['keepRecentTokens' => 1]]),
        );

        // Two answered turns first, because a compaction has to be worth making — and the fourth
        // model call, the summariser, is the one held.
        $release = $this->holdTheAgent(letThrough: 3);

        foreach (['one', 'two', 'three'] as $said) {
            $this->type($said);
            $this->type(self::ENTER);
            $this->settle();
        }

        // Upstream's `CompactionStatusIndicator` for an overflow.
        // pig's loader puts the elapsed seconds in front of the parenthesis once a second has passed.
        $this->assertMatchesRegularExpression('/Context overflow detected, Auto-compacting\\.\\.\\.( · \\d+s)? \\(escape to cancel\\)/u', $this->screen());

        $this->type('a question I was half way through');
        $this->type(self::ENTER);
        $this->settle();

        $this->assertStringContainsString('a question I was half way through', $this->screen());
        $this->assertStringNotContainsString('already working', $this->screen());

        $release();
        $this->settle();

        // And Enter works again afterwards, which nothing else asserts: leaving the flag set is a
        // prompt that has quietly stopped sending, and it breaks no other test in this file.
        $this->type(' — and now the rest of it');
        $this->type(self::ENTER);
        $this->settle();

        // The *answer* and not the text: with submit still disabled the typed line is on screen
        // either way — in the editor rather than in the transcript — so asserting on it is an
        // assertion that cannot fail. What only happens if the turn ran is the reply.
        $this->assertStringContainsString('and one more', $this->screen());
    }

    public function testAProvidersQuotaWallIsShownOnceAsItWasWordedAndNotRetried(): void
    {
        // The actionable sentence is the provider's own now — pi-antigravity's, which
        // `AntigravityApi` writes — and the session neither rewrites it nor retries it. pig's
        // session used to turn "out of quota (429): … Resets in …" into this sentence itself.
        $wall = 'Quota reached. Please wait 13h58m52s. Next: switch models or try again after reset.';

        $this->start(answers: [self::failed($wall)]);
        $this->type('hi');
        $this->type(self::ENTER);
        $this->settle();

        $screen = $this->screenText();
        $this->assertSame(1, substr_count($screen, $wall));
        $this->assertStringNotContainsString('Retrying', $screen);
    }

    public function testEscapeStopsTheRetryTheScreenSaysItCanStop(): void
    {
        // Two loaders on this screen name escape — the retry countdown and the summariser — and
        // `interrupt()`'s last branch called `$this->session->agent->abort()`, which reaches
        // neither: a sleeping retry and a running summariser both happen between runs, where the
        // agent has no controller to raise. So the label said escape stopped it and the key did not.
        $this->start(
            answers: [self::failed('Anthropic returned 503: overloaded'), 'here you go'],
            settings: Settings::inMemory(['retry' => ['baseDelayMs' => 30_000]]),
        );

        $this->type('hi');
        $this->type(self::ENTER);
        self::turnTheLoop();

        $this->assertTrue($this->session->isRetrying());
        // Upstream's `RetryStatusIndicator` wording: the interrupt key as `keyText()` names it
        // (`escape`) and the seconds rounded up. This used to say `(esc to stop)`, which upstream
        // never says.
        $this->assertStringContainsString('Retrying (1/3) in 30s... (escape to cancel)', $this->screen());

        $this->type(self::ESC);
        self::turnTheLoop();

        $this->assertFalse($this->session->isRetrying());
        $this->assertStringContainsString('cancelled', $this->screen());
    }

    public function testTheRetryCountdownCountsDownOnceASecond(): void
    {
        // Upstream's `CountdownTimer` under the `RetryStatusIndicator`: the seconds left, ticked
        // down once a second until the retry starts.
        $this->start(
            answers: [self::failed('Anthropic returned 503: overloaded'), 'here you go'],
            settings: Settings::inMemory(['retry' => ['baseDelayMs' => 3_000]]),
        );

        $this->type('hi');
        $this->type(self::ENTER);
        self::turnTheLoop();

        $this->assertStringContainsString('Retrying (1/3) in 3s... (escape to cancel)', $this->screen());

        $until = microtime(true) + 1.3;

        while (microtime(true) < $until) {
            self::turnTheLoop(1);
            usleep(5_000);
        }

        $this->assertStringContainsString('Retrying (1/3) in 2s... (escape to cancel)', $this->screen());

        $this->type(self::ESC);
        self::turnTheLoop();
    }

    public function testWorkingIsBackForTheTurnAfterARetriedOneCalledATool(): void
    {
        // A successful retry is announced at the end of the answer it got, and that answer here
        // is a tool call: the turn after it — the model reading the tool's result — is still the
        // same run. Taking every loader down at the retry's end left that turn with nothing above
        // the prompt; upstream clears only the countdown, and shows Working on every turn_start.
        file_put_contents("{$this->cwd}/notes.txt", "a note\n");
        $this->start(
            answers: [self::failed('Anthropic returned 503: overloaded'), self::wants('read', ['path' => 'notes.txt']), 'never asked for'],
            settings: Settings::inMemory(['retry' => ['baseDelayMs' => 50]]),
        );
        $release = $this->holdTheAgent(letThrough: 2);

        $this->type('hi');
        $this->type(self::ENTER);
        $until = microtime(true) + 2.0;

        while ($this->held === null && microtime(true) < $until) {
            self::turnTheLoop(1);
            usleep(5_000);
        }

        $this->assertNotNull($this->held, 'the turn after the tool never asked the model');
        $this->assertStringContainsString('read notes.txt', $this->screen());
        $this->assertMatchesRegularExpression('/Working(?: · \d+s)?/', $this->screen());

        $release();
        $this->settle();
    }

    public function testWhatIsTypedDuringARetryJoinsThatPromptAndItSettlesOnce(): void
    {
        // Enter during "Retrying (1/3) in …" used to send a prompt of its own: the session said it
        // was not streaming between runs, so the text waited for the retried turn to settle and
        // then ran — `agent_settled`, the "task complete" notification, and Working again at once.
        // Upstream's session is streaming for the whole prompt, so the text is steering.
        $settled = 0;
        $api = new ExtensionApi('.', 'test.php');
        $api->on('agent_settled', static function () use (&$settled): void {
            $settled++;
        });

        $this->start(
            answers: [self::failed('Anthropic returned 503: overloaded'), 'here you go', 'never asked for'],
            settings: Settings::inMemory(['retry' => ['baseDelayMs' => 200]]),
            extensionRunner: new ExtensionRunner([new LoadedExtension('test.php', 'test.php', $api->name, $api)], $this->cwd),
        );

        $this->type('hi');
        $this->type(self::ENTER);
        self::turnTheLoop();

        $this->assertTrue($this->session->isRetrying());

        $this->type('also this');
        $this->type(self::ENTER);
        self::turnTheLoop();

        $this->assertSame(['also this'], $this->session->queuedByKind()['steering']);
        $this->assertSame(0, $settled);

        for ($tick = 0; $tick < 200 && !$this->session->isIdle(); $tick++) {
            Loop::get()->tick();
        }

        $this->assertSame([], $this->session->queued());
        $this->assertSame(1, $settled, 'one prompt, one agent_settled');
    }

    // ---- what a hook says -------------------------------------------------------------

    public function testAHooksMessageIsDrawnAsItsOwnThingNotAsSomethingYouSaid(): void
    {
        $api = new ExtensionApi('.', 'test.php');
        $extensionRunner = new ExtensionRunner([new LoadedExtension('test.php', 'test.php', $api->name, $api)], $this->cwd);
        $this->start(answers: ['ok'], extensionRunner: $extensionRunner);

        Async::spawn(static function () use ($api): void {
            $api->sendMessage('build', 'the build is broken');
        });
        $this->settle();

        $screen = $this->screen();
        $this->assertStringContainsString('the build is broken', $screen);

        // Labelled with the hook's own type: it reaches the model as a user message, and
        // drawing it as one would have someone scroll back and find themselves saying
        // something they never typed.
        $this->assertStringContainsString('build', $screen);
    }

    public function testALongHookMessageIsDrawnWholeAndCtrlOLeavesItSo(): void
    {
        // Upstream's default draw of a custom message is not folded.
        $api = new ExtensionApi('.', 'test.php');
        $extensionRunner = new ExtensionRunner([new LoadedExtension('test.php', 'test.php', $api->name, $api)], $this->cwd);
        $this->start(answers: ['ok'], extensionRunner: $extensionRunner);

        $long = implode("\n", array_map(static fn (int $i): string => "detail {$i}", range(1, 20)));

        Async::spawn(static function () use ($api, $long): void {
            $api->sendMessage('lint', $long);
        });
        $this->settle();

        $this->assertStringContainsString('detail 20', $this->screen());

        $this->type("\x0f");

        $this->assertStringContainsString('detail 20', $this->screen());
    }

    public function testAMessageMarkedNotToDisplayIsNotDrawn(): void
    {
        $api = new ExtensionApi('.', 'test.php');
        $extensionRunner = new ExtensionRunner([new LoadedExtension('test.php', 'test.php', $api->name, $api)], $this->cwd);
        $this->start(answers: ['ok'], extensionRunner: $extensionRunner);

        Async::spawn(static function () use ($api): void {
            $api->sendMessage('reminder', 'only for the model', display: false);
        });
        $this->settle();

        // It is in the conversation and not on the screen — which is the whole point of the
        // flag: a reminder injected before every turn would otherwise fill the transcript.
        $this->assertStringNotContainsString('only for the model', $this->screen());
        $this->assertCount(1, $this->session->messages());
    }

    public function testAHookCanDrawItsOwnMessage(): void
    {
        $api = new ExtensionApi('.', 'test.php');
        $api->registerMessageRenderer(
            'build',
            static fn (): Text => new Text('drawn by the hook itself', 0, 0),
        );

        $extensionRunner = new ExtensionRunner([new LoadedExtension('test.php', 'test.php', $api->name, $api)], $this->cwd);
        $this->start(answers: ['ok'], extensionRunner: $extensionRunner);

        Async::spawn(static function () use ($api): void {
            $api->sendMessage('build', 'the plain version');
        });
        $this->settle();

        $screen = $this->screen();
        $this->assertStringContainsString('drawn by the hook itself', $screen);
        $this->assertStringNotContainsString('the plain version', $screen);
    }

    public function testARendererThatReturnsNullGetsTheDefaultWithoutComplaint(): void
    {
        $api = new ExtensionApi('.', 'test.php');
        $api->registerMessageRenderer('build', static fn (): mixed => null);

        $extensionRunner = new ExtensionRunner([new LoadedExtension('test.php', 'test.php', $api->name, $api)], $this->cwd);
        $this->start(answers: ['ok'], extensionRunner: $extensionRunner);

        Async::spawn(static function () use ($api): void {
            $api->sendMessage('build', 'the plain version');
        });
        $this->settle();

        // "Nothing to draw here" is a legitimate answer.
        $screen = $this->screen();
        $this->assertStringContainsString('the plain version', $screen);
        $this->assertStringNotContainsString('Warning:', $screen);
    }

    public function testARendererThatThrowsFallsBackAndSaysSo(): void
    {
        $api = new ExtensionApi('.', 'test.php');
        $api->registerMessageRenderer('build', static fn (): mixed => throw new RuntimeException('bad renderer'));

        $extensionRunner = new ExtensionRunner([new LoadedExtension('test.php', 'test.php', $api->name, $api)], $this->cwd);
        $this->start(answers: ['ok'], extensionRunner: $extensionRunner);

        Async::spawn(static function () use ($api): void {
            $api->sendMessage('build', 'the plain version');
        });
        $this->settle();

        // Both: the message still gets drawn, and the broken renderer is named. A picture
        // that quietly turns into plain text is a bug nobody reports.
        $screen = $this->screen();
        $this->assertStringContainsString('the plain version', $screen);
        $this->assertStringContainsString('bad renderer', $screen);
    }

    public function testARendererThatReturnsSomethingElseIsAComplaint(): void
    {
        $api = new ExtensionApi('.', 'test.php');
        $api->registerMessageRenderer('build', static fn (): string => 'not a component');

        $extensionRunner = new ExtensionRunner([new LoadedExtension('test.php', 'test.php', $api->name, $api)], $this->cwd);
        $this->start(answers: ['ok'], extensionRunner: $extensionRunner);

        Async::spawn(static function () use ($api): void {
            $api->sendMessage('build', 'the plain version');
        });
        $this->settle();

        $screen = $this->screen();
        $this->assertStringContainsString('not a component', $screen);
        $this->assertStringContainsString('the plain version', $screen);
    }

    public function testAHooksMessageComesBackWhenTheSessionIsResumed(): void
    {
        $this->start(answers: ['answered'], store: true);
        $this->type('hi');
        $this->type(self::ENTER);
        $this->settle();

        $store = $this->session->store();
        self::assertNotNull($store);
        $store->append(new CustomMessage('build', [new TextContent('remembered across a restart')]));

        $path = $store->path;
        $this->mode->stop();
        $this->start(answers: [], resume: $path);

        $this->assertStringContainsString('remembered across a restart', $this->screen());
    }

    // ---- custom tools -------------------------------------------------------------------

    public function testSlashToolsListsTheBuiltInsAndWhereTheyCameFrom(): void
    {
        $this->start();
        $this->type('/tools');
        $this->type(self::ENTER);

        $this->assertStringContainsString('built-in', $this->screen());
    }

    public function testSlashToolsNamesTheFileACustomToolCameFrom(): void
    {
        $this->start(customTools: $this->tools('wc'));
        $this->type('/tools');
        $this->type(self::ENTER);
        $screen = $this->screen();

        $this->assertStringContainsString('wc', $screen);
        $this->assertStringContainsString('wc/index.php', $screen);
    }

    public function testAnExtensionsToolsAreNotNamedInTheBanner(): void
    {
        // Upstream lists no tools at all: they belong to the extension that registered them, and
        // a built-in's — codemode, web search — are not even named.
        $this->start(customTools: $this->tools('wc'));
        $extension = new \Pig\CodingAgent\Extensions\LoadedExtension(
            'wc/index.php',
            'wc/index.php',
            'wc',
            new \Pig\CodingAgent\Extensions\ExtensionApi(sys_get_temp_dir(), 'wc/index.php', 'wc'),
        );
        (new \ReflectionProperty($this->mode, 'extensions'))->setValue($this->mode, [$extension]);
        (new \ReflectionMethod($this->mode, 'showLoadedResources'))->invoke($this->mode, true);
        $this->settle();

        $this->assertStringNotContainsString('[Tools]', $this->screen());
    }

    /**
     * The model calling a tool somebody wrote, drawn and answered like any other.
     *
     * Every custom-tool test above drives `/tools`, the banner or `onSession`; none had the model
     * *call* one — and `addTool()`'s `toolRenderers($name, $custom)` is only reached with a
     * non-null `$custom`. Its signature named `CustomTool` without the import, so the one real
     * call site was a `TypeError` in a listener: the turn ended with nothing drawn and nothing
     * written, and `/debug` was the only place the error existed. Red if the import goes again:
     * the tool never runs, so `ran` and `done` never reach the screen. The other half — the
     * failure being *shown* when a listener throws — is `AgentTest`'s
     * `testAThrowThatEscapesTheLoopIsAFailedTurnEveryListenerSees`.
     */
    public function testTheModelCallingACustomToolIsDrawnRatherThanEndingTheTurnInSilence(): void
    {
        $this->start(
            customTools: $this->tools('wc'),
            answers: [self::wants('wc', []), 'done'],
        );

        $this->type('count them');
        $this->type(self::ENTER);
        $this->settle();

        $screen = $this->screen();
        $this->assertStringContainsString('ran', $screen);
        $this->assertStringContainsString('done', $screen);
        $this->assertStringNotContainsString('must be of type', $screen);
    }

    /**
     * A plain custom tool called while hooks are loaded. `toolRenderers()` `array_filter`s the
     * tool's two null renderers down to `[]` — not null, so `drawsItself()` looks inside it — and
     * the check used to read `a ?? null !== null || b ?? null !== null`, which with `!==` binding
     * tighter than `??` is `a ?? ((false || b) ?? false)`: `b` is reached outside any `??` and
     * warned `Undefined array key "renderResult"` on every such call. Red under `failOnWarning`.
     */
    public function testACustomToolWithNoRenderersDoesNotWarnWhenHooksAreLoaded(): void
    {
        $this->start(
            customTools: $this->tools('wc'),
            answers: [self::wants('wc', []), 'done'],
            extensionRunner: $this->runner(new ExtensionApi($this->cwd, 'bystander.php'), 'bystander.php'),
        );

        $this->type('count them');
        $this->type(self::ENTER);
        $this->settle();

        $screen = $this->screen();
        $this->assertStringContainsString('ran', $screen);
        $this->assertStringContainsString('done', $screen);
    }

    public function testAToolIsToldTheSessionStartedAndThenSwitched(): void
    {
        $seen = [];
        $this->start(customTools: $this->tools('wc', function ($event) use (&$seen): void {
            $seen[] = $event->reason;
        }));

        $this->type('/new');
        $this->type(self::ENTER);

        $this->assertSame(['start', 'switch'], $seen);
    }

    public function testAToolIsToldOnTheWayOut(): void
    {
        $seen = [];
        $this->start(customTools: $this->tools('wc', function ($event) use (&$seen): void {
            $seen[] = $event->reason;
        }));

        $this->mode->stop();

        $this->assertSame(['start', 'shutdown'], $seen);
    }

    public function testACallbackThatFailsIsAWarningRatherThanAStartupCrash(): void
    {
        // Only on start: the tear-down stops the mode, and a tool that also failed on the
        // way out would print to the test run's stderr for no extra assurance.
        $this->start(customTools: $this->tools('wc', static function ($event): void {
            if ($event->reason === 'start') {
                throw new RuntimeException('could not read its cache');
            }
        }));

        $this->assertStringContainsString(
            'Warning: tool wc/index.php: onSession(start)',
            $this->screen(),
        );
    }

    private function tools(string $name, ?Closure $onSession = null): CustomToolSet
    {
        $path = "{$name}/index.php";
        $tool = new CustomTool(
            name: $name,
            label: 'Count lines',
            description: 'Counts the lines in a file.',
            parameters: ['type' => 'object', 'properties' => []],
            execute: static fn () => new \Pig\Agent\AgentToolResult([new TextContent('ran')]),
            onSession: $onSession,
        );

        return new CustomToolSet([new LoadedCustomTool($path, $path, $tool)]);
    }

    /**
     * Keep the agent mid-run until the returned closure is called.
     *
     * The scripted provider answers instantly, which is right for every other test and
     * useless for the two about what happens while it is still working.
     */
    private function holdTheAgent(int $letThrough = 0): Closure
    {
        $this->holding = true;
        $this->letThrough = $letThrough;

        return function (): void {
            $this->holding = false;
            $stream = $this->held;
            $this->held = null;

            if ($stream === null) {
                return;
            }

            $stream->push(new StartEvent(self::message('held')));
            $stream->push(new DoneEvent(StopReason::Stop, self::message('held')));
            $stream->end();
        };
    }

    // ---- signing in ------------------------------------------------------------------

    private const string DOWN = "\e[B";

    public function testSlashLoginAsksHowThenListsTheProviders(): void
    {
        $this->start(auth: Auth::inMemory());

        $this->type('/login');
        $this->type(self::ENTER);

        // Upstream's `showLoginAuthTypeSelector()`: the two kinds, and Radius with its status.
        $screen = $this->screen();
        $this->assertStringContainsString('Select authentication method:', $screen);
        $this->assertStringContainsString('Sign in with an account', $screen);
        $this->assertStringContainsString('Sign in with an API key', $screen);
        $this->assertStringContainsString('Sign in with Radius • not configured', $screen);

        $this->type(self::ENTER);

        // The account sign-ins: `Auth::signIns()`, by upstream's provider names, sorted.
        $screen = $this->screen();
        $this->assertStringContainsString('Select provider to configure:', $screen);
        $this->assertMatchesRegularExpression('/Anthropic • not configured.*GitHub Copilot • not configured.*OpenAI Codex \(legacy\).*Radius/s', $screen);
        $this->assertStringNotContainsString('Antigravity', $screen);

        // Escape goes back to the kinds, as upstream's does.
        $this->type(self::ESCAPE);
        $this->assertStringContainsString('Select authentication method:', $this->screen());
    }

    public function testSignInWithAnApiKeyListsTheBuiltInProvidersAndKeepsTheKey(): void
    {
        putenv('PIG_OFFLINE=1');
        putenv('DEEPSEEK_API_KEY');

        try {
            $auth = Auth::inMemory();
            $this->start(auth: $auth);

            $this->type('/login');
            $this->type(self::ENTER);
            $this->type(self::DOWN);
            $this->type(self::ENTER);

            $screen = $this->screen();
            $this->assertStringContainsString('Select provider to configure:', $screen);
            $this->assertStringContainsString('Amazon Bedrock', $screen);

            // Searched, as upstream's list is.
            $this->type('deepseek');
            $this->assertStringContainsString('DeepSeek • not configured', $this->screen());
            $this->type(self::ENTER);
            $this->settle();

            $this->assertStringContainsString('Enter DeepSeek API key', $this->screen());
            $this->type('sk-deep');
            $this->type(self::ENTER);
            $this->settle();

            $this->assertSame('sk-deep', $auth->apiKey('deepseek'));
            $this->assertStringContainsString('Saved API key for DeepSeek', $this->screenText());

            // `/logout` offers the stored key, and only what is stored.
            $this->type('/logout');
            $this->type(self::ENTER);
            $this->assertStringContainsString('DeepSeek ✓ configured', $this->screen());
            $this->type(self::ENTER);
            $this->settle();

            $this->assertNull($auth->apiKeyCredential('deepseek'));
            $this->assertStringContainsString('Removed stored API key for DeepSeek. Environment variables and models.json config are unchanged.', $this->screenText());
        } finally {
            putenv('PIG_OFFLINE');
        }
    }

    public function testAnExtensionsSignInIsARowInSlashLoginLikeAnyOther(): void
    {
        // The whole reason `Auth::signIns()` exists: a provider an extension registered reaches
        // `/login` without the list knowing it, and choosing it runs the extension's flow.
        $asked = 0;
        $flow = new class($asked) implements OauthFlow {
            public function __construct(private int &$asked)
            {
            }

            public function id(): string
            {
                return 'zzp-provider';
            }

            public function label(): string
            {
                return 'Probe Sign-in';
            }

            public function isSubscription(): bool
            {
                return false;
            }

            public function login(\Closure $onAuth, \Closure $onPrompt, ?\Closure $onProgress = null, ?\Pig\Async\AbortSignal $signal = null, ?\Closure $onSelect = null): ?Credentials
            {
                $this->asked++;

                return null;
            }

            public function refresh(Credentials $credentials): Credentials
            {
                return $credentials;
            }

            public function apiKey(Credentials $credentials): string
            {
                return $credentials->access;
            }
        };
        ProviderRegistry::register(new \Pig\Ai\Extension\Provider('zzp-provider', 'Probe', [], oauth: $flow));

        try {
            $this->start(auth: Auth::inMemory());

            $this->type('/login');
            $this->type(self::ENTER);
            $this->type(self::ENTER);

            $this->assertStringContainsString('Probe Sign-in', $this->screen());

            $this->type('probe');
            $this->type(self::ENTER);
            $this->settle();

            $this->assertSame(1, $asked, "the extension's flow ran");
            // Cancelled, the list it was chosen from comes back — upstream's `onBack`.
            $this->assertStringContainsString('Select provider to configure:', $this->screen());
        } finally {
            ProviderRegistry::forget();
        }
    }

    /**
     * An extension provider with an api-key sign-in — what pig-llama registers — and a catalog it
     * fetches. `$refreshes` records each `refreshModels` phase: network or not, and the key.
     *
     * @param list<array{bool, ?string}> $refreshes
     */
    private static function apiKeyProvider(array &$refreshes, bool $failRefresh = false): \Pig\Ai\Extension\Provider
    {
        $auth = new class implements \Pig\Ai\Extension\ApiKeyAuth {
            public function name(): string
            {
                return 'Probe key';
            }

            public function login(\Closure $onPrompt, ?\Pig\Async\AbortSignal $signal = null): ?\Pig\Ai\Extension\ApiKeyCredential
            {
                $key = $onPrompt('Probe API key', '', false, $signal);

                return $key === null ? null : new \Pig\Ai\Extension\ApiKeyCredential($key);
            }

            public function check(?\Pig\Ai\Extension\ApiKeyCredential $credential): ?string
            {
                return $credential === null ? null : 'stored credential';
            }

            public function resolve(?\Pig\Ai\Extension\ApiKeyCredential $credential): ?\Pig\Ai\Extension\AuthResult
            {
                return $credential === null ? null : new \Pig\Ai\Extension\AuthResult(new \Pig\Ai\Extension\ModelAuth($credential->key));
            }
        };

        return new \Pig\Ai\Extension\Provider(
            'zzk-probe',
            'Probe Keyed',
            [],
            apiKeyAuth: $auth,
            refreshModels: static function (\Pig\Ai\Extension\RefreshModelsContext $context) use (&$refreshes, $failRefresh): void {
                $refreshes[] = [$context->allowNetwork, $context->credential?->key];

                if ($context->allowNetwork && $failRefresh) {
                    throw new RuntimeException('router down');
                }
            },
        );
    }

    public function testSlashLoginWithAProviderNameStartsItsApiKeySignInAndRefreshesItsCatalog(): void
    {
        $refreshes = [];
        ProviderRegistry::register(self::apiKeyProvider($refreshes));
        putenv('PIG_OFFLINE=1');

        try {
            $auth = Auth::inMemory();
            $this->start(auth: $auth);

            // By id or by name, ignoring case: upstream's `findLoginProviderOptions()`.
            $this->type('/login probe keyed');
            $this->type(self::ENTER);
            $this->settle();
            $this->assertStringContainsString('Probe API key', $this->screen());

            $this->type('sk-probe');
            $this->type(self::ENTER);
            $this->settle();

            $this->assertSame('sk-probe', $auth->apiKeyCredential('zzk-probe')?->key);
            $this->assertStringContainsString('Saved API key for Probe Keyed', $this->screen());
            // The stored catalog, then the network with the key just kept — after a sign-in even
            // under PIG_OFFLINE, as upstream refreshes after one whatever the startup did.
            $this->assertSame([[false, 'sk-probe'], [true, 'sk-probe']], $refreshes);
        } finally {
            putenv('PIG_OFFLINE');
            ProviderRegistry::forget();
        }
    }

    public function testAFailedCatalogRefreshAfterSignInIsAWarningAndTheCachedModelsStay(): void
    {
        $refreshes = [];
        ProviderRegistry::register(self::apiKeyProvider($refreshes, failRefresh: true));
        putenv('PIG_OFFLINE=1');

        try {
            $this->start(auth: Auth::inMemory());
            $this->type('/login zzk-probe');
            $this->type(self::ENTER);
            $this->settle();
            $this->type('k');
            $this->type(self::ENTER);
            $this->settle();

            $this->assertStringContainsString('Saved API key for Probe Keyed, but its model catalog could not be refreshed; using cached models.', $this->screenText());
        } finally {
            putenv('PIG_OFFLINE');
            ProviderRegistry::forget();
        }
    }

    public function testAnApiKeyProviderIsARowInSlashLoginAndSlashLogoutRemovesItsKey(): void
    {
        $refreshes = [];
        ProviderRegistry::register(self::apiKeyProvider($refreshes));
        putenv('PIG_OFFLINE=1');

        try {
            $auth = Auth::inMemory();
            $this->start(auth: $auth);

            $this->type('/login');
            $this->type(self::ENTER);
            $this->type(self::DOWN);
            $this->type(self::ENTER);
            $this->type('probe');
            $this->assertStringContainsString('Probe Keyed • not configured', $this->screen());
            $this->type(self::ESCAPE);
            $this->type(self::ESCAPE);

            $auth->setApiKeyCredential('zzk-probe', new \Pig\Ai\Extension\ApiKeyCredential('sk-x'));
            $this->type('/logout');
            $this->type(self::ENTER);
            $this->assertStringContainsString('Probe Keyed ✓ configured', $this->screen());
            $this->type(self::ENTER);
            $this->settle();

            $this->assertNull($auth->apiKeyCredential('zzk-probe'));
            $this->assertStringContainsString('Removed stored API key for Probe Keyed. Environment variables and models.json config are unchanged.', $this->screenText());
        } finally {
            putenv('PIG_OFFLINE');
            ProviderRegistry::forget();
        }
    }

    public function testSlashLoginSupportsCustomProviderFromModelsJson(): void
    {
        $customModel = new \Pig\Ai\Model(
            id: 'custom-model',
            name: 'Custom Model',
            api: \Pig\Ai\Api::OpenAiCompletions,
            provider: 'my-custom-gateway',
            baseUrl: 'https://example.com/v1',
            contextWindow: 32000,
            maxTokens: 4096,
        );
        \Pig\Ai\Models::useOverlay(static fn (array $table): array => ['my-custom-gateway/custom-model' => $customModel, ...$table]);

        try {
            $auth = Auth::inMemory();
            $this->start(auth: $auth);

            $this->type('/login my-custom-gateway');
            $this->type(self::ENTER);
            $this->settle();
            $this->assertStringContainsString('My Custom Gateway API key', $this->screen());

            $this->type('sk-custom-secret');
            $this->type(self::ENTER);
            $this->settle();

            $this->assertSame('sk-custom-secret', $auth->apiKey('my-custom-gateway'));
        } finally {
            \Pig\Ai\Models::useOverlay(null);
        }
    }

    public function testSlashLoginUnknownCustomProviderPromptsForUrlAndKeyAndConfiguresModels(): void
    {
        $modelsFile = \Pig\CodingAgent\Config::home() . '/models.json';
        $originalModelsJson = is_file($modelsFile) ? file_get_contents($modelsFile) : null;

        try {
            $auth = Auth::inMemory();
            $this->start(auth: $auth);

            $this->type('/login my-mock-gateway');
            $this->type(self::ENTER);
            $this->settle();
            $this->assertStringContainsString('Enter My Mock Gateway base URL', $this->screen());

            $this->type('https://api.example.com/v1');
            $this->type(self::ENTER);
            $this->settle();
            $this->assertStringContainsString('Enter My Mock Gateway API key', $this->screen());

            $this->type('sk-mock-key');
            $this->type(self::ENTER);
            $this->settle();

            $this->assertSame('sk-mock-key', $auth->apiKey('my-mock-gateway'));
            $this->assertStringContainsString('Added My Mock Gateway', $this->screen());
            $this->assertFileExists($modelsFile);
            $saved = json_decode((string) file_get_contents($modelsFile), true);
            $this->assertSame('https://api.example.com/v1', $saved['providers']['my-mock-gateway']['baseUrl'] ?? null);
        } finally {
            if ($originalModelsJson !== null) {
                file_put_contents($modelsFile, $originalModelsJson);
            } else {
                unlink($modelsFile);
            }
        }
    }

    public function testChoosingAnthropicAsksWhichWayInAndCopyCodeShowsAUrlThenAPasteBox(): void
    {
        $this->start(auth: Auth::inMemory());

        $this->type('/login');
        $this->type(self::ENTER);
        $this->type(self::ENTER); // an account
        $this->type(self::ENTER); // Anthropic, the first row
        $this->settle();

        // pi 1.0: the browser is the default and copying the code is for a headless machine.
        $screen = $this->screen();
        $this->assertStringContainsString('Select Anthropic login method', $screen);
        $this->assertStringContainsString('Browser login (default)', $screen);
        $this->assertStringContainsString('Copy code login (headless)', $screen);

        $this->type(self::DOWN);
        $this->type(self::ENTER);
        $this->settle();

        // The copy-code way: Anthropic's own page, then a box for what it shows. No loopback
        // is opened, which is the way that works with the browser on another machine. Words,
        // not layout — the URL wraps.
        $screen = $this->screenText();
        $this->assertStringContainsString('Open this and approve it', $screen);
        $this->assertStringContainsString('platform.claude.com%2Foauth%2Fcode%2Fcallback', $screen);
        $this->assertStringContainsString('code#state', $screen);

        $this->type(self::ESCAPE);
        $this->settle();

        // Upstream's `onBack`: the provider list again.
        $this->assertStringContainsString('Select provider to configure:', $this->screen());
    }

    public function testSlashLoginNeverOpensTheRealBrowserFromATest(): void
    {
        // Every run of this file used to open the developer's browser on Anthropic's authorize
        // page, because `/login` says the URL and then hands it to `open`. A stand-in `open` on
        // the PATH is what makes both halves observable: with `PIG_OFFLINE` it is never run, and
        // without it, it is — so the guard is proven at both ends and no real browser is in it.
        $bin = $this->cwd . '-bin';
        mkdir($bin, 0700, true);
        $opener = match (PHP_OS_FAMILY) {
            'Darwin' => 'open',
            'Windows' => self::markTestSkipped('a stand-in for `cmd /c start` is not a shell script'),
            default => 'xdg-open',
        };
        $marker = $bin . '/opened';
        file_put_contents($bin . '/' . $opener, "#!/bin/sh\necho \"\$1\" > " . escapeshellarg($marker) . "\n");
        chmod($bin . '/' . $opener, 0700);
        $path = (string) getenv('PATH');
        putenv('PATH=' . $bin . ':' . $path);

        try {
            $this->start(auth: Auth::inMemory());

            $this->type('/login');
            $this->type(self::ENTER);
            $this->type(self::ENTER); // an account
            $this->type(self::ENTER); // Anthropic
            $this->settle();
            $this->type(self::DOWN);
            $this->type(self::ENTER); // copy code: the flow says its URL at once
            $this->settle();

            $this->assertStringContainsString('Open this and approve it', $this->screenText());
            $this->assertFileDoesNotExist($marker, 'offline, so nothing was opened');

            $this->type(self::ESCAPE);
            $this->settle();
            $this->type(self::ESCAPE);
            $this->type(self::ESCAPE);

            putenv('PIG_OFFLINE');
            $this->type('/login');
            $this->type(self::ENTER);
            $this->type(self::ENTER);
            $this->type(self::ENTER);
            $this->settle();
            $this->type(self::DOWN);
            $this->type(self::ENTER);
            $this->settle();

            // The opener is started and left to run, not waited on, so nothing in the loop says
            // when it is done: wait for what it writes, a while at most.
            for ($waited = 0; $waited < 500 && (!is_file($marker) || (string) file_get_contents($marker) === ''); $waited++) {
                usleep(10_000);
            }
            $this->assertFileExists($marker, 'online, the URL is handed to the opener');
            $this->assertStringContainsString('claude.ai', (string) file_get_contents($marker));

            $this->type(self::ESCAPE);
            $this->settle();
        } finally {
            putenv('PATH=' . $path);
            self::remove($bin);
        }
    }

    public function testAFlowThatRefusesSaysWhyRatherThanOpeningABrowser(): void
    {
        // What the Antigravity extension does when its client pair is not set: refuse by name
        // from inside `login()`, before anybody is sent anywhere. The screen has to carry the
        // refusal, or the list reads as broken.
        $flow = new class implements OauthFlow {
            public function id(): string
            {
                return 'zzp-provider';
            }

            public function label(): string
            {
                return 'Probe Sign-in';
            }

            public function isSubscription(): bool
            {
                return true;
            }

            public function login(\Closure $onAuth, \Closure $onPrompt, ?\Closure $onProgress = null, ?\Pig\Async\AbortSignal $signal = null, ?\Closure $onSelect = null): ?Credentials
            {
                throw new OauthError('Signing in needs PROBE_CLIENT_ID, which pig does not ship.');
            }

            public function refresh(Credentials $credentials): Credentials
            {
                return $credentials;
            }

            public function apiKey(Credentials $credentials): string
            {
                return $credentials->access;
            }
        };
        ProviderRegistry::register(new \Pig\Ai\Extension\Provider('zzp-provider', 'Probe', [], oauth: $flow));

        try {
            $this->start(auth: Auth::inMemory());

            $this->type('/login');
            $this->type(self::ENTER);
            $this->type(self::ENTER);
            $this->type('probe');
            $this->type(self::ENTER);
            $this->settle();

            $screen = $this->screen();
            $this->assertStringContainsString('PROBE_CLIENT_ID', $screen);
            $this->assertStringNotContainsString('Open this and approve it', $screen);
        } finally {
            ProviderRegistry::forget();
        }
    }

    public function testASignInOpensOnlyWebUrlsAndKeepsControlCharactersOffTheTerminal(): void
    {
        // Upstream 89c921d's login dialog: a URL from a server is opened only when it is http(s), and
        // never reaches the terminal with its control characters — a BEL in it ended the OSC 8 link
        // early and what followed (here OSC 52, a clipboard write) ran as the terminal's own.
        $injected = "x\x07\e]52;c;Zm9v\x07";
        $flow = new class($injected) implements OauthFlow {
            public function __construct(private readonly string $injected)
            {
            }

            public function id(): string
            {
                return 'zzp-provider';
            }

            public function label(): string
            {
                return 'Probe Sign-in';
            }

            public function isSubscription(): bool
            {
                return false;
            }

            public function login(\Closure $onAuth, \Closure $onPrompt, ?\Closure $onProgress = null, ?\Pig\Async\AbortSignal $signal = null, ?\Closure $onSelect = null): ?Credentials
            {
                $onAuth("file:///tmp/{$this->injected}", null);
                $onAuth("https://example.com/device/{$this->injected}?u", null);

                return null;
            }

            public function refresh(Credentials $credentials): Credentials
            {
                return $credentials;
            }

            public function apiKey(Credentials $credentials): string
            {
                return $credentials->access;
            }
        };
        ProviderRegistry::register(new \Pig\Ai\Extension\Provider('zzp-provider', 'Probe', [], oauth: $flow));

        $bin = $this->cwd . '-bin';
        mkdir($bin, 0700, true);
        $opener = match (PHP_OS_FAMILY) {
            'Darwin' => 'open',
            'Windows' => self::markTestSkipped('a stand-in for `cmd /c start` is not a shell script'),
            default => 'xdg-open',
        };
        $marker = $bin . '/opened';
        file_put_contents($bin . '/' . $opener, "#!/bin/sh\necho \"\$1\" >> " . escapeshellarg($marker) . "\n");
        chmod($bin . '/' . $opener, 0700);
        $path = (string) getenv('PATH');
        putenv('PATH=' . $bin . ':' . $path);

        try {
            $this->start(auth: Auth::inMemory());
            putenv('PIG_OFFLINE');

            $this->type('/login');
            $this->type(self::ENTER);
            $this->type(self::ENTER);
            $this->type('probe');
            $this->type(self::ENTER);
            $this->settle();

            $raw = implode("\n", $this->mode->screen()->render(400));
            $this->assertStringNotContainsString("\e]52", $raw);
            $this->assertStringNotContainsString("\x07\e]52", $raw);
            // Not a web URL: shown as text, each run of controls one space, and not linked.
            $this->assertStringContainsString('file:///tmp/x ]52;c;Zm9v ', $this->screenText());
            $this->assertStringNotContainsString("\e]8;;file:", $raw);
            // A web URL: linked and shown in its normalized form.
            $this->assertStringContainsString("\e]8;;https://example.com/device/x%07%1B]52;c;Zm9v%07?u\x07", $raw);

            for ($waited = 0; $waited < 500 && (!is_file($marker) || file_get_contents($marker) === ''); $waited++) {
                usleep(10_000);
            }
            $this->assertSame("https://example.com/device/x%07%1B]52;c;Zm9v%07?u\n", (string) file_get_contents($marker), 'only the web URL is opened');
        } finally {
            putenv('PATH=' . $path);
            self::remove($bin);
            ProviderRegistry::forget();
        }
    }

    public function testSlashLogoutWithNothingSignedInSaysSo(): void
    {
        $this->start(auth: Auth::inMemory());

        $this->type('/logout');
        $this->type(self::ENTER);

        $this->assertStringContainsString('No stored credentials to remove.', $this->screenText());
    }

    public function testSlashLogoutForgetsTheSignIn(): void
    {
        $auth = Auth::inMemory();
        $auth->setCredentials(Provider::Anthropic, new Credentials('r', 'sk-ant-oat-x', 0));

        $this->start(auth: $auth);

        $this->type('/logout');
        $this->type(self::ENTER);
        $this->type(self::ENTER);
        $this->settle();

        $this->assertFalse($auth->has('anthropic'));
        $this->assertStringContainsString('Logged out of Anthropic', $this->screen());
    }

    public function testSlashLogoutOnlyOffersWhatIsActuallySignedIn(): void
    {
        $auth = Auth::inMemory();
        $auth->setCredentials(Provider::Anthropic, new Credentials('r', 'a', 0));

        $this->start(auth: $auth);

        $this->type('/logout');
        $this->type(self::ENTER);

        $screen = $this->screen();

        $this->assertStringContainsString('Anthropic ✓ configured', $screen);
        // The other three have nothing to forget, so offering them would be three ways of
        // doing nothing.
        $this->assertStringNotContainsString('GitHub Copilot', $screen);
    }

    public function testWithNowhereToKeepASignInItSaysSoRatherThanOpeningAList(): void
    {
        $this->start();

        $this->type('/login');
        $this->type(self::ENTER);

        $this->assertStringContainsString('nowhere to keep a sign-in', $this->screen());
    }

    // ---- the easter egg --------------------------------------------------------------

    public function testTheEasterEggIsReachableButNotAdvertised(): void
    {
        $this->start();

        $this->type('/help');
        $this->type(self::ENTER);

        // Known and not listed, like `quit`: something you have to already know about is the
        // whole idea, and upstream leaves it out of its own command list too.
        $this->assertStringNotContainsString('arminsayshi', $this->screen());

        $this->type('/arminsayshi');
        $this->type(self::ENTER);
        $this->settle();

        $screen = $this->screen();

        $this->assertStringContainsString('ARMIN SAYS HI', $screen);
        $this->assertStringNotContainsString('No command called', $screen);
    }

    // ---- /changelog ------------------------------------------------------------------

    public function testSlashChangelogShowsPigsOwnFileAndNotTheInjectedNote(): void
    {
        $this->start();

        $this->type('/changelog');
        $this->type(self::ENTER);

        $screen = $this->screen();

        // **This used to assert `No changelog entries found.` and passed because pig had no
        // `CHANGELOG.md`.** The constructor's changelog is the upgrade note only; `/changelog`
        // calls `Changelog::parse()`, which reads the file at the root of the repository — so for
        // as long as that file was missing, the one test of this command was pinning the absence
        // of a file rather than the command. The empty answer has its case in `ChangelogTest`,
        // against a path that is not there, which is where a question about the file belongs.
        // Asserted against what the parser found rather than against a number typed here: the
        // version this build *is* comes from the git tag, so in a checkout it is not a release and
        // has nothing to do with which entries the file holds.
        $entries = Changelog::parse();

        $this->assertNotSame([], $entries, 'there is a CHANGELOG.md to show');
        $this->assertStringContainsString("What's New", $screen);
        $this->assertStringContainsString($entries[0]->version, $screen);
        $this->assertStringNotContainsString('No changelog entries found.', $screen);
    }

    public function testAnUpgradeNoteIsDrawnUnderTheConversationItIsAbout(): void
    {
        $this->start(changelog: "## 0.2.0\n\n- Something changed.");

        $screen = $this->screen();

        $this->assertStringContainsString("What's New", $screen);
        $this->assertStringContainsString('Something changed.', $screen);
    }

    public function testACollapsedUpgradeNoteIsOneLineNamingTheVersion(): void
    {
        $this->start(changelog: "## [0.2.0] - 2026-10-01\n\n- Something changed.", settings: Settings::inMemory(['collapseChangelog' => true]));

        $screen = $this->screenText();

        $this->assertStringContainsString('Updated to v0.2.0. Use /changelog to view full changelog.', $screen);
        $this->assertStringNotContainsString('Something changed.', $screen);
    }

    /** Upstream b4b72a3: a package's changelog after it was updated, under pig's own notes. */
    public function testAnUpdatedPackagesChangelogIsShownOnceAndItsVersionRemembered(): void
    {
        [$settings, $extensions, $key] = $this->packageWithChangelog('1.2.0');
        $settings->setExtensionChangelogVersion($key, '1.0.0');
        $this->start(changelog: "## 0.2.0\n\n- Something changed.", settings: $settings, extensions: $extensions);

        $screen = $this->screenText();
        $this->assertStringContainsString("What's New", $screen);
        $this->assertStringContainsString('Extension Updates', $screen);
        $this->assertStringContainsString('acme/tools [1.2.0]', $screen);
        $this->assertStringContainsString('Faster lookups.', $screen);
        $this->assertStringContainsString('Second release.', $screen);
        $this->assertStringNotContainsString('First release.', $screen);
        $this->assertSame('1.2.0', $settings->extensionChangelogVersion($key));
    }

    public function testAPackageSeenForTheFirstTimeIsRecordedAndNotShown(): void
    {
        [$settings, $extensions, $key] = $this->packageWithChangelog('1.2.0');
        $this->start(settings: $settings, extensions: $extensions);

        $this->assertStringNotContainsString('Extension Updates', $this->screenText());
        $this->assertSame('1.2.0', $settings->extensionChangelogVersion($key));
    }

    public function testACollapsedPackageChangelogIsOneLinePerPackage(): void
    {
        [$settings, $extensions, $key] = $this->packageWithChangelog('1.2.0', ['collapseChangelog' => true]);
        $settings->setExtensionChangelogVersion($key, '1.0.0');
        $this->start(settings: $settings, extensions: $extensions);

        $screen = $this->screenText();
        $this->assertStringContainsString('Updated acme/tools to v1.2.0.', $screen);
        $this->assertStringNotContainsString('Faster lookups.', $screen);
    }

    /**
     * A local package with a loaded extension, a `composer.json` at $version and a changelog.
     *
     * @param array<string, mixed> $values
     * @return array{0: Settings, 1: list<\Pig\CodingAgent\Extensions\LoadedExtension>, 2: string}
     */
    private function packageWithChangelog(string $version, array $values = []): array
    {
        $root = "{$this->cwd}/tools";
        mkdir("{$root}/extensions", 0o755, true);
        file_put_contents("{$root}/extensions/tools.php", '<?php return static fn () => null;');
        file_put_contents("{$root}/composer.json", json_encode(['name' => 'acme/tools', 'version' => $version]));
        file_put_contents("{$root}/CHANGELOG.md", "# Changelog\n\n## [1.2.0]\n\n- Faster lookups.\n\n## [1.1.0]\n\n- Second release.\n\n## [1.0.0]\n\n- First release.\n");
        $path = "{$root}/extensions/tools.php";
        $extension = new \Pig\CodingAgent\Extensions\LoadedExtension($path, $path, 'tools', new \Pig\CodingAgent\Extensions\ExtensionApi($this->cwd, $path, 'tools'));

        return [
            Settings::inMemory(['packages' => [$root], ...$values]),
            [$extension],
            json_encode(['source' => $root, 'scope' => 'user'], JSON_UNESCAPED_SLASHES),
        ];
    }

    public function testTheChangelogAndTrustRowsAreInSlashSettings(): void
    {
        $this->start();
        $this->openSettings();
        $this->typeUntilRow('Collapse changelog');
        $this->type(self::ENTER);
        $this->assertTrue($this->settings->collapseChangelog());
        $this->typeUntilRow('Default project trust');
        $this->type(self::ENTER);
        $this->assertSame('always', $this->settings->defaultProjectTrust());
    }

    public function testTheTransportRowIsInSlashSettings(): void
    {
        $this->start();
        $this->openSettings();
        $this->typeUntilRow('Transport');
        $this->type(self::ENTER);
        $this->assertSame('sse', $this->settings->transport(), 'from auto, the last of the four, round to the first');
    }

    public function testAMermaidBlockInAnAnswerIsDrawnAsItsDiagram(): void
    {
        $this->start(["Like this:\n\n```mermaid\ngraph LR\n  A[Ask] --> B[Answer]\n```"]);
        $this->type('a question');
        $this->type(self::ENTER);
        $this->settle();

        $this->assertStringContainsString('│ Ask ├───▶│ Answer │', $this->screen());
        $this->assertStringNotContainsString('graph LR', $this->screen());
    }

    public function testTheMermaidRowTurnsTheDiagramsOff(): void
    {
        $this->start(["```mermaid\ngraph LR\n  A[Ask] --> B[Answer]\n```"]);
        $this->type('a question');
        $this->type(self::ENTER);
        $this->settle();
        $this->openSettings();
        $this->typeUntilRow('Mermaid diagrams');
        $this->type(self::ENTER);
        $this->assertSame('off', $this->settings->mermaidRenderingMode(), 'from streaming, the last of the three, round to the first');
        $this->type(self::ESC);

        $this->assertStringContainsString('graph LR', $this->screen(), 'the answer already drawn is drawn again');
    }

    public function testTheInstallTelemetryRowIsInSlashSettings(): void
    {
        $this->start();
        $this->openSettings();
        $this->typeUntilRow('Install telemetry');
        $this->type(self::ENTER);
        $this->assertFalse($this->settings->installTelemetry());
    }

    public function testNothingIsDrawnWhenThereIsNoUpgradeNote(): void
    {
        $this->start();

        // The common case by far, and a title with nothing under it would be worse than
        // nothing at all.
        $this->assertStringNotContainsString("What's New", $this->screen());
    }

    // ---- there is a newer pig --------------------------------------------------------

    public function testTheUpdateNoticeNamesBothVersionsAndTheCommandToRun(): void
    {
        $this->start();
        $this->mode->sayNewVersion('9.9.9');

        $screen = $this->screen();

        // All three facts, because each of them is the reason one of the others is worth
        // reading: which version is out, which one this is, and the one line that closes the
        // gap. A block naming two of the three is a block that sends somebody to a search
        // engine.
        $this->assertStringContainsString('Update Available', $screen);
        $this->assertStringContainsString('9.9.9', $screen);
        $this->assertStringContainsString(UpdateCheck::COMMAND, $screen);
    }

    public function testTheVersionItSaysYouHaveIsTheOneTheBannerDrew(): void
    {
        $this->start();

        // One fact, one source. `sayNewVersion()` read `Version::current()` for a batch, which
        // is the manifest rather than the string this session was started as — so the banner
        // said one number and the notice said another three lines below it, about the very
        // comparison the block exists to make.
        $this->assertStringContainsString('Pig v0.0.0', $this->screen());

        $this->mode->sayNewVersion('9.9.9');

        $this->assertStringContainsString('New version 9.9.9 is available. Run ' . UpdateCheck::COMMAND, $this->screen());
        $this->assertStringContainsString('https://pigagent.dev/changelog', $this->screen());
    }

    public function testNothingIsSaidAboutAVersionUntilSomethingSaysThereIsOne(): void
    {
        $this->start();

        // The answer arrives from a spawned check that is null nearly every time, so a start
        // that drew this block by itself would be a warning every morning.
        $this->assertStringNotContainsString('Update Available', $this->screen());
    }

    // ---- /settings -------------------------------------------------------------------

    private const string ESCAPE = "\e";

    private static function signedInToClaude(): Auth
    {
        $auth = Auth::inMemory();
        $auth->setCredentials('anthropic', new Credentials('refresh', 'access', PHP_INT_MAX));

        return $auth;
    }

    /** Down through a list until the selection is on the row with $label. */
    private function typeUntilRow(string $label): void
    {
        for ($i = 0; $i < 60 && !str_contains($this->selectedRow(), $label); $i++) {
            $this->type(self::DOWN);
        }

        $this->assertStringContainsString($label, $this->selectedRow());
    }

    private function openSettings(): void
    {
        $this->type('/settings');
        $this->type(self::ENTER);
    }

    public function testSlashSettingsShowsWhatEachOneIsSetTo(): void
    {
        $this->start();
        $this->openSettings();

        $screen = $this->screen();

        $this->assertStringContainsString('Theme', $screen);
        $this->assertStringContainsString('dark', $screen);
        $this->assertStringContainsString('Session share destination', $screen);
        // The eighth row, the last the list shows before it scrolls; Auto-compact is below the fold.
        $this->assertStringContainsString('HTTP idle timeout', $screen);
        $this->assertStringContainsString('5 min', $screen);
        $this->assertStringContainsString('esc when done', $screen);
    }

    public function testASettingChangedFromTheScreenIsAppliedAndRemembered(): void
    {
        $this->start();
        $this->openSettings();

        // Theme is the first row and opens upstream's submenu: system, automatic, then the
        // themes, the cursor on dark, so the one below it is labra. Enter picks it.
        $this->type(self::ENTER);
        $this->type(self::DOWN);
        $this->type(self::ENTER);

        $this->assertSame('labra', $this->settings->theme());
        $this->assertSame('labra', Themes::theme()->name);
    }

    public function testSkillCommandsAreOfferedUnlessTheSettingSaysNot(): void
    {
        $skill = new Skill('review', 'Review code', '/somewhere/review/SKILL.md', '/somewhere/review', 'test');
        $this->start(skills: [$skill]);
        $this->type('/');
        $this->type('skill:');
        $this->assertStringContainsString('skill:review', $this->screen());
    }

    public function testSkillCommandsAreNotOfferedWhenTheSettingIsOff(): void
    {
        $skill = new Skill('review', 'Review code', '/somewhere/review/SKILL.md', '/somewhere/review', 'test');
        $this->start(skills: [$skill], settings: Settings::inMemory(['enableSkillCommands' => false]));
        $this->type('/');
        $this->type('skill:');
        $this->assertStringNotContainsString('skill:review', $this->screen());
    }

    public function testTheImageRowsAreInSlashSettingsAndChangeTheSetting(): void
    {
        $this->start();
        $this->openSettings();
        $this->typeUntilRow('Auto-resize images');
        $this->type(self::ENTER);
        $this->assertFalse($this->settings->imageAutoResize());
        $this->typeUntilRow('Block images');
        $this->type(self::ENTER);
        $this->assertTrue($this->settings->blockImages());
    }

    public function testTheWarningsRowTurnsTheAnthropicExtraUsageWarningOff(): void
    {
        $this->start();
        $this->openSettings();
        $this->typeUntilRow('Warnings');
        $this->type(self::ENTER);
        $this->assertStringContainsString('Anthropic extra usage', $this->screen());
        $this->type(self::ENTER);

        $this->assertFalse($this->settings->warnAnthropicExtraUsage());
    }

    public function testAPerModelThinkingLevelIsSetFromSettings(): void
    {
        $this->start(reasoning: true);
        $this->openSettings();
        $this->typeUntilRow('Default thinking level');
        $this->type(self::ENTER);
        $this->assertStringContainsString('Per-Model Thinking Level', $this->screen());

        $this->type(self::ENTER);
        $this->assertStringContainsString('Thinking Level for', $this->screen());
        $this->type(self::DOWN);
        $this->type(self::ENTER);

        $this->assertSame(['anthropic/claude-test' => ThinkingLevel::Minimal], $this->settings->allModelThinkingLevels());
        $this->assertStringContainsString('Per-Model Thinking Level', $this->screen(), 'back to the models, as upstream loops');
        $this->type(self::ESC);
        $this->assertStringContainsString('1 configured', $this->screen());
    }

    public function testASubscriptionTokenForAnthropicIsWarnedAboutOnce(): void
    {
        $this->start(auth: self::signedInToClaude());
        $this->type('/model claude-test');
        $this->type(self::ENTER);

        $this->assertSame(1, substr_count($this->screenText(), 'Anthropic subscription auth is active'), 'at startup, and not again on a switch');
    }

    public function testTheSubscriptionWarningCanBeTurnedOff(): void
    {
        $this->start(auth: self::signedInToClaude(), settings: Settings::inMemory(['warnings' => ['anthropicExtraUsage' => false]]));

        $this->assertStringNotContainsString('Anthropic subscription auth is active', $this->screenText());
    }

    public function testTurningOffAutoCompactIsRemembered(): void
    {
        $this->start();
        $this->openSettings();

        // Down to Auto-compact. No thinking row: the test model does not reason, which is the
        // case the row is left out for.
        $this->typeUntilRow('Auto-compact');
        $this->type(self::ENTER);

        $this->assertFalse($this->settings->compactionEnabled());
        $this->assertTrue($this->settings->retryEnabled(), 'and not the row below it');
    }

    public function testHidingThinkingFromTheScreenReachesTheTranscriptToo(): void
    {
        $this->start();
        $this->openSettings();

        $this->type(self::DOWN);
        $this->type(self::ENTER);

        // The reason ctrl+t and this row go through the same method: writing the setting
        // without telling the components already on screen is a toggle that half works.
        $this->assertTrue($this->settings->hideThinking());
    }

    public function testTurningPicturesOffIsRememberedAndReachesTheTranscript(): void
    {
        $this->start();
        $this->openSettings();

        $this->type(self::DOWN);
        $this->type(self::DOWN);
        $this->type(self::ENTER);

        $this->assertFalse($this->settings->showImages());
    }

    public function testChangingHowSteeringMessagesAreHandedOverIsRemembered(): void
    {
        $this->start();
        $this->openSettings();
        $this->typeUntilRow('Steering mode');
        $this->type(self::ENTER);

        // Both halves, which is the whole point of the pair: the agent is told so this run
        // behaves, and the file is written so the next one does — and only this queue's.
        $this->assertSame(QueueMode::All, $this->session->steeringMode());
        $this->assertSame(QueueMode::All, $this->settings->steeringMode());
        $this->assertSame(QueueMode::OneAtATime, $this->session->followUpMode());
    }

    public function testChangingHowFollowUpsAreHandedOverIsRemembered(): void
    {
        $this->start();
        $this->openSettings();
        $this->typeUntilRow('Follow-up mode');
        $this->type(self::ENTER);

        $this->assertSame(QueueMode::All, $this->session->followUpMode());
        $this->assertSame(QueueMode::All, $this->settings->followUpMode());
        $this->assertSame(QueueMode::OneAtATime, $this->session->steeringMode());
    }

    public function testTheQueueModesChosenLastTimeAreWhatTheAgentStartsOn(): void
    {
        $this->start(settings: Settings::inMemory(['steeringMode' => 'all', 'followUpMode' => 'all']));

        // Read out of the settings and into the agent at construction — a row that only took
        // effect for the session it was changed in would be a setting in name only.
        $this->assertSame(QueueMode::All, $this->session->steeringMode());
        $this->assertSame(QueueMode::All, $this->session->followUpMode());
    }

    public function testAModelThatCannotThinkIsNotOfferedAThinkingRow(): void
    {
        $this->start();

        $this->openSettings();
        $this->assertStringNotContainsString('Thinking  ', $this->screen(), 'the row, not the blocks one');

        $this->type(self::ESCAPE);
    }

    public function testAThinkingModelGetsARowThatOpensTheLevels(): void
    {
        $this->start(reasoning: true);
        $this->openSettings();

        $this->type(self::DOWN);
        $this->type(self::ENTER);

        $screen = $this->screen();

        // A submenu rather than a cycle: six levels, each of which needs saying.
        $this->assertStringContainsString('Moderate reasoning', $screen);
        $this->assertStringContainsString('Esc to go back', $screen);
    }

    public function testChoosingALevelSetsItOnTheSessionAndRemembersIt(): void
    {
        $this->start(reasoning: true);
        $this->openSettings();

        $this->type(self::DOWN);
        $this->type(self::ENTER);
        // `off` is selected, being the level the session starts on; one down is `minimal`.
        $this->type(self::DOWN);
        $this->type(self::ENTER);

        $this->assertSame(ThinkingLevel::Minimal, $this->session->thinkingLevel());
        $this->assertSame(ThinkingLevel::Minimal, $this->settings->defaultThinkingLevel());
        $this->assertStringContainsString('minimal', $this->screen(), 'and the row says so');
    }

    public function testATurnEndingDoesNotEraseAnOpenScreenFromUnderTheCursor(): void
    {
        $this->start(['done']);
        $held = $this->holdTheAgent();

        $this->type('hello');
        $this->type(self::ENTER);
        $this->settle();

        // Opened while the agent is working, which `/settings` allows on purpose — the two
        // pickers that refuse are the ones that would change the conversation underneath it.
        $this->openSettings();
        $this->settle();
        $this->assertStringContainsString('esc when done', $this->screen());

        $held();
        $this->settle();

        // The bug: `onEnd()` cleared the container the picker was in, so the screen went
        // away **with the focus still on it** — and the next keystroke went to an invisible
        // list. Somebody typing what they thought was a message was changing settings, one
        // row at a time, with nothing on screen to say so.
        $this->assertStringContainsString('esc when done', $this->screen(), 'still on screen');
        $this->assertStringContainsString('held', $this->screen(), 'and the answer arrived too');
    }

    public function testAWorkingLoaderAndAnOpenScreenBothFitOnTheScreen(): void
    {
        $this->start(['done']);
        $held = $this->holdTheAgent();

        $this->type('hello');
        $this->type(self::ENTER);
        $this->settle();
        $this->openSettings();
        $this->settle();

        $screen = $this->screen();

        // Which is the honest answer: both are true at once, so both are drawn. Sharing one
        // container meant whichever wrote last was the only one you could see.
        $this->assertStringContainsString('Working', $screen);
        $this->assertStringContainsString('HTTP idle timeout', $screen);

        $held();
        $this->settle();
    }

    public function testTheWorkingLoaderIsDrawnInsideThePromptsBorderAsUpstreamDrawsIt(): void
    {
        $this->start(['done']);
        $held = $this->holdTheAgent();

        $this->type('hello');
        $this->type(self::ENTER);
        $this->settle();

        // Upstream's `embedWorkingStatus`: the spinner is worked into the rule above the
        // prompt (`── ⠋ Working ───`) rather than drawn on a line of its own above it, so a turn
        // starting and ending does not grow and shrink the frame by two rows every time.
        $lines = explode("\n", $this->screen());
        $border = array_values(array_filter($lines, static fn (string $line): bool => str_contains($line, 'Working')));

        $this->assertCount(1, $border, 'the loader is on exactly one line');
        $this->assertMatchesRegularExpression('/^\x{2500}\x{2500} \S Working(?: · \d+s)? \x{2500}+$/u', $border[0]);

        // And that line *is* the prompt's top rule: the editor row sits right under it and the
        // bottom rule under that, where a loader of its own would have put a blank and a rule
        // between itself and the prompt.
        $at = array_search($border[0], $lines, true);
        $this->assertMatchesRegularExpression('/^\x{2500}+$/u', $lines[$at + 2], 'the bottom rule is two rows down');

        $held();
        $this->settle();

        $this->assertStringNotContainsString('Working', $this->screen());
    }

    public function testTheWorkingLoaderBorderMatchesTheThinkingLevelBorderColor(): void
    {
        // A model that reasons: on one that does not, `setThinkingLevel()` clamps medium to off.
        $this->start(['done'], reasoning: true);
        $this->session->setThinkingLevel(ThinkingLevel::Medium);
        $held = $this->holdTheAgent();

        $this->type('hello');
        $this->type(self::ENTER);
        $this->settle();

        // The top border with working status and bottom border both carry the thinkingMedium color.
        $raw = $this->terminal->output();
        $this->assertStringContainsString("[38;2;97;133;204m", $raw);

        $held();
        $this->settle();
    }

    public function testEscapeClosesTheScreenAndGivesTheEditorBackTheKeys(): void
    {
        $this->start();
        $this->openSettings();

        $this->type(self::ESCAPE);

        $this->assertStringNotContainsString('esc when done', $this->screen());

        // Which is the part worth asserting: a screen that closes without moving the focus
        // leaves a terminal where typing does nothing.
        $this->type('hello');
        $this->assertStringContainsString('hello', $this->screen());
    }

    // ---- a throw out of a loop callback ---------------------------------------------------

    public function testAThrowFromInsideTheLoopIsDrawnRatherThanEndingTheSession(): void
    {
        // The other end of `Loop::setErrorHandler()`, and the reason it exists: five entries in
        // the traps begin "runs inside the loop's own input callback, so there is nothing above
        // it to catch", and each one is a small thing that took the whole session. `Loop`
        // rethrows unless an application says otherwise; `start()` is what says otherwise.
        $this->start();

        Loop::get()->defer(static fn () => throw new RuntimeException('a component could not draw'));

        self::turnTheLoop(5);

        $this->assertStringContainsString('Error: a component could not draw', $this->screen());

        // And the session is still usable, which is the whole point of not crashing.
        $this->type('h');
        $this->type('i');
        $this->assertStringContainsString('hi', $this->screen());
    }

    public function testTheSameFailureEveryTickSaysSoOnceAndNotEveryTime(): void
    {
        // A `render()` that throws throws again next tick, so reporting every one fills the
        // transcript with the same line and scrolls away the thing it is trying to say — the
        // same rule `ToolExecutionComponent`'s renderer fallback follows per call.
        $this->start();

        foreach (range(1, 4) as $ignored) {
            Loop::get()->defer(static fn () => throw new RuntimeException('the same thing twice'));
        }

        self::turnTheLoop(5);

        $this->assertSame(1, substr_count($this->screen(), 'the same thing twice'));
    }

    public function testSlashWebShowsUrlAndDaemonHint(): void
    {
        $this->start();
        $this->type('/web 28210');
        $this->type(self::ENTER);
        self::turnTheLoop(2);

        $this->assertStringContainsString('Web UI started at', $this->screen());
        $this->assertStringContainsString('To keep it running in background', $this->screenText());

        $this->type('/web stop');
        $this->type(self::ENTER);
        self::turnTheLoop(2);
        $this->assertStringContainsString('Web UI server stopped.', $this->screen());
    }

    /** Upstream #11592: the redraw used to cover the failure, so Ctrl+G seemed to do nothing. */
    public function testAnExternalEditorThatCannotBeStartedIsReported(): void
    {
        $this->start();
        $this->settings->setExternalEditor('pig-external-editor-does-not-exist');
        $this->type('draft');
        $this->type("\x07");
        $this->settle();

        $this->assertStringContainsString('Failed to launch external editor: pig-external-editor-does-not-exist', $this->screen());
        $this->assertSame('draft', $this->editorText());
    }

    public function testExternalEditorCommandResolution(): void
    {
        $this->start();
        $ref = new \ReflectionMethod($this->mode, 'resolveExternalEditorCommand');

        // 1. settings.externalEditor takes highest precedence
        $this->settings->setExternalEditor('code --wait');
        putenv('VISUAL=nano');
        putenv('EDITOR=vi');
        $this->assertSame('code --wait', $ref->invoke($this->mode));

        // 2. $VISUAL takes second precedence
        $this->settings->setExternalEditor(null);
        putenv('VISUAL=vim');
        putenv('EDITOR=nano');
        $this->assertSame('vim', $ref->invoke($this->mode));

        // 3. $EDITOR takes third precedence
        putenv('VISUAL');
        putenv('EDITOR=nvim');
        $this->assertSame('nvim', $ref->invoke($this->mode));

        // 4. Default fallback when unconfigured
        putenv('VISUAL');
        putenv('EDITOR');
        $fallback = $ref->invoke($this->mode);
        $this->assertIsString($fallback);
        $this->assertTrue(in_array($fallback, ['notepad', 'nano', 'vim', 'vi'], true));
    }

    public function testFullscreenViewportPinsDockAndShowsJumpToBottomIndicatorWhenScrolledUp(): void
    {
        $this->start(array_fill(0, 10, "an answer with several lines of output\nsecond line\nthird line"), tuiMode: 'fullscreen');
        $tui = $this->mode->screen();
        $this->assertInstanceOf(TuiAltScreen::class, $tui);
        // The frame actually written, not the document: the pill is composited onto it.
        $frame = static fn (): string => implode("\n", array_map(Ansi::strip(...), $tui->getScreenLines()));

        for ($i = 1; $i <= 8; $i++) {
            $this->type("user question {$i}");
            $this->type(self::ENTER);
            $this->settle();
        }

        // PageUp — upstream's `tui.altScreen.pageUp`.
        $this->type("\x1b[5~");
        $this->settle();
        $this->assertStringContainsString('Jump to latest message · Ctrl+End', $frame());

        // A click on the pill jumps back to the end.
        $row = null;
        $column = null;
        foreach ($tui->getScreenLines() as $index => $line) {
            $at = mb_strpos(Ansi::strip($line), 'Jump to latest');
            if ($at !== false) {
                [$row, $column] = [$index, $at];
            }
        }
        $this->assertNotNull($row);
        $this->type("\x1b[<0;" . ($column + 2) . ';' . ($row + 1) . 'M');
        $this->settle();
        $this->assertStringNotContainsString('Jump to latest message', $frame());

        // Ctrl+End — upstream's `tui.altScreen.bottom`.
        $this->type("\x1b[5~");
        $this->settle();
        $this->assertStringContainsString('Jump to latest message', $frame());
        $this->type("\x1b[1;5F");
        $this->settle();
        $this->assertStringNotContainsString('Jump to latest message', $frame());

        // A trackpad gesture arrives as several wheel reports in one read.
        $this->type("\x1b[<64;40;10M\x1b[<64;40;10M\x1b[<64;40;10M");
        $this->settle();
        $this->assertStringContainsString('Jump to latest message', $frame());
        $this->type("\x1b[<65;40;10M\x1b[<65;40;10M\x1b[<65;40;10M\x1b[<65;40;10M\x1b[<65;40;10M");
        $this->settle();
        $this->assertStringNotContainsString('Jump to latest message', $frame());

        // The editor and footer stay on the last rows whatever the transcript does.
        $lines = $tui->getScreenLines();
        $this->assertSame(24, count($lines));
    }

    public function testSwitchingTuiModeMovesTheSameTreeAndListenersToTheNewRenderer(): void
    {
        // Upstream's `switchTuiMode()`: the transcript, the focus and an extension's terminal
        // listener all carry over, and what components hold keeps working.
        $this->start(['first answer'], tuiMode: 'fullscreen');
        $this->assertInstanceOf(TuiAltScreen::class, $this->mode->screen());

        $heard = [];
        $ui = (new \ReflectionProperty($this->mode, 'ui'))->getValue($this->mode);
        $ui->onTerminalInput(static function (string $data) use (&$heard): null {
            $heard[] = $data;

            return null;
        });

        $this->type('hello');
        $this->type(self::ENTER);
        $this->settle();

        $switch = new \ReflectionMethod($this->mode, 'switchTuiMode');
        $this->assertTrue($switch->invoke($this->mode, 'regular'));
        $this->settle();

        $this->assertInstanceOf(\Pig\Tui\TuiMainScreen::class, $this->mode->screen());
        $this->assertStringContainsString('first answer', $this->screen());
        $this->type('x');
        $this->settle();
        $this->assertContains('x', $heard, 'the listener was moved to the new renderer');
        $this->assertStringContainsString('x', $this->screen(), 'the editor still has the focus');

        $this->assertTrue($switch->invoke($this->mode, 'fullscreen'));
        $this->settle();
        $tui = $this->mode->screen();
        $this->assertInstanceOf(TuiAltScreen::class, $tui);
        $this->assertStringContainsString('first answer', implode("\n", array_map(Ansi::strip(...), $tui->getScreenLines())));
    }

    public function testLeavingFullscreenPrintsTheTranscriptThroughARegularRenderer(): void
    {
        $this->start(['an answer to keep'], tuiMode: 'fullscreen');
        $this->type('question');
        $this->type(self::ENTER);
        $this->settle();
        $this->terminal->clearWrites();

        $this->mode->stop();

        $written = $this->terminal->output();
        $this->assertStringContainsString("\x1b[?1049l", $written, 'the alternate screen is left first');
        $this->assertGreaterThan(strpos($written, "\x1b[?1049l"), strpos($written, 'an answer to keep'), 'then the transcript is drawn on the normal screen');
    }

    public function testResumeHintExitLeavesOnlyTheNormalScreen(): void
    {
        $this->start(['an answer not to print'], settings: Settings::inMemory(['fullscreenExitOutput' => 'resume-hint']), tuiMode: 'fullscreen');
        $this->type('question');
        $this->type(self::ENTER);
        $this->settle();
        $this->terminal->clearWrites();

        $this->mode->stop();

        $written = $this->terminal->output();
        $this->assertStringContainsString("\x1b[?1049l", $written);
        $this->assertStringNotContainsString('an answer not to print', $written);
    }

    public function testAClickInTheFullscreenPromptMovesTheCursorThere(): void
    {
        // Upstream's custom editor is an `Editor` and inherits its `handleMouse()`; pig's wraps
        // one and forwards. Press and release on one cell is the click that places the cursor.
        $this->start(tuiMode: 'fullscreen');
        $tui = $this->mode->screen();
        $this->assertInstanceOf(TuiAltScreen::class, $tui);
        $this->type('hello');
        $this->settle();

        $row = null;
        $column = null;
        foreach ($tui->getScreenLines() as $index => $line) {
            $at = mb_strpos(Ansi::strip($line), 'hello');
            if ($at !== false) {
                [$row, $column] = [$index, $at];
            }
        }
        $this->assertNotNull($row, 'the prompt is on screen');
        $sgr = ';' . ($column + 2) . ';' . ($row + 1);
        $this->type("\x1b[<0{$sgr}M\x1b[<0{$sgr}m");
        $this->settle();
        $this->type('X');
        $this->settle();

        $this->assertSame('hXello', $this->editorText());
    }

    // ---- /scoped-models, /export .jsonl, /import, /share --------------------------------------

    public function testScopedModelsNarrowsCtrlPAndSavesOnlyWhenAsked(): void
    {
        $auth = Auth::inMemory();
        $auth->setRuntimeApiKey('anthropic', 'for-this-run');
        $this->start(auth: $auth);

        $this->type('/scoped-models');
        $this->type(self::ENTER);
        $this->assertStringContainsString('Model Configuration', $this->screen());
        $this->assertStringContainsString('all enabled', $this->screenText());

        $this->type("\x18"); // ctrl+x: app.models.clearAll
        $this->type('claude-haiku-4-5');
        $this->type(self::ENTER); // toggles the top match on

        $this->assertSame(['anthropic/claude-haiku-4-5'], array_map(
            static fn (\Pig\CodingAgent\ModelChoice $c): string => "{$c->model->provider}/{$c->model->id}",
            $this->session->modelScope(),
        ));
        $this->assertStringContainsString('(unsaved)', $this->screenText());
        $this->assertNull($this->settings->enabledModels(), 'session-only until saved');

        $this->type("\x13"); // ctrl+s: app.models.save
        $this->assertSame(['anthropic/claude-haiku-4-5'], $this->settings->enabledModels());

        $this->type(self::ESC);
        $this->settle();
        $this->assertStringContainsString('Model selection saved to settings', $this->screenText());
        $this->assertStringNotContainsString('Model Configuration', $this->screen());
    }

    public function testScopedModelsAndModelRefreshTheCatalogsWhileOpen(): void
    {
        // Upstream's `refreshModelCatalogs()` from both selectors: a status line while it runs,
        // then the outcome — here no provider has a catalog to fetch, so it is quickly done.
        $auth = Auth::inMemory();
        $auth->setRuntimeApiKey('anthropic', 'for-this-run');
        $this->start(auth: $auth);

        $this->type('/scoped-models');
        $this->type(self::ENTER);
        $this->assertStringContainsString('Refreshing model catalogs…', $this->screenText());
        $this->settle();
        $this->assertStringContainsString('Model catalogs refreshed.', $this->screenText());
        $this->assertStringContainsString('all enabled', $this->screenText());
        $this->type(self::ESC);
        $this->settle();

        $this->type('/model');
        $this->type(self::ENTER);
        $this->assertStringContainsString('Refreshing model catalogs…', $this->screenText());
        $this->settle();
        $this->assertStringContainsString('Model catalogs refreshed.', $this->screenText());
        $this->assertStringContainsString('claude-haiku-4-5', $this->screenText());
    }

    public function testExportToAJsonlPathWritesTheBranchAsASessionFile(): void
    {
        $this->start(['the answer'], store: true);
        $this->type('hello');
        $this->type(self::ENTER);
        $this->settle();

        $this->type('/export "out dir/branch.jsonl"');
        $this->type(self::ENTER);
        $this->settle();

        $path = $this->cwd . '/out dir/branch.jsonl';
        $this->assertFileExists($path);
        $lines = array_map(static fn (string $l): array => json_decode($l, true), file($path, FILE_IGNORE_NEW_LINES) ?: []);
        $this->assertSame('session', $lines[0]['type']);
        $this->assertSame($this->session->store()?->id, $lines[0]['id']);
        $this->assertNull($lines[1]['parentId']);
        $this->assertSame($lines[1]['id'], $lines[2]['parentId'], 're-chained root to leaf');
        $this->assertStringContainsString('Session exported to: ' . $path, $this->screenText());

        // And it opens as a conversation of its own.
        $this->assertCount(2, self::said(SessionManager::open($path)->messages()));
    }

    /** pig's own `/discard`: asked, then quit, then the file is gone and there is nothing to resume. */
    public function testDiscardAsksThenQuitsAndThrowsTheSessionFileAway(): void
    {
        $this->start(['the answer'], store: true);
        $this->type('a passing question');
        $this->type(self::ENTER);
        $this->settle();
        $path = (string) $this->session->store()?->path;
        $this->assertFileExists($path);

        // No is no: the session stays, and so does pig.
        $this->type('/discard');
        $this->type(self::ENTER);
        $this->settle();
        $this->assertStringContainsString('Discard this session?', $this->screenText());
        $this->type(self::DOWN);
        $this->type(self::ENTER);
        $this->settle();
        $this->assertStringContainsString('Discard cancelled', $this->screenText());
        $this->assertFileExists($path);

        $this->type('/discard');
        $this->type(self::ENTER);
        $this->settle();
        $this->type(self::ENTER); // Yes
        $this->settle();

        $this->assertFileDoesNotExist($path);
        $this->assertNull($this->mode->resumeCommand(), 'no "To resume this session" line for a file that is gone');
    }

    public function testDiscardWithNothingOnDiskIsQuit(): void
    {
        $this->start();
        $this->type('/discard');
        $this->type(self::ENTER);
        $this->settle();

        $this->assertStringNotContainsString('Discard this session?', $this->screenText());
        $this->assertNull($this->mode->resumeCommand());
    }

    public function testIncognitoAsksThenTrashesTheFileAndCarriesOnUnsaved(): void
    {
        $this->start(['the first answer', 'the second answer'], store: true);
        $this->type('a question');
        $this->type(self::ENTER);
        $this->settle();
        $path = (string) $this->session->store()?->path;
        $id = $this->session->sessionId();
        $this->assertFileExists($path);
        $this->assertStringNotContainsString(FooterComponent::INCOGNITO_LABEL, $this->screenText());

        $this->type('/incognito');
        $this->type(self::ENTER);
        $this->settle();
        $this->assertStringContainsString('Make this session private?', $this->screenText());
        $this->type(self::ENTER); // Yes
        $this->settle();

        $this->assertFileDoesNotExist($path);
        $this->assertTrue($this->session->isIncognito());
        $this->assertNull($this->session->store());
        // The same id, so the provider's prompt cache still recognises the conversation.
        $this->assertSame($id, $this->session->sessionId());
        $screen = $this->screenText();
        $this->assertStringContainsString(FooterComponent::INCOGNITO_LABEL, $screen, 'the footer says so');
        $this->assertStringContainsString('still goes to the model provider (anthropic)', $screen);

        // The conversation carries on, and nothing is written for it.
        $this->type('and another');
        $this->type(self::ENTER);
        $this->settle();
        $this->assertStringContainsString('the second answer', $this->screenText());
        $this->assertFileDoesNotExist($path);
        $this->assertSame([], glob(dirname($path) . '/*.jsonl') ?: []);
        $this->assertNull($this->mode->resumeCommand());

        $this->type('/incognito');
        $this->type(self::ENTER);
        $this->settle();
        $this->assertStringContainsString('This session is already private', $this->screenText());
    }

    public function testIncognitoWithNothingSavedAsksNothing(): void
    {
        $this->start();
        $this->type('/incognito');
        $this->type(self::ENTER);
        $this->settle();

        $this->assertStringNotContainsString('Make this session private?', $this->screenText());
        $this->assertTrue($this->session->isIncognito());
        $this->assertStringContainsString('Incognito — nothing about this session is saved', $this->screenText());
    }

    public function testAPrivateSessionSaysSoFromTheStart(): void
    {
        $this->start(incognito: true);

        $screen = $this->screenText();
        $this->assertStringContainsString(FooterComponent::INCOGNITO_LABEL, $screen);
        $this->assertStringContainsString('Incognito — nothing about this session is saved', $screen);

        // `/discard` has nothing to throw away: it is `/quit`.
        $this->type('/discard');
        $this->type(self::ENTER);
        $this->settle();
        $this->assertStringNotContainsString('Discard this session?', $this->screenText());
    }

    public function testImportAsksThenResumesACopyInThisProject(): void
    {
        $this->start(['the answer'], store: true);
        $this->type('imported question');
        $this->type(self::ENTER);
        $this->settle();
        $source = $this->cwd . '/elsewhere.jsonl';
        file_put_contents($source, (string) $this->session->store()?->serializeBranch());
        $this->mode->stop();

        $this->start(store: true);
        $this->type('/import');
        $this->type(self::ENTER);
        $this->settle();
        $this->assertStringContainsString('Usage: /import <path.jsonl>', $this->screenText());

        $this->type('/import ' . $source);
        $this->type(self::ENTER);
        $this->settle();
        $this->assertStringContainsString('Replace current session with', $this->screenText());
        $this->type(self::ENTER); // Yes
        $this->settle();

        $this->assertStringContainsString('Session imported from: ' . $source, $this->screenText());
        $this->assertStringContainsString('imported question', $this->screenText());
        $copy = (string) $this->session->store()?->path;
        $this->assertSame(SessionManager::directory($this->cwd) . '/elsewhere.jsonl', $copy);
        $this->assertFileExists($source, 'the original is left alone');
    }

    public function testImportingAnotherProjectsSessionCarriesOnInItsDirectory(): void
    {
        // Upstream's `importFromJsonl()` → `createRuntime({ cwd: sessionManager.getCwd() })`: the
        // runtime factory builds a session for the directory the file names, and the screen
        // carries on with it — the footer names that directory now.
        $other = $this->cwd . '/other-project';
        mkdir($other);
        $file = SessionManager::create($other);
        $file->append(new UserMessage('asked over there'));
        $file->append(new AssistantMessage([new TextContent('answered over there')], Api::AnthropicMessages, 'anthropic', 'claude-test', new Usage(), StopReason::Stop));
        $source = $this->cwd . '/other.jsonl';
        copy($file->path, $source);
        $asked = [];

        $createRuntime = function (string $cwd, SessionManager $opened, ?Closure $askTrust) use (&$asked): \Pig\CodingAgent\StartedSession {
            $asked[] = $cwd;
            $agent = new Agent(new AgentOptions(streamFn: $this->provider(...), apiKey: 'k'));
            $agent->setModel($this->session->model());
            $extensionRunner = new ExtensionRunner([], $cwd, $opened);
            $session = new AgentSession($agent, $cwd, $opened, $this->settings, $extensionRunner);
            $session->restore($opened->messages());

            return new \Pig\CodingAgent\StartedSession($session, $agent->state->model, $session->thinkingLevel(), [], [], [], $extensionRunner, new CustomToolSet(), $opened, ['a warning from over there'], true);
        };

        $this->start(store: true, createRuntime: $createRuntime);
        $this->type('/import ' . $source);
        $this->type(self::ENTER);
        $this->settle();
        $this->type(self::ENTER); // Yes
        $this->settle();

        $screen = $this->screenText();
        $this->assertSame([$other], $asked);
        $this->assertStringContainsString('answered over there', $screen);
        $this->assertStringContainsString('a warning from over there', $screen);
        $this->assertStringContainsString('other-project', $screen);
        $this->assertStringContainsString('Session imported from: ' . $source, $screen);
    }

    public function testShareMakesASecretGistAndAnswersTheViewerUrl(): void
    {
        // A `gh` of this test's own, first on PATH: it says it is signed in, and answers
        // `gist create` with a URL after checking it was asked for a secret one.
        $bin = $this->cwd . '/bin';
        mkdir($bin);
        file_put_contents("{$bin}/gh", "#!/bin/sh\n"
            . "if [ \"$1\" = auth ]; then exit 0; fi\n"
            . "if [ \"$1 $2 $3\" = 'gist create --public=false' ] && [ -f \"$4\" ]; then echo https://gist.github.com/someone/abc123; exit 0; fi\n"
            . "echo \"unexpected: $*\" >&2; exit 1\n");
        chmod("{$bin}/gh", 0o755);
        $path = (string) getenv('PATH');
        putenv("PATH={$bin}:{$path}");
        putenv('PIG_SHARE_VIEWER_URL=https://viewer.test/s/');

        try {
            $this->start(['the answer'], store: true);
            $this->type('hello');
            $this->type(self::ENTER);
            $this->settle();

            $this->type('/share');
            $this->type(self::ENTER);
            $this->settle();

            $this->assertStringContainsString('Share URL: https://viewer.test/s/#abc123', $this->screenText());
            $this->assertStringContainsString('Gist: https://gist.github.com/someone/abc123', $this->screenText());
        } finally {
            putenv("PATH={$path}");
            putenv('PIG_SHARE_VIEWER_URL');
        }
    }

    public function testShareToRadiusWithoutASignInSaysHowToGetOne(): void
    {
        // Upstream's `sessionShareDestination: "radius"`: no gist to fall back on.
        $this->start(['the answer'], store: true, settings: Settings::inMemory(['sessionShareDestination' => 'radius']));
        $this->type('/share');
        $this->type(self::ENTER);
        $this->settle();

        $this->assertStringContainsString("Radius authentication is not configured. Run '/login radius' first.", $this->screenText());
    }

    public function testShareWithoutGhSaysWhereToGetIt(): void
    {
        $path = (string) getenv('PATH');
        putenv('PATH=' . $this->cwd);

        try {
            $this->start(['the answer'], store: true);
            $this->type('/share');
            $this->type(self::ENTER);
            $this->settle();

            $this->assertStringContainsString('GitHub CLI (gh) is not installed', $this->screenText());
        } finally {
            putenv("PATH={$path}");
        }
    }

    public function testQuitIsTheListedNameAsUpstreamsIs(): void
    {
        // `/exit` still quits (see the test that types it); `/quit` is the one the menu offers.
        $this->start();
        $this->type('/');
        $this->type('qui');
        $this->assertStringContainsString('Quit pig', $this->screen());
    }

    /**
     * The messages that were said: the transcript without its system messages, which carry the
     * prompt and the tool declarations (the first prompt declares this agent's tools in one).
     *
     * @param list<mixed> $messages
     * @return list<mixed>
     */
    private static function said(array $messages): array
    {
        return array_values(array_filter($messages, static fn (mixed $message): bool => !$message instanceof \Pig\Ai\SystemMessage));
    }
}
